import { useMemo } from 'react';
import { useNavigate, useSearchParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { Download, Plus } from 'lucide-react';
import { toast } from 'sonner';

import { api, apiDownload } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { inrShort, formatDate, formatRate } from '@/lib/format';
import type {
  FdrListItem,
  PaginatedResponse,
  MetaResponse,
  InstitutionItem,
} from '@/lib/types';

import { PageHeader } from '@/components/shared/PageHeader';
import { DataTable, type Column } from '@/components/shared/DataTable';
import { FilterBar } from '@/components/shared/FilterBar';
import { StatusPill } from '@/components/shared/StatusPill';
import { MaturityChip } from '@/components/shared/MaturityChip';
import { Money } from '@/components/shared/Money';
import { HealthBar } from '@/components/shared/HealthBar';
import { ProvenanceBadge } from '@/components/shared/ProvenanceBadge';
import { ErrorState } from '@/components/shared/ErrorState';
import { Button } from '@/components/ui/button';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

export default function DepositsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [searchParams, setSearchParams] = useSearchParams();

  // Parse filters from URL
  const q = searchParams.get('q') || '';
  const status = searchParams.get('status') || '';
  const bank = searchParams.get('bank') || '';
  const institutionId = searchParams.get('institution_id') || '';
  const windowParam = searchParams.get('window') || '';
  const verification = searchParams.get('verification') || '';
  const sort = searchParams.get('sort') || 'maturity_date';
  const order = (searchParams.get('order') as 'asc' | 'desc') || 'asc';
  const page = parseInt(searchParams.get('page') || '1', 10);
  const pageSize = 15;

  // Metadata for filter dropdowns
  const { data: meta } = useQuery<MetaResponse>({
    queryKey: queryKeys.meta,
    queryFn: () => api.get<MetaResponse>('/meta'),
    staleTime: 5 * 60 * 1000,
  });

  // Institutions list for filter dropdown
  const { data: institutions } = useQuery<InstitutionItem[]>({
    queryKey: queryKeys.institutions.all,
    queryFn: () => api.get<InstitutionItem[]>('/institutions'),
    staleTime: 5 * 60 * 1000,
  });

  // Query FDR register
  const queryParams = useMemo(() => {
    const params: Record<string, string> = {
      page: page.toString(),
      page_size: pageSize.toString(),
      sort,
      order,
    };
    if (q) params.q = q;
    if (status) params.status = status;
    if (bank) params.bank = bank;
    if (institutionId) params.institution_id = institutionId;
    if (windowParam) params.window = windowParam;
    if (verification) params.verification = verification;
    return params;
  }, [q, status, bank, institutionId, windowParam, verification, sort, order, page, pageSize]);

  const {
    data: fdrData,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery<PaginatedResponse<FdrListItem>>({
    queryKey: queryKeys.fdrs.list(queryParams),
    queryFn: () => {
      const sp = new URLSearchParams(queryParams);
      return api.get<PaginatedResponse<FdrListItem>>(`/fdrs?${sp.toString()}`);
    },
    staleTime: 30000,
  });

  // URL search params helper
  const updateFilter = (key: string, val: string | null) => {
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      if (val && val !== 'ALL') {
        next.set(key, val);
      } else {
        next.delete(key);
      }
      // reset to page 1 on filter changes
      if (key !== 'page') {
        next.set('page', '1');
      }
      return next;
    });
  };

  const handleResetFilters = () => {
    setSearchParams(new URLSearchParams());
  };

  const hasActiveFilters = Boolean(
    q || status || bank || institutionId || windowParam || verification
  );

  // Sorting handler
  const handleSort = (colKey: string) => {
    const newOrder = sort === colKey && order === 'asc' ? 'desc' : 'asc';
    setSearchParams((prev) => {
      const next = new URLSearchParams(prev);
      next.set('sort', colKey);
      next.set('order', newOrder);
      return next;
    });
  };

  // Export CSV with current filters
  const handleExportCsv = async () => {
    try {
      const sp = new URLSearchParams(queryParams);
      sp.delete('page');
      sp.delete('page_size');
      await apiDownload(`/fdrs/export.csv?${sp.toString()}`, 'fdr_deposits_register.csv');
      toast.success('Deposits register exported to CSV');
    } catch {
      toast.error('Failed to export CSV file');
    }
  };

  // Total filtered count and total amount across all matching rows
  const totalCount = fdrData?.total ?? 0;
  const totalAmount = fdrData?.total_amount ?? 0;

  // Table Columns
  const columns: Column<FdrListItem>[] = [
    {
      key: 'fdr_number',
      header: 'FDR Number',
      sortable: true,
      cell: (item) => (
        <span className="font-mono font-medium text-[var(--primary)] hover:underline whitespace-nowrap">
          {item.fdr_number}
        </span>
      ),
    },
    {
      key: 'institution_name',
      header: 'Institution',
      cell: (item) => (
        <div className="max-w-[150px] xl:max-w-[170px] 2xl:max-w-[220px]">
          <span className="font-medium text-[var(--ink)] truncate block" title={item.institution_name}>
            {item.institution_name}
          </span>
        </div>
      ),
    },
    {
      key: 'bank_name',
      header: 'Bank',
      cell: (item) => (
        <span className="text-[var(--ink-2)] truncate max-w-[85px] xl:max-w-[95px] 2xl:max-w-[110px] block" title={item.bank_name}>
          {item.bank_name}
        </span>
      ),
    },
    {
      key: 'amount',
      header: 'Principal',
      sortable: true,
      align: 'right',
      cell: (item) => <Money amount={item.amount} className="whitespace-nowrap" />,
    },
    {
      key: 'interest_rate',
      header: 'Rate',
      align: 'right',
      cell: (item) => (
        <span className="font-mono text-xs whitespace-nowrap">{formatRate(item.interest_rate)}</span>
      ),
    },
    {
      key: 'maturity_date',
      header: 'Maturity Date',
      sortable: true,
      cell: (item) => (
        <div className="flex items-center gap-1.5 whitespace-nowrap">
          <span>{formatDate(item.maturity_date)}</span>
          <MaturityChip days={item.days_to_maturity} state={item.maturity_state} />
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (item) => <StatusPill status={item.status} className="whitespace-nowrap" />,
    },
    {
      key: 'verification',
      header: 'Provenance',
      cell: (item) => <ProvenanceBadge verification={item.verification} />,
    },
    {
      key: 'health_score',
      header: 'Health',
      sortable: true,
      align: 'center',
      cell: (item) => <HealthBar score={item.health_score} size="sm" />,
    },
  ];

  if (isError) {
    return (
      <div className="space-y-4">
        <PageHeader
          title="Deposits Register"
          description="Search, monitor, and audit institutional fixed deposit receipts and compliance status"
        />
        <ErrorState error={error} onRetry={() => refetch()} />
      </div>
    );
  }

  return (
    <div className="space-y-4">
      {/* Page Header */}
      <PageHeader
        title="Deposits Register"
        description="Search, monitor, and audit institutional fixed deposit receipts and compliance status"
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={handleExportCsv}
              className="text-xs gap-1.5"
            >
              <Download className="h-3.5 w-3.5" />
              <span>Export CSV</span>
            </Button>
            {(user?.role === 'admin' || user?.role === 'institution') && (
              <Button
                size="sm"
                onClick={() => navigate('/deposits/new')}
                className="text-xs gap-1.5"
              >
                <Plus className="h-3.5 w-3.5" />
                <span>New FDR</span>
              </Button>
            )}
          </div>
        }
      />

      {/* Filter and Search Bar */}
      <FilterBar
        searchValue={q}
        onSearchChange={(val) => updateFilter('q', val)}
        searchPlaceholder="Search FDR number, institution or AICTE ID..."
        hasActiveFilters={hasActiveFilters}
        onReset={handleResetFilters}
        context={
          <span className="font-mono text-xs">
            {totalCount} {totalCount === 1 ? 'deposit' : 'deposits'}
            {totalAmount > 0 && ` · ${inrShort(totalAmount)}`}
          </span>
        }
      >
        {/* Status Filter */}
        <Select
          value={status || 'ALL'}
          onValueChange={(val) => updateFilter('status', val)}
        >
          <SelectTrigger className="w-[140px] text-xs h-8">
            <SelectValue placeholder="All Statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Statuses</SelectItem>
            <SelectItem value="draft">Draft</SelectItem>
            <SelectItem value="pending_approval">Pending approval</SelectItem>
            <SelectItem value="approved">Approved</SelectItem>
            <SelectItem value="rejected">Rejected</SelectItem>
            <SelectItem value="release_requested">Release requested</SelectItem>
            <SelectItem value="released">Released</SelectItem>
            <SelectItem value="renewed">Renewed</SelectItem>
          </SelectContent>
        </Select>

        {/* Maturity Window Filter */}
        <Select
          value={windowParam || 'ALL'}
          onValueChange={(val) => updateFilter('window', val)}
        >
          <SelectTrigger className="w-[145px] text-xs h-8">
            <SelectValue placeholder="All Windows" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Windows</SelectItem>
            <SelectItem value="due_7">Due in 7 days</SelectItem>
            <SelectItem value="due_30">Due in 30 days</SelectItem>
            <SelectItem value="due_60">Due in 60 days</SelectItem>
            <SelectItem value="due_90">Due in 90 days</SelectItem>
            <SelectItem value="matured">Matured overdue</SelectItem>
          </SelectContent>
        </Select>

        {/* Bank Filter */}
        <Select
          value={bank || 'ALL'}
          onValueChange={(val) => updateFilter('bank', val)}
        >
          <SelectTrigger className="w-[155px] text-xs h-8">
            <SelectValue placeholder="All Banks" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Banks</SelectItem>
            {meta?.banks?.map((b) => (
              <SelectItem key={b} value={b}>
                {b}
              </SelectItem>
            ))}
          </SelectContent>
        </Select>

        {/* Institution Filter (Bureau officers only) */}
        {user?.role !== 'institution' && (
          <Select
            value={institutionId || 'ALL'}
            onValueChange={(val) => updateFilter('institution_id', val)}
          >
            <SelectTrigger className="w-[170px] text-xs h-8">
              <SelectValue placeholder="All Institutions" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="ALL">All Institutions</SelectItem>
              {institutions?.map((inst) => (
                <SelectItem key={inst.id} value={inst.id.toString()}>
                  {inst.name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
        )}

        {/* Verification Filter */}
        <Select
          value={verification || 'ALL'}
          onValueChange={(val) => updateFilter('verification', val)}
        >
          <SelectTrigger className="w-[145px] text-xs h-8">
            <SelectValue placeholder="All Provenance" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="ALL">All Provenance</SelectItem>
            <SelectItem value="submitted">Submitted</SelectItem>
            <SelectItem value="officer_verified">Officer-verified</SelectItem>
            <SelectItem value="bank_confirmed">Bank-confirmed (letter)</SelectItem>
          </SelectContent>
        </Select>
      </FilterBar>

      {/* Main Data Table */}
      <DataTable
        className="[&_td]:px-1.5 [&_th]:px-1.5"
        columns={columns}
        data={fdrData?.items}
        isLoading={isLoading}
        sortBy={sort}
        sortOrder={order}
        onSort={handleSort}
        page={page}
        pageSize={pageSize}
        total={totalCount}
        onPageChange={(newPage) => updateFilter('page', newPage.toString())}
        onRowClick={(item) =>
          navigate(`/deposits/${item.id}`, { state: { fdrNumber: item.fdr_number } })
        }
        emptyMessage={
          hasActiveFilters
            ? 'No deposits matched the active filter criteria.'
            : 'No deposit receipts found in the bureau database.'
        }
        emptyActionLabel={hasActiveFilters ? 'Reset all filters' : undefined}
        emptyOnAction={hasActiveFilters ? handleResetFilters : undefined}
      />
    </div>
  );
}
