import { useState } from 'react';
import { useQuery } from '@tanstack/react-query';
import { format, parseISO } from 'date-fns';
import { Bar, BarChart, CartesianGrid, ResponsiveContainer, Tooltip, XAxis, YAxis } from 'recharts';
import { toast } from 'sonner';
import { ApiError, api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { formatDate, inr, inrShort } from '@/lib/format';
import type {
  AuditItem,
  BureauMetrics,
  DashboardResponse,
  FdrListItem,
  InstitutionItem,
  PaginatedResponse,
} from '@/lib/types';
import { isInstitution, optionalNumber, ownInstitution, visibleToInstitution } from '@/pages/Approvals/roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { KpiTile } from '@/components/shared/KpiTile';
import { DataTable, type Column } from '@/components/shared/DataTable';
import { Money } from '@/components/shared/Money';
import { MaturityChip } from '@/components/shared/MaturityChip';
import { StatusPill } from '@/components/shared/StatusPill';
import { ErrorState } from '@/components/shared/ErrorState';
import { EmptyState } from '@/components/shared/EmptyState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

const columns: Column<FdrListItem>[] = [
  {
    key: 'fdr_number',
    header: 'FDR number',
    cell: (item) => <span className="font-mono text-[13px]">{item.fdr_number}</span>,
  },
  {
    key: 'institution',
    header: 'Institution',
    cell: (item) => item.institution_name,
  },
  {
    key: 'amount',
    header: 'Amount',
    align: 'right',
    cell: (item) => <Money amount={item.amount} />,
  },
  {
    key: 'maturity',
    header: 'Maturity',
    cell: (item) => formatDate(item.maturity_date),
  },
  {
    key: 'days',
    header: 'Window',
    cell: (item) => <MaturityChip days={item.days_to_maturity} state={item.maturity_state} />,
  },
  {
    key: 'status',
    header: 'Status',
    className: 'whitespace-nowrap',
    cell: (item) => <StatusPill status={item.status} />,
  },
];

function toastError(err: unknown, fallback: string) {
  toast.error(err instanceof ApiError ? err.detail : fallback);
}

const NOT_ENOUGH = 'Not enough data yet';

function oneDecimal(value: number) {
  const digits = Number.isInteger(value) ? 0 : 1;
  return value.toLocaleString('en-IN', { maximumFractionDigits: 1, minimumFractionDigits: digits });
}

function daysText(value: number | null) {
  if (value == null) return null;
  return `${oneDecimal(value)} days`;
}

function rateText(value: number | null) {
  if (value == null) return null;
  return `${value.toLocaleString('en-IN', { minimumFractionDigits: 1, maximumFractionDigits: 1 })}%`;
}

function hoursText(value: number | null) {
  if (value == null) return null;
  return `${oneDecimal(value)} hours`;
}

function monthLabel(month: string) {
  const parsed = parseISO(`${month}-01`);
  return Number.isNaN(parsed.getTime()) ? month : format(parsed, 'MMM yyyy');
}

function MetricFigure({ text }: { text: string | null }) {
  if (text == null) {
    return <span className="font-sans text-[13px] font-normal leading-snug text-[var(--ink-2)]">{NOT_ENOUGH}</span>;
  }
  return <span className="font-mono text-[20px] font-medium tabular-nums text-[var(--ink)]">{text}</span>;
}

const BUREAU_MEANINGS = {
  approval: 'Average days from submission to the decision, last 180 days.',
  release: 'Average days from a release request to the decision, last 180 days.',
  sla: 'Deposits still pending past the review time limit.',
  verification: 'Share of approved and release-requested deposits that are officer-verified or confirmed by a bank letter.',
  documents: 'Open deposits with an FDR receipt on file.',
  renewals: 'Renewals completed on or before the old maturity date.',
  quality: 'Open deposits with no critical finding.',
  alerts: 'Median hours until an alert is acknowledged.',
} as const;

function splitCsv(text: string) {
  const clean = text.replace(/^\uFEFF/, '');
  const lines = clean.split(/\r?\n/).filter((line) => line.trim().length > 0);
  return { header: lines[0] ?? '', rows: lines.slice(1) };
}

function parseCsvLine(line: string) {
  const fields: string[] = [];
  let index = 0;
  while (index <= line.length) {
    if (line[index] === '"') {
      let value = '';
      index += 1;
      while (index < line.length) {
        if (line[index] === '"') {
          if (line[index + 1] === '"') {
            value += '"';
            index += 2;
            continue;
          }
          index += 1;
          break;
        }
        value += line[index];
        index += 1;
      }
      fields.push(value);
      if (line[index] === ',') index += 1;
      else break;
    } else {
      const comma = line.indexOf(',', index);
      const end = comma === -1 ? line.length : comma;
      fields.push(line.slice(index, end));
      index = comma === -1 ? line.length + 1 : comma + 1;
    }
  }
  return fields;
}

function writeCsvLine(fields: string[]) {
  return fields
    .map((value) => {
      const risky =
        /^[=+@\t\r]/.test(value) || (value.startsWith('-') && !/^-?\d+(\.\d+)?$/.test(value));
      const safe = risky ? `'${value}` : value;
      if (/[",\r\n]/.test(safe)) return `"${safe.replace(/"/g, '""')}"`;
      return safe;
    })
    .join(',');
}

function firstField(line: string) {
  if (line.startsWith('"')) {
    const end = line.indexOf('"', 1);
    return end > 1 ? line.slice(1, end) : line;
  }
  return line.split(',')[0] ?? '';
}

async function saveDownload(endpoint: string, filename: string) {
  const blob = await api.download(endpoint);
  const parsed = splitCsv(await blob.text());
  saveCsv(parsed.header, parsed.rows, filename);
}

function saveCsv(header: string, rows: string[], filename: string) {
  const body = `\uFEFF${writeCsvLine(parseCsvLine(header))}\r\n${rows.map((row) => writeCsvLine(parseCsvLine(row))).join('\r\n')}${rows.length ? '\r\n' : ''}`;
  const blob = new Blob([body], { type: 'text/csv;charset=utf-8' });
  const url = URL.createObjectURL(blob);
  const link = document.createElement('a');
  link.href = url;
  link.download = filename;
  document.body.appendChild(link);
  link.click();
  link.remove();
  URL.revokeObjectURL(url);
}

function istYear(iso: string) {
  return Number(
    new Intl.DateTimeFormat('en-GB', { timeZone: 'Asia/Kolkata', year: 'numeric' }).format(new Date(iso))
  );
}

async function loadReleasedNumbers(year: number) {
  const numbers = new Set<string>();
  const pageSize = 200;
  let page = 1;
  let total = 0;
  do {
    const data = await api.get<PaginatedResponse<AuditItem>>(
      `/audit?action=fdr.released&page=${page}&page_size=${pageSize}`
    );
    total = data.total;
    for (const item of data.items) {
      if (item.fdr_number && istYear(item.at) === year) numbers.add(item.fdr_number);
    }
    page += 1;
  } while ((page - 1) * pageSize < total && page <= 15);
  return numbers;
}

export default function ReportsPage() {
  const { user } = useAuth();
  const own = ownInstitution(user);
  const [busy, setBusy] = useState<string | null>(null);
  const dashboard = useQuery({
    queryKey: queryKeys.dashboard,
    queryFn: () => api.get<DashboardResponse>('/dashboard'),
  });
  const maturing = useQuery({
    queryKey: queryKeys.fdrs.list({ window: 'due_90', page_size: 500, report: true }),
    queryFn: () =>
      api.get<PaginatedResponse<FdrListItem>>('/fdrs?window=due_90&page=1&page_size=500&sort=maturity_date&order=asc'),
  });
  const metrics = useQuery({
    queryKey: ['metrics', user?.id ?? null],
    queryFn: () => api.get<BureauMetrics>('/metrics'),
  });
  useRefetchOffline(dashboard.refetch);
  useRefetchOffline(maturing.refetch);
  useRefetchOffline(metrics.refetch);

  const institutionUser = isInstitution(user?.role);
  const year = istYear(new Date().toISOString());
  const performanceTitle = institutionUser ? 'Your deposits' : 'Bureau performance';
  const performanceDetail = institutionUser
    ? 'Last 180 days, for your institution.'
    : 'Last 180 days, from the audit log and the current register.';
  const kpis = dashboard.data?.kpis;
  const maturingRows = (maturing.data?.items ?? []).filter((item) =>
    visibleToInstitution(user, { institution_id: item.institution_id, institution_name: item.institution_name })
  );

  function scoped(path: string) {
    if (own?.id == null) return path;
    const join = path.includes('?') ? '&' : '?';
    return `${path}${join}institution_id=${own.id}`;
  }

  async function run(id: string) {
    setBusy(id);
    try {
      if (id === 'active') {
        await saveDownload(scoped('/fdrs/export.csv?status=approved,release_requested'), 'fdr-active.csv');
        toast.success('Active deposits exported.');
      } else if (id === 'due90') {
        await saveDownload(scoped('/fdrs/export.csv?window=due_90'), 'fdr-maturing-90-days.csv');
        toast.success('Deposits maturing in 90 days exported.');
      } else if (id === 'pending') {
        await saveDownload(scoped('/fdrs/export.csv?status=pending_approval'), 'fdr-pending-approval.csv');
        toast.success('Pending approvals exported.');
      } else if (id === 'released') {
        const numbers = await loadReleasedNumbers(year);
        const blob = await api.download(scoped('/fdrs/export.csv?status=released'));
        const parsed = splitCsv(await blob.text());
        const rows = parsed.rows.filter((line) => numbers.has(firstField(line)));
        saveCsv(parsed.header, rows, `fdr-released-${year}.csv`);
        toast.success(
          rows.length === 1
            ? `1 deposit released in ${year} exported.`
            : `${rows.length} deposits released in ${year} exported.`
        );
      } else if (id === 'shortfall') {
        const institutions = (await api.get<InstitutionItem[]>('/institutions')).filter((item) =>
          own?.id == null ? true : item.id === own.id
        );
        const short = institutions.filter((item) => item.shortfall > 0);
        if (short.length === 0) {
          toast.success('No institution is below its required deposit.');
          return;
        }
        const blobs = await Promise.all(
          short.map((item) =>
            api.download(
              scoped(`/fdrs/export.csv?institution_id=${item.id}&status=pending_approval,approved,release_requested`)
            )
          )
        );
        const texts = await Promise.all(blobs.map((blob) => blob.text()));
        const parsed = texts.map(splitCsv);
        const header = parsed.find((file) => file.header)?.header ?? '';
        const rows = parsed.flatMap((file) => file.rows);
        saveCsv(header, rows, 'fdr-below-required.csv');
        toast.success(
          `${short.length} ${short.length === 1 ? 'institution' : 'institutions'} below the required deposit exported.`
        );
      }
    } catch (err) {
      toastError(err, 'Export failed.');
    } finally {
      setBusy(null);
    }
  }

  const presets = [
    {
      id: 'active',
      title: 'All active',
      detail: 'Approved deposits and those with a release request.',
    },
    {
      id: 'due90',
      title: 'Maturing in 90 days',
      detail: 'Open deposits with maturity inside the next 90 days.',
    },
    {
      id: 'pending',
      title: 'Pending approval',
      detail: 'Deposits submitted and not yet decided.',
    },
    {
      id: 'released',
      title: 'Released this year',
      detail: `Deposits released in ${year}, from the audit log.`,
    },
    {
      id: 'shortfall',
      title: 'Below required deposit',
      detail: 'Held deposits of institutions whose balance is short.',
    },
  ];

  return (
    <div className="flex min-w-0 flex-col gap-4">
      <style>{`
        @page { size: A4 portrait; margin: 10mm; }
        @media print {
          aside, header, .no-print { display: none !important; }
          main { max-width: none !important; padding: 0 !important; }
          #report-print {
            position: absolute;
            left: 0;
            top: 0;
            width: 190mm;
            background: white;
          }
          #report-print h2 { font-size: 16px !important; margin: 0; }
          #report-print h3 { font-size: 13px !important; margin: 6px 0 !important; }
          #report-print .grid { gap: 8px !important; }
          #report-print tr { height: 26px !important; }
          #report-print th, #report-print td { padding: 2px 6px !important; font-size: 10px !important; }
        }
      `}</style>

      <div className="no-print flex flex-col gap-4">
        <PageHeader
          title="Reports"
          description="Download a register, or print the summary."
          actions={
            <Button type="button" onClick={() => window.print()}>
              Print summary
            </Button>
          }
        />
        <ul className="overflow-hidden rounded-[8px] border border-[var(--line)] bg-white">
          {presets
            .filter((preset) => !own || (preset.id !== 'released' && preset.id !== 'shortfall'))
            .map((preset, index) => (
            <li
              key={preset.id}
              className={`flex flex-col gap-3 px-4 py-3 sm:flex-row sm:items-center sm:justify-between ${
                index > 0 ? 'border-t border-[var(--line)]' : ''
              }`}
            >
              <div>
                <p className="text-[14px] font-medium text-[var(--ink)]">{preset.title}</p>
                <p className="text-[12px] text-[var(--ink-3)]">{preset.detail}</p>
              </div>
              <Button
                type="button"
                variant="outline"
                size="sm"
                disabled={busy !== null}
                onClick={() => run(preset.id)}
              >
                {busy === preset.id ? 'Preparing...' : 'Download CSV'}
              </Button>
            </li>
            ))}
        </ul>

        <section className="flex flex-col gap-3">
          <div>
            <h2 className="text-[16px] font-semibold text-[var(--ink)]">{performanceTitle}</h2>
            <p className="text-[12px] text-[var(--ink-3)]">{performanceDetail}</p>
          </div>
          <BureauPanel metrics={metrics} kpis={kpis} />
        </section>
      </div>

      <section id="report-print" className="flex flex-col gap-4">
        <div>
          <h2 className="text-[20px] font-semibold text-[var(--ink)]">Amanat summary</h2>
          <p className="text-[12px] text-[var(--ink-3)]">Position as on {formatDate(new Date())}</p>
        </div>

        {queryFailed(dashboard) ? (
          <ErrorState error={dashboard.error} message={offlineNotice()} onRetry={() => dashboard.refetch()} />
        ) : dashboard.isLoading ? (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
            <Skeleton className="h-24" />
          </div>
        ) : (
          <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
            <KpiTile
              label="Active amount"
              value={inrShort(kpis?.active_amount)}
              tooltipExact={inr(kpis?.active_amount)}
              context={`${kpis?.active_count ?? 0} deposits`}
            />
            <KpiTile
              label="Maturing in 90 days"
              value={String(kpis?.maturing_90 ?? 0)}
              context="Open deposits"
            />
            <KpiTile
              label="Pending approval"
              value={String(kpis?.pending_approvals ?? 0)}
              context="Waiting for a reviewer"
            />
            <KpiTile
              label="Overdue"
              value={String(kpis?.overdue ?? 0)}
              context="Matured and still open"
              valueColor={(kpis?.overdue ?? 0) > 0 ? 'text-[var(--risk)]' : undefined}
            />
          </div>
        )}

        <div>
          <h3 className="mb-2 text-[16px] font-semibold text-[var(--ink)]">{performanceTitle}</h3>
          {metrics.data ? (
            <dl className="grid grid-cols-2 gap-3 lg:grid-cols-4">
              <PrintStat label="Approval turnaround" text={daysText(metrics.data.approval_turnaround_days)} />
              <PrintStat label="Verification rate" text={rateText(metrics.data.verification_rate)} />
              <PrintStat label="Document coverage" text={rateText(metrics.data.document_coverage)} />
              <PrintStat label="On-time renewals" text={rateText(metrics.data.renewal_on_time_rate)} />
              {(() => {
                const observations = optionalNumber(kpis, 'observations_open');
                const confirmed = optionalNumber(metrics.data, 'bank_confirmed_share');
                return (
                  <>
                    {observations !== undefined && (
                      <PrintStat
                        label="Open observations"
                        text={observations == null ? null : observations.toLocaleString('en-IN')}
                      />
                    )}
                    {confirmed !== undefined && (
                      <PrintStat label="Bank-confirmed share" text={rateText(confirmed)} />
                    )}
                  </>
                );
              })()}
            </dl>
          ) : queryFailed(metrics) ? (
            <p className="text-[13px] text-[var(--ink-2)]">{performanceTitle} could not be loaded.</p>
          ) : (
            <Skeleton className="h-16 w-full" />
          )}
        </div>

        <div>
          <h3 className="mb-2 text-[16px] font-semibold text-[var(--ink)]">Maturing in 90 days</h3>
          {queryFailed(maturing) ? (
            <ErrorState error={maturing.error} message={offlineNotice()} onRetry={() => maturing.refetch()} />
          ) : maturing.isLoading ? (
            <DataTable columns={columns} data={[]} isLoading />
          ) : maturingRows.length === 0 ? (
            <EmptyState message="No deposits mature in the next 90 days." />
          ) : (
            <>
              <DataTable columns={columns} data={maturingRows} />
              {!own && maturing.data && maturing.data.total > maturing.data.items.length && (
                <p className="mt-2 text-[12px] text-[var(--ink-3)]">
                  Showing {maturing.data.items.length} of {maturing.data.total}.
                </p>
              )}
            </>
          )}
        </div>
      </section>
    </div>
  );
}

function PrintStat({ label, text }: { label: string; text: string | null }) {
  return (
    <div className="rounded-[8px] border border-[var(--line)] bg-white px-3 py-2">
      <dt className="text-[12px] font-medium text-[var(--ink-2)]">{label}</dt>
      <dd className="mt-1 font-mono text-[14px] tabular-nums text-[var(--ink)]">{text ?? NOT_ENOUGH}</dd>
    </div>
  );
}

function BureauPanel({
  metrics,
  kpis,
}: {
  metrics: ReturnType<typeof useQuery<BureauMetrics>>;
  kpis: DashboardResponse['kpis'] | undefined;
}) {
  if (queryFailed(metrics)) {
    return <ErrorState error={metrics.error} message={offlineNotice()} onRetry={() => metrics.refetch()} />;
  }
  if (metrics.isLoading || !metrics.data) {
    return (
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {Array.from({ length: 8 }).map((_, index) => (
          <Skeleton key={index} className="h-24" />
        ))}
      </div>
    );
  }
  const data = metrics.data;
  const tiles: { label: string; text: string | null; meaning: string }[] = [
    { label: 'Approval turnaround', text: daysText(data.approval_turnaround_days), meaning: BUREAU_MEANINGS.approval },
    { label: 'Release turnaround', text: daysText(data.release_turnaround_days), meaning: BUREAU_MEANINGS.release },
    { label: 'Pending over review limit', text: data.pending_over_sla.toLocaleString('en-IN'), meaning: BUREAU_MEANINGS.sla },
    { label: 'Verification rate', text: rateText(data.verification_rate), meaning: BUREAU_MEANINGS.verification },
    { label: 'Document coverage', text: rateText(data.document_coverage), meaning: BUREAU_MEANINGS.documents },
    { label: 'On-time renewals', text: rateText(data.renewal_on_time_rate), meaning: BUREAU_MEANINGS.renewals },
    { label: 'Data quality', text: rateText(data.data_quality_rate), meaning: BUREAU_MEANINGS.quality },
    { label: 'Alert response time', text: hoursText(data.alert_ack_median_hours), meaning: BUREAU_MEANINGS.alerts },
  ];
  const observations = optionalNumber(kpis, 'observations_open');
  if (observations !== undefined) {
    tiles.push({
      label: 'Open observations',
      text: observations == null ? null : observations.toLocaleString('en-IN'),
      meaning: 'Scrutiny questions that are still open.',
    });
  }
  const confirmed = optionalNumber(data, 'bank_confirmed_share');
  if (confirmed !== undefined) {
    tiles.push({
      label: 'Bank-confirmed share',
      text: confirmed == null ? null : rateText(confirmed),
      meaning: 'Approved deposits confirmed by a bank letter on file.',
    });
  }
  const chart = data.monthly.map((point) => ({
    label: monthLabel(point.month),
    days: point.avg_turnaround_days,
    decided: point.decided,
  }));

  return (
    <div className="flex flex-col gap-3">
      <div className="grid grid-cols-2 gap-3 lg:grid-cols-4">
        {tiles.map((tile) => (
          <div key={tile.label} className="rounded-[8px] border border-[var(--line)] bg-white p-3">
            <p className="text-[12px] font-medium text-[var(--ink-2)]">{tile.label}</p>
            <div className="my-1 min-h-7">
              <MetricFigure text={tile.text} />
            </div>
            <p className="text-[12px] leading-snug text-[var(--ink-3)]">{tile.meaning}</p>
          </div>
        ))}
      </div>
      <div className="rounded-[8px] border border-[var(--line)] bg-white p-4">
        <h3 className="mb-3 text-[16px] font-semibold text-[var(--ink)]">Average turnaround</h3>
        {chart.length === 0 || chart.every((point) => point.days == null) ? (
          <p className="text-[13px] text-[var(--ink-2)]">{NOT_ENOUGH}</p>
        ) : (
          <>
            <div className="h-56 w-full min-w-0">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={chart} margin={{ top: 8, right: 8, left: 0, bottom: 0 }}>
                  <CartesianGrid stroke="var(--line)" vertical={false} />
                  <XAxis
                    dataKey="label"
                    tick={{ fontSize: 12, fill: 'var(--ink-3)' }}
                    axisLine={{ stroke: 'var(--line)' }}
                    tickLine={false}
                  />
                  <YAxis
                    tick={{ fontSize: 12, fill: 'var(--ink-3)', fontFamily: 'IBM Plex Mono' }}
                    axisLine={{ stroke: 'var(--line)' }}
                    tickLine={false}
                    width={36}
                    allowDecimals={false}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (!active || !payload?.length) return null;
                      const row = payload[0]?.payload as (typeof chart)[number] | undefined;
                      if (!row) return null;
                      return (
                        <div className="rounded-[6px] border border-[var(--line)] bg-white p-2.5 text-[12px]">
                          <div className="mb-1 font-medium text-[var(--ink)]">{label}</div>
                          <div className="font-mono text-[var(--primary)]">
                            {row.days == null ? NOT_ENOUGH : `${oneDecimal(row.days)} days`}
                          </div>
                          <div className="text-[var(--ink-3)]">
                            {row.decided.toLocaleString('en-IN')} decided
                          </div>
                        </div>
                      );
                    }}
                  />
                  <Bar dataKey="days" fill="var(--primary)" radius={[3, 3, 0, 0]} maxBarSize={36} />
                </BarChart>
              </ResponsiveContainer>
            </div>
            {chart.some((point) => point.days == null) && (
              <p className="mt-2 text-[12px] text-[var(--ink-3)]">
                {chart
                  .filter((point) => point.days == null)
                  .map((point) => `${point.label}: ${NOT_ENOUGH}`)
                  .join(' · ')}
              </p>
            )}
          </>
        )}
      </div>
    </div>
  );
}
