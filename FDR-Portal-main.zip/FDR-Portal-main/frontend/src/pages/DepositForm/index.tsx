import { useEffect, useMemo, useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { z } from 'zod';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ArrowLeft, Save, Building2, Calendar as CalendarIcon, Check } from 'lucide-react';
import { toast } from 'sonner';

import { api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { inr, formatDate, formatRate } from '@/lib/format';
import type {
  FdrDetail,
  FdrInput,
  MetaResponse,
  InstitutionItem,
  Purpose,
} from '@/lib/types';

import { PageHeader } from '@/components/shared/PageHeader';
import { ErrorState } from '@/components/shared/ErrorState';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Checkbox } from '@/components/ui/checkbox';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from '@/components/ui/command';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { Skeleton } from '@/components/ui/skeleton';

interface DepositFormPageProps {
  mode?: 'create' | 'edit' | 'renew';
}

const fdrSchema = z
  .object({
    fdr_number: z
      .string()
      .min(1, 'FDR instrument number is required')
      .max(40, 'FDR number cannot exceed 40 characters')
      .trim(),
    institution_id: z.coerce
      .number({ invalid_type_error: 'Please select an institution' })
      .positive('Please select an institution'),
    bank_name: z.string().min(1, 'Please select a designated bank'),
    branch: z.string().optional(),
    ifsc: z
      .string()
      .optional()
      .refine(
        (val) => !val || /^[A-Z]{4}0[A-Z0-9]{6}$/.test(val.trim().toUpperCase()),
        {
          message: 'Invalid IFSC format (e.g. SBIN0001234)',
        }
      ),
    amount: z.coerce
      .number({ invalid_type_error: 'Principal amount is required' })
      .positive('Principal amount must be greater than zero'),
    issue_date: z.string().min(1, 'Issue date is required'),
    maturity_date: z.string().min(1, 'Maturity date is required'),
    interest_rate: z.coerce
      .number({ invalid_type_error: 'Interest rate is required' })
      .min(0.1, 'Interest rate must be greater than 0%')
      .max(30, 'Interest rate cannot exceed 30%'),
    maturity_amount: z.coerce
      .number()
      .optional()
      .nullable(),
    purpose: z.enum([
      'security_deposit',
      'additional_intake',
      'performance_security',
      'other',
    ]),
    lien_to_aicte: z.boolean(),
    remarks: z.string().optional(),
  })
  .refine(
    (data) => {
      if (!data.issue_date || !data.maturity_date) return true;
      return new Date(data.maturity_date) > new Date(data.issue_date);
    },
    {
      message: 'Maturity date must be strictly after the issue date',
      path: ['maturity_date'],
    }
  );

type FdrFormData = z.infer<typeof fdrSchema>;

export default function DepositFormPage({ mode = 'create' }: DepositFormPageProps) {
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const [institutionComboboxOpen, setInstitutionComboboxOpen] = useState(false);

  // Load Banks & Purposes from /api/meta
  const { data: meta } = useQuery<MetaResponse>({
    queryKey: queryKeys.meta,
    queryFn: () => api.get<MetaResponse>('/meta'),
    staleTime: 5 * 60 * 1000,
  });

  // Load Institutions list for combobox
  const { data: institutions } = useQuery<InstitutionItem[]>({
    queryKey: queryKeys.institutions.all,
    queryFn: () => api.get<InstitutionItem[]>('/institutions'),
    staleTime: 5 * 60 * 1000,
  });

  // If in edit or renew mode, load existing FDR detail
  const {
    data: existingFdr,
    isLoading: isFdrLoading,
    isError: isFdrError,
    error: fdrError,
    refetch: refetchFdr,
  } = useQuery<FdrDetail>({
    queryKey: queryKeys.fdrs.detail(id!),
    queryFn: () => api.get<FdrDetail>(`/fdrs/${id}`),
    enabled: !!id && (mode === 'edit' || mode === 'renew'),
  });

  // Calculate default dates
  const todayStr = new Date().toISOString().split('T')[0];
  const nextYearDate = new Date();
  nextYearDate.setFullYear(nextYearDate.getFullYear() + 3);
  const defaultMaturityStr = nextYearDate.toISOString().split('T')[0];

  const {
    register,
    handleSubmit,
    control,
    setValue,
    watch,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<FdrFormData>({
    resolver: zodResolver(fdrSchema),
    defaultValues: {
      fdr_number: '',
      institution_id: (user?.role === 'institution' && user?.institution_id) ? user.institution_id : 0,
      bank_name: '',
      branch: '',
      ifsc: '',
      amount: 0,
      issue_date: todayStr,
      maturity_date: defaultMaturityStr,
      interest_rate: 6.5,
      maturity_amount: null,
      purpose: 'security_deposit',
      lien_to_aicte: true,
      remarks: '',
    },
  });

  // For institution users, ensure institution_id is set
  useEffect(() => {
    if (user?.role === 'institution' && user?.institution_id && mode === 'create') {
      setValue('institution_id', user.institution_id, { shouldValidate: true });
    }
  }, [user, mode, setValue]);

  // Pre-fill form when existing FDR data loads (for edit or renew)
  useEffect(() => {
    if (!existingFdr) return;

    if (mode === 'edit') {
      reset({
        fdr_number: existingFdr.fdr_number,
        institution_id: existingFdr.institution_id,
        bank_name: existingFdr.bank_name,
        branch: existingFdr.branch || '',
        ifsc: existingFdr.ifsc || '',
        amount: Number(existingFdr.amount),
        issue_date: existingFdr.issue_date,
        maturity_date: existingFdr.maturity_date,
        interest_rate: Number(existingFdr.interest_rate),
        maturity_amount: existingFdr.maturity_amount ? Number(existingFdr.maturity_amount) : null,
        purpose: existingFdr.purpose,
        lien_to_aicte: existingFdr.lien_to_aicte,
        remarks: existingFdr.remarks || '',
      });
    } else if (mode === 'renew') {
      // For renewal: institution is fixed, issue date is old maturity date, new maturity date is +3 years
      const renewalIssueDate = existingFdr.maturity_date || todayStr;
      const renewalMaturity = new Date(renewalIssueDate);
      renewalMaturity.setFullYear(renewalMaturity.getFullYear() + 3);

      reset({
        fdr_number: `${existingFdr.fdr_number}-R`,
        institution_id: existingFdr.institution_id,
        bank_name: existingFdr.bank_name,
        branch: existingFdr.branch || '',
        ifsc: existingFdr.ifsc || '',
        amount: Number(existingFdr.amount),
        issue_date: renewalIssueDate,
        maturity_date: renewalMaturity.toISOString().split('T')[0],
        interest_rate: Number(existingFdr.interest_rate),
        maturity_amount: null,
        purpose: existingFdr.purpose,
        lien_to_aicte: existingFdr.lien_to_aicte,
        remarks: `Renewal of FDR #${existingFdr.fdr_number}`,
      });
    }
  }, [existingFdr, mode, reset, todayStr]);

  // Watch fields for live projected maturity value calculation
  const watchedAmount = watch('amount') || 0;
  const watchedRate = watch('interest_rate') || 0;
  const watchedIssueDate = watch('issue_date');
  const watchedMaturityDate = watch('maturity_date');
  const watchedInstitutionId = watch('institution_id');

  // Compute Live Projected Maturity Value
  // Quarterly compounding: projected_value = amount * (1 + r/400)^(4 * years)
  // years = (maturity - issue) / 365.25
  const liveProjectedValue = useMemo(() => {
    if (!watchedAmount || !watchedRate || !watchedIssueDate || !watchedMaturityDate) {
      return 0;
    }
    const start = new Date(watchedIssueDate).getTime();
    const end = new Date(watchedMaturityDate).getTime();
    if (isNaN(start) || isNaN(end) || end <= start) return 0;

    const diffDays = (end - start) / (1000 * 60 * 60 * 24);
    const years = diffDays / 365.25;
    const r = watchedRate;
    // Compound quarterly
    const val = watchedAmount * Math.pow(1 + r / 400, 4 * years);
    return Math.round(val * 100) / 100;
  }, [watchedAmount, watchedRate, watchedIssueDate, watchedMaturityDate]);

  // Selected institution label
  const selectedInstitution = useMemo(() => {
    return institutions?.find((i) => i.id === watchedInstitutionId);
  }, [institutions, watchedInstitutionId]);

  // Mutation for saving
  const saveMutation = useMutation({
    mutationFn: async (data: FdrFormData) => {
      const payload: FdrInput = {
        fdr_number: data.fdr_number,
        institution_id: data.institution_id,
        bank_name: data.bank_name,
        branch: data.branch || undefined,
        ifsc: data.ifsc ? data.ifsc.trim().toUpperCase() : undefined,
        amount: data.amount,
        issue_date: data.issue_date,
        maturity_date: data.maturity_date,
        interest_rate: data.interest_rate,
        maturity_amount: data.maturity_amount || undefined,
        purpose: data.purpose as Purpose,
        lien_to_aicte: data.lien_to_aicte,
        remarks: data.remarks || undefined,
      };

      if (mode === 'create') {
        return api.post<FdrDetail>('/fdrs', payload);
      } else if (mode === 'edit') {
        return api.patch<FdrDetail>(`/fdrs/${id}`, payload);
      } else {
        // renew
        return api.post<FdrDetail>(`/fdrs/${id}/renew`, payload);
      }
    },
    onSuccess: (savedFdr) => {
      const actionWord =
        mode === 'create' ? 'created as draft' : mode === 'edit' ? 'updated' : 'renewed';
      toast.success(`FDR #${savedFdr.fdr_number} ${actionWord}`);

      queryClient.invalidateQueries({ queryKey: queryKeys.fdrs.all });
      queryClient.invalidateQueries({ queryKey: queryKeys.dashboard });
      queryClient.invalidateQueries({ queryKey: ['approvals'] });
      queryClient.invalidateQueries({ queryKey: ['alerts'] });

      navigate(`/deposits/${savedFdr.id}`);
    },
    onError: (err: any) => {
      toast.error(err?.detail || err?.message || 'Failed to save FDR record');
    },
  });

  const onSubmit = (data: FdrFormData) => {
    saveMutation.mutate(data);
  };

  const pageTitle =
    mode === 'create'
      ? 'Record New FDR Deposit'
      : mode === 'edit'
      ? `Edit FDR #${existingFdr?.fdr_number || ''}`
      : `Renew FDR #${existingFdr?.fdr_number || ''}`;

  const pageDesc =
    mode === 'create'
      ? 'Enter the details from the FDR receipt. It is saved as a draft until you submit it.'
      : mode === 'edit'
      ? 'Modify deposit parameters prior to final bureau approval'
      : 'Issue a replacement instrument for an expiring security deposit';

  if (isFdrLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-6 w-32" />
        <Skeleton className="h-96 w-full" />
      </div>
    );
  }

  if (isFdrError) {
    return (
      <div className="space-y-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/deposits')}
          className="gap-1.5 text-xs text-[var(--ink-2)] -ml-2"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to deposits register</span>
        </Button>
        <ErrorState error={fdrError} onRetry={() => refetchFdr()} />
      </div>
    );
  }

  if (mode === 'edit' && existingFdr && !existingFdr.allowed_actions?.includes('edit')) {
    return (
      <div className="space-y-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate(`/deposits/${id}`)}
          className="gap-1.5 text-xs text-[var(--ink-2)] -ml-2"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to deposit record</span>
        </Button>
        <div className="rounded-[8px] border border-[#F8D4D0] bg-[#FDECEA]/40 p-6 max-w-lg mx-auto my-8 space-y-3 shadow-2xs">
          <div className="flex items-center gap-2 text-[#B42318]">
            <span className="text-xs font-semibold uppercase tracking-wider">
              Deposit Locked from Editing
            </span>
          </div>
          <p className="text-xs text-[var(--ink-2)] leading-relaxed">
            Deposit <strong>{existingFdr.fdr_number}</strong> is currently in status{' '}
            <span className="font-mono font-medium text-[var(--ink)]">"{existingFdr.status}"</span>.
            Edits are permitted only while an instrument is in Draft or Rejected status.
          </p>
          <div className="pt-2">
            <Button
              size="sm"
              onClick={() => navigate(`/deposits/${id}`)}
              className="text-xs"
            >
              Return to Deposit Record
            </Button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      {/* Back button */}
      <div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => (id ? navigate(`/deposits/${id}`) : navigate('/deposits'))}
          className="gap-1.5 text-xs text-[var(--ink-2)] -ml-2"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>{id ? 'Back to deposit detail' : 'Back to register'}</span>
        </Button>
      </div>

      <PageHeader title={pageTitle} description={pageDesc} />

      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        {/* Two-column layout: Form sections on left, Projected Live Summary on right */}
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
          {/* Main Form Fields: 8 columns */}
          <div className="lg:col-span-8 space-y-6">
            {/* Section 1: Institution Selection */}
            <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 shadow-2xs space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-[var(--line)]">
                <Building2 className="h-4 w-4 text-[var(--primary)]" />
                <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--ink)]">
                  1. Designated Institution
                </h2>
              </div>

              <div className="space-y-1.5">
                <Label htmlFor="institution_id">
                  Affiliated Institution <span className="text-[var(--risk)]">*</span>
                </Label>
                {mode === 'renew' || user?.role === 'institution' ? (
                  <div className="p-2.5 rounded-[6px] border border-[var(--line)] bg-[var(--surface-2)] text-xs font-medium text-[var(--ink)]">
                    {user?.institution_name || selectedInstitution?.name || 'Selected Institution'}
                    {selectedInstitution?.aicte_id && ` (AICTE ID: ${selectedInstitution.aicte_id})`}
                  </div>
                ) : (
                  <Popover
                    open={institutionComboboxOpen}
                    onOpenChange={setInstitutionComboboxOpen}
                  >
                    <PopoverTrigger asChild>
                      <Button
                        variant="outline"
                        role="combobox"
                        className="w-full justify-between text-xs h-9 font-normal bg-white"
                      >
                        <span className="truncate">
                          {selectedInstitution
                            ? `${selectedInstitution.name} (${selectedInstitution.aicte_id})`
                            : 'Select affiliated institution...'}
                        </span>
                        <CalendarIcon className="ml-2 h-3.5 w-3.5 opacity-50 shrink-0" />
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-[420px] p-0" align="start">
                      <Command>
                        <CommandInput placeholder="Search institution name, city, or AICTE ID..." />
                        <CommandList>
                          <CommandEmpty>No matching institution found.</CommandEmpty>
                          <CommandGroup>
                            {institutions?.map((inst) => (
                              <CommandItem
                                key={inst.id}
                                value={`${inst.name} ${inst.aicte_id} ${inst.city}`}
                                onSelect={() => {
                                  setValue('institution_id', inst.id, {
                                    shouldValidate: true,
                                  });
                                  setInstitutionComboboxOpen(false);
                                }}
                                className="flex items-center justify-between cursor-pointer"
                              >
                                <div className="flex items-center gap-2 truncate">
                                  <Check
                                    className={`h-3.5 w-3.5 shrink-0 ${
                                      watchedInstitutionId === inst.id
                                        ? 'opacity-100 text-[var(--primary)]'
                                        : 'opacity-0'
                                    }`}
                                  />
                                  <span className="truncate font-medium">{inst.name}</span>
                                </div>
                                <span className="font-mono text-[10px] text-[var(--ink-3)] shrink-0 ml-2">
                                  {inst.aicte_id}
                                </span>
                              </CommandItem>
                            ))}
                          </CommandGroup>
                        </CommandList>
                      </Command>
                    </PopoverContent>
                  </Popover>
                )}
                {errors.institution_id && (
                  <p className="text-[11px] text-[var(--risk)]">
                    {errors.institution_id.message}
                  </p>
                )}
              </div>
            </div>

            {/* Section 2: Instrument & Bank */}
            <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 shadow-2xs space-y-4">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--ink)] pb-2 border-b border-[var(--line)]">
                2. Instrument &amp; Bank Details
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* FDR Number */}
                <div className="space-y-1.5">
                  <Label htmlFor="fdr_number">
                    FDR Instrument Number <span className="text-[var(--risk)]">*</span>
                  </Label>
                  <Input
                    id="fdr_number"
                    {...register('fdr_number')}
                    placeholder="e.g. FDR-2026-98124"
                    className="font-mono"
                  />
                  {errors.fdr_number && (
                    <p className="text-[11px] text-[var(--risk)]">
                      {errors.fdr_number.message}
                    </p>
                  )}
                </div>

                {/* Bank Select */}
                <div className="space-y-1.5">
                  <Label htmlFor="bank_name">
                    Issuing Bank <span className="text-[var(--risk)]">*</span>
                  </Label>
                  <Controller
                    control={control}
                    name="bank_name"
                    render={({ field }) => (
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger className="w-full h-8 text-xs">
                          <SelectValue placeholder="Select bank name" />
                        </SelectTrigger>
                        <SelectContent>
                          {meta?.banks?.map((b) => (
                            <SelectItem key={b} value={b}>
                              {b}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    )}
                  />
                  {errors.bank_name && (
                    <p className="text-[11px] text-[var(--risk)]">
                      {errors.bank_name.message}
                    </p>
                  )}
                </div>

                {/* Branch */}
                <div className="space-y-1.5">
                  <Label htmlFor="branch">Bank Branch</Label>
                  <Input
                    id="branch"
                    {...register('branch')}
                    placeholder="e.g. Connaught Place Branch"
                  />
                </div>

                {/* IFSC */}
                <div className="space-y-1.5">
                  <Label htmlFor="ifsc">Branch IFSC Code</Label>
                  <Input
                    id="ifsc"
                    {...register('ifsc')}
                    placeholder="e.g. SBIN0001234"
                    className="font-mono uppercase"
                    maxLength={11}
                  />
                  {errors.ifsc && (
                    <p className="text-[11px] text-[var(--risk)]">
                      {errors.ifsc.message}
                    </p>
                  )}
                </div>
              </div>
            </div>

            {/* Section 3: Dates and Interest */}
            <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 shadow-2xs space-y-4">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--ink)] pb-2 border-b border-[var(--line)]">
                3. Financial Terms &amp; Dates
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Principal Amount */}
                <div className="space-y-1.5">
                  <Label htmlFor="amount">
                    Principal Deposit (₹) <span className="text-[var(--risk)]">*</span>
                  </Label>
                  <Input
                    id="amount"
                    type="number"
                    step="any"
                    {...register('amount')}
                    placeholder="e.g. 1500000"
                    className="font-mono"
                  />
                  {errors.amount && (
                    <p className="text-[11px] text-[var(--risk)]">
                      {errors.amount.message}
                    </p>
                  )}
                </div>

                {/* Interest Rate */}
                <div className="space-y-1.5">
                  <Label htmlFor="interest_rate">
                    Interest Rate (% p.a.) <span className="text-[var(--risk)]">*</span>
                  </Label>
                  <Input
                    id="interest_rate"
                    type="number"
                    step="0.01"
                    {...register('interest_rate')}
                    placeholder="e.g. 7.25"
                    className="font-mono"
                  />
                  {errors.interest_rate && (
                    <p className="text-[11px] text-[var(--risk)]">
                      {errors.interest_rate.message}
                    </p>
                  )}
                </div>

                {/* Issue Date */}
                <div className="space-y-1.5">
                  <Label htmlFor="issue_date">
                    Issue Date <span className="text-[var(--risk)]">*</span>
                  </Label>
                  <Input
                    id="issue_date"
                    type="date"
                    {...register('issue_date')}
                    className="font-mono"
                  />
                  {errors.issue_date && (
                    <p className="text-[11px] text-[var(--risk)]">
                      {errors.issue_date.message}
                    </p>
                  )}
                </div>

                {/* Maturity Date */}
                <div className="space-y-1.5">
                  <Label htmlFor="maturity_date">
                    Maturity Date <span className="text-[var(--risk)]">*</span>
                  </Label>
                  <Input
                    id="maturity_date"
                    type="date"
                    {...register('maturity_date')}
                    className="font-mono"
                  />
                  {errors.maturity_date && (
                    <p className="text-[11px] text-[var(--risk)]">
                      {errors.maturity_date.message}
                    </p>
                  )}
                </div>

                {/* Printed Maturity Amount (optional) */}
                <div className="space-y-1.5 md:col-span-2">
                  <Label htmlFor="maturity_amount">
                    Maturity Value as printed on Physical Receipt (Optional)
                  </Label>
                  <Input
                    id="maturity_amount"
                    type="number"
                    step="any"
                    {...register('maturity_amount')}
                    placeholder="Optional printed receipt maturity amount"
                    className="font-mono"
                  />
                  <span className="text-[11px] text-[var(--ink-3)] block">
                    If provided, Health Check flags it if it differs from the computed value by more than 1%.
                  </span>
                </div>
              </div>
            </div>

            {/* Section 4: Compliance & Purpose */}
            <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 shadow-2xs space-y-4">
              <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--ink)] pb-2 border-b border-[var(--line)]">
                4. Purpose &amp; lien
              </h2>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {/* Purpose */}
                <div className="space-y-1.5">
                  <Label htmlFor="purpose">Deposit Purpose</Label>
                  <Controller
                    control={control}
                    name="purpose"
                    render={({ field }) => (
                      <Select
                        value={field.value}
                        onValueChange={field.onChange}
                      >
                        <SelectTrigger className="w-full h-8 text-xs">
                          <SelectValue placeholder="Select purpose" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="security_deposit">Security deposit</SelectItem>
                          <SelectItem value="additional_intake">Additional intake</SelectItem>
                          <SelectItem value="performance_security">Performance security</SelectItem>
                          <SelectItem value="other">Other</SelectItem>
                        </SelectContent>
                      </Select>
                    )}
                  />
                </div>

                {/* Lien Marked Checkbox */}
                <div className="flex items-center space-x-2 pt-6">
                  <Controller
                    control={control}
                    name="lien_to_aicte"
                    render={({ field }) => (
                      <Checkbox
                        id="lien_to_aicte"
                        checked={field.value}
                        onCheckedChange={field.onChange}
                      />
                    )}
                  />
                  <Label
                    htmlFor="lien_to_aicte"
                    className="text-xs font-medium text-[var(--ink)] cursor-pointer leading-tight"
                  >
                    Lien marked to AICTE / Joint Account with Bureau
                  </Label>
                </div>

                {/* Remarks */}
                <div className="space-y-1.5 md:col-span-2">
                  <Label htmlFor="remarks">Internal Notes / Bureau Remarks</Label>
                  <Textarea
                    id="remarks"
                    {...register('remarks')}
                    placeholder="Enter any reference numbers, tenure conditions, or dispatch details..."
                    rows={2}
                  />
                </div>
              </div>
            </div>
          </div>

          {/* Right Column: Live Projected Summary & Actions: 4 columns */}
          <div className="lg:col-span-4 space-y-4">
            {/* Live Projected Value Box */}
            <div className="rounded-[8px] border border-[#CCD2DB] bg-white p-4 shadow-sm space-y-3 sticky top-20">
              <div className="text-xs font-semibold text-[var(--ink)] pb-2 border-b border-[var(--line)]">
                Projected maturity value
              </div>

              <div className="space-y-3 text-xs">
                <div>
                  <span className="text-[11px] text-[var(--ink-3)] block">
                    Principal Amount
                  </span>
                  <span className="font-mono text-base font-semibold text-[var(--ink)]">
                    {inr(watchedAmount)}
                  </span>
                </div>

                <div>
                  <span className="text-[11px] text-[var(--ink-3)] block">
                    Projected maturity value (quarterly compounding)
                  </span>
                  <span className="font-mono text-xl font-bold text-[var(--primary)] block mt-0.5">
                    {inr(liveProjectedValue)}
                  </span>
                  <span className="text-[10px] text-[var(--ink-3)] block mt-0.5">
                    Compound Growth: +{inr(liveProjectedValue - watchedAmount)}
                  </span>
                </div>

                <div className="p-2.5 rounded-[4px] bg-[var(--surface-2)] border border-[var(--line)] space-y-1 text-[11px]">
                  <div className="flex justify-between text-[var(--ink-2)]">
                    <span>Rate:</span>
                    <span className="font-mono">{formatRate(watchedRate)} p.a.</span>
                  </div>
                  <div className="flex justify-between text-[var(--ink-2)]">
                    <span>Issue:</span>
                    <span className="font-mono">{formatDate(watchedIssueDate)}</span>
                  </div>
                  <div className="flex justify-between text-[var(--ink-2)]">
                    <span>Maturity:</span>
                    <span className="font-mono">{formatDate(watchedMaturityDate)}</span>
                  </div>
                </div>

                {/* Submit Actions */}
                <div className="pt-2 space-y-2">
                  <Button
                    type="submit"
                    disabled={isSubmitting || saveMutation.isPending}
                    className="w-full text-xs h-9 gap-1.5"
                  >
                    <Save className="h-3.5 w-3.5" />
                    <span>
                      {isSubmitting || saveMutation.isPending
                        ? 'Saving...'
                        : mode === 'create'
                        ? 'Save as Draft'
                        : mode === 'edit'
                        ? 'Save Changes'
                        : 'Confirm Renewal'}
                    </span>
                  </Button>

                  <Button
                    type="button"
                    variant="outline"
                    onClick={() =>
                      id ? navigate(`/deposits/${id}`) : navigate('/deposits')
                    }
                    className="w-full text-xs h-8"
                  >
                    Cancel
                  </Button>
                </div>
              </div>
            </div>
          </div>
        </div>
      </form>
    </div>
  );
}
