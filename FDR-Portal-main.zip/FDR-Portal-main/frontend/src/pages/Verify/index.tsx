import React, { useState, useEffect } from 'react';
import { BrandMark } from '@/components/shared/BrandMark';
import { useSearchParams, NavLink } from 'react-router-dom';
import { CheckCircle2, XCircle, Search, ArrowLeft } from 'lucide-react';
import { api } from '@/lib/api';
import { formatDate } from '@/lib/format';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import type { NoticeVerifyResponse } from '@/lib/types';

export default function VerifyPage() {
  const [searchParams, setSearchParams] = useSearchParams();
  const initialRef = searchParams.get('ref') || '';
  const initialCode = searchParams.get('code') || '';

  const [ref, setRef] = useState(initialRef);
  const [code, setCode] = useState(initialCode);
  const [loading, setLoading] = useState(false);
  const [result, setResult] = useState<NoticeVerifyResponse | null>(null);
  const [hasSearched, setHasSearched] = useState(false);

  const performVerification = async (r: string, c: string) => {
    if (!r.trim() || !c.trim()) return;
    setLoading(true);
    setHasSearched(true);
    try {
      const res = await api.get<NoticeVerifyResponse>(
        `/public/verify-notice?ref=${encodeURIComponent(r.trim())}&code=${encodeURIComponent(c.trim())}`
      );
      setResult(res);
    } catch {
      setResult({ valid: false });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (initialRef && initialCode) {
      performVerification(initialRef, initialCode);
    }
  }, [initialRef, initialCode]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSearchParams({ ref: ref.trim(), code: code.trim() });
    performVerification(ref, code);
  };

  return (
    <div className="min-h-screen bg-[var(--bg)] flex flex-col justify-between p-4 sm:p-6 antialiased">
      {/* Top bar with logo and back link */}
      <div className="max-w-2xl mx-auto w-full flex items-center justify-between pb-6">
        <div className="flex items-center gap-2.5">
          <BrandMark className="h-7 w-7" />
          <div className="flex flex-col">
            <span className="text-[13px] font-semibold tracking-tight text-[var(--ink)] leading-tight">
              Amanat
            </span>
            <span className="text-[10px] text-[var(--ink-3)] leading-tight">
              Letter &amp; Document Verification Service
            </span>
          </div>
        </div>
        <NavLink
          to="/login"
          className="inline-flex items-center gap-1.5 text-xs text-[var(--ink-2)] hover:text-[var(--primary)] transition-colors"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Sign In</span>
        </NavLink>
      </div>

      {/* Main card */}
      <div className="max-w-xl mx-auto w-full my-auto">
        <div className="rounded-lg border border-[var(--line)] bg-white p-6 sm:p-8 shadow-xs">
          <div className="border-b border-[var(--line)] pb-4 text-center">
            <h1 className="text-lg font-semibold text-[var(--ink)]">
              Official Letter Verification
            </h1>
            <p className="mt-1 text-xs text-[var(--ink-2)]">
              Verify the authenticity and integrity of notices issued by the Regulation Bureau.
            </p>
          </div>

          <form onSubmit={handleSubmit} className="mt-6 space-y-4">
            <div className="space-y-1.5">
              <Label htmlFor="ref" className="text-xs font-medium text-[var(--ink-2)]">
                Notice Reference Number
              </Label>
              <Input
                id="ref"
                placeholder="e.g. FDRP/NOT/2026/0001"
                value={ref}
                onChange={(e) => setRef(e.target.value)}
                className="font-mono text-xs"
                required
              />
            </div>

            <div className="space-y-1.5">
              <Label htmlFor="code" className="text-xs font-medium text-[var(--ink-2)]">
                Verification Code (16-character hex)
              </Label>
              <Input
                id="code"
                placeholder="e.g. 7f3b8a1c9d2e4f5a"
                value={code}
                onChange={(e) => setCode(e.target.value)}
                className="font-mono text-xs"
                required
              />
            </div>

            <Button type="submit" disabled={loading} className="w-full gap-2">
              <Search className="h-4 w-4" />
              <span>{loading ? 'Verifying...' : 'Verify Authenticity'}</span>
            </Button>
          </form>

          {/* Verification Result */}
          {hasSearched && !loading && result && (
            <div className="mt-6 pt-6 border-t border-[var(--line)]">
              {result.valid ? (
                <div className="rounded-md border border-[var(--ok)]/30 bg-[#E7F5EE] p-4 text-[var(--ink)]">
                  <div className="flex items-center gap-2 text-[#167A4A] font-semibold text-sm">
                    <CheckCircle2 className="h-5 w-5 shrink-0" />
                    <span>Official Record Verified Intact</span>
                  </div>
                  <div className="mt-3 space-y-2 text-xs border-t border-[var(--ok)]/20 pt-3">
                    <div className="flex justify-between py-0.5">
                      <span className="text-[var(--ink-2)]">Reference Number</span>
                      <span className="font-mono font-medium">{result.reference_no}</span>
                    </div>
                    <div className="flex justify-between py-0.5">
                      <span className="text-[var(--ink-2)]">Notice Kind</span>
                      <span className="font-medium">{result.kind_label}</span>
                    </div>
                    <div className="flex justify-between py-0.5">
                      <span className="text-[var(--ink-2)]">Issue Date</span>
                      <span>{formatDate(result.issued_at)}</span>
                    </div>
                    <div className="flex justify-between py-0.5">
                      <span className="text-[var(--ink-2)]">Recipient Institution</span>
                      <span className="font-medium text-right max-w-[280px]">{result.institution_name}</span>
                    </div>
                    {result.fdr_number && (
                      <div className="flex justify-between py-0.5">
                        <span className="text-[var(--ink-2)]">Associated FDR</span>
                        <span className="font-mono">{result.fdr_number}</span>
                      </div>
                    )}
                  </div>
                </div>
              ) : (
                <div className="rounded-md border border-[var(--risk)]/30 bg-[#FDECEA] p-4 text-[var(--ink)]">
                  <div className="flex items-center gap-2 text-[#B42318] font-semibold text-sm">
                    <XCircle className="h-5 w-5 shrink-0" />
                    <span>Invalid or Unrecognised Document</span>
                  </div>
                  <p className="mt-2 text-xs text-[var(--ink-2)]">
                    The provided reference number and verification code do not match any issued record in the Amanat registry.
                  </p>
                </div>
              )}
            </div>
          )}
        </div>
      </div>

      {/* Footer */}
      <div className="text-center text-[11px] text-[var(--ink-3)] max-w-xl mx-auto pt-6">
        Verification uses the portal's own record; it does not contact any bank.
      </div>
    </div>
  );
}
