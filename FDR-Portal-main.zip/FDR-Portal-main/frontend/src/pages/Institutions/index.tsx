import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import type { InstitutionItem } from '@/lib/types';
import { isInstitution, ownInstitution, visibleToInstitution } from '@/pages/Approvals/roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { FilterBar } from '@/components/shared/FilterBar';
import { DataTable, type Column } from '@/components/shared/DataTable';
import { Money } from '@/components/shared/Money';
import { HealthBar } from '@/components/shared/HealthBar';
import { ErrorState } from '@/components/shared/ErrorState';
import { EmptyState } from '@/components/shared/EmptyState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';

function useDebounced(value: string, delay = 300) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), delay);
    return () => window.clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

const columns: Column<InstitutionItem>[] = [
  {
    key: 'name',
    header: 'Institution',
    cell: (item) => <span className="font-medium text-[var(--ink)]">{item.name}</span>,
  },
  {
    key: 'aicte_id',
    header: 'AICTE ID',
    cell: (item) => <span className="font-mono text-[13px] tabular-nums">{item.aicte_id}</span>,
  },
  {
    key: 'place',
    header: 'City / State',
    cell: (item) => `${item.city}, ${item.state}`,
  },
  {
    key: 'type',
    header: 'Type',
    cell: (item) => item.type,
  },
  {
    key: 'fdr_count',
    header: 'FDRs',
    align: 'right',
    cell: (item) => item.fdr_count,
  },
  {
    key: 'active_amount',
    header: 'Active amount',
    align: 'right',
    cell: (item) => <Money amount={item.active_amount} />,
  },
  {
    key: 'required',
    header: 'Required',
    align: 'right',
    cell: (item) => <Money amount={item.required_deposit} />,
  },
  {
    key: 'shortfall',
    header: 'Shortfall',
    align: 'right',
    cell: (item) => (
      <Money
        amount={item.shortfall}
        className={item.shortfall > 0 ? 'text-[var(--risk)]' : 'text-[var(--ink-2)]'}
      />
    ),
  },
  {
    key: 'health',
    header: 'Health',
    cell: (item) =>
      item.health_score == null ? (
        <span className="text-[12px] text-[var(--ink-3)]">—</span>
      ) : (
        <HealthBar score={item.health_score} />
      ),
  },
];

export default function InstitutionsPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const own = ownInstitution(user);
  const institutionUser = isInstitution(user?.role);
  const [search, setSearch] = useState('');
  const q = useDebounced(search.trim());

  const institutions = useQuery({
    queryKey: institutionUser
      ? ['institutions', 'own', own?.id ?? null]
      : queryKeys.institutions.list(q || undefined),
    queryFn: () =>
      institutionUser
        ? api.get<InstitutionItem>(`/institutions/${own?.id}`).then((item) => [item])
        : api.get<InstitutionItem[]>(`/institutions${q ? `?q=${encodeURIComponent(q)}` : ''}`),
    enabled: !institutionUser || own?.id != null,
  });
  useRefetchOffline(institutions.refetch);

  const items = (institutions.data ?? []).filter((item) => {
    if (!visibleToInstitution(user, { institution_id: item.id, institution_name: item.name })) return false;
    if (!institutionUser || !q) return true;
    const haystack = `${item.name} ${item.aicte_id} ${item.city} ${item.state}`.toLowerCase();
    return haystack.includes(q.toLowerCase());
  });

  return (
    <div className="flex min-w-0 flex-col gap-4">
      <PageHeader
        title="Institutions"
        description={
          institutionUser
            ? 'Your institution: required deposit, amount on record and health.'
            : 'Required deposit, amount on record and health of each institution.'
        }
      />
      <FilterBar
        searchValue={search}
        onSearchChange={setSearch}
        searchPlaceholder="Search name, AICTE ID, city or state"
        hasActiveFilters={search.length > 0}
        onReset={() => setSearch('')}
        context={
          institutions.data
            ? institutionUser
              ? 'Your institution'
              : `${items.length} institutions`
            : undefined
        }
      />
      {queryFailed(institutions) ? (
        <ErrorState error={institutions.error} message={offlineNotice()} onRetry={() => institutions.refetch()} />
      ) : institutions.isLoading ? (
        <DataTable columns={columns} data={[]} isLoading />
      ) : items.length === 0 ? (
        <EmptyState
          message={search ? 'No institutions match this search.' : 'No institutions are on record.'}
          actionLabel={search ? 'Clear search' : undefined}
          onAction={search ? () => setSearch('') : undefined}
        />
      ) : (
        <DataTable
          columns={columns}
          data={items}
          onRowClick={(item) => navigate(`/institutions/${item.id}`)}
        />
      )}
    </div>
  );
}
