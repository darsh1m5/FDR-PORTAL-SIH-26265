import type { ReactNode } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { ApiError, api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { formatDate } from '@/lib/format';
import type { FdrListItem, InstitutionDetail, NoticeItem } from '@/lib/types';
import { isInstitution, optionalNumber, visibleToInstitution, RoleUnavailable } from '@/pages/Approvals/roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { Button } from '@/components/ui/button';
import { DataTable, type Column } from '@/components/shared/DataTable';
import { Money } from '@/components/shared/Money';
import { HealthBar } from '@/components/shared/HealthBar';
import { StatusPill } from '@/components/shared/StatusPill';
import { MaturityChip } from '@/components/shared/MaturityChip';
import { ErrorState } from '@/components/shared/ErrorState';
import { EmptyState } from '@/components/shared/EmptyState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';
import { Skeleton } from '@/components/ui/skeleton';

const columns: Column<FdrListItem>[] = [
  {
    key: 'fdr_number',
    header: 'FDR number',
    cell: (item) => (
      <Link
        to={`/deposits/${item.id}`}
        className="font-mono text-[13px] tabular-nums text-[var(--primary)] hover:underline"
        onClick={(event) => event.stopPropagation()}
      >
        {item.fdr_number}
      </Link>
    ),
  },
  {
    key: 'bank',
    header: 'Bank',
    cell: (item) => item.bank_name,
  },
  {
    key: 'amount',
    header: 'Amount',
    align: 'right',
    cell: (item) => <Money amount={item.amount} />,
  },
  {
    key: 'maturity',
    header: 'Maturity',
    cell: (item) => formatDate(item.maturity_date),
  },
  {
    key: 'days',
    header: 'Window',
    cell: (item) => <MaturityChip days={item.days_to_maturity} state={item.maturity_state} />,
  },
  {
    key: 'status',
    header: 'Status',
    className: 'whitespace-nowrap',
    cell: (item) => <StatusPill status={item.status} />,
  },
  {
    key: 'verification',
    header: 'Verification',
    className: 'whitespace-nowrap',
    cell: (item) => (
      <span className="text-[12px] text-[var(--ink-2)]">
        {item.verification === 'bank_confirmed'
          ? 'Bank-confirmed (letter)'
          : item.verification === 'officer_verified'
            ? 'Officer-verified'
            : 'Submitted'}
      </span>
    ),
  },
  {
    key: 'health',
    header: 'Health',
    cell: (item) => <HealthBar score={item.health_score} />,
  },
];

function Fact({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5">
      <dt className="text-[12px] font-medium text-[var(--ink-2)]">{label}</dt>
      <dd className="text-[13px] text-[var(--ink)]">{children}</dd>
    </div>
  );
}

export default function InstitutionDetailPage() {
  const { id } = useParams();
  const institutionId = Number(id);
  const enabled = Number.isFinite(institutionId) && institutionId > 0;

  const { user } = useAuth();

  const institution = useQuery({
    queryKey: queryKeys.institutions.detail(institutionId),
    queryFn: () => api.get<InstitutionDetail>(`/institutions/${institutionId}`),
    enabled,
  });
  useRefetchOffline(institution.refetch);

  if (!enabled) {
    return <ErrorState message="This institution address is not valid." />;
  }

  if (institution.isLoading) {
    return (
      <div className="flex flex-col gap-3">
        <Skeleton className="h-8 w-64" />
        <Skeleton className="h-24 w-full" />
        <Skeleton className="h-64 w-full" />
      </div>
    );
  }

  if (queryFailed(institution) || !institution.data) {
    const status = institution.error instanceof ApiError ? institution.error.status : 0;
    if (isInstitution(user?.role) && (status === 403 || status === 404)) {
      return <RoleUnavailable title="Institutions" />;
    }
    return <ErrorState error={institution.error} message={offlineNotice()} onRetry={() => institution.refetch()} />;
  }

  const item = institution.data;
  const held = item.fdrs
    .filter((fdr) => fdr.status === 'pending_approval' || fdr.status === 'approved' || fdr.status === 'release_requested')
    .reduce((sum, fdr) => sum + fdr.amount, 0);

  return (
    <InstitutionDetailBody item={item} held={held} institutionId={institutionId} />
  );
}

function InstitutionDetailBody({
  item,
  held,
  institutionId,
}: {
  item: InstitutionDetail;
  held: number;
  institutionId: number;
}) {
  const { role, user } = useAuth();
  const navigate = useNavigate();
  const notices = useQuery({
    queryKey: ['notices', 'institution', institutionId],
    queryFn: () => api.get<NoticeItem[]>(`/notices?institution_id=${institutionId}`),
  });
  useRefetchOffline(notices.refetch);
  const onRecord = optionalNumber(item, 'observations_open');
  const fromDeposits = item.fdrs.reduce<{ seen: boolean; total: number }>(
    (sum, fdr) => {
      const count = optionalNumber(fdr, 'observations_open');
      if (count === undefined) return sum;
      return { seen: true, total: sum.total + (count ?? 0) };
    },
    { seen: false, total: 0 }
  );
  const observations = onRecord !== undefined ? onRecord : fromDeposits.seen ? fromDeposits.total : undefined;
  const users = optionalNumber(item, 'users_count') ?? optionalNumber(item, 'user_count');

  if (!visibleToInstitution(user, { institution_id: item.id, institution_name: item.name })) {
    return <RoleUnavailable title="Institutions" />;
  }

  return (
    <div className="flex flex-col gap-4">
      <Link to="/institutions" className="text-[12px] font-medium text-[var(--primary)] hover:underline">
        All institutions
      </Link>
      <PageHeader
        title={item.name}
        description={`${item.city}, ${item.state} · ${item.type}`}
        actions={
          role === 'admin' && item.shortfall > 0 ? (
            <Button type="button" variant="outline" asChild>
              <Link to={`/notices?tab=shortfall&institution_id=${institutionId}`}>Shortfall notice</Link>
            </Button>
          ) : null
        }
      />
      <dl className="grid grid-cols-2 gap-3 rounded-[8px] border border-[var(--line)] bg-white p-4 sm:grid-cols-4">
        <Fact label="AICTE ID">
          <span className="font-mono tabular-nums">{item.aicte_id}</span>
        </Fact>
        <Fact label="Deposits">
          <span className="font-mono tabular-nums">{item.fdr_count}</span>
        </Fact>
        <Fact label="Required">
          <Money amount={item.required_deposit} />
        </Fact>
        <Fact label="Held">
          <Money amount={held} />
        </Fact>
        <Fact label="Shortfall">
          <Money
            amount={item.shortfall}
            className={item.shortfall > 0 ? 'text-[var(--risk)]' : 'text-[var(--ink-2)]'}
          />
        </Fact>
        <Fact label="Health">
          {item.health_score == null ? (
            <span className="text-[var(--ink-3)]">No open deposit</span>
          ) : (
            <HealthBar score={item.health_score} />
          )}
        </Fact>
        <Fact label="Bank-confirmed">
          <span className="font-mono tabular-nums">
            {item.fdrs.filter((fdr) => fdr.verification === 'bank_confirmed').length.toLocaleString('en-IN')}
          </span>
        </Fact>
        {observations !== undefined && (
          <Fact label="Open observations">
            <span className="font-mono tabular-nums">
              {observations == null ? '—' : observations.toLocaleString('en-IN')}
            </span>
          </Fact>
        )}
        {users !== undefined && users != null && (
          <Fact label="Users">
            <span className="font-mono tabular-nums">{users.toLocaleString('en-IN')}</span>
          </Fact>
        )}
      </dl>
      <p className="text-[12px] text-[var(--ink-3)]">
        Held is pending approval, approved and release requested. Shortfall is required minus held.
      </p>
      {item.fdrs.length === 0 ? (
        <EmptyState
          message="This institution has no deposits."
          actionLabel="All institutions"
          onAction={() => navigate('/institutions')}
        />
      ) : (
        <DataTable
          columns={columns}
          data={item.fdrs}
          onRowClick={(row) => navigate(`/deposits/${row.id}`)}
        />
      )}

      <section className="flex flex-col gap-2">
        <h2 className="text-[16px] font-semibold text-[var(--ink)]">Notices</h2>
        {queryFailed(notices) ? (
          <ErrorState error={notices.error} message={offlineNotice()} onRetry={() => notices.refetch()} />
        ) : notices.isLoading ? (
          <Skeleton className="h-20 w-full" />
        ) : (notices.data?.length ?? 0) === 0 ? (
          <EmptyState message="No notices have been issued for this institution." />
        ) : (
          <ul className="overflow-hidden rounded-[8px] border border-[var(--line)] bg-white">
            {notices.data?.map((notice, index) => (
              <li
                key={notice.id}
                className={`flex flex-col gap-2 px-3 py-2 sm:flex-row sm:items-center sm:justify-between ${
                  index > 0 ? 'border-t border-[var(--line)]' : ''
                }`}
              >
                <div className="min-w-0">
                  <p className="font-mono text-[13px] tabular-nums text-[var(--ink)]">{notice.reference_no}</p>
                  <p className="text-[12px] text-[var(--ink-3)]">
                    {notice.kind_label}
                    {notice.fdr_number ? ` · ${notice.fdr_number}` : ''}
                    {' · '}
                    {formatDate(notice.issued_at)}
                    {' · '}
                    {notice.issued_by}
                  </p>
                </div>
                <Link
                  to={`/notices?notice=${notice.id}`}
                  className="shrink-0 text-[13px] font-medium text-[var(--primary)] hover:underline"
                >
                  View letter
                </Link>
              </li>
            ))}
          </ul>
        )}
      </section>
    </div>
  );
}
