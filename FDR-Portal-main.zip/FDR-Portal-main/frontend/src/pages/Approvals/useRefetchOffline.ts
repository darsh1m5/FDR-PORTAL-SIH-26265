import { useEffect } from 'react';

export function queryFailed(query: { isError: boolean; isRefetchError: boolean; isPaused: boolean }) {
  return query.isError || query.isRefetchError || query.isPaused;
}

export function offlineNotice() {
  return typeof navigator !== 'undefined' && navigator.onLine === false
    ? 'You are offline. Reconnect and try again.'
    : undefined;
}

export function useRefetchOffline(refetch: () => unknown) {
  useEffect(() => {
    const onOffline = () => {
      void refetch();
    };
    window.addEventListener('offline', onOffline);
    return () => window.removeEventListener('offline', onOffline);
  }, [refetch]);
}
