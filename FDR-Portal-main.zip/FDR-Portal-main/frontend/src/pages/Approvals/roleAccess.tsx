import type { Role, User } from '@/lib/types';
import { PageHeader } from '@/components/shared/PageHeader';
import { EmptyState } from '@/components/shared/EmptyState';

export function RoleUnavailable({ title }: { title: string }) {
  return (
    <div className="flex min-w-0 flex-col gap-4">
      <PageHeader title={title} description="Not available for your role." />
      <EmptyState message="Not available for your role." />
    </div>
  );
}

export function isInstitution(role: Role | null | undefined) {
  return role === 'institution';
}

export function canAcknowledge(role: Role | null | undefined) {
  return role != null && role !== 'auditor';
}

export function ownInstitution(user: User | null) {
  if (!user || user.role !== 'institution') return null;
  return {
    id: typeof user.institution_id === 'number' ? user.institution_id : null,
    name: user.institution_name ?? null,
  };
}

export function visibleToInstitution(
  user: User | null,
  record: { institution_id?: number | null; institution_name?: string | null }
) {
  const own = ownInstitution(user);
  if (!own) return true;
  if (own.id != null && record.institution_id != null) return own.id === record.institution_id;
  if (own.name && record.institution_name) return own.name === record.institution_name;
  return false;
}

export function optionalNumber(source: object | null | undefined, key: string): number | null | undefined {
  if (!source || !(key in source)) return undefined;
  const value = (source as Record<string, unknown>)[key];
  if (value == null) return null;
  return typeof value === 'number' && Number.isFinite(value) ? value : undefined;
}
