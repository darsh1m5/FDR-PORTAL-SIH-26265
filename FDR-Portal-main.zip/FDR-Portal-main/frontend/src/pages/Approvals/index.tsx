import { useMemo, useRef, useState, type ReactNode } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ApiError, api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { formatDate, formatDateTime, formatRate, PURPOSE_LABELS } from '@/lib/format';
import type { ApprovalsItem, ApprovalsResponse, FindingGroup, ReleaseChecklist, Settings } from '@/lib/types';
import { isInstitution, RoleUnavailable } from './roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { DataTable, type Column } from '@/components/shared/DataTable';
import { StatusPill } from '@/components/shared/StatusPill';
import { MaturityChip } from '@/components/shared/MaturityChip';
import { Money } from '@/components/shared/Money';
import { ErrorState } from '@/components/shared/ErrorState';
import { EmptyState } from '@/components/shared/EmptyState';
import { offlineNotice, queryFailed, useRefetchOffline } from './useRefetchOffline';
import { ConfirmDialog } from '@/components/shared/ConfirmDialog';
import { Button } from '@/components/ui/button';
import {
  Sheet,
  SheetContent,
  SheetDescription,
  SheetFooter,
  SheetHeader,
  SheetTitle,
} from '@/components/ui/sheet';
import { cn } from '@/lib/utils';

const DEFAULT_SLA_DAYS = 7;

function kindLabel(kind: ApprovalsItem['kind']) {
  return kind === 'release' ? 'Release requested' : 'Pending approval';
}

function KindPill({ kind }: { kind: ApprovalsItem['kind'] }) {
  const release = kind === 'release';
  return (
    <span
      className={cn(
        'inline-flex h-[22px] items-center rounded-full px-2.5 text-[12px] font-medium',
        release
          ? 'bg-[var(--violet-bg)] text-[var(--violet)]'
          : 'bg-[var(--primary-soft)] text-[var(--primary)]'
      )}
    >
      {kindLabel(kind)}
    </span>
  );
}

function Fact({ label, children }: { label: string; children: ReactNode }) {
  return (
    <div className="flex flex-col gap-0.5">
      <dt className="text-[12px] font-medium text-[var(--ink-2)]">{label}</dt>
      <dd className="text-[13px] text-[var(--ink)]">{children}</dd>
    </div>
  );
}

const CHECKLIST_LINES: { key: keyof ReleaseChecklist; label: string }[] = [
  { key: 'affidavit_received', label: 'Affidavit received' },
  { key: 'no_pending_complaints', label: 'No pending complaints' },
  { key: 'institution_closure_certificate', label: 'Closure certificate' },
  { key: 'matured_or_lock_in_complete', label: 'Matured or lock-in complete' },
  { key: 'bank_discharge_noted', label: 'Bank discharge noted' },
];

function missingChecklist(list: ReleaseChecklist) {
  return CHECKLIST_LINES.filter((line) => list[line.key] === false).map((line) => line.label);
}

const SEVERITY_RANK: Record<string, number> = { critical: 0, warning: 1, info: 2 };

function topFinding(groups: FindingGroup[] | undefined, fdrId: number) {
  const group = groups?.find((item) => item.fdr_id === fdrId);
  if (!group || group.findings.length === 0) return null;
  const ranked = [...group.findings].sort(
    (a, b) => (SEVERITY_RANK[a.severity] ?? 9) - (SEVERITY_RANK[b.severity] ?? 9)
  );
  return ranked[0]?.message ?? null;
}

function whyWaiting(item: ApprovalsItem, sla: number) {
  if (item.kind === 'release') {
    const missing = releaseBlockReason(item);
    if (missing) return missing;
    return 'Waiting for sanction';
  }
  if (item.waiting_days > sla) return `Past the ${sla}-day review limit`;
  return item.reason || 'Waiting for a reviewer';
}

function releaseBlockReason(item: ApprovalsItem): string | null {
  if (item.kind !== 'release' || item.release_checklist == null) return null;
  const missing = missingChecklist(item.release_checklist);
  if (item.release_ready === false || missing.length > 0) {
    return missing.length > 0 ? `Missing: ${missing.join(', ')}` : 'Release checklist incomplete.';
  }
  return null;
}

function ChecklistMark({ value }: { value: boolean | null }) {
  if (value == null) {
    return <span className="text-[13px] text-[var(--ink-3)]">Not applicable</span>;
  }
  return (
    <span
      className={value ? 'text-[13px] font-medium text-[var(--ok)]' : 'text-[13px] font-medium text-[var(--risk)]'}
      aria-label={value ? 'Recorded' : 'Missing'}
    >
      {value ? 'Yes' : 'Missing'}
    </span>
  );
}

function ReleaseChecklistPanel({ item }: { item: ApprovalsItem }) {
  const list = item.release_checklist;
  if (list == null) {
    return <p className="text-[13px] text-[var(--ink-2)]">Checklist not recorded</p>;
  }
  const missing = missingChecklist(list);
  const complete = item.release_ready !== false && missing.length === 0;
  return (
    <div className="flex flex-col gap-2 rounded-[8px] border border-[var(--line)] p-3">
      <p className="text-[12px] font-medium uppercase tracking-[0.06em] text-[var(--ink-3)]">Release checklist</p>
      <ul className="flex flex-col gap-1.5">
        {CHECKLIST_LINES.map((line) => (
          <li key={line.key} className="flex items-center justify-between gap-3 text-[13px]">
            <span>{line.label}</span>
            <ChecklistMark value={list[line.key]} />
          </li>
        ))}
      </ul>
      <p className={complete ? 'text-[13px] font-medium text-[var(--ok)]' : 'text-[13px] font-medium text-[var(--risk)]'}>
        {complete ? 'Checklist complete' : missing.length > 0 ? `Missing: ${missing.join(', ')}` : 'Release checklist incomplete.'}
      </p>
    </div>
  );
}

export default function ApprovalsPage() {
  const { role, user } = useAuth();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const isReviewer = role === 'reviewer';
  const isApprover = role === 'approver';
  const [sortRisk, setSortRisk] = useState(false);
  const [lateOnly, setLateOnly] = useState(false);
  const [selected, setSelected] = useState<ApprovalsItem | null>(null);
  const [dialog, setDialog] = useState<'approve' | 'reject' | null>(null);
  const [decisionNote, setDecisionNote] = useState<string | null>(null);
  const returnFocus = useRef<HTMLElement | null>(null);

  const queue = useQuery({
    queryKey: ['approvals', sortRisk ? 'risk' : 'waiting'],
    queryFn: () => api.get<ApprovalsResponse>(sortRisk ? '/approvals?sort=risk' : '/approvals'),
    enabled: !isInstitution(role),
  });
  useRefetchOffline(queue.refetch);
  const findings = useQuery({
    queryKey: queryKeys.findings(),
    queryFn: () => api.get<FindingGroup[]>('/findings'),
    enabled: sortRisk && !isInstitution(role),
  });

  const settings = useQuery({
    queryKey: queryKeys.settings,
    queryFn: () => api.get<Settings>('/settings'),
    enabled: !isInstitution(role),
  });

  const sla = settings.data?.pending_sla_days ?? DEFAULT_SLA_DAYS;
  const items = useMemo(() => {
    const filtered = (queue.data?.items ?? []).filter((item) => {
      if (isReviewer && item.kind !== 'approval') return false;
      if (isApprover && item.kind !== 'release') return false;
      if (lateOnly && item.waiting_days <= sla) return false;
      return true;
    });
    if (!sortRisk) return filtered;
    return [...filtered].sort((a, b) => {
      if (a.fdr.health_score !== b.fdr.health_score) return a.fdr.health_score - b.fdr.health_score;
      return b.waiting_days - a.waiting_days;
    });
  }, [isApprover, isReviewer, lateOnly, queue.data, sla, sortRisk]);

  function ownRelease(item: ApprovalsItem) {
    return isApprover && item.kind === 'release' && user?.name === item.requested_by;
  }

  const decide = useMutation({
    mutationFn: (body: { id: number; action: 'approve' | 'reject'; remark?: string }) =>
      api.post(`/fdrs/${body.id}/decision`, {
        action: body.action,
        remark: body.remark,
      }),
    onSuccess: async () => {
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: ['approvals'] }),
        queryClient.invalidateQueries({ queryKey: queryKeys.fdrs.all }),
        queryClient.invalidateQueries({ queryKey: queryKeys.dashboard }),
        queryClient.invalidateQueries({ queryKey: queryKeys.audit.all }),
        queryClient.invalidateQueries({ queryKey: ['alerts'] }),
        queryClient.invalidateQueries({ queryKey: queryKeys.institutions.all }),
      ]);
    },
  });

  const columns = useMemo<Column<ApprovalsItem>[]>(
    () => [
      {
        key: 'kind',
        header: 'Kind',
        width: '1%',
        className: 'whitespace-nowrap',
        cell: (item) => (
          <div className="flex flex-col gap-0.5">
            <KindPill kind={item.kind} />
            <span className="max-w-[220px] text-[12px] text-[var(--ink-3)]">{whyWaiting(item, sla)}</span>
          </div>
        ),
      },
      {
        key: 'fdr_number',
        header: 'FDR number',
        cell: (item) => (
          <span className="font-mono text-[13px] text-[var(--ink)]">{item.fdr.fdr_number}</span>
        ),
      },
      {
        key: 'institution',
        header: 'Institution',
        cell: (item) => item.fdr.institution_name,
      },
      {
        key: 'amount',
        header: 'Amount',
        align: 'right',
        cell: (item) => <Money amount={item.fdr.amount} />,
      },
      {
        key: 'waiting',
        header: 'Waiting',
        align: 'right',
        width: '90px',
        cell: (item) => (
          <span
            className={cn(
              'font-mono tabular-nums',
              item.waiting_days > sla && 'font-semibold text-[var(--warn)]'
            )}
          >
            {item.waiting_days} {item.waiting_days === 1 ? 'day' : 'days'}
          </span>
        ),
      },
      {
        key: 'requested_by',
        header: 'Requested by',
        cell: (item) => item.requested_by,
      },
      ...(sortRisk
        ? [
            {
              key: 'health',
              header: 'Health',
              align: 'right' as const,
              width: '72px',
              cell: (item: ApprovalsItem) => (
                <span className="font-mono tabular-nums">{item.fdr.health_score}</span>
              ),
            },
            {
              key: 'finding',
              header: 'Top finding',
              cell: (item: ApprovalsItem) => {
                const message = topFinding(findings.data, item.fdr.id);
                return (
                  <span className="block max-w-[240px] truncate text-[12px] text-[var(--ink-2)]" title={message ?? undefined}>
                    {message ?? '—'}
                  </span>
                );
              },
            },
          ]
        : []),
    ],
    [findings.data, sla, sortRisk]
  );

  function closeDialog() {
    const releaseDecision = isApprover && selected?.kind === 'release';
    const label = dialog === 'reject' ? (releaseDecision ? 'Return' : 'Reject') : releaseDecision ? 'Sanction release' : 'Approve';
    setDialog(null);
    requestAnimationFrame(() => {
      const button = [...document.querySelectorAll('[role=dialog] button')].find(
        (candidate) => candidate.textContent?.trim() === label
      );
      if (button instanceof HTMLElement) button.focus();
    });
  }

  const lateCount = items.filter((item) => item.waiting_days > sla).length;
  const fdr = selected?.fdr;

  async function onConfirm(remark?: string) {
    if (!selected || !dialog) return;
    const action = dialog;
    try {
      await decide.mutateAsync({ id: selected.fdr.id, action, remark });
      const release = selected.kind === 'release';
      const message =
        action === 'approve'
          ? release
            ? `Release of ${selected.fdr.fdr_number} sanctioned.`
            : `${selected.fdr.fdr_number} approved.`
          : release
            ? `Release of ${selected.fdr.fdr_number} returned.`
            : `${selected.fdr.fdr_number} rejected.`;
      toast.success(message);
      setDialog(null);
      setSelected(null);
    } catch (err) {
      const raw = err instanceof ApiError ? err.detail : 'Decision could not be saved.';
      const detail = raw.toLowerCase().includes('cannot sanction')
        ? 'You requested this release; another officer must sanction it.'
        : raw;
      toast.error(detail);
      if (err instanceof ApiError && err.status === 409) setDecisionNote(detail);
    }
  }

  if (isInstitution(role)) {
    return <RoleUnavailable title="Approvals" />;
  }

  const releaseDecision = isApprover && selected?.kind === 'release';
  const emptyMessage = lateOnly
    ? 'Nothing is past the review limit.'
    : isApprover
    ? 'No release requests are waiting.'
    : isReviewer
      ? 'No submissions are waiting for a decision.'
      : 'No deposits are waiting for a decision.';

  return (
    <div className="flex flex-col gap-4">
      <PageHeader
        title="Approvals"
        description={
          isApprover
            ? 'Release requests waiting for sanction.'
            : isReviewer
              ? 'Submissions waiting for a decision.'
              : 'Submissions and release requests on the queue.'
        }
        actions={
          <div className="flex flex-wrap items-center justify-end gap-2">
            <Button
              type="button"
              variant="outline"
              aria-pressed={lateOnly}
              className={lateOnly ? 'border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]' : undefined}
              onClick={() => setLateOnly((current) => !current)}
            >
              Past the review limit
            </Button>
            <Button
              type="button"
              variant={sortRisk ? 'default' : 'outline'}
              aria-pressed={sortRisk}
              onClick={() => setSortRisk((current) => !current)}
            >
              Sort by risk
            </Button>
          </div>
        }
      />

      {role === 'admin' && (
        <p className="rounded-[8px] border border-[var(--line)] bg-[var(--surface-2)] px-3 py-2 text-[13px] text-[var(--ink-2)]">
          Reviewers decide submissions. The Competent Authority sanctions release requests. Administrators can open a deposit, and cannot decide it here.
        </p>
      )}
      {role === 'auditor' && (
        <p className="rounded-[8px] border border-[var(--line)] bg-[var(--surface-2)] px-3 py-2 text-[13px] text-[var(--ink-2)]">
          You can read this queue. You cannot approve, reject, sanction or return a request.
        </p>
      )}

      {queryFailed(queue) ? (
        <ErrorState error={queue.error} message={offlineNotice()} onRetry={() => queue.refetch()} />
      ) : queue.isLoading ? (
        <DataTable columns={columns} data={[]} isLoading />
      ) : items.length === 0 ? (
        <EmptyState
          message={emptyMessage}
          actionLabel={lateOnly ? 'Show the whole queue' : 'Open the register'}
          onAction={() => (lateOnly ? setLateOnly(false) : navigate('/deposits'))}
        />
      ) : (
        <>
          <DataTable
            columns={columns}
            data={items}
            onRowClick={(item) => {
              const row = [...document.querySelectorAll('main tbody tr')].find((candidate) =>
                candidate.textContent?.includes(item.fdr.fdr_number)
              );
              if (row instanceof HTMLElement) {
                row.tabIndex = -1;
                row.focus();
                returnFocus.current = row;
              }
              setDecisionNote(null);
              setSelected(item);
            }}
            total={items.length}
            page={1}
            pageSize={Math.max(items.length, 1)}
            onPageChange={() => undefined}
          />
          {lateCount > 0 && (
            <p className="text-[12px] text-[var(--warn)]">
              {lateCount} waiting past the {sla}-day review limit.
            </p>
          )}
        </>
      )}

      <Sheet
        open={selected !== null}
        onOpenChange={(open) => {
          if (!open) {
            setSelected(null);
            setDecisionNote(null);
          }
        }}
      >
        <SheetContent
          side="right"
          className="flex w-full flex-col sm:max-w-md"
          onCloseAutoFocus={(event) => {
            if (!returnFocus.current) return;
            event.preventDefault();
            returnFocus.current.focus();
          }}
        >
          {selected && fdr && (
            <>
              <SheetHeader>
                <SheetTitle className="font-mono text-[16px]">{fdr.fdr_number}</SheetTitle>
                <SheetDescription>{fdr.institution_name}</SheetDescription>
              </SheetHeader>

              <div className="flex flex-1 flex-col gap-4 overflow-y-auto py-4">
                <div className="flex flex-wrap items-center gap-2">
                  <KindPill kind={selected.kind} />
                  <StatusPill status={fdr.status} />
                  <MaturityChip days={fdr.days_to_maturity} state={fdr.maturity_state} />
                </div>
                <p className="text-[13px] text-[var(--ink-2)]">{whyWaiting(selected, sla)}</p>

                <dl className="grid grid-cols-2 gap-3">
                  <Fact label="Bank">{fdr.bank_name}</Fact>
                  <Fact label="Amount">
                    <Money amount={fdr.amount} />
                  </Fact>
                  <Fact label="Interest">{formatRate(fdr.interest_rate)} p.a.</Fact>
                  <Fact label="Purpose">{PURPOSE_LABELS[fdr.purpose]}</Fact>
                  <Fact label="Issued">{formatDate(fdr.issue_date)}</Fact>
                  <Fact label="Matures">{formatDate(fdr.maturity_date)}</Fact>
                  <Fact label="Findings">{fdr.findings_count}</Fact>
                  <Fact label="Documents">{fdr.document_count}</Fact>
                  <Fact label="Requested by">{selected.requested_by}</Fact>
                  <Fact label="Waiting">
                    <span className={cn(selected.waiting_days > sla && 'font-semibold text-[var(--warn)]')}>
                      {selected.waiting_days} {selected.waiting_days === 1 ? 'day' : 'days'}
                    </span>
                  </Fact>
                </dl>

                <p className="text-[12px] text-[var(--ink-3)]">
                  Requested {formatDateTime(selected.requested_at)}
                </p>

                {selected.reason && (
                  <Fact label="Note">{selected.reason}</Fact>
                )}

                <Link
                  to={`/deposits/${fdr.id}`}
                  className="text-[13px] font-medium text-[var(--primary)] hover:underline"
                >
                  Open full record
                </Link>

                {selected.kind === 'release' && <ReleaseChecklistPanel item={selected} />}
              </div>

              {((isReviewer && selected.kind === 'approval') || (isApprover && selected.kind === 'release')) && (
                <SheetFooter className="gap-2 sm:flex-col sm:items-stretch">
                  {(() => {
                    const missing = isApprover ? releaseBlockReason(selected) : null;
                    const selfRequested = ownRelease(selected)
                      ? 'You requested this release; another officer must sanction it.'
                      : null;
                    const blocked = decisionNote ?? selfRequested ?? missing;
                    return (
                      <>
                        {blocked && (
                          <p className="text-[12px] text-[var(--risk)]">{blocked}</p>
                        )}
                        <div className="flex justify-end gap-2">
                          <Button
                            type="button"
                            variant="outline"
                            disabled={selfRequested != null}
                            onClick={() => setDialog('reject')}
                          >
                            {releaseDecision ? 'Return' : 'Reject'}
                          </Button>
                          <Button
                            type="button"
                            disabled={missing != null || selfRequested != null}
                            onClick={() => setDialog('approve')}
                          >
                            {releaseDecision ? 'Sanction release' : 'Approve'}
                          </Button>
                        </div>
                      </>
                    );
                  })()}
                </SheetFooter>
              )}
            </>
          )}
        </SheetContent>
      </Sheet>

      <ConfirmDialog
        open={dialog === 'approve'}
        onOpenChange={(open) => !open && closeDialog()}
        title={releaseDecision ? 'Sanction release' : 'Approve deposit'}
        description="The decision is written to the audit log."
        confirmLabel={releaseDecision ? 'Sanction release' : 'Approve'}
        showRemark
        remarkLabel="Remark"
        remarkPlaceholder="Optional note for the audit log"
        isLoading={decide.isPending}
        onConfirm={onConfirm}
      />
      <ConfirmDialog
        open={dialog === 'reject'}
        onOpenChange={(open) => !open && closeDialog()}
        title={releaseDecision ? 'Return release' : 'Reject deposit'}
        description={
          releaseDecision
            ? 'A remark is required. The deposit returns to Approved.'
            : 'A remark is required. The deposit stays on record.'
        }
        confirmLabel={releaseDecision ? 'Return' : 'Reject'}
        variant="destructive"
        requireRemark
        remarkLabel="Remark"
        remarkPlaceholder={
          releaseDecision ? 'Why this release is being returned' : 'Why this request is being rejected'
        }
        isLoading={decide.isPending}
        onConfirm={onConfirm}
      />
    </div>
  );
}
