import React, { useState, useRef } from 'react';
import { Link } from 'react-router-dom';
import {
  Upload,
  Download,
  FileSpreadsheet,
  CheckCircle2,
  AlertTriangle,
  XCircle,
  ArrowRight,
  RefreshCw,
  Info,
} from 'lucide-react';
import { toast } from 'sonner';

import { api, apiDownload } from '@/lib/api';
import { inr, formatDate } from '@/lib/format';
import type { ImportPreview, ImportCommitResponse, FdrInput } from '@/lib/types';
import { PageHeader } from '@/components/shared/PageHeader';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

export default function ImportsPage() {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const [isDragging, setIsDragging] = useState(false);
  const [isPreviewing, setIsPreviewing] = useState(false);
  const [isCommitting, setIsCommitting] = useState(false);
  const [previewError, setPreviewError] = useState<string | null>(null);
  const [preview, setPreview] = useState<ImportPreview | null>(null);
  const [commitResult, setCommitResult] = useState<ImportCommitResponse | null>(null);

  // Download template
  const handleDownloadTemplate = async () => {
    try {
      await apiDownload('/imports/template.csv', 'fdr-import-template.csv');
      toast.success('Import template downloaded');
    } catch {
      toast.error('Failed to download template');
    }
  };

  // Process and preview file
  const processFile = async (file: File) => {
    if (!file) return;

    if (!file.name.toLowerCase().endsWith('.csv')) {
      toast.error('Only CSV spreadsheet files (.csv) are accepted');
      return;
    }

    if (file.size > 2 * 1024 * 1024) {
      toast.error('File size exceeds the 2 MB limit');
      return;
    }

    setSelectedFile(file);
    setCommitResult(null);
    setPreviewError(null);
    setIsPreviewing(true);

    const formData = new FormData();
    formData.append('file', file);

    try {
      const res = await api.post<ImportPreview>('/imports/preview', formData);
      setPreview(res);
      toast.success(`Parsed ${res.rows.length} rows from ${file.name}`);
    } catch (err: any) {
      const msg = err?.detail || err?.message || 'Failed to preview spreadsheet';
      setPreviewError(msg);
      toast.error(msg);
      setPreview(null);
    } finally {
      setIsPreviewing(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) await processFile(file);
  };

  // Commit valid rows
  const handleCommit = async () => {
    if (!preview || !selectedFile) return;

    // Filter to valid and warning rows (rows with valid data object)
    const validRows: FdrInput[] = preview.rows
      .filter((r) => (r.status === 'valid' || r.status === 'warning') && r.data !== null)
      .map((r) => r.data!);

    if (validRows.length === 0) {
      toast.error('No valid rows available to import');
      return;
    }

    setIsCommitting(true);
    try {
      const res = await api.post<ImportCommitResponse>('/imports/commit', {
        rows: validRows,
        source_name: selectedFile.name,
      });
      setCommitResult(res);
      toast.success(`Imported ${res.created} records as drafts`);
    } catch (err: any) {
      toast.error(err?.detail || err?.message || 'Failed to commit import rows');
    } finally {
      setIsCommitting(false);
    }
  };

  const resetAll = () => {
    setSelectedFile(null);
    setPreview(null);
    setPreviewError(null);
    setCommitResult(null);
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const importableCount = preview ? preview.valid_count + preview.warning_count : 0;

  return (
    <div className="space-y-6">
      <PageHeader
        title="Spreadsheet Import"
        description="Upload batch deposit schedules from spreadsheets into draft registers"
        actions={
          <Button
            variant="outline"
            size="sm"
            onClick={handleDownloadTemplate}
            className="text-xs gap-1.5"
          >
            <Download className="h-3.5 w-3.5" />
            <span>Download Template (CSV)</span>
          </Button>
        }
      />

      {/* Success banner after commit */}
      {commitResult && (
        <div className="rounded-[8px] border border-[#A6F4C5] bg-[#ECFDF3] p-5 space-y-3">
          <div className="flex items-start gap-3">
            <CheckCircle2 className="h-5 w-5 text-[#027A48] shrink-0 mt-0.5" />
            <div className="space-y-1">
              <h3 className="text-sm font-semibold text-[#027A48]">
                Batch Import Completed
              </h3>
              <p className="text-xs text-[#054F31]">
                Successfully created <strong>{commitResult.created} deposit records</strong> as drafts under batch reference{' '}
                <span className="font-mono font-medium">{commitResult.batch}</span>.
              </p>
            </div>
          </div>
          <div className="flex items-center gap-3 pt-2">
            <Link to="/deposits?status=draft">
              <Button size="sm" className="text-xs gap-1.5">
                <span>View Drafts in Register</span>
                <ArrowRight className="h-3.5 w-3.5" />
              </Button>
            </Link>
            <Button
              variant="outline"
              size="sm"
              onClick={resetAll}
              className="text-xs"
            >
              Import Another File
            </Button>
          </div>
        </div>
      )}

      {/* Upload Zone (shown when no commit result) */}
      {!commitResult && (
        <div
          role="button"
          tabIndex={0}
          aria-label="Upload CSV spreadsheet"
          onDragOver={(e) => {
            e.preventDefault();
            setIsDragging(true);
          }}
          onDragLeave={() => setIsDragging(false)}
          onDrop={(e) => {
            e.preventDefault();
            setIsDragging(false);
            const file = e.dataTransfer.files?.[0];
            if (file) processFile(file);
          }}
          onKeyDown={(e) => {
            if (e.key === 'Enter' || e.key === ' ') {
              e.preventDefault();
              fileInputRef.current?.click();
            }
          }}
          className={`rounded-[8px] border-2 border-dashed p-6 text-center transition-colors focus:outline-none focus-visible:ring-2 focus-visible:ring-[var(--primary)] cursor-pointer ${
            isDragging
              ? 'border-[var(--primary)] bg-[var(--surface-2)] ring-2 ring-[var(--primary)]/20'
              : 'border-[var(--line)] bg-[var(--surface-1)] hover:bg-[var(--surface-2)]/60'
          }`}
        >
          <input
            type="file"
            ref={fileInputRef}
            onChange={handleFileChange}
            accept=".csv"
            className="hidden"
          />
          <div className="mx-auto flex h-12 w-12 items-center justify-center rounded-full bg-[var(--surface-2)] mb-3">
            <FileSpreadsheet className="h-6 w-6 text-[var(--primary)]" />
          </div>
          <h3 className="text-sm font-semibold text-[var(--ink)]">
            {selectedFile ? selectedFile.name : 'Select or drag spreadsheet file to validate'}
          </h3>
          <p className="text-xs text-[var(--ink-3)] mt-1 max-w-md mx-auto">
            Upload CSV up to 2 MB and 500 rows. Bank names or short forms (SBI, BoB, PNB, HDFC) and standard Indian date formats are accepted.
          </p>
          <div className="mt-4 flex items-center justify-center gap-3">
            <Button
              size="sm"
              disabled={isPreviewing}
              onClick={(e) => {
                e.stopPropagation();
                fileInputRef.current?.click();
              }}
              className="text-xs gap-1.5"
            >
              <Upload className="h-3.5 w-3.5" />
              <span>{isPreviewing ? 'Validating spreadsheet...' : selectedFile ? 'Choose another file' : 'Browse CSV File'}</span>
            </Button>
            {selectedFile && (
              <Button
                variant="ghost"
                size="sm"
                onClick={(e) => {
                  e.stopPropagation();
                  resetAll();
                }}
                className="text-xs text-[var(--ink-3)]"
              >
                Clear
              </Button>
            )}
          </div>
        </div>
      )}

      {/* Validation Error Banner */}
      {previewError && !preview && (
        <div className="rounded-[8px] border border-[#FECDCA] bg-[#FEF3F2] p-4 text-xs text-[#B42318] flex items-start justify-between gap-3">
          <div className="flex items-start gap-2.5">
            <XCircle className="h-4 w-4 shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold block">Spreadsheet Validation Error</span>
              <span className="mt-0.5 block">{previewError}</span>
            </div>
          </div>
          <Button
            variant="outline"
            size="sm"
            onClick={() => {
              if (selectedFile) processFile(selectedFile);
            }}
            className="text-xs shrink-0 border-[#FECDCA] hover:bg-white"
          >
            Retry Validation
          </Button>
        </div>
      )}

      {/* Loading Skeleton */}
      {isPreviewing && (
        <div className="space-y-4 pt-2">
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
          <div className="rounded-[8px] border border-[var(--line)] bg-white p-4 space-y-3">
            <div className="flex items-center justify-between">
              <Skeleton className="h-4 w-48" />
              <Skeleton className="h-8 w-40" />
            </div>
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
            <Skeleton className="h-10 w-full" />
          </div>
        </div>
      )}

      {/* Preview Section */}
      {preview && !commitResult && (
        <div className="space-y-4">
          {/* Summary counts */}
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
            <div className="rounded-[6px] border border-[var(--line)] bg-[var(--surface-1)] p-3">
              <span className="text-[11px] font-medium text-[var(--ink-3)] block">Total Rows</span>
              <span className="text-xl font-semibold font-mono text-[var(--ink)] mt-0.5 block">
                {preview.rows.length}
              </span>
            </div>
            <div className="rounded-[6px] border border-[#A6F4C5] bg-[#ECFDF3] p-3">
              <span className="text-[11px] font-medium text-[#027A48] block">Valid Rows</span>
              <span className="text-xl font-semibold font-mono text-[#027A48] mt-0.5 block">
                {preview.valid_count}
              </span>
            </div>
            <div className="rounded-[6px] border border-[#FEDF89] bg-[#FFFAEB] p-3">
              <span className="text-[11px] font-medium text-[#B54708] block">Warning Rows</span>
              <span className="text-xl font-semibold font-mono text-[#B54708] mt-0.5 block">
                {preview.warning_count}
              </span>
            </div>
            <div className="rounded-[6px] border border-[#FECDCA] bg-[#FEF3F2] p-3">
              <span className="text-[11px] font-medium text-[#B42318] block">Error Rows</span>
              <span className="text-xl font-semibold font-mono text-[#B42318] mt-0.5 block">
                {preview.error_count}
              </span>
            </div>
          </div>

          {/* Action Header */}
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 p-3 rounded-[6px] bg-[var(--surface-2)] border border-[var(--line)]">
            <div className="text-xs text-[var(--ink-2)]">
              {preview.valid_count} ready, {preview.warning_count} with a warning, {preview.error_count} with errors.
              {preview.error_count > 0 && ' Rows with errors are not imported.'}
            </div>
            <Button
              size="sm"
              disabled={importableCount === 0 || isCommitting}
              onClick={handleCommit}
              className="text-xs gap-1.5 shrink-0"
            >
              {isCommitting ? (
                <>
                  <RefreshCw className="h-3.5 w-3.5 animate-spin" />
                  <span>Importing...</span>
                </>
              ) : (
                <>
                  <CheckCircle2 className="h-3.5 w-3.5" />
                  <span>Import {importableCount} rows as drafts</span>
                </>
              )}
            </Button>
          </div>

          {/* Preview Table */}
          <div className="rounded-[8px] border border-[var(--line)] bg-[var(--surface-1)] overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-xs text-left border-collapse">
                <thead>
                  <tr className="border-b border-[var(--line)] bg-[var(--surface-2)] text-[var(--ink-3)] uppercase font-semibold text-[10px] tracking-wider">
                    <th className="py-2.5 px-3 w-12 text-center">Row</th>
                    <th className="py-2.5 px-3 w-24">Status</th>
                    <th className="py-2.5 px-3">FDR Number</th>
                    <th className="py-2.5 px-3">Institution</th>
                    <th className="py-2.5 px-3">Bank</th>
                    <th className="py-2.5 px-3 text-right">Amount</th>
                    <th className="py-2.5 px-3">Maturity</th>
                    <th className="py-2.5 px-3">Findings &amp; Errors</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-[var(--line)]">
                  {preview.rows.map((row) => {
                    const statusConfig = {
                      valid: {
                        bg: 'bg-[#ECFDF3]',
                        text: 'text-[#027A48]',
                        border: 'border-[#A6F4C5]',
                        label: 'Valid',
                        icon: CheckCircle2,
                      },
                      warning: {
                        bg: 'bg-[#FFFAEB]',
                        text: 'text-[#B54708]',
                        border: 'border-[#FEDF89]',
                        label: 'Warning',
                        icon: AlertTriangle,
                      },
                      error: {
                        bg: 'bg-[#FEF3F2]',
                        text: 'text-[#B42318]',
                        border: 'border-[#FECDCA]',
                        label: 'Error',
                        icon: XCircle,
                      },
                    }[row.status];
                    const StatusIcon = statusConfig.icon;

                    return (
                      <tr
                        key={row.row}
                        className={`hover:bg-[var(--surface-2)] transition-colors ${
                          row.status === 'error' ? 'bg-[#FEF3F2]/30' : ''
                        }`}
                      >
                        <td className="py-2.5 px-3 font-mono text-[var(--ink-3)] text-center">
                          {row.row}
                        </td>
                        <td className="py-2.5 px-3 whitespace-nowrap">
                          <span
                            className={`inline-flex items-center gap-1 px-1.5 py-0.5 rounded-[4px] border text-[11px] font-medium ${statusConfig.bg} ${statusConfig.text} ${statusConfig.border}`}
                          >
                            <StatusIcon className="h-3 w-3" />
                            {statusConfig.label}
                          </span>
                        </td>
                        <td className="py-2.5 px-3 font-mono font-medium text-[var(--ink)] whitespace-nowrap">
                          {row.data?.fdr_number || '—'}
                        </td>
                        <td className="py-2.5 px-3 text-[var(--ink)] max-w-[200px] truncate" title={row.institution_name || ''}>
                          {row.institution_name || '—'}
                        </td>
                        <td className="py-2.5 px-3 text-[var(--ink-2)]">
                          {row.data?.bank_name || '—'}
                        </td>
                        <td className="py-2.5 px-3 font-mono text-right text-[var(--ink)]">
                          {row.data ? inr(row.data.amount) : '—'}
                        </td>
                        <td className="py-2.5 px-3 text-[var(--ink-2)] whitespace-nowrap font-mono text-[11px]">
                          {row.data ? formatDate(row.data.maturity_date) : '—'}
                        </td>
                        <td className="py-2.5 px-3 max-w-[300px]">
                          {row.errors.length > 0 ? (
                            <div className="space-y-1">
                              {row.errors.map((err, i) => (
                                <div key={i} className="flex items-start gap-1 text-[11px] text-[#B42318]">
                                  <XCircle className="h-3 w-3 shrink-0 mt-0.5" />
                                  <span>{err}</span>
                                </div>
                              ))}
                            </div>
                          ) : row.findings.length > 0 ? (
                            <div className="space-y-1">
                              {row.findings.map((f, i) => (
                                <div key={i} className="flex items-start gap-1 text-[11px] text-[#B54708]">
                                  <Info className="h-3 w-3 shrink-0 mt-0.5" />
                                  <span>{f.message}</span>
                                </div>
                              ))}
                            </div>
                          ) : (
                            <span className="text-[11px] text-[#027A48]">Ready to import</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
