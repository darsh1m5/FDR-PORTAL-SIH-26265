import { Fragment, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { SEVERITY_LABELS } from '@/lib/format';
import type { DashboardResponse, FindingGroup, FindingSeverity } from '@/lib/types';
import { isInstitution, RoleUnavailable } from '@/pages/Approvals/roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { KpiTile } from '@/components/shared/KpiTile';
import { HealthBar } from '@/components/shared/HealthBar';
import { StatusPill } from '@/components/shared/StatusPill';
import { EmptyState } from '@/components/shared/EmptyState';
import { ErrorState } from '@/components/shared/ErrorState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

const RULES: { code: string; severity: string; when: string; fix?: string }[] = [
  { code: 'DATE_ORDER', severity: 'Critical −30', when: 'Maturity date is on or before the issue date.' },
  { code: 'DUPLICATE_NUMBER', severity: 'Critical −30', when: 'Another deposit has the same FDR number and bank.' },
  { code: 'MATURED_UNRESOLVED', severity: 'Critical −30', when: 'Maturity has passed and the deposit is still approved.' },
  { code: 'DOCUMENT_REUSED', severity: 'Critical −30', when: 'The same file is attached to another FDR.', fix: 'Remove the duplicate and upload the receipt that belongs to this deposit.' },
  { code: 'BELOW_REQUIRED', severity: 'Warning −12', when: 'The institution’s held deposits are under the required amount.' },
  { code: 'NO_LIEN', severity: 'Warning −12', when: 'Lien in favour of AICTE is not marked.' },
  { code: 'NO_DOCUMENT', severity: 'Warning −12', when: 'No FDR receipt is attached.' },
  { code: 'RENEWAL_GAP', severity: 'Warning −12', when: 'Cover lapsed between the previous maturity and this issue date.', fix: 'Ask the institution to cover the days between the two deposits.' },
  { code: 'RENEWAL_AMOUNT_DROP', severity: 'Warning −12', when: 'The replacement amount is below the earlier deposit.', fix: 'Ask the institution to restore the earlier amount, or record why it is lower.' },
  { code: 'NO_LIEN_LETTER', severity: 'Note −4', when: 'Lien is marked, but no lien letter from the bank is attached.' },
  { code: 'BAD_IFSC', severity: 'Warning −12', when: 'IFSC is present and does not match the bank format.' },
  { code: 'VALUE_MISMATCH', severity: 'Warning −12', when: 'Printed maturity amount differs from the projected value by more than 1%.' },
  { code: 'RATE_OUT_OF_BAND', severity: 'Note −4', when: 'Interest rate is outside the settings band.' },
  { code: 'NOT_VERIFIED', severity: 'Note −4', when: 'An approved deposit is still marked submitted.' },
];

const RENEWAL_CODES = new Set(['RENEWAL_GAP', 'RENEWAL_AMOUNT_DROP']);

function scoreText(value: number | null | undefined) {
  if (value == null || Number.isNaN(value)) return '—';
  return Number.isInteger(value) ? String(value) : value.toFixed(1);
}

function countOf(findings: FindingGroup['findings'], severity: FindingSeverity) {
  return findings.filter((finding) => finding.severity === severity).length;
}

export default function HealthCheckPage() {
  const { role } = useAuth();
  const [severity, setSeverity] = useState<string>('all');
  const [open, setOpen] = useState<number[]>([]);
  const [byInstitution, setByInstitution] = useState(false);
  const [renewalOnly, setRenewalOnly] = useState(false);
  const [unverifiedOnly, setUnverifiedOnly] = useState(false);

  const findings = useQuery({
    queryKey: queryKeys.findings(),
    queryFn: () => api.get<FindingGroup[]>('/findings'),
    enabled: !isInstitution(role),
  });
  const dashboard = useQuery({
    queryKey: queryKeys.dashboard,
    queryFn: () => api.get<DashboardResponse>('/dashboard'),
    enabled: !isInstitution(role),
  });
  useRefetchOffline(findings.refetch);
  useRefetchOffline(dashboard.refetch);

  const groups = findings.data ?? [];
  const visible = useMemo(
    () =>
      groups.filter((group) => {
        if (severity !== 'all' && !group.findings.some((finding) => finding.severity === severity)) return false;
        if (renewalOnly && !group.findings.some((finding) => RENEWAL_CODES.has(finding.code))) return false;
        if (unverifiedOnly && !group.findings.some((finding) => finding.code === 'NOT_VERIFIED')) return false;
        return true;
      }),
    [groups, renewalOnly, severity, unverifiedOnly]
  );
  const blocks = useMemo(() => {
    if (!byInstitution) return [{ name: null as string | null, rows: visible }];
    const map = new Map<string, FindingGroup[]>();
    for (const row of visible) {
      const list = map.get(row.institution_name) ?? [];
      list.push(row);
      map.set(row.institution_name, list);
    }
    return [...map.entries()]
      .map(([name, rows]) => ({ name, rows }))
      .sort((a, b) => {
        const average = (rows: FindingGroup[]) =>
          rows.reduce((sum, row) => sum + row.health_score, 0) / rows.length;
        return average(a.rows) - average(b.rows);
      });
  }, [byInstitution, visible]);
  const criticalDeposits = groups.filter((group) =>
    group.findings.some((finding) => finding.severity === 'critical')
  ).length;
  const warningDeposits = groups.filter((group) =>
    group.findings.some((finding) => finding.severity === 'warning')
  ).length;

  function toggle(id: number) {
    setOpen((current) => (current.includes(id) ? current.filter((value) => value !== id) : [...current, id]));
  }

  if (isInstitution(role)) {
    return <RoleUnavailable title="Health Check" />;
  }

  return (
    <div className="flex min-w-0 flex-col gap-4">
      <PageHeader
        title="Health Check"
        description="Deposits with problems, worst score first."
        actions={
          <Popover>
            <PopoverTrigger asChild>
              <Button type="button" variant="outline">
                How the score works
              </Button>
            </PopoverTrigger>
            <PopoverContent align="end" className="max-h-[min(70vh,520px)] w-[380px] overflow-y-auto p-3">
              <p className="text-[13px] font-medium text-[var(--ink)]">Score</p>
              <p className="mt-1 text-[12px] text-[var(--ink-2)]">
                The score starts at 100. Each critical problem takes off 30, each warning 12, and each note 4. It does not go below 0. 85 and above is sound, 60 to 84 needs attention, below 60 is at risk.
              </p>
              <ul className="mt-3 flex flex-col gap-2">
                {RULES.map((rule) => (
                  <li key={rule.code} className="text-[12px]">
                    <span className="font-mono text-[var(--ink)]">{rule.code}</span>
                    <span className="text-[var(--ink-3)]"> · {rule.severity}</span>
                    <span className="mt-0.5 block text-[var(--ink-2)]">{rule.when}</span>
                    {rule.fix && <span className="mt-0.5 block text-[var(--ink-2)]">Fix: {rule.fix}</span>}
                  </li>
                ))}
              </ul>
            </PopoverContent>
          </Popover>
        }
      />

      {findings.isLoading ? (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
          <Skeleton className="h-24" />
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-3">
          <KpiTile
            label="Average score"
            value={scoreText(dashboard.data?.kpis.avg_health)}
            context="Open deposits"
          />
          <KpiTile
            label="Critical findings"
            value={String(criticalDeposits)}
            context="Deposits with a critical finding"
            valueColor={criticalDeposits > 0 ? 'text-[var(--risk)]' : undefined}
            onClick={() => setSeverity('critical')}
          />
          <KpiTile
            label="Warnings"
            value={String(warningDeposits)}
            context="Deposits with a warning"
            valueColor={warningDeposits > 0 ? 'text-[var(--warn)]' : undefined}
            onClick={() => setSeverity('warning')}
          />
        </div>
      )}

      <div className="flex flex-wrap items-center gap-2">
        <Select value={severity} onValueChange={setSeverity}>
          <SelectTrigger className="w-[180px]" aria-label="Severity">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectItem value="all">All severities</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
              <SelectItem value="info">Note</SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
        <Button
          type="button"
          variant="outline"
          aria-pressed={renewalOnly}
          className={renewalOnly ? 'border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]' : undefined}
          onClick={() => setRenewalOnly((current) => !current)}
        >
          Renewal problems
        </Button>
        <Button
          type="button"
          variant="outline"
          aria-pressed={unverifiedOnly}
          className={
            unverifiedOnly ? 'border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]' : undefined
          }
          onClick={() => setUnverifiedOnly((current) => !current)}
        >
          Not yet verified
        </Button>
        <Button
          type="button"
          variant="outline"
          aria-pressed={byInstitution}
          className={
            byInstitution ? 'border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]' : undefined
          }
          onClick={() => setByInstitution((current) => !current)}
        >
          Group by institution
        </Button>
      </div>

      {queryFailed(findings) ? (
        <ErrorState error={findings.error} message={offlineNotice()} onRetry={() => findings.refetch()} />
      ) : findings.isLoading ? (
        <Skeleton className="h-64 w-full" />
      ) : groups.length === 0 ? (
        <EmptyState message="No deposits have findings." />
      ) : visible.length === 0 ? (
        <EmptyState
          message={
            renewalOnly
              ? 'No renewal gap or amount drop is on record.'
              : unverifiedOnly
                ? 'No approved deposit is still marked submitted.'
                : 'No deposits match this severity.'
          }
          actionLabel="Show all"
          onAction={() => {
            setSeverity('all');
            setRenewalOnly(false);
            setUnverifiedOnly(false);
          }}
        />
      ) : (
        <div className="overflow-hidden rounded-[8px] border border-[var(--line)] bg-white">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>FDR number</TableHead>
                <TableHead>Institution</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Score</TableHead>
                <TableHead>Findings</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {blocks.map((block) => (
                <Fragment key={block.name ?? 'all'}>
                  {block.name && (
                    <TableRow className="hover:bg-transparent">
                      <TableCell colSpan={5} className="h-8 bg-[var(--surface-2)] py-1">
                        <span className="text-[12px] font-semibold uppercase tracking-[0.06em] text-[var(--ink-2)]">
                          {block.name} · {block.rows.length}
                        </span>
                      </TableCell>
                    </TableRow>
                  )}
                  {block.rows.map((group) => {
                const expanded = open.includes(group.fdr_id);
                const critical = countOf(group.findings, 'critical');
                const warning = countOf(group.findings, 'warning');
                const info = countOf(group.findings, 'info');
                return (
                  <Fragment key={group.fdr_id}>
                    <TableRow
                      className="cursor-pointer"
                      onClick={() => toggle(group.fdr_id)}
                    >
                      <TableCell>
                        <Link
                          to={`/deposits/${group.fdr_id}`}
                          className="font-mono text-[13px] text-[var(--primary)] hover:underline"
                          onClick={(event) => event.stopPropagation()}
                        >
                          {group.fdr_number}
                        </Link>
                      </TableCell>
                      <TableCell>{group.institution_name}</TableCell>
                      <TableCell className="whitespace-nowrap">
                        <StatusPill status={group.status} />
                      </TableCell>
                      <TableCell>
                        <HealthBar score={group.health_score} />
                      </TableCell>
                      <TableCell className="text-[12px]">
                        <span className={cn(critical > 0 && 'font-medium text-[var(--risk)]')}>
                          {critical} critical
                        </span>
                        <span className="text-[var(--ink-3)]"> · </span>
                        <span className={cn(warning > 0 && 'text-[var(--warn)]')}>{warning} warning</span>
                        <span className="text-[var(--ink-3)]"> · </span>
                        <span className="text-[var(--ink-3)]">{info} note</span>
                        <span className="ml-2 text-[var(--ink-3)]">{expanded ? 'Hide' : 'Show'}</span>
                      </TableCell>
                    </TableRow>
                    {expanded && (
                      <TableRow className="hover:bg-transparent">
                        <TableCell colSpan={5} className="bg-[var(--surface-2)]">
                          <ul className="flex flex-col gap-2 py-1">
                            {group.findings.map((finding) => (
                              <li key={finding.code} className="text-[13px]">
                                <span className="font-mono text-[12px] text-[var(--ink-2)]">{finding.code}</span>
                                <span className="text-[var(--ink-3)]"> · {finding.severity === 'info' ? 'Note' : SEVERITY_LABELS[finding.severity]}</span>
                                <p className="text-[var(--ink)]">{finding.message}</p>
                                <p className="text-[12px] text-[var(--ink-2)]">Fix: {finding.fix}</p>
                              </li>
                            ))}
                          </ul>
                        </TableCell>
                      </TableRow>
                    )}
                  </Fragment>
                  );
                })}
                </Fragment>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
