import { useNavigate, Link } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import {
  ComposedChart,
  Bar,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from 'recharts';
import {
  Plus,
  ArrowRight,
  ShieldCheck,
  ExternalLink,
  ArrowUpRight,
} from 'lucide-react';
import { api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { inr, inrShort, formatDate, formatDateTime } from '@/lib/format';
import type { DashboardResponse, FdrListItem, BureauMetrics } from '@/lib/types';

import { PageHeader } from '@/components/shared/PageHeader';
import { KpiTile } from '@/components/shared/KpiTile';
import { StatusPill } from '@/components/shared/StatusPill';
import { MaturityChip } from '@/components/shared/MaturityChip';
import { Money } from '@/components/shared/Money';
import { DataTable, type Column } from '@/components/shared/DataTable';
import { HealthBar } from '@/components/shared/HealthBar';
import { ErrorState } from '@/components/shared/ErrorState';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';

export default function DashboardPage() {
  const { user } = useAuth();
  const navigate = useNavigate();

  const {
    data: dash,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery<DashboardResponse>({
    queryKey: queryKeys.dashboard,
    queryFn: () => api.get<DashboardResponse>('/dashboard'),
    staleTime: 45000,
  });

  const {
    data: metrics,
    isLoading: isMetricsLoading,
    isError: isMetricsError,
    refetch: refetchMetrics,
  } = useQuery<BureauMetrics>({
    queryKey: ['metrics'],
    queryFn: () => api.get<BureauMetrics>('/metrics'),
    staleTime: 60000,
  });

  if (isError) {
    return (
      <div className="space-y-4">
        <PageHeader
          title="Dashboard"
          description="Institutional deposit overview and maturity monitoring"
        />
        <ErrorState error={error} onRetry={() => refetch()} />
      </div>
    );
  }

  const kpis = dash?.kpis;

  // Columns for the "Maturing Next" table (compact to avoid clipping on 1366px/1440px screens)
  const columns: Column<FdrListItem>[] = [
    {
      key: 'fdr_number',
      header: 'FDR Number',
      cell: (item) => (
        <span className="font-mono font-medium text-[var(--primary)] hover:underline whitespace-nowrap">
          {item.fdr_number}
        </span>
      ),
    },
    {
      key: 'institution_name',
      header: 'Institution',
      cell: (item) => (
        <span className="truncate max-w-[130px] block" title={item.institution_name}>
          {item.institution_name}
        </span>
      ),
    },
    {
      key: 'amount',
      header: 'Amount',
      align: 'right',
      cell: (item) => <Money amount={item.amount} />,
    },
    {
      key: 'maturity_date',
      header: 'Maturity',
      cell: (item) => (
        <div className="flex items-center gap-1.5 whitespace-nowrap">
          <span>{formatDate(item.maturity_date)}</span>
          <MaturityChip days={item.days_to_maturity} state={item.maturity_state} />
        </div>
      ),
    },
    {
      key: 'status',
      header: 'Status',
      cell: (item) => <StatusPill status={item.status} />,
    },
    {
      key: 'health',
      header: 'Health',
      align: 'center',
      cell: (item) => <HealthBar score={item.health_score} size="sm" />,
    },
  ];

  // Format month label for the 12-month timeline chart
  const timelineData =
    dash?.timeline?.map((item) => {
      // item.month is "YYYY-MM"
      const [year, month] = item.month.split('-');
      const monthNames = [
        'Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun',
        'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec',
      ];
      const mIdx = parseInt(month, 10) - 1;
      const formattedMonth = `${monthNames[mIdx]} '${year.slice(2)}`;
      return {
        month: formattedMonth,
        rawMonth: item.month,
        amount: item.amount,
        amountCr: Number((item.amount / 10000000).toFixed(2)),
        count: item.count,
      };
    }) || [];

  return (
    <div className="space-y-5">
      {/* Page Header */}
      <PageHeader
        title="Institutional Deposit Dashboard"
        description="Regulation Bureau central security deposit ledger and real-time compliance tracker"
        actions={
          <div className="flex items-center gap-2">
            <Button
              variant="outline"
              size="sm"
              onClick={() => navigate('/radar')}
              className="text-xs"
            >
              <ExternalLink className="mr-1.5 h-3.5 w-3.5" />
              Maturity Radar
            </Button>
            {user?.role === 'admin' && (
              <Button
                size="sm"
                onClick={() => navigate('/deposits/new')}
                className="text-xs"
              >
                <Plus className="mr-1.5 h-3.5 w-3.5" />
                New Deposit
              </Button>
            )}
          </div>
        }
      />

      {/* KPI Strip (8 Tiles) */}
      {isLoading ? (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {Array.from({ length: 8 }).map((_, i) => (
            <div
              key={i}
              className="h-24 rounded-[8px] border border-[var(--line)] bg-white p-4"
            >
              <Skeleton className="h-3 w-20 mb-3" />
              <Skeleton className="h-7 w-28 mb-2" />
              <Skeleton className="h-3 w-16" />
            </div>
          ))}
        </div>
      ) : (
        <div className="grid grid-cols-2 md:grid-cols-4 gap-3">
          {/* Tile 1: Total Portfolio */}
          <KpiTile
            label="Total Portfolio"
            value={inrShort(kpis?.total_amount)}
            tooltipExact={inr(kpis?.total_amount)}
            context={`${kpis?.total_count ?? 0} total open FDRs`}
            href="/deposits?status=draft,pending_approval,approved,release_requested"
          />

          {/* Tile 2: Active Value */}
          <KpiTile
            label="Active Value"
            value={inrShort(kpis?.active_amount)}
            tooltipExact={inr(kpis?.active_amount)}
            context={`${kpis?.active_count ?? 0} approved or release requested`}
            href="/deposits?status=approved,release_requested"
            valueColor="text-[#167A4A]"
          />

          {/* Tile 3: Pending Approvals */}
          <KpiTile
            label="Pending Approvals"
            value={kpis?.pending_approvals ?? 0}
            context={
              (kpis?.pending_approvals ?? 0) > 0
                ? 'Action required by reviewer'
                : 'Queue clear'
            }
            href="/approvals"
            alert={(kpis?.pending_approvals ?? 0) > 0}
            valueColor={
              (kpis?.pending_approvals ?? 0) > 0 ? 'text-[var(--primary)]' : undefined
            }
          />

          {/* Tile 4: Release Requests */}
          <KpiTile
            label="Release Requests"
            value={kpis?.release_requests ?? 0}
            context="Submitted for final refund"
            href="/approvals"
            valueColor={
              (kpis?.release_requests ?? 0) > 0 ? 'text-[#5B4BB7]' : undefined
            }
          />

          {/* Tile 5: Due in 30 Days */}
          <KpiTile
            label="Due in 30 Days"
            value={kpis?.maturing_30 ?? 0}
            context="Action window open"
            href="/deposits?window=due_30"
            alert={(kpis?.maturing_30 ?? 0) > 0}
            valueColor={
              (kpis?.maturing_30 ?? 0) > 0 ? 'text-[#B45309]' : undefined
            }
          />

          {/* Tile 6: Due in 90 Days */}
          <KpiTile
            label="Due in 90 Days"
            value={kpis?.maturing_90 ?? 0}
            context="Quarterly pipeline"
            href="/deposits?window=due_90"
          />

          {/* Tile 7: Overdue / Matured */}
          <KpiTile
            label="Matured Overdue"
            value={kpis?.overdue ?? 0}
            context={
              (kpis?.overdue ?? 0) > 0
                ? 'Immediate renewal needed'
                : 'Zero overdue deposits'
            }
            href="/deposits?window=matured"
            alert={(kpis?.overdue ?? 0) > 0}
            valueColor={(kpis?.overdue ?? 0) > 0 ? 'text-[#B42318]' : undefined}
          />

          {/* Tile 8: System Integrity Score */}
          <KpiTile
            label="Average Health"
            value={
              kpis?.avg_health !== null && kpis?.avg_health !== undefined
                ? `${kpis.avg_health}/100`
                : '—'
            }
            context={`${kpis?.open_alerts ?? 0} active alerts flagged`}
            href="/health"
            valueColor={
              (kpis?.avg_health ?? 100) >= 85
                ? 'text-[#167A4A]'
                : (kpis?.avg_health ?? 100) >= 60
                ? 'text-[#B45309]'
                : 'text-[#B42318]'
            }
          />
        </div>
      )}

      {/* Bureau Performance Metrics Strip (§9.7) */}
      <div className="rounded-[8px] border border-[var(--line)] bg-[var(--surface-1)] p-4 space-y-3">
        <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
          <div>
            <h2 className="text-xs font-semibold uppercase tracking-wider text-[var(--ink-2)]">
              Bureau Operating Performance
            </h2>
            <p className="text-[11px] text-[var(--ink-3)]">
              Last 180 days, from the audit log.
            </p>
          </div>
          <Link
            to="/reports"
            className="text-xs text-[var(--primary)] font-medium inline-flex items-center gap-1 hover:underline"
          >
            <span>Detailed Reports</span>
            <ArrowRight className="h-3 w-3" />
          </Link>
        </div>

        {isMetricsLoading ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {Array.from({ length: 4 }).map((_, i) => (
              <div
                key={i}
                className="h-20 rounded-[6px] border border-[var(--line)] bg-white p-3 space-y-2"
              >
                <Skeleton className="h-3 w-24" />
                <Skeleton className="h-6 w-20" />
                <Skeleton className="h-2.5 w-full" />
              </div>
            ))}
          </div>
        ) : isMetricsError ? (
          <div className="rounded-[6px] border border-[#FECDCA] bg-[#FEF3F2] p-3 text-xs text-[#B42318] flex items-center justify-between">
            <span>Unable to load bureau performance metrics.</span>
            <Button
              variant="outline"
              size="sm"
              onClick={() => refetchMetrics()}
              className="text-xs h-7"
            >
              Retry
            </Button>
          </div>
        ) : (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-3">
            {/* 1. Approval Turnaround */}
            <Link
              to="/reports"
              className="rounded-[6px] border border-[var(--line)] bg-white p-3 hover:border-[var(--primary)] hover:bg-[var(--surface-2)] transition-colors block group"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium text-[var(--ink-3)]">
                  Approval Turnaround
                </span>
                <ArrowUpRight className="h-3 w-3 text-[var(--ink-3)] group-hover:text-[var(--primary)] transition-colors" />
              </div>
              <div className="text-lg font-semibold font-mono text-[var(--ink)] mt-0.5">
                {metrics?.approval_turnaround_days !== null && metrics?.approval_turnaround_days !== undefined
                  ? `${metrics.approval_turnaround_days.toFixed(1)} days`
                  : '—'}
              </div>
              <p className="text-[10px] text-[var(--ink-3)] mt-1 truncate" title="Average decision turnaround from submission over the last 180 days">
                Avg decision turnaround (180 days)
              </p>
            </Link>

            {/* 2. Verification Rate */}
            <Link
              to="/reports"
              className="rounded-[6px] border border-[var(--line)] bg-white p-3 hover:border-[var(--primary)] hover:bg-[var(--surface-2)] transition-colors block group"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium text-[var(--ink-3)]">
                  Verification Rate
                </span>
                <ArrowUpRight className="h-3 w-3 text-[var(--ink-3)] group-hover:text-[var(--primary)] transition-colors" />
              </div>
              <div className="text-lg font-semibold font-mono text-[var(--ink)] mt-0.5">
                {metrics ? `${metrics.verification_rate.toFixed(1)}%` : '—'}
              </div>
              <p className="text-[10px] text-[var(--ink-3)] mt-1 truncate" title="Officer-verified share of active approved deposits">
                Officer-verified share of portfolio
              </p>
            </Link>

            {/* 3. Document Coverage */}
            <Link
              to="/reports"
              className="rounded-[6px] border border-[var(--line)] bg-white p-3 hover:border-[var(--primary)] hover:bg-[var(--surface-2)] transition-colors block group"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium text-[var(--ink-3)]">
                  Document Coverage
                </span>
                <ArrowUpRight className="h-3 w-3 text-[var(--ink-3)] group-hover:text-[var(--primary)] transition-colors" />
              </div>
              <div className="text-lg font-semibold font-mono text-[var(--ink)] mt-0.5">
                {metrics ? `${metrics.document_coverage.toFixed(1)}%` : '—'}
              </div>
              <p className="text-[10px] text-[var(--ink-3)] mt-1 truncate" title="Open deposits with original bank receipt scan attached">
                Deposits with receipt attached
              </p>
            </Link>

            {/* 4. On-time Renewals */}
            <Link
              to="/reports"
              className="rounded-[6px] border border-[var(--line)] bg-white p-3 hover:border-[var(--primary)] hover:bg-[var(--surface-2)] transition-colors block group"
            >
              <div className="flex items-center justify-between">
                <span className="text-[11px] font-medium text-[var(--ink-3)]">
                  On-Time Renewals
                </span>
                <ArrowUpRight className="h-3 w-3 text-[var(--ink-3)] group-hover:text-[var(--primary)] transition-colors" />
              </div>
              <div className="text-lg font-semibold font-mono text-[var(--ink)] mt-0.5">
                {metrics?.renewal_on_time_rate !== null && metrics?.renewal_on_time_rate !== undefined
                  ? `${metrics.renewal_on_time_rate.toFixed(1)}%`
                  : '—'}
              </div>
              <p className="text-[10px] text-[var(--ink-3)] mt-1 truncate" title="Renewals completed on or before the deposit maturity date">
                Renewals on or before maturity
              </p>
            </Link>
          </div>
        )}
      </div>

      {/* Middle Row: 12-Month Timeline & Status Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 7 cols: 12-Month Maturity Timeline */}
        <div className="lg:col-span-7 rounded-[8px] border border-[var(--line)] bg-white p-4 shadow-2xs flex flex-col h-full">
          <div className="flex items-center justify-between pb-3 border-b border-[var(--line)]">
            <div>
              <h2 className="text-sm font-semibold text-[var(--ink)]">
                12-Month Maturity Pipeline
              </h2>
              <p className="text-[11px] text-[var(--ink-3)]">
                Upcoming monthly principal commitments (bars, in ₹ Cr) and deposit count (line)
              </p>
            </div>
            <span className="font-mono text-[11px] text-[var(--ink-2)] bg-[var(--surface-2)] px-2 py-0.5 rounded-[4px] border border-[var(--line)]">
              Next 12 Months
            </span>
          </div>

          <div className="mt-4 flex-1 min-h-[290px] w-full">
            {isLoading ? (
              <div className="h-full flex items-center justify-center">
                <Skeleton className="h-48 w-full" />
              </div>
            ) : timelineData.length === 0 ? (
              <div className="h-full flex items-center justify-center text-xs text-[var(--ink-3)]">
                No upcoming maturities recorded in the timeline period.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height="100%">
                <ComposedChart
                  data={timelineData}
                  margin={{ top: 10, right: 10, left: 10, bottom: 0 }}
                >
                  <CartesianGrid strokeDasharray="3 3" stroke="#E3E7EC" vertical={false} />
                  <XAxis
                    dataKey="month"
                    tick={{ fontSize: 11, fill: '#7A8496' }}
                    axisLine={{ stroke: '#E3E7EC' }}
                    tickLine={false}
                  />
                  <YAxis
                    yAxisId="left"
                    width={56}
                    tick={{ fontSize: 11, fill: '#7A8496', fontFamily: 'IBM Plex Mono' }}
                    axisLine={{ stroke: '#E3E7EC' }}
                    tickLine={false}
                    tickFormatter={(v) => `₹${v} Cr`}
                  />
                  <YAxis
                    yAxisId="right"
                    orientation="right"
                    domain={[0, 'auto']}
                    tick={{ fontSize: 11, fill: '#7A8496', fontFamily: 'IBM Plex Mono' }}
                    axisLine={{ stroke: '#E3E7EC' }}
                    tickLine={false}
                    allowDecimals={false}
                  />
                  <Tooltip
                    content={({ active, payload, label }) => {
                      if (active && payload && payload.length) {
                        const amount = payload[0]?.payload?.amount;
                        const count = payload[0]?.payload?.count;
                        return (
                          <div className="rounded-[6px] border border-[var(--line)] bg-white p-2.5 shadow-md font-sans text-xs">
                            <div className="font-semibold text-[var(--ink)] mb-1">
                              {label}
                            </div>
                            <div className="font-mono text-[var(--primary)] font-medium">
                              Maturing: {inr(amount)}
                            </div>
                            <div className="text-[11px] text-[var(--ink-2)] mt-0.5">
                              Instruments: {count}
                            </div>
                          </div>
                        );
                      }
                      return null;
                    }}
                  />
                  <Bar
                    yAxisId="left"
                    dataKey="amountCr"
                    fill="#0B5CAD"
                    radius={[3, 3, 0, 0]}
                    maxBarSize={32}
                  />
                  <Line
                    yAxisId="right"
                    type="linear"
                    dataKey="count"
                    stroke="#4A5567"
                    strokeWidth={2}
                    dot={{ r: 3, fill: '#4A5567' }}
                  />
                </ComposedChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Right 5 cols: Status Breakdown & Bank Concentration */}
        <div className="lg:col-span-5 flex flex-col gap-5">
          {/* Status Breakdown Panel */}
          <div className="rounded-[8px] border border-[var(--line)] bg-white p-4 shadow-2xs flex-1">
            <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
              <h2 className="text-sm font-semibold text-[var(--ink)]">
                Status Distribution
              </h2>
              <span className="text-[11px] text-[var(--ink-3)]">
                {dash?.by_status?.reduce((acc, curr) => acc + curr.count, 0) ?? 0} Total
              </span>
            </div>

            <div className="mt-3 space-y-2.5">
              {isLoading
                ? Array.from({ length: 4 }).map((_, i) => (
                    <Skeleton key={i} className="h-6 w-full" />
                  ))
                : dash?.by_status?.map((item) => (
                    <div
                      key={item.status}
                      onClick={() => navigate(`/deposits?status=${item.status}`)}
                      className="group flex items-center justify-between p-1.5 rounded-[4px] hover:bg-[var(--surface-2)] transition-colors cursor-pointer select-none"
                    >
                      <div className="flex items-center gap-2">
                        <StatusPill status={item.status} />
                        <span className="font-mono text-xs text-[var(--ink-3)]">
                          ({item.count})
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <span className="font-mono text-xs font-medium text-[var(--ink)]">
                          {inrShort(item.amount)}
                        </span>
                        <ArrowRight className="h-3 w-3 text-[var(--ink-3)] opacity-0 group-hover:opacity-100 transition-opacity" />
                      </div>
                    </div>
                  ))}
            </div>
          </div>

          {/* Bank Concentration */}
          <div className="rounded-[8px] border border-[var(--line)] bg-white p-4 shadow-2xs">
            <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
              <h2 className="text-sm font-semibold text-[var(--ink)]">
                Bank Concentration
              </h2>
              <span className="text-[11px] text-[var(--ink-3)]">Top Portfolios</span>
            </div>

            <div className="mt-3 space-y-2">
              {isLoading
                ? Array.from({ length: 3 }).map((_, i) => (
                    <Skeleton key={i} className="h-5 w-full" />
                  ))
                : dash?.by_bank?.slice(0, 4).map((b) => (
                    <div
                      key={b.bank}
                      onClick={() => navigate(`/deposits?bank=${encodeURIComponent(b.bank)}`)}
                      className="flex items-center justify-between text-xs hover:bg-[var(--surface-2)] p-1 rounded-[4px] cursor-pointer"
                    >
                      <span className="truncate max-w-[180px] text-[var(--ink)] font-medium">
                        {b.bank}
                      </span>
                      <div className="flex items-center gap-2 font-mono">
                        <span className="text-[var(--ink-3)] text-[11px]">{b.count} FDRs</span>
                        <span className="font-semibold text-[var(--ink)]">
                          {inrShort(b.amount)}
                        </span>
                      </div>
                    </div>
                  ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom Row: "Maturing Next" Table & Bureau Activity */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5">
        {/* Left 8 cols: Maturing Next Table */}
        <div className="lg:col-span-8 space-y-2">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <h2 className="text-sm font-semibold text-[var(--ink)]">
                Instruments Maturing Next
              </h2>
              <span className="text-xs text-[var(--ink-3)]">
                (Next 8 upcoming deadlines)
              </span>
            </div>
            <Button
              variant="link"
              size="sm"
              onClick={() => navigate('/deposits')}
              className="text-xs text-[var(--primary)] gap-1"
            >
              <span>View full register</span>
              <ArrowRight className="h-3 w-3" />
            </Button>
          </div>

          <DataTable
            columns={columns}
            data={dash?.upcoming}
            isLoading={isLoading}
            onRowClick={(item) =>
              navigate(`/deposits/${item.id}`, { state: { fdrNumber: item.fdr_number } })
            }
            className="[&_td]:px-2.5 [&_th]:px-2.5"
            emptyMessage="No upcoming maturities recorded."
          />
        </div>

        {/* Right 4 cols: Recent Bureau Activity */}
        <div className="lg:col-span-4 rounded-[8px] border border-[var(--line)] bg-white p-4 shadow-2xs">
          <div className="flex items-center justify-between pb-3 border-b border-[var(--line)]">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-4 w-4 text-[var(--primary)]" />
              <h2 className="text-sm font-semibold text-[var(--ink)]">
                Audit Trail Activity
              </h2>
            </div>
            <Button
              variant="link"
              size="sm"
              onClick={() => navigate('/audit')}
              className="text-[11px] text-[var(--primary)] p-0"
            >
              Audit log →
            </Button>
          </div>

          <div className="mt-3 divide-y divide-[var(--line)] max-h-[380px] overflow-y-auto pr-1">
            {isLoading ? (
              Array.from({ length: 5 }).map((_, i) => (
                <div key={i} className="py-2.5">
                  <Skeleton className="h-3 w-28 mb-1" />
                  <Skeleton className="h-3 w-40" />
                </div>
              ))
            ) : dash?.activity && dash.activity.length > 0 ? (
              dash.activity.slice(0, 7).map((act) => (
                <div key={act.id} className="py-2.5 first:pt-0 last:pb-0 text-xs">
                  <div className="flex items-center justify-between">
                    <span className="font-semibold text-[var(--ink)] text-[12px]">
                      {act.action_label || act.action}
                    </span>
                    <span className="text-[10px] text-[var(--ink-3)] font-mono">
                      {formatDateTime(act.at)}
                    </span>
                  </div>

                  <div className="mt-1 flex items-center justify-between text-[11px] text-[var(--ink-2)]">
                    <div className="flex items-center gap-1.5 truncate">
                      <span className="font-medium text-[var(--ink)]">
                        {act.actor_name}
                      </span>
                      {act.actor_role && (
                        <span className="font-mono text-[9px] uppercase px-1 rounded bg-[var(--surface-2)] border border-[var(--line)] text-[var(--ink-3)]">
                          {act.actor_role}
                        </span>
                      )}
                    </div>
                    {act.fdr_number && (
                      <span
                        onClick={(e) => {
                          e.stopPropagation();
                          if (act.fdr_id) navigate(`/deposits/${act.fdr_id}`);
                        }}
                        className="font-mono text-[10px] text-[var(--primary)] hover:underline cursor-pointer"
                      >
                        {act.fdr_number}
                      </span>
                    )}
                  </div>
                </div>
              ))
            ) : (
              <div className="py-6 text-center text-xs text-[var(--ink-3)]">
                No recent bureau actions recorded.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
