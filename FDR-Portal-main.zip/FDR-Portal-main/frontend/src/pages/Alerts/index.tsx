import { Fragment, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ApiError, api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { formatDate, relDays, SEVERITY_LABELS } from '@/lib/format';
import type { AlertItem, AlertRunResponse, AlertSeverity } from '@/lib/types';
import { canAcknowledge, visibleToInstitution } from '@/pages/Approvals/roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { EmptyState } from '@/components/shared/EmptyState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';
import { ErrorState } from '@/components/shared/ErrorState';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Checkbox } from '@/components/ui/checkbox';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';

type AlertState = 'open' | 'acknowledged' | 'all';

const SEVERITY_ORDER: AlertSeverity[] = ['critical', 'warning', 'info'];

const ALERT_FILTER_TYPES = [
  'maturity_upcoming',
  'matured_overdue',
  'pending_too_long',
  'discrepancy',
] as const;

function alertTypeLabel(type: string) {
  const labels: Record<string, string> = {
    maturity_upcoming: 'Maturity',
    matured_overdue: 'Overdue',
    pending_too_long: 'Pending too long',
    discrepancy: 'Finding',
    observation_unanswered: 'Observation unanswered',
  };
  return labels[type] ?? type.replace(/_/g, ' ');
}

const SEVERITY_TEXT: Record<AlertSeverity, string> = {
  critical: 'text-[var(--risk)]',
  warning: 'text-[var(--warn)]',
  info: 'text-[var(--info)]',
};

function toastError(err: unknown, fallback: string) {
  toast.error(err instanceof ApiError ? err.detail : fallback);
}

function alertDays(alert: AlertItem): string {
  if (alert.days == null) return '—';
  const kind = alert.type as string;
  if (kind === 'maturity_upcoming' || kind === 'matured_overdue') {
    return relDays(alert.days);
  }
  if (kind === 'pending_too_long' || kind === 'observation_unanswered') {
    const days = alert.days;
    return `waiting ${days} ${days === 1 ? 'day' : 'days'}`;
  }
  return '—';
}

function ageDays(alert: AlertItem): number | null {
  if (typeof alert.age_days === 'number' && Number.isFinite(alert.age_days)) {
    return alert.age_days;
  }
  const created = new Date(alert.created_at);
  if (Number.isNaN(created.getTime())) return null;
  return Math.max(0, Math.floor((Date.now() - created.getTime()) / 86_400_000));
}

function openForLabel(days: number) {
  return `Open for ${days} ${days === 1 ? 'day' : 'days'}`;
}

export default function AlertsPage() {
  const { role, user } = useAuth();
  const mayAck = canAcknowledge(role);
  const queryClient = useQueryClient();
  const [state, setState] = useState<AlertState>('open');
  const [severity, setSeverity] = useState<string>('all');
  const [type, setType] = useState<string>('all');
  const [selected, setSelected] = useState<number[]>([]);
  const [escalatedOnly, setEscalatedOnly] = useState(false);

  const params = {
    state,
    severity: severity === 'all' ? undefined : severity,
    type: type === 'all' ? undefined : type,
  };
  const shareBadge = state === 'open' && severity === 'all' && type === 'all';

  const alerts = useQuery({
    queryKey: shareBadge ? ['alerts', 'badge'] : queryKeys.alerts.list(params),
    queryFn: () => {
      const q = new URLSearchParams({ state });
      if (params.severity) q.set('severity', params.severity);
      if (params.type) q.set('type', params.type);
      return api.get<AlertItem[]>(`/alerts?${q.toString()}`);
    },
  });
  useRefetchOffline(alerts.refetch);
  const unansweredType = useQuery({
    queryKey: ['alerts', 'supports', 'observation_unanswered'],
    queryFn: async () => {
      try {
        await api.get<AlertItem[]>('/alerts?state=open&type=observation_unanswered');
        return true;
      } catch {
        return false;
      }
    },
    staleTime: 60_000,
  });
  const typeOptions = unansweredType.data
    ? [...ALERT_FILTER_TYPES, 'observation_unanswered' as const]
    : [...ALERT_FILTER_TYPES];

  const refresh = () =>
    Promise.all([
      queryClient.invalidateQueries({ queryKey: ['alerts'] }),
      queryClient.invalidateQueries({ queryKey: queryKeys.audit.all }),
    ]);

  const [acking, setAcking] = useState(false);

  const runChecks = useMutation({
    mutationFn: () => api.post<AlertRunResponse>('/alerts/run'),
    onSuccess: async (result) => {
      await refresh();
      toast.success(
        `Checks finished. ${result.created} created, ${result.resolved} resolved, ${result.open} open.`
      );
    },
    onError: (err) => toastError(err, 'Alert checks could not be run.'),
  });

  const loaded = (alerts.data ?? []).filter((item) =>
    visibleToInstitution(user, { institution_name: item.institution_name })
  );
  const items = escalatedOnly ? loaded.filter((item) => item.escalated === true) : loaded;
  const escalatedOnPage = loaded.filter((item) => item.escalated === true).length;
  const openIds = useMemo(
    () => items.filter((item) => item.acknowledged_at === null).map((item) => item.id),
    [items]
  );
  const selectedOpen = selected.filter((id) => openIds.includes(id));

  function toggle(id: number) {
    setSelected((current) =>
      current.includes(id) ? current.filter((value) => value !== id) : [...current, id]
    );
  }

  async function acknowledgeIds(ids: number[]) {
    if (ids.length === 0 || acking) return;
    setAcking(true);
    try {
      const results = await Promise.allSettled(
        ids.map((id) => api.post(`/alerts/${id}/acknowledge`))
      );
      const failed = results.filter((result) => result.status === 'rejected').length;
      const done = results.length - failed;
      await refresh();
      setSelected([]);
      if (done > 0) {
        toast.success(done === 1 ? 'Alert acknowledged.' : `${done} alerts acknowledged.`);
      }
      if (failed > 0) {
        const first = results.find((result) => result.status === 'rejected');
        toastError(
          first && first.status === 'rejected' ? first.reason : null,
          failed === 1 ? '1 alert could not be acknowledged.' : `${failed} alerts could not be acknowledged.`
        );
      }
    } finally {
      setAcking(false);
    }
  }

  const groups = SEVERITY_ORDER.map((level) => ({
    level,
    rows: items
      .filter((item) => item.severity === level)
      .slice()
      .sort((a, b) => Number(b.escalated === true) - Number(a.escalated === true)),
  })).filter((group) => group.rows.length > 0);

  return (
    <div className="flex min-w-0 flex-col gap-4">
      <PageHeader
        title="Alerts"
        description="Maturity dates, overdue deposits, stalled approvals and other problems."
        actions={
          role === 'admin' ? (
            <Button
              type="button"
              onClick={() => runChecks.mutate()}
              disabled={runChecks.isPending}
            >
              {runChecks.isPending ? 'Running checks...' : 'Run checks now'}
            </Button>
          ) : null
        }
      />

      <Tabs
        value={state}
        onValueChange={(value) => {
          setState(value as AlertState);
          setSelected([]);
        }}
      >
        <TabsList>
          <TabsTrigger value="open">Open</TabsTrigger>
          <TabsTrigger value="acknowledged">Acknowledged</TabsTrigger>
          <TabsTrigger value="all">All</TabsTrigger>
        </TabsList>
      </Tabs>

      <div className="flex flex-wrap items-center gap-2">
        <Select value={severity} onValueChange={setSeverity}>
          <SelectTrigger className="w-[160px]" aria-label="Severity">
            <SelectValue placeholder="Severity" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectItem value="all">All severities</SelectItem>
              <SelectItem value="critical">Critical</SelectItem>
              <SelectItem value="warning">Warning</SelectItem>
              <SelectItem value="info">Note</SelectItem>
            </SelectGroup>
          </SelectContent>
        </Select>
        <Select value={type} onValueChange={setType}>
          <SelectTrigger className="w-[180px]" aria-label="Type">
            <SelectValue placeholder="Type" />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectItem value="all">All types</SelectItem>
              {typeOptions.map((key) => (
                <SelectItem key={key} value={key}>
                  {alertTypeLabel(key)}
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
        <Button
          type="button"
          size="sm"
          variant="outline"
          aria-pressed={type === 'matured_overdue'}
          className={
            type === 'matured_overdue'
              ? 'border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]'
              : undefined
          }
          onClick={() => setType((current) => (current === 'matured_overdue' ? 'all' : 'matured_overdue'))}
        >
          Unclaimed matured
        </Button>
        <Button
          type="button"
          size="sm"
          variant="outline"
          aria-pressed={escalatedOnly}
          className={
            escalatedOnly ? 'border-[var(--primary)] bg-[var(--primary-soft)] text-[var(--primary)]' : undefined
          }
          onClick={() => setEscalatedOnly((current) => !current)}
        >
          Escalated only
          {escalatedOnPage > 0 ? ` (${escalatedOnPage.toLocaleString('en-IN')})` : ''}
        </Button>
        {(severity !== 'all' || type !== 'all' || escalatedOnly) && (
          <Button
            type="button"
            variant="ghost"
            size="sm"
            onClick={() => {
              setSeverity('all');
              setType('all');
              setEscalatedOnly(false);
            }}
          >
            Reset filters
          </Button>
        )}
        {mayAck && selectedOpen.length > 0 && (
          <Button
            type="button"
            size="sm"
            className="ml-auto"
            disabled={acking}
            onClick={() => acknowledgeIds(selectedOpen)}
          >
            Acknowledge {selectedOpen.length}
          </Button>
        )}
      </div>

      {queryFailed(alerts) ? (
        <ErrorState error={alerts.error} message={offlineNotice()} onRetry={() => alerts.refetch()} />
      ) : alerts.isLoading ? (
        <div className="flex flex-col gap-2 rounded-[8px] border border-[var(--line)] bg-white p-3">
          {Array.from({ length: 6 }).map((_, index) => (
            <Skeleton key={index} className="h-8 w-full" />
          ))}
        </div>
      ) : items.length === 0 ? (
        <EmptyState
          message={
            state === 'open' && severity === 'all' && type === 'all' && !escalatedOnly
              ? 'No open alerts.'
              : type === 'observation_unanswered'
                ? 'No observation has gone unanswered.'
                : type === 'matured_overdue'
                  ? 'No matured deposit is still unclaimed.'
                  : 'No alerts match this view.'
          }
          actionLabel={
            state !== 'open' || severity !== 'all' || type !== 'all' || escalatedOnly
              ? 'Show open alerts'
              : undefined
          }
          onAction={
            state !== 'open' || severity !== 'all' || type !== 'all' || escalatedOnly
              ? () => {
                  setState('open');
                  setSeverity('all');
                  setType('all');
                  setEscalatedOnly(false);
                  setSelected([]);
                }
              : undefined
          }
        />
      ) : (
        <div className="overflow-hidden rounded-[8px] border border-[var(--line)] bg-white">
          <Table>
            <TableHeader>
              <TableRow>
                {mayAck && (
                <TableHead className="w-10">
                  <Checkbox
                    checked={openIds.length > 0 && selectedOpen.length === openIds.length}
                    disabled={openIds.length === 0}
                    onCheckedChange={(checked) => setSelected(checked === true ? openIds : [])}
                    aria-label="Select open alerts"
                  />
                </TableHead>
                )}
                <TableHead>Alert</TableHead>
                <TableHead className="w-[140px]">Type</TableHead>
                <TableHead className="w-[120px]">Due</TableHead>
                <TableHead className="w-[168px]">Days</TableHead>
                {mayAck && <TableHead className="w-[130px]" />}
              </TableRow>
            </TableHeader>
            <TableBody>
              {groups.map((group) => (
                <Fragment key={group.level}>
                  <TableRow className="hover:bg-transparent">
                    <TableCell colSpan={mayAck ? 6 : 5} className="h-8 bg-[var(--surface-2)] py-1">
                      <span
                        className={cn(
                          'text-[12px] font-semibold uppercase tracking-[0.06em]',
                          SEVERITY_TEXT[group.level]
                        )}
                      >
                        {group.level === 'info' ? 'Note' : SEVERITY_LABELS[group.level]} · {group.rows.length}
                      </span>
                    </TableCell>
                  </TableRow>
                  {group.rows.map((alert) => {
                    const open = alert.acknowledged_at === null;
                    return (
                      <TableRow key={alert.id}>
                        {mayAck && (
                        <TableCell>
                          <Checkbox
                            checked={selected.includes(alert.id)}
                            disabled={!open}
                            onCheckedChange={() => toggle(alert.id)}
                            aria-label={`Select alert ${alert.fdr_number}`}
                          />
                        </TableCell>
                        )}
                        <TableCell>
                          <div className="flex flex-col gap-0.5">
                            <span className="text-[13px] text-[var(--ink)]">
                              {alert.message}
                              {alert.escalated && (
                                <span className="ml-2 inline-flex h-[22px] items-center rounded-full bg-[var(--risk-bg)] px-2 align-middle text-[12px] font-medium text-[var(--risk)]">
                                  Escalated
                                </span>
                              )}
                            </span>
                            <span className="text-[12px] text-[var(--ink-3)]">
                              <Link
                                to={`/deposits/${alert.fdr_id}`}
                                className="font-mono text-[var(--primary)] hover:underline"
                              >
                                {alert.fdr_number}
                              </Link>
                              {' · '}
                              {alert.institution_name}
                              {alert.acknowledged_by && (
                                <>
                                  {' · '}
                                  Acknowledged by {alert.acknowledged_by}
                                </>
                              )}
                            </span>
                          </div>
                        </TableCell>
                        <TableCell className="text-[13px] text-[var(--ink-2)]">
                          {alertTypeLabel(alert.type)}
                        </TableCell>
                        <TableCell className="text-[13px]">{formatDate(alert.due_date)}</TableCell>
                        <TableCell className="whitespace-nowrap font-mono text-[13px]">
                          <span className="block">{alertDays(alert)}</span>
                          {ageDays(alert) != null && (
                            <span className="mt-0.5 block font-sans text-[12px] text-[var(--ink-3)]">
                              {openForLabel(ageDays(alert) as number)}
                            </span>
                          )}
                        </TableCell>
                        {mayAck && (
                        <TableCell className="text-right">
                          {open && (
                            <Button
                              type="button"
                              variant="outline"
                              size="sm"
                              disabled={acking}
                              onClick={() => acknowledgeIds([alert.id])}
                            >
                              Acknowledge
                            </Button>
                          )}
                        </TableCell>
                        )}
                      </TableRow>
                    );
                  })}
                </Fragment>
              ))}
            </TableBody>
          </Table>
        </div>
      )}
    </div>
  );
}
