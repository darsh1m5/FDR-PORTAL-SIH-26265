import { useState, type ReactNode } from 'react';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ApiError, api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { formatRate } from '@/lib/format';
import { useAuth } from '@/lib/auth';
import type { Settings } from '@/lib/types';
import { isInstitution, RoleUnavailable } from '@/pages/Approvals/roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { ErrorState } from '@/components/shared/ErrorState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Skeleton } from '@/components/ui/skeleton';

function Field({
  label,
  hint,
  children,
}: {
  label: string;
  hint?: string;
  children: ReactNode;
}) {
  return (
    <div className="flex flex-col gap-1.5">
      <span className="text-[12px] font-medium text-[var(--ink-2)]">{label}</span>
      {children}
      {hint && <span className="text-[12px] text-[var(--ink-3)]">{hint}</span>}
    </div>
  );
}

export default function SettingsPage() {
  const { role } = useAuth();
  const queryClient = useQueryClient();
  const canEdit = role === 'admin';
  const [draft, setDraft] = useState<Settings | null>(null);
  const [dayInput, setDayInput] = useState('');
  const [editingRate, setEditingRate] = useState<'min' | 'max' | null>(null);

  const settings = useQuery({
    queryKey: queryKeys.settings,
    queryFn: () => api.get<Settings>('/settings'),
    enabled: !isInstitution(role),
  });
  useRefetchOffline(settings.refetch);

  const form = draft ?? settings.data ?? null;

  const save = useMutation({
    mutationFn: (body: Settings) => api.put<Settings>('/settings', body),
    onSuccess: async () => {
      setDraft(null);
      await Promise.all([
        queryClient.invalidateQueries({ queryKey: queryKeys.settings }),
        queryClient.invalidateQueries({ queryKey: ['alerts'] }),
        queryClient.invalidateQueries({ queryKey: queryKeys.findings() }),
        queryClient.invalidateQueries({ queryKey: queryKeys.dashboard }),
      ]);
      toast.success('Settings saved. Alert checks ran again.');
    },
    onError: (err) => {
      toast.error(err instanceof ApiError ? err.detail : 'Settings could not be saved.');
    },
  });

  function update(patch: Partial<Settings>) {
    if (!form || !canEdit) return;
    setDraft({ ...form, ...patch });
  }

  function addDay() {
    if (!form) return;
    const value = Number(dayInput);
    if (!Number.isInteger(value) || value < 1 || value > 730) {
      toast.error('Reminder days must be a whole number from 1 to 730.');
      return;
    }
    if (form.reminder_days.includes(value)) {
      setDayInput('');
      return;
    }
    if (form.reminder_days.length >= 8) {
      toast.error('At most 8 reminder days.');
      return;
    }
    update({ reminder_days: [...form.reminder_days, value].sort((a, b) => b - a) });
    setDayInput('');
  }

  function onSave() {
    if (!form) return;
    if (form.reminder_days.length < 1) {
      toast.error('Keep at least one reminder day.');
      return;
    }
    if (form.interest_min >= form.interest_max) {
      toast.error('Minimum interest rate must be below the maximum.');
      return;
    }
    if (form.pending_sla_days < 1 || form.pending_sla_days > 365) {
      toast.error('Review time limit must be between 1 and 365 days.');
      return;
    }
    if (form.overdue_grace_days < 0 || form.overdue_grace_days > 365) {
      toast.error('Days after maturity must be between 0 and 365.');
      return;
    }
    const escalateAfter = form.escalate_after_days ?? 3;
    if (!Number.isInteger(escalateAfter) || escalateAfter < 1 || escalateAfter > 60) {
      toast.error('Escalate after must be a whole number from 1 to 60.');
      return;
    }
    save.mutate({
      ...form,
      reminder_days: [...form.reminder_days].sort((a, b) => b - a),
      interest_min: Number(form.interest_min),
      interest_max: Number(form.interest_max),
      escalate_after_days: escalateAfter,
    });
  }

  return (
    <div className="flex max-w-3xl flex-col gap-4">
      {isInstitution(role) ? (
        <RoleUnavailable title="Settings" />
      ) : (
      <>
      <PageHeader
        title="Settings"
        description="Reminder days, review time limit, and the usual interest range."
        actions={
          canEdit ? (
            <Button type="button" onClick={onSave} disabled={!form || save.isPending}>
              {save.isPending ? 'Saving...' : 'Save'}
            </Button>
          ) : null
        }
      />

      {!canEdit && (
        <p className="rounded-[8px] border border-[var(--line)] bg-[var(--surface-2)] px-3 py-2 text-[13px] text-[var(--ink-2)]">
          Only an administrator can change these rules.
        </p>
      )}

      {queryFailed(settings) ? (
        <ErrorState error={settings.error} message={offlineNotice()} onRetry={() => settings.refetch()} />
      ) : settings.isLoading || !form ? (
        <Skeleton className="h-64 w-full" />
      ) : (
        <div className="flex flex-col gap-5 rounded-[8px] border border-[var(--line)] bg-white p-4">
          <Field label="Reminder days" hint="Alerts fire when a deposit is this many days from maturity. 1 to 730, up to 8 values.">
            <div className="flex flex-wrap items-center gap-2">
              {form.reminder_days.map((day) => (
                <span
                  key={day}
                  className="inline-flex h-[22px] items-center gap-1 rounded-[6px] bg-[var(--primary-soft)] px-2.5 font-mono text-[12px] tabular-nums font-medium text-[var(--primary)]"
                >
                  {day}d
                  {canEdit && (
                    <button
                      type="button"
                      className="rounded-[2px] text-[var(--primary)] hover:text-[var(--ink)] focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--primary)]"
                      aria-label={`Remove ${day} days`}
                      onClick={() =>
                        update({ reminder_days: form.reminder_days.filter((value) => value !== day) })
                      }
                    >
                      Remove
                    </button>
                  )}
                </span>
              ))}
              {canEdit && (
                <span className="inline-flex items-center gap-2">
                  <Input
                    value={dayInput}
                    onChange={(event) => setDayInput(event.target.value)}
                    onKeyDown={(event) => {
                      if (event.key === 'Enter') {
                        event.preventDefault();
                        addDay();
                      }
                    }}
                    inputMode="numeric"
                    aria-label="Add reminder day"
                    placeholder="Add"
                    className="w-20"
                  />
                  <Button type="button" variant="outline" size="sm" onClick={addDay}>
                    Add
                  </Button>
                </span>
              )}
            </div>
          </Field>

          <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
            <Field label="Days after maturity" hint="How long after the maturity date before an overdue alert.">
              <Input
                type="number"
                min={0}
                max={365}
                disabled={!canEdit}
                value={form.overdue_grace_days}
                onChange={(event) => update({ overdue_grace_days: Number(event.target.value) })}
              />
            </Field>
            <Field label="Review time limit (days)" hint="After this many days the approvals queue marks the request late.">
              <Input
                type="number"
                min={1}
                max={365}
                disabled={!canEdit}
                value={form.pending_sla_days}
                onChange={(event) => update({ pending_sla_days: Number(event.target.value) })}
              />
            </Field>
            <Field
              label="Escalate after (days)"
              hint="Unacknowledged alerts are flagged Escalated after this many days."
            >
              <Input
                type="number"
                min={1}
                max={60}
                disabled={!canEdit}
                value={form.escalate_after_days ?? 3}
                onChange={(event) => update({ escalate_after_days: Number(event.target.value) })}
              />
            </Field>
            <Field label="Minimum interest" hint="A lower rate is flagged on Health Check.">
              {canEdit ? (
                <Input
                  type="number"
                  min={0}
                  max={20}
                  step="0.01"
                  value={editingRate === 'min' ? form.interest_min : Number(form.interest_min).toFixed(2)}
                  onFocus={() => setEditingRate('min')}
                  onBlur={() => {
                    setEditingRate(null);
                    update({ interest_min: Number(Number(form.interest_min).toFixed(2)) });
                  }}
                  onChange={(event) => update({ interest_min: Number(event.target.value) })}
                />
              ) : (
                <p className="font-mono text-[13px]">{formatRate(form.interest_min)}</p>
              )}
            </Field>
            <Field label="Maximum interest" hint="A higher rate is flagged on Health Check.">
              {canEdit ? (
                <Input
                  type="number"
                  min={0}
                  max={20}
                  step="0.01"
                  value={editingRate === 'max' ? form.interest_max : Number(form.interest_max).toFixed(2)}
                  onFocus={() => setEditingRate('max')}
                  onBlur={() => {
                    setEditingRate(null);
                    update({ interest_max: Number(Number(form.interest_max).toFixed(2)) });
                  }}
                  onChange={(event) => update({ interest_max: Number(event.target.value) })}
                />
              ) : (
                <p className="font-mono text-[13px]">{formatRate(form.interest_max)}</p>
              )}
            </Field>
          </div>
        </div>
      )}
      </>
      )}
    </div>
  );
}
