import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';
import { ReleaseChecklist } from '@/lib/types';

interface RequestReleaseDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  isLoading?: boolean;
  onConfirm: (data: { reason: string; checklist: ReleaseChecklist }) => Promise<void>;
}

export const RequestReleaseDialog: React.FC<RequestReleaseDialogProps> = ({
  open,
  onOpenChange,
  isLoading = false,
  onConfirm,
}) => {
  const [reason, setReason] = useState('');
  const [affidavitReceived, setAffidavitReceived] = useState(false);
  const [noPendingComplaints, setNoPendingComplaints] = useState(false);
  const [closureCertOption, setClosureCertOption] = useState<'na' | 'yes' | 'no'>('na');
  const [maturedOrLockIn, setMaturedOrLockIn] = useState(false);
  const [bankDischargeNoted, setBankDischargeNoted] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (reason.trim().length < 3) return;

    const closureCertValue =
      closureCertOption === 'yes' ? true : closureCertOption === 'no' ? false : null;

    const checklist: ReleaseChecklist = {
      affidavit_received: affidavitReceived,
      no_pending_complaints: noPendingComplaints,
      institution_closure_certificate: closureCertValue,
      matured_or_lock_in_complete: maturedOrLockIn,
      bank_discharge_noted: bankDischargeNoted,
    };

    await onConfirm({ reason: reason.trim(), checklist });
  };

  const isFormValid = reason.trim().length >= 3 && !isLoading;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="sm:max-w-[560px] p-6 max-h-[90vh] overflow-y-auto">
        <form onSubmit={handleSubmit} className="space-y-5">
          <DialogHeader>
            <DialogTitle className="text-base font-semibold text-[var(--ink)]">
              Request Deposit Release
            </DialogTitle>
            <DialogDescription className="text-xs text-[var(--ink-3)]">
              Formal bureau sanction to discharge the security deposit instrument to the institution.
            </DialogDescription>
          </DialogHeader>

          {/* Reason */}
          <div className="space-y-1.5">
            <Label htmlFor="release-reason" className="text-xs font-semibold text-[var(--ink)]">
              Reason for release <span className="text-[var(--risk)]">*</span>
            </Label>
            <Textarea
              id="release-reason"
              rows={3}
              value={reason}
              onChange={(e) => setReason(e.target.value)}
              onKeyDown={(e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && isFormValid) {
                  e.preventDefault();
                  handleSubmit(e);
                }
              }}
              placeholder="e.g. Completion of 10-year lock-in tenure, approval of refund NOC by Executive Committee..."
              className="text-xs"
              required
              autoFocus
            />
            <p className="text-[11px] text-[var(--ink-3)]">
              Recorded in the immutable audit trail for regulatory compliance.
            </p>
          </div>

          {/* Release readiness checklist */}
          <div className="rounded-[6px] border border-[var(--line)] bg-[var(--surface-2)] p-4 space-y-3">
            <div className="flex items-center justify-between border-b border-[var(--line)] pb-2">
              <h4 className="text-xs font-semibold text-[var(--ink)]">
                Release Readiness Checklist
              </h4>
              <span className="text-[10px] text-[var(--ink-3)] uppercase tracking-wider font-mono">
                Mandatory Review
              </span>
            </div>

            <div className="space-y-3 text-xs text-[var(--ink)]">
              {/* Item 1 */}
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={affidavitReceived}
                  onChange={(e) => setAffidavitReceived(e.target.checked)}
                  className="mt-0.5 rounded border-[var(--line)] text-[var(--primary)] focus:ring-[var(--primary)] focus-visible:ring-2 focus-visible:ring-[var(--primary)]"
                />
                <span className="leading-snug">
                  Affidavit received from the institution
                </span>
              </label>

              {/* Item 2 */}
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={noPendingComplaints}
                  onChange={(e) => setNoPendingComplaints(e.target.checked)}
                  className="mt-0.5 rounded border-[var(--line)] text-[var(--primary)] focus:ring-[var(--primary)] focus-visible:ring-2 focus-visible:ring-[var(--primary)]"
                />
                <span className="leading-snug">
                  No pending complaints, vigilance inquiries, or liabilities against the institution
                </span>
              </label>

              {/* Item 3: Closure Certificate */}
              <div className="pt-1 space-y-1.5">
                <span className="block font-medium text-[11px] text-[var(--ink-2)]">
                  Institution closure / progressive closure certificate:
                </span>
                <div className="grid grid-cols-3 gap-2 text-[11px]">
                  <label
                    className={`flex items-center gap-1.5 p-2 rounded border cursor-pointer transition-colors focus-within:ring-2 focus-within:ring-[var(--primary)] ${
                      closureCertOption === 'na'
                        ? 'border-[var(--primary)] bg-white font-medium text-[var(--primary)]'
                        : 'border-[var(--line)] bg-white/50 text-[var(--ink-3)]'
                    }`}
                  >
                    <input
                      type="radio"
                      name="closureCert"
                      value="na"
                      checked={closureCertOption === 'na'}
                      onChange={() => setClosureCertOption('na')}
                      className="sr-only"
                    />
                    <span>Not applicable</span>
                  </label>

                  <label
                    className={`flex items-center gap-1.5 p-2 rounded border cursor-pointer transition-colors focus-within:ring-2 focus-within:ring-[var(--primary)] ${
                      closureCertOption === 'yes'
                        ? 'border-[#027A48] bg-[#ECFDF3] font-medium text-[#027A48]'
                        : 'border-[var(--line)] bg-white/50 text-[var(--ink-3)]'
                    }`}
                  >
                    <input
                      type="radio"
                      name="closureCert"
                      value="yes"
                      checked={closureCertOption === 'yes'}
                      onChange={() => setClosureCertOption('yes')}
                      className="sr-only"
                    />
                    <span>Verified / Received</span>
                  </label>

                  <label
                    className={`flex items-center gap-1.5 p-2 rounded border cursor-pointer transition-colors focus-within:ring-2 focus-within:ring-[var(--primary)] ${
                      closureCertOption === 'no'
                        ? 'border-[#B42318] bg-[#FEF3F2] font-medium text-[#B42318]'
                        : 'border-[var(--line)] bg-white/50 text-[var(--ink-3)]'
                    }`}
                  >
                    <input
                      type="radio"
                      name="closureCert"
                      value="no"
                      checked={closureCertOption === 'no'}
                      onChange={() => setClosureCertOption('no')}
                      className="sr-only"
                    />
                    <span>Not received</span>
                  </label>
                </div>
              </div>

              {/* Item 4 */}
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={maturedOrLockIn}
                  onChange={(e) => setMaturedOrLockIn(e.target.checked)}
                  className="mt-0.5 rounded border-[var(--line)] text-[var(--primary)] focus:ring-[var(--primary)] focus-visible:ring-2 focus-visible:ring-[var(--primary)]"
                />
                <span className="leading-snug">
                  Deposit has matured or its lock-in period is complete
                </span>
              </label>

              {/* Item 5 */}
              <label className="flex items-start gap-2.5 cursor-pointer">
                <input
                  type="checkbox"
                  checked={bankDischargeNoted}
                  onChange={(e) => setBankDischargeNoted(e.target.checked)}
                  className="mt-0.5 rounded border-[var(--line)] text-[var(--primary)] focus:ring-[var(--primary)] focus-visible:ring-2 focus-visible:ring-[var(--primary)]"
                />
                <span className="leading-snug">
                  Bank branch discharge and lien removal instruction noted
                </span>
              </label>
            </div>
          </div>

          <DialogFooter className="pt-2">
            <Button
              type="button"
              variant="outline"
              size="sm"
              onClick={() => onOpenChange(false)}
              disabled={isLoading}
            >
              Cancel
            </Button>
            <Button
              type="submit"
              size="sm"
              disabled={!isFormValid}
              className="bg-[var(--primary)] text-white hover:bg-[var(--primary-hover)]"
            >
              {isLoading ? 'Submitting...' : 'Request Release'}
            </Button>
          </DialogFooter>
        </form>
      </DialogContent>
    </Dialog>
  );
};
