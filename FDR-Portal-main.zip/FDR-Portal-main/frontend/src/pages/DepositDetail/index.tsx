import React, { useState, useRef } from 'react';
import { useParams, useNavigate, Link } from 'react-router-dom';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import {
  FileText,
  Upload,
  Download,
  Trash2,
  ArrowLeft,
  Edit,
  Send,
  CheckCircle,
  XCircle,
  RotateCw,
  ShieldCheck,
  Building2,
  ArrowRight,
  Info,
  Check,
  CheckCircle2,
  MinusCircle,
  FileQuestion,
  MessageSquare,
  ShieldAlert,
} from 'lucide-react';
import { toast } from 'sonner';

import { api, apiDownload } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import {
  inr,
  formatDate,
  formatDateTime,
  formatRate,
  PURPOSE_LABELS,
} from '@/lib/format';
import type {
  FdrDetail,
  FdrStatus,
  AllowedAction,
  ReleaseChecklist,
  DocumentType,
  ObservationItem,
} from '@/lib/types';
import { RequestReleaseDialog } from './RequestReleaseDialog';

import { StatusPill } from '@/components/shared/StatusPill';
import { MaturityChip } from '@/components/shared/MaturityChip';
import { ProvenanceBadge } from '@/components/shared/ProvenanceBadge';
import { HealthBar } from '@/components/shared/HealthBar';
import { ConfirmDialog } from '@/components/shared/ConfirmDialog';
import { ErrorState } from '@/components/shared/ErrorState';
import { Button } from '@/components/ui/button';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Skeleton } from '@/components/ui/skeleton';
import { Badge } from '@/components/ui/badge';
import { Textarea } from '@/components/ui/textarea';

export default function DepositDetailPage() {
  const { user } = useAuth();
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);

  // Active dialog state
  const [confirmAction, setConfirmAction] = useState<
    'submit' | 'approve' | 'reject' | 'request_release' | 'verify' | 'delete_doc' | 'bank_confirm' | null
  >(null);
  const [selectedDocId, setSelectedDocId] = useState<number | null>(null);
  const [actionLoading, setActionLoading] = useState(false);
  const [isUploading, setIsUploading] = useState(false);
  const [uploadDocType, setUploadDocType] = useState<DocumentType>('fdr_receipt');
  const [verifiedDownloads, setVerifiedDownloads] = useState<Record<number, boolean>>({});
  const [newObsText, setNewObsText] = useState('');
  const [replyText, setReplyText] = useState<Record<number, string>>({});
  const [isSubmittingObs, setIsSubmittingObs] = useState(false);

  // Fetch FDR Detail
  const {
    data: fdr,
    isLoading,
    isError,
    error,
    refetch,
  } = useQuery<FdrDetail>({
    queryKey: queryKeys.fdrs.detail(id!),
    queryFn: () => api.get<FdrDetail>(`/fdrs/${id}`),
    enabled: !!id,
    staleTime: 10000,
  });

  // Notify breadcrumbs of current FDR number or not found status
  React.useEffect(() => {
    if (fdr?.fdr_number) {
      window.dispatchEvent(new CustomEvent('fdr-loaded', { detail: fdr.fdr_number }));
    } else if (isError) {
      window.dispatchEvent(new CustomEvent('fdr-loaded', { detail: 'Not found' }));
    }
  }, [fdr?.fdr_number, isError]);

  // Compute tenure in years from issue and maturity dates
  const tenure = React.useMemo(() => {
    if (!fdr?.issue_date || !fdr?.maturity_date) return null;
    const diffDays =
      (new Date(fdr.maturity_date).getTime() - new Date(fdr.issue_date).getTime()) /
      (1000 * 60 * 60 * 24);
    const years = Math.round((diffDays / 365.25) * 10) / 10;
    if (years === 1) return '1 yr';
    return years % 1 === 0 ? `${years.toFixed(0)} yrs` : `${years.toFixed(1)} yrs`;
  }, [fdr?.issue_date, fdr?.maturity_date]);

  // Observations query
  const { data: observations } = useQuery<ObservationItem[]>({
    queryKey: ['observations', id],
    queryFn: () => api.get<ObservationItem[]>(`/fdrs/${id}/observations`),
    enabled: !!id,
    staleTime: 10000,
  });

  const hasBankConfirmationDoc = Boolean(
    fdr?.documents?.some((d) => d.doc_type === 'bank_confirmation')
  );

  const invalidateFdrQueries = () => {
    queryClient.invalidateQueries({ queryKey: queryKeys.fdrs.detail(id!) });
    queryClient.invalidateQueries({ queryKey: queryKeys.fdrs.all });
    queryClient.invalidateQueries({ queryKey: queryKeys.dashboard });
    queryClient.invalidateQueries({ queryKey: ['approvals'] });
    queryClient.invalidateQueries({ queryKey: ['alerts'] });
    queryClient.invalidateQueries({ queryKey: ['observations', id] });
  };

  // Submit FDR for approval
  const submitMutation = useMutation({
    mutationFn: () => api.post(`/fdrs/${id}/submit`),
    onSuccess: () => {
      toast.success(
        fdr?.status === 'rejected'
          ? 'FDR resubmitted for approval'
          : 'FDR submitted for approval'
      );
      invalidateFdrQueries();
    },
    onError: (err: any) => {
      toast.error(err?.detail || err?.message || 'Failed to submit FDR');
    },
  });

  // Reviewer Decision: Approve or Reject
  const decisionMutation = useMutation({
    mutationFn: ({
      action,
      remark,
    }: {
      action: 'approve' | 'reject';
      remark?: string;
    }) => api.post(`/fdrs/${id}/decision`, { action, remark }),
    onSuccess: (_, variables) => {
      if (variables.action === 'approve') {
        toast.success(
          fdr?.status === 'release_requested'
            ? 'Deposit released successfully'
            : 'Deposit approved successfully'
        );
      } else {
        toast.success(
          fdr?.status === 'release_requested'
            ? 'Release request rejected (returned to Approved)'
            : 'Deposit rejected with officer remark'
        );
      }
      invalidateFdrQueries();
    },
    onError: (err: any) => {
      toast.error(err?.detail || err?.message || 'Decision request failed');
    },
  });

  // Admin Request Release
  const releaseMutation = useMutation({
    mutationFn: (data: { reason: string; checklist: ReleaseChecklist }) =>
      api.post(`/fdrs/${id}/request-release`, data),
    onSuccess: () => {
      toast.success('Deposit release requested');
      invalidateFdrQueries();
    },
    onError: (err: any) => {
      toast.error(err?.detail || err?.message || 'Failed to request release');
    },
  });

  // Reviewer Verify
  const verifyMutation = useMutation({
    mutationFn: (remark?: string) => api.post(`/fdrs/${id}/verify`, { remark }),
    onSuccess: () => {
      toast.success('Officer verification recorded on ledger');
      invalidateFdrQueries();
    },
    onError: (err: any) => {
      toast.error(err?.detail || err?.message || 'Verification failed');
    },
  });

  // Reviewer Bank Confirmation by Letter
  const bankConfirmMutation = useMutation({
    mutationFn: (remark?: string) => api.post(`/fdrs/${id}/bank-confirm`, { remark }),
    onSuccess: () => {
      toast.success('Bank confirmation letter recorded on ledger');
      invalidateFdrQueries();
    },
    onError: (err: any) => {
      toast.error(err?.detail || err?.message || 'Bank confirmation failed');
    },
  });

  // Observations actions
  const handleRaiseObservation = async () => {
    if (!newObsText.trim()) return;
    setIsSubmittingObs(true);
    try {
      await api.post(`/fdrs/${id}/observations`, { text: newObsText.trim() });
      toast.success('Scrutiny observation raised');
      setNewObsText('');
      invalidateFdrQueries();
    } catch (err: any) {
      toast.error(err?.detail || 'Failed to raise observation');
    } finally {
      setIsSubmittingObs(false);
    }
  };

  const handleRespondObservation = async (obsId: number) => {
    const text = replyText[obsId];
    if (!text || !text.trim()) return;
    setIsSubmittingObs(true);
    try {
      await api.post(`/observations/${obsId}/respond`, { response: text.trim() });
      toast.success('Reply submitted to observation');
      setReplyText((prev) => ({ ...prev, [obsId]: '' }));
      invalidateFdrQueries();
    } catch (err: any) {
      toast.error(err?.detail || 'Failed to submit response');
    } finally {
      setIsSubmittingObs(false);
    }
  };

  const handleCloseObservation = async (obsId: number) => {
    setIsSubmittingObs(true);
    try {
      await api.post(`/observations/${obsId}/close`);
      toast.success('Observation marked as resolved and closed');
      invalidateFdrQueries();
    } catch (err: any) {
      toast.error(err?.detail || 'Failed to close observation');
    } finally {
      setIsSubmittingObs(false);
    }
  };

  // Upload Document
  const handleFileUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (file.size > 10 * 1024 * 1024) {
      toast.error('File size exceeds the 10 MB limit');
      return;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('doc_type', uploadDocType);

    setIsUploading(true);
    try {
      await api.post(`/fdrs/${id}/documents`, formData);
      toast.success('Document uploaded and attached to record');
      invalidateFdrQueries();
    } catch (err: any) {
      toast.error(err?.detail || 'Failed to upload document');
    } finally {
      setIsUploading(false);
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Delete Document
  const handleDeleteDoc = async () => {
    if (!selectedDocId) return;
    setActionLoading(true);
    try {
      await api.delete(`/documents/${selectedDocId}`);
      toast.success('Document deleted');
      invalidateFdrQueries();
    } catch (err: any) {
      toast.error(err?.detail || 'Failed to delete document');
    } finally {
      setActionLoading(false);
      setConfirmAction(null);
      setSelectedDocId(null);
    }
  };

  // Download Document with integrity check
  const handleDownloadDoc = async (docId: number, filename: string) => {
    try {
      const blob = await apiDownload(`/documents/${docId}/download`, filename);
      if ((blob as any)?.integrity === 'verified') {
        setVerifiedDownloads((prev) => ({ ...prev, [docId]: true }));
        toast.success('Document downloaded · Integrity verified via SHA-256');
      } else {
        toast.success('Document downloaded');
      }
    } catch {
      toast.error('Could not download document');
    }
  };

  if (isLoading) {
    return (
      <div className="space-y-4">
        <Skeleton className="h-6 w-36" />
        <div className="rounded-[8px] border border-[var(--line)] bg-white p-6 space-y-4">
          <Skeleton className="h-8 w-64" />
          <Skeleton className="h-4 w-96" />
          <div className="grid grid-cols-4 gap-4 pt-4">
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
            <Skeleton className="h-16 w-full" />
          </div>
        </div>
      </div>
    );
  }

  if (isError || !fdr) {
    const isNotFound =
      (error as any)?.status === 404 ||
      (error as any)?.detail?.toLowerCase()?.includes('not found') ||
      (error as any)?.message?.toLowerCase()?.includes('not found');

    if (isNotFound) {
      return (
        <div className="space-y-4">
          <Button
            variant="ghost"
            size="sm"
            onClick={() => navigate('/deposits')}
            className="gap-1.5 text-xs text-[var(--ink-2)] -ml-2 hover:bg-[var(--surface-2)]"
          >
            <ArrowLeft className="h-3.5 w-3.5" />
            <span>Back to deposits register</span>
          </Button>

          <div className="rounded-[8px] border border-[var(--line)] bg-white p-8 text-center space-y-4 max-w-lg mx-auto my-8 shadow-2xs">
            <div className="h-12 w-12 rounded-full bg-[var(--surface-2)] border border-[var(--line)] flex items-center justify-center mx-auto">
              <FileQuestion className="h-6 w-6 text-[var(--ink-3)]" />
            </div>
            <div className="space-y-1.5">
              <h2 className="text-sm font-semibold text-[var(--ink)]">
                Deposit Record Not Found
              </h2>
              <p className="text-xs text-[var(--ink-2)] leading-relaxed">
                No deposit with ID {id}. Check the link or search the register.
              </p>
            </div>
            <div className="pt-2">
              <Button
                size="sm"
                onClick={() => navigate('/deposits')}
                className="text-xs"
              >
                Return to Deposits Register
              </Button>
            </div>
          </div>
        </div>
      );
    }

    return (
      <div className="space-y-4">
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/deposits')}
          className="gap-1.5 text-xs text-[var(--ink-2)] -ml-2 hover:bg-[var(--surface-2)]"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to deposits register</span>
        </Button>
        <ErrorState error={error} onRetry={() => refetch()} />
      </div>
    );
  }

  const allowedActions = (fdr.allowed_actions || []) as AllowedAction[];

  return (
    <div className="space-y-5">
      {/* Back button */}
      <div>
        <Button
          variant="ghost"
          size="sm"
          onClick={() => navigate('/deposits')}
          className="gap-1.5 text-xs text-[var(--ink-2)] -ml-2 hover:bg-[var(--surface-2)]"
        >
          <ArrowLeft className="h-3.5 w-3.5" />
          <span>Back to deposits register</span>
        </Button>
      </div>

      {/* Two-way Lineage Banners */}
      {fdr.renewed_from && (
        <div className="rounded-[6px] border border-[#B2DDFF] bg-[#EFF8FF] px-4 py-2.5 text-xs flex items-center justify-between text-[#175CD3]">
          <div className="flex items-center gap-2">
            <RotateCw className="h-4 w-4 shrink-0" />
            <span>
              <strong>Replacement FDR:</strong> This deposit was issued as a renewal replacing previous deposit{' '}
              <Link
                to={`/deposits/${fdr.renewed_from.id}`}
                className="font-mono font-semibold underline hover:text-[#1849A9]"
              >
                {fdr.renewed_from.fdr_number}
              </Link>.
            </span>
          </div>
          <Link
            to={`/deposits/${fdr.renewed_from.id}`}
            className="text-[11px] font-medium underline shrink-0 ml-2"
          >
            View previous FDR →
          </Link>
        </div>
      )}

      {fdr.renewed_to && (
        <div className="rounded-[6px] border border-[#FEDF89] bg-[#FFFAEB] px-4 py-2.5 text-xs flex items-center justify-between text-[#B54708]">
          <div className="flex items-center gap-2">
            <RotateCw className="h-4 w-4 shrink-0" />
            <span>
              <strong>Superseded by Renewal:</strong> This deposit has matured and was renewed into replacement{' '}
              <Link
                to={`/deposits/${fdr.renewed_to.id}`}
                className="font-mono font-semibold underline hover:text-[#7A2E0E]"
              >
                {fdr.renewed_to.fdr_number}
              </Link>.
            </span>
          </div>
          <Link
            to={`/deposits/${fdr.renewed_to.id}`}
            className="text-[11px] font-medium underline shrink-0 ml-2"
          >
            View active replacement →
          </Link>
        </div>
      )}

      {/* Main FDR Header Card */}
      <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 shadow-2xs">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4 pb-4 border-b border-[var(--line)]">
          {/* Header metadata */}
          <div className="space-y-1.5">
            <div className="flex flex-wrap items-center gap-2.5">
              <span className="font-mono text-xl font-bold text-[var(--ink)] tracking-tight">
                {fdr.fdr_number}
              </span>
              <StatusPill status={fdr.status} />
              <ProvenanceBadge verification={fdr.verification} />
              <MaturityChip days={fdr.days_to_maturity} state={fdr.maturity_state} />
            </div>

            <div className="flex items-center gap-2 text-xs text-[var(--ink-2)]">
              <Building2 className="h-3.5 w-3.5 text-[var(--ink-3)]" />
              <Link
                to={`/institutions/${fdr.institution_id}`}
                className="font-medium hover:text-[var(--primary)] hover:underline"
              >
                {fdr.institution_name}
              </Link>
              <span className="text-[var(--ink-3)]">·</span>
              <span>{fdr.bank_name}</span>
              {fdr.branch && <span className="text-[var(--ink-3)]">({fdr.branch})</span>}
            </div>
          </div>

          {/* Action buttons matching allowed_actions */}
          <div className="flex flex-wrap items-center gap-2">
            {allowedActions.includes('edit') && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => navigate(`/deposits/${id}/edit`)}
                className="text-xs gap-1.5"
              >
                <Edit className="h-3.5 w-3.5" />
                <span>Edit</span>
              </Button>
            )}

            {allowedActions.includes('submit') && (
              <Button
                size="sm"
                onClick={() => setConfirmAction('submit')}
                className="text-xs gap-1.5"
              >
                <Send className="h-3.5 w-3.5" />
                <span>{fdr.status === 'rejected' ? 'Resubmit for Approval' : 'Submit for Approval'}</span>
              </Button>
            )}

            {(allowedActions.includes('approve') || allowedActions.includes('sanction_release')) && (
              <Button
                size="sm"
                onClick={() => setConfirmAction('approve')}
                className="text-xs gap-1.5 bg-[#167A4A] hover:bg-[#12633C] text-white"
              >
                <CheckCircle className="h-3.5 w-3.5" />
                <span>{fdr.status === 'release_requested' ? 'Approve Release' : 'Approve'}</span>
              </Button>
            )}

            {(allowedActions.includes('reject') || allowedActions.includes('return_release')) && (
              <Button
                variant="destructive"
                size="sm"
                onClick={() => setConfirmAction('reject')}
                className="text-xs gap-1.5"
              >
                <XCircle className="h-3.5 w-3.5" />
                <span>{fdr.status === 'release_requested' ? 'Reject Release' : 'Reject'}</span>
              </Button>
            )}

            {allowedActions.includes('request_release') && (
              <Button
                size="sm"
                onClick={() => setConfirmAction('request_release')}
                className="text-xs gap-1.5 bg-[#5B4BB7] hover:bg-[#4B3D9E] text-white"
              >
                <span>Request Release</span>
              </Button>
            )}

            {allowedActions.includes('renew') && (
              <Button
                size="sm"
                onClick={() => navigate(`/deposits/${id}/renew`)}
                className="text-xs gap-1.5"
              >
                <RotateCw className="h-3.5 w-3.5" />
                <span>Renew FDR</span>
              </Button>
            )}

            {allowedActions.includes('verify') && (
              <Button
                variant="outline"
                size="sm"
                onClick={() => setConfirmAction('verify')}
                className="text-xs gap-1.5 border-[#C5E9D5] text-[#167A4A] hover:bg-[#E7F5EE]"
              >
                <ShieldCheck className="h-3.5 w-3.5" />
                <span>Mark Verified</span>
              </Button>
            )}

            {/* Bank-confirm action for reviewer */}
            {user?.role === 'reviewer' && fdr.verification !== 'bank_confirmed' && fdr.status !== 'released' && (
              hasBankConfirmationDoc ? (
                <Button
                  size="sm"
                  onClick={() => setConfirmAction('bank_confirm')}
                  className="text-xs gap-1.5 bg-[#167A4A] hover:bg-[#12633C] text-white"
                >
                  <ShieldCheck className="h-3.5 w-3.5" />
                  <span>Bank-confirm</span>
                </Button>
              ) : (
                <div className="relative group inline-block">
                  <Button
                    size="sm"
                    disabled
                    className="text-xs gap-1.5 opacity-60 cursor-not-allowed"
                  >
                    <ShieldCheck className="h-3.5 w-3.5" />
                    <span>Bank-confirm</span>
                  </Button>
                  <div className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1.5 hidden group-hover:block z-50 whitespace-nowrap rounded-[4px] bg-[var(--ink)] px-2 py-1 text-[11px] text-white shadow-xs pointer-events-none">
                    The Bureau attaches the bank&apos;s confirmation letter first
                  </div>
                </div>
              )
            )}
          </div>
        </div>

        {/* 4 Primary Metric Pillars */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 pt-4 text-xs">
          <div>
            <span className="text-[11px] text-[var(--ink-3)] block font-medium">
              Principal Deposit
            </span>
            <span className="font-mono text-base font-semibold text-[var(--ink)] tabular-nums mt-0.5 block">
              {inr(fdr.amount)}
            </span>
          </div>

          <div>
            <span className="text-[11px] text-[var(--ink-3)] block font-medium">
              Projected value
            </span>
            <span className="font-mono text-base font-semibold text-[var(--primary)] tabular-nums mt-0.5 block">
              {inr(fdr.projected_value)}
            </span>
          </div>

          <div>
            <span className="text-[11px] text-[var(--ink-3)] block font-medium">
              Interest Rate &amp; Tenure
            </span>
            <span className="font-mono text-base font-medium text-[var(--ink)] tabular-nums mt-0.5 block">
              {formatRate(fdr.interest_rate)} p.a.{tenure && ` · ${tenure}`}
            </span>
          </div>

          <div>
            <span className="text-[11px] text-[var(--ink-3)] block font-medium">
              Integrity Health Score
            </span>
            <div className="mt-1">
              <HealthBar score={fdr.health_score} size="default" />
            </div>
          </div>
        </div>

        {/* Provenance 4-stage status trail */}
        <div className="mt-4 pt-3 border-t border-[var(--line)]">
          <div className="text-[11px] font-semibold uppercase tracking-wider text-[var(--ink-3)] mb-2">
            Deposit Provenance &amp; Verification Chain
          </div>
          <div className="flex flex-wrap items-center gap-2 text-xs">
            <span className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] font-medium border text-xs bg-[#E7F5EE] border-[#C5E9D5] text-[#167A4A]">
              <Check className="h-3.5 w-3.5 text-[#167A4A]" />
              <span>Submitted</span>
            </span>

            <span className="text-[var(--ink-3)]">→</span>

            <span
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] font-medium border text-xs ${
                fdr.verification === 'officer_verified' || fdr.verification === 'bank_confirmed'
                  ? 'bg-[#E7F5EE] border-[#C5E9D5] text-[#167A4A]'
                  : 'bg-white border-[var(--line)] text-[var(--ink-3)]'
              }`}
            >
              {(fdr.verification === 'officer_verified' || fdr.verification === 'bank_confirmed') && (
                <Check className="h-3.5 w-3.5 text-[#167A4A]" />
              )}
              <span>Officer-verified</span>
            </span>

            <span className="text-[var(--ink-3)]">→</span>

            <span
              className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] font-medium border text-xs ${
                fdr.verification === 'bank_confirmed'
                  ? 'bg-[#E7F5EE] border-[#C5E9D5] text-[#167A4A]'
                  : 'bg-white border-[var(--line)] text-[var(--ink-3)]'
              }`}
            >
              {fdr.verification === 'bank_confirmed' && (
                <Check className="h-3.5 w-3.5 text-[#167A4A]" />
              )}
              <span>Bank-confirmed (letter on file)</span>
            </span>

            <span className="text-[var(--ink-3)]">→</span>

            <span
              className="inline-flex items-center gap-1.5 px-2.5 py-1 rounded-[4px] font-medium border border-dashed border-[var(--line)] bg-[var(--surface-1)] text-[var(--ink-3)] opacity-70 cursor-not-allowed"
              title="Bank verification API not connected in prototype"
            >
              <ShieldAlert className="h-3.5 w-3.5 text-[var(--ink-3)]" />
              <span>Bank API: not connected in prototype</span>
            </span>
          </div>
        </div>
      </div>

      {/* Detail Tabs */}
      <Tabs defaultValue="overview" className="w-full">
        <TabsList>
          <TabsTrigger value="overview">Overview &amp; Terms</TabsTrigger>
          <TabsTrigger value="observations" className="relative">
            <span>Observations ({observations?.length || 0})</span>
            {(fdr.observations_open ?? 0) > 0 && (
              <span className="ml-1.5 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-[var(--warn)] px-1 font-mono text-[10px] font-bold text-white">
                {fdr.observations_open}
              </span>
            )}
          </TabsTrigger>
          <TabsTrigger value="documents">
            Documents ({fdr.documents?.length || 0})
          </TabsTrigger>
          <TabsTrigger value="health">
            Health Check ({fdr.findings?.length || 0})
          </TabsTrigger>
          <TabsTrigger value="history">
            Audit Timeline ({fdr.history?.length || 0})
          </TabsTrigger>
        </TabsList>

        {/* Tab 1: Overview */}
        <TabsContent value="overview">
          <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 space-y-6">
            {/* Release Readiness Checklist (shown if release requested, released, or checklist recorded) */}
            {(fdr.status === 'release_requested' || fdr.status === 'released' || fdr.release_checklist) && (
              <div className="rounded-[6px] border border-[var(--line)] bg-[var(--surface-2)] p-4 space-y-3">
                <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
                  <div className="flex items-center gap-2">
                    <h3 className="text-xs font-semibold text-[var(--ink)]">
                      Release Readiness Checklist
                    </h3>
                    {fdr.release_ready === true ? (
                      <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-[#ECFDF3] text-[#027A48]">
                        Checklist complete
                      </span>
                    ) : fdr.release_ready === false ? (
                      <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-[#FEF3F2] text-[#B42318]">
                        Checklist incomplete
                      </span>
                    ) : (
                      <span className="px-2 py-0.5 rounded text-[11px] font-medium bg-white text-[var(--ink-3)] border border-[var(--line)]">
                        Checklist not recorded
                      </span>
                    )}
                  </div>
                </div>

                {fdr.release_checklist ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-xs">
                    <div className="flex items-center gap-2">
                      {fdr.release_checklist.affidavit_received ? (
                        <CheckCircle2 className="h-4 w-4 text-[#027A48] shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 text-[#B42318] shrink-0" />
                      )}
                      <span className="text-[var(--ink)]">Affidavit received from institution</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {fdr.release_checklist.no_pending_complaints ? (
                        <CheckCircle2 className="h-4 w-4 text-[#027A48] shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 text-[#B42318] shrink-0" />
                      )}
                      <span className="text-[var(--ink)]">No pending complaints or liabilities</span>
                    </div>
                    <div className="flex items-center gap-2">
                      {fdr.release_checklist.institution_closure_certificate === true ? (
                        <CheckCircle2 className="h-4 w-4 text-[#027A48] shrink-0" />
                      ) : fdr.release_checklist.institution_closure_certificate === false ? (
                        <XCircle className="h-4 w-4 text-[#B42318] shrink-0" />
                      ) : (
                        <MinusCircle className="h-4 w-4 text-[var(--ink-3)] shrink-0" />
                      )}
                      <span className="text-[var(--ink)]">
                        Closure certificate:{' '}
                        {fdr.release_checklist.institution_closure_certificate === true
                          ? 'Verified'
                          : fdr.release_checklist.institution_closure_certificate === false
                          ? 'Not received'
                          : 'Not applicable'}
                      </span>
                    </div>
                    <div className="flex items-center gap-2">
                      {fdr.release_checklist.matured_or_lock_in_complete ? (
                        <CheckCircle2 className="h-4 w-4 text-[#027A48] shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 text-[#B42318] shrink-0" />
                      )}
                      <span className="text-[var(--ink)]">Matured or lock-in complete</span>
                    </div>
                    <div className="flex items-center gap-2 sm:col-span-2">
                      {fdr.release_checklist.bank_discharge_noted ? (
                        <CheckCircle2 className="h-4 w-4 text-[#027A48] shrink-0" />
                      ) : (
                        <XCircle className="h-4 w-4 text-[#B42318] shrink-0" />
                      )}
                      <span className="text-[var(--ink)]">Bank discharge noted</span>
                    </div>
                  </div>
                ) : (
                  <p className="text-xs text-[var(--ink-3)]">
                    This release request was made before the checklist was recorded.
                  </p>
                )}
              </div>
            )}

            {/* Section 1: Instrument & Terms */}
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--ink-3)] mb-3">
                Instrument &amp; Bank Details
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-y-4 gap-x-6 text-xs">
                <div>
                  <span className="text-[var(--ink-3)] block">FDR Number</span>
                  <span className="font-mono font-medium text-[var(--ink)] mt-0.5 block">
                    {fdr.fdr_number}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Bank Name</span>
                  <span className="font-medium text-[var(--ink)] mt-0.5 block">
                    {fdr.bank_name}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Branch</span>
                  <span className="text-[var(--ink)] mt-0.5 block">
                    {fdr.branch || '—'}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">IFSC Code</span>
                  <span className="font-mono text-[var(--ink)] mt-0.5 block">
                    {fdr.ifsc || '—'}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Purpose of Deposit</span>
                  <span className="text-[var(--ink)] mt-0.5 block">
                    {PURPOSE_LABELS[fdr.purpose] || fdr.purpose}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Lien Marked to AICTE</span>
                  <span className="font-medium mt-0.5 block">
                    {fdr.lien_to_aicte ? (
                      <span className="text-[#167A4A] inline-flex items-center gap-1">
                        <Check className="h-3 w-3 stroke-[2.5]" /> Marked
                      </span>
                    ) : (
                      <span className="text-[#B42318]">No lien marked</span>
                    )}
                  </span>
                </div>
              </div>
            </div>

            <div className="h-[1px] bg-[var(--line)]" />

            {/* Section 2: Dates and Calculations */}
            <div>
              <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--ink-3)] mb-3">
                Dates and Calculations
              </h3>
              <div className="grid grid-cols-1 md:grid-cols-3 gap-y-4 gap-x-6 text-xs">
                <div>
                  <span className="text-[var(--ink-3)] block">Issue Date</span>
                  <span className="font-medium text-[var(--ink)] mt-0.5 block">
                    {formatDate(fdr.issue_date)}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Maturity Date</span>
                  <div className="flex items-center gap-1.5 mt-0.5">
                    <span className="font-medium text-[var(--ink)]">
                      {formatDate(fdr.maturity_date)}
                    </span>
                    <MaturityChip days={fdr.days_to_maturity} state={fdr.maturity_state} />
                  </div>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Interest Rate</span>
                  <span className="font-mono text-[var(--ink)] mt-0.5 block">
                    {formatRate(fdr.interest_rate)} p.a. (compounded quarterly)
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Maturity Value on Receipt</span>
                  <span className="font-mono text-[var(--ink)] mt-0.5 block">
                    {fdr.maturity_amount ? inr(fdr.maturity_amount) : 'Not specified'}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Projected value</span>
                  <span className="font-mono font-semibold text-[var(--primary)] mt-0.5 block">
                    {inr(fdr.projected_value)}
                  </span>
                </div>
                <div>
                  <span className="text-[var(--ink-3)] block">Days to Maturity</span>
                  <span className="font-mono text-[var(--ink)] mt-0.5 block">
                    {fdr.status === 'released' || fdr.status === 'renewed'
                      ? 'Closed'
                      : fdr.days_to_maturity < 0
                      ? `Matured ${Math.abs(fdr.days_to_maturity)} days ago`
                      : fdr.days_to_maturity === 0
                      ? 'Matures today'
                      : `${fdr.days_to_maturity} days`}
                  </span>
                </div>
              </div>
            </div>

            {/* Section 3: Renewal Lineage & Remarks */}
            {((fdr.lineage && fdr.lineage.length > 1) || fdr.remarks) && (
              <>
                <div className="h-[1px] bg-[var(--line)]" />
                <div>
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-[var(--ink-3)] mb-3">
                    Renewal Lineage &amp; Remarks
                  </h3>

                  {fdr.lineage && fdr.lineage.length > 1 && (
                    <div className="mb-4">
                      <div className="flex items-center gap-2 overflow-x-auto pb-2">
                        {fdr.lineage.map((item, idx) => {
                          const isCurrent = item.id === fdr.id;
                          return (
                            <React.Fragment key={item.id}>
                              {idx > 0 && (
                                <ArrowRight className="h-4 w-4 text-[var(--ink-3)] shrink-0" />
                              )}
                              <div
                                className={`shrink-0 rounded-[6px] p-2.5 min-w-[180px] border transition-colors ${
                                  isCurrent
                                    ? 'bg-[var(--surface-2)] border-[var(--primary)] ring-1 ring-[var(--primary)]'
                                    : 'bg-[var(--surface-1)] border-[var(--line)] hover:bg-[var(--surface-2)]'
                                }`}
                              >
                                <div className="flex items-center justify-between gap-1.5 mb-1">
                                  {isCurrent ? (
                                    <span className="font-mono text-xs font-semibold text-[var(--ink)] truncate">
                                      {item.fdr_number}
                                    </span>
                                  ) : (
                                    <Link
                                      to={`/deposits/${item.id}`}
                                      className="font-mono text-xs font-semibold text-[var(--primary)] hover:underline truncate"
                                    >
                                      {item.fdr_number}
                                    </Link>
                                  )}
                                  <StatusPill status={item.status} />
                                </div>
                                <div className="text-[11px] text-[var(--ink-3)] font-mono space-y-0.5">
                                  <div>{inr(item.amount)}</div>
                                  <div className="text-[10px]">
                                    {formatDate(item.issue_date)} → {formatDate(item.maturity_date)}
                                  </div>
                                </div>
                                {isCurrent && (
                                  <div className="mt-1.5 pt-1 border-t border-[var(--line)] text-[10px] font-medium text-[var(--primary)]">
                                    Current Record
                                  </div>
                                )}
                              </div>
                            </React.Fragment>
                          );
                        })}
                      </div>
                    </div>
                  )}

                  {fdr.remarks && (
                    <div>
                      <span className="text-[var(--ink-3)] block text-xs">Officer Remarks</span>
                      <p className="mt-1 p-2.5 rounded-[4px] bg-[var(--surface-2)] border border-[var(--line)] text-xs text-[var(--ink-2)]">
                        {fdr.remarks}
                      </p>
                    </div>
                  )}
                </div>
              </>
            )}

            <div className="h-[1px] bg-[var(--line)]" />

            {/* Section 4: Record Provenance */}
            <div className="text-[11px] text-[var(--ink-3)] flex flex-wrap items-center justify-between gap-2">
              <div>
                Created by <span className="text-[var(--ink)]">{fdr.created_by}</span> on{' '}
                {formatDateTime(fdr.created_at)}
              </div>
              <div>Last modified: {formatDateTime(fdr.updated_at)}</div>
            </div>
          </div>
        </TabsContent>

        {/* Tab: Observations */}
        <TabsContent value="observations">
          <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 space-y-5">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--line)]">
              <div>
                <h3 className="text-sm font-semibold text-[var(--ink)]">
                  Scrutiny Observations &amp; Replies
                </h3>
                <p className="text-[11px] text-[var(--ink-3)]">
                  Formal regulatory queries and clarifications raised by scrutiny officers during review
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs font-mono text-[var(--ink-3)]">
                  {observations?.length || 0} {observations?.length === 1 ? 'thread' : 'threads'}
                </span>
                {(fdr.observations_open ?? 0) > 0 && (
                  <Badge variant="secondary" className="bg-[#FEF3E2] text-[#B45309] border-[#FEDF89] text-[10px]">
                    {fdr.observations_open} open
                  </Badge>
                )}
              </div>
            </div>

            {/* Reviewer Raise Observation Box */}
            {user?.role === 'reviewer' && ['pending_approval', 'approved', 'release_requested'].includes(fdr.status) && (
              <div className="rounded-[6px] border border-[var(--line)] bg-[var(--surface-2)] p-4 space-y-3">
                <div className="flex items-center gap-2 text-xs font-semibold text-[var(--ink)]">
                  <MessageSquare className="h-4 w-4 text-[var(--primary)]" />
                  <span>Raise a Scrutiny Observation</span>
                </div>
                <Textarea
                  placeholder="Enter observation or query for the institution (e.g. Please clarify mismatch in maturity date on receipt)..."
                  value={newObsText}
                  onChange={(e) => setNewObsText(e.target.value)}
                  className="text-xs min-h-[70px] bg-white resize-none"
                />
                <div className="flex justify-end">
                  <Button
                    size="sm"
                    disabled={!newObsText.trim() || isSubmittingObs}
                    onClick={handleRaiseObservation}
                    className="text-xs gap-1.5"
                  >
                    <span>{isSubmittingObs ? 'Raising...' : 'Raise Observation'}</span>
                  </Button>
                </div>
              </div>
            )}

            {/* Observations List */}
            {observations && observations.length > 0 ? (
              <div className="space-y-4">
                {observations.map((obs) => {
                  const isOpen = obs.status === 'open';
                  const isAnswered = obs.status === 'answered';
                  const isClosed = obs.status === 'closed';

                  return (
                    <div
                      key={obs.id}
                      className="rounded-[6px] border border-[var(--line)] bg-[var(--surface-1)] p-4 space-y-3 text-xs"
                    >
                      <div className="flex items-center justify-between pb-2 border-b border-[var(--line)]">
                        <div className="flex items-center gap-2">
                          <span className="font-semibold text-[var(--ink)]">
                            {obs.author_name}
                          </span>
                          <span className="text-[10px] text-[var(--ink-3)] font-mono">
                            ({obs.author_role || 'Scrutiny Officer'})
                          </span>
                          <span className="text-[var(--ink-3)]">·</span>
                          <span className="text-[11px] text-[var(--ink-3)] font-mono">
                            {formatDateTime(obs.created_at)}
                          </span>
                        </div>
                        <div className="flex items-center gap-2">
                          {isOpen && (
                            <span className="px-2 py-0.5 rounded-[3px] text-[10px] font-medium bg-[#FEF3E2] text-[#B45309] border border-[#FEDF89]">
                              Open
                            </span>
                          )}
                          {isAnswered && (
                            <span className="px-2 py-0.5 rounded-[3px] text-[10px] font-medium bg-[#EEF1F5] text-[#475467] border border-[var(--line)]">
                              Answered
                            </span>
                          )}
                          {isClosed && (
                            <span className="px-2 py-0.5 rounded-[3px] text-[10px] font-medium bg-[#ECFDF3] text-[#027A48] border border-[#A6F4C5]">
                              Closed
                            </span>
                          )}
                        </div>
                      </div>

                      {/* Question text */}
                      <p className="text-[var(--ink)] whitespace-pre-wrap leading-relaxed">
                        {obs.text}
                      </p>

                      {/* Institution Response if present */}
                      {obs.response && (
                        <div className="rounded-[4px] border border-[var(--line)] bg-white p-3 space-y-1.5 mt-2">
                          <div className="flex items-center justify-between text-[11px] text-[var(--ink-3)]">
                            <span className="font-medium text-[var(--ink)]">
                              Institution Response {obs.responded_by ? `(${obs.responded_by})` : ''}
                            </span>
                            <span className="font-mono">{formatDateTime(obs.responded_at)}</span>
                          </div>
                          <p className="text-[var(--ink)] whitespace-pre-wrap">
                            {obs.response}
                          </p>
                        </div>
                      )}

                      {/* Reply Form for institution or admin when observation is open */}
                      {isOpen && (user?.role === 'institution' || user?.role === 'admin') && (
                        <div className="pt-2 space-y-2 border-t border-[var(--line)]">
                          <Textarea
                            placeholder="Type official reply to this observation..."
                            value={replyText[obs.id] || ''}
                            onChange={(e) =>
                              setReplyText((prev) => ({ ...prev, [obs.id]: e.target.value }))
                            }
                            className="text-xs min-h-[60px] bg-white resize-none"
                          />
                          <div className="flex justify-end">
                            <Button
                              size="sm"
                              disabled={!replyText[obs.id]?.trim() || isSubmittingObs}
                              onClick={() => handleRespondObservation(obs.id)}
                              className="text-xs"
                            >
                              Submit Reply
                            </Button>
                          </div>
                        </div>
                      )}

                      {/* Reviewer Close Action */}
                      {user?.role === 'reviewer' && !isClosed && (
                        <div className="flex justify-end pt-1 border-t border-[var(--line)]">
                          <Button
                            variant="outline"
                            size="sm"
                            disabled={isSubmittingObs}
                            onClick={() => handleCloseObservation(obs.id)}
                            className="text-xs h-7"
                          >
                            Mark Observation Closed
                          </Button>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-[var(--ink-3)] space-y-1">
                <MessageSquare className="h-7 w-7 mx-auto text-[var(--ink-3)] opacity-40 mb-1" />
                <p className="font-medium">No scrutiny observations on this deposit.</p>
                <p className="text-[11px]">
                  Scrutiny officers can raise clarification queries before approving the deposit.
                </p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tab 2: Documents */}
        <TabsContent value="documents">
          <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 space-y-4">
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-[var(--line)]">
              <div>
                <h3 className="text-sm font-semibold text-[var(--ink)]">
                  Attached Deposit Instruments &amp; Receipts
                </h3>
                <p className="text-[11px] text-[var(--ink-3)]">
                  Original bank receipts, verification notes, and lien confirmation letters
                </p>
              </div>

              {/* Upload button when allowed by status/role */}
              {allowedActions.includes('upload') && (
                <div className="flex items-center gap-2">
                  <select
                    value={uploadDocType}
                    onChange={(e) => setUploadDocType(e.target.value as DocumentType)}
                    className="h-8 text-xs px-2 rounded-[4px] border border-[var(--line)] bg-[var(--surface-1)] text-[var(--ink)] focus:outline-none focus:border-[var(--primary)]"
                    aria-label="Document type"
                  >
                    <option value="fdr_receipt">FDR receipt</option>
                    {user?.role !== 'institution' && (
                      <option value="bank_confirmation">Bank confirmation letter</option>
                    )}
                    <option value="lien_letter">Lien letter</option>
                    <option value="affidavit">Affidavit</option>
                    <option value="closure_certificate">Closure certificate</option>
                    <option value="renewal_letter">Renewal letter</option>
                    <option value="other">Other</option>
                  </select>
                  <input
                    type="file"
                    ref={fileInputRef}
                    onChange={handleFileUpload}
                    accept=".pdf,.jpg,.jpeg,.png"
                    className="hidden"
                  />
                  <Button
                    size="sm"
                    disabled={isUploading}
                    onClick={() => fileInputRef.current?.click()}
                    className="text-xs gap-1.5"
                  >
                    <Upload className="h-3.5 w-3.5" />
                    <span>{isUploading ? 'Uploading...' : 'Upload Document'}</span>
                  </Button>
                </div>
              )}
            </div>

            {/* Document list */}
            {fdr.documents && fdr.documents.length > 0 ? (
              <div className="divide-y divide-[var(--line)]">
                {fdr.documents.map((doc) => (
                  <div
                    key={doc.id}
                    className="py-3 flex items-center justify-between gap-3 text-xs hover:bg-[var(--surface-2)] px-2 rounded-[4px] transition-colors"
                  >
                    <div className="flex items-center gap-3 min-w-0">
                      <div className="h-8 w-8 rounded-[4px] bg-[var(--surface-2)] border border-[var(--line)] flex items-center justify-center shrink-0">
                        <FileText className="h-4 w-4 text-[var(--primary)]" />
                      </div>
                      <div className="min-w-0">
                        <div className="flex items-center gap-2 flex-wrap">
                          <span className="font-medium text-[var(--ink)] block truncate">
                            {doc.filename}
                          </span>
                          <span className="text-[10px] font-medium px-1.5 py-0.5 rounded-[3px] bg-[var(--surface-2)] text-[var(--ink-2)] border border-[var(--line)] shrink-0">
                            {doc.doc_type_label || 'FDR receipt'}
                          </span>
                          {doc.sha256 && (
                            <span
                              className="font-mono text-[10px] text-[var(--ink-3)] bg-[var(--surface-2)] border border-[var(--line)] px-1.5 py-0.2 rounded shrink-0"
                              title={`SHA-256 fingerprint: ${doc.sha256}`}
                            >
                              SHA: {doc.sha256.slice(0, 8)}
                            </span>
                          )}
                          {verifiedDownloads[doc.id] && (
                            <span className="inline-flex items-center gap-1 text-[10px] font-medium text-[#167A4A] bg-[#E7F5EE] border border-[#C5E9D5] px-1.5 py-0.2 rounded shrink-0">
                              <Check className="h-2.5 w-2.5 stroke-[2.5]" />
                              <span>Integrity verified</span>
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-2 text-[11px] text-[var(--ink-3)] font-mono">
                          <span>{(doc.size_bytes / 1024).toFixed(1)} KB</span>
                          <span>·</span>
                          <span>{formatDate(doc.uploaded_at)}</span>
                          {doc.uploaded_by && (
                            <>
                              <span>·</span>
                              <span>Uploaded by {doc.uploaded_by}</span>
                            </>
                          )}
                        </div>
                      </div>
                    </div>

                    <div className="flex items-center gap-1.5 shrink-0">
                      <Button
                        variant="outline"
                        size="icon-sm"
                        onClick={() => handleDownloadDoc(doc.id, doc.filename)}
                        title="Download document"
                      >
                        <Download className="h-3.5 w-3.5 text-[var(--ink-2)]" />
                      </Button>

                      {allowedActions.includes('upload') && (
                        <Button
                          variant="ghost"
                          size="icon-sm"
                          onClick={() => {
                            setSelectedDocId(doc.id);
                            setConfirmAction('delete_doc');
                          }}
                          title="Delete document"
                          className="hover:text-[var(--risk)]"
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-[var(--ink-3)]">
                <FileText className="h-8 w-8 mx-auto text-[var(--ink-3)] opacity-40 mb-2" />
                <p>No document attached to this deposit yet.</p>
                {allowedActions.includes('upload') && (
                  <p className="mt-1 text-[11px]">
                    Upload a scanned copy of the FDR receipt or bank confirmation letter.
                  </p>
                )}
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tab 3: Health Check */}
        <TabsContent value="health">
          <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[var(--line)]">
              <div>
                <h3 className="text-sm font-semibold text-[var(--ink)]">
                  Compliance &amp; Discrepancy Findings
                </h3>
                <p className="text-[11px] text-[var(--ink-3)]">
                  Evaluated automatically by backend rules engine against deposit terms
                </p>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-xs text-[var(--ink-3)]">Health Score:</span>
                <HealthBar score={fdr.health_score} />
              </div>
            </div>

            {fdr.findings && fdr.findings.length > 0 ? (
              <div className="space-y-3">
                {fdr.findings.map((finding, idx) => {
                  let borderClass = 'border-[#E3E7EC]';
                  if (finding.severity === 'critical') {
                    borderClass = 'border-[#F8D4D0] bg-[#FDECEA]/30';
                  } else if (finding.severity === 'warning') {
                    borderClass = 'border-[#F8E1BE] bg-[#FEF3E2]/30';
                  }

                  return (
                    <div
                      key={idx}
                      className={`p-3.5 rounded-[6px] border ${borderClass} space-y-1.5 text-xs`}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <span
                            className={`font-mono text-[10px] uppercase font-bold px-1.5 py-0.5 rounded ${
                              finding.severity === 'critical'
                                ? 'bg-[#FDECEA] text-[#B42318]'
                                : finding.severity === 'warning'
                                ? 'bg-[#FEF3E2] text-[#B45309]'
                                : 'bg-[#EEF1F5] text-[#475467]'
                            }`}
                          >
                            {finding.severity}
                          </span>
                          <span className="font-mono text-[11px] text-[var(--ink-2)] font-semibold">
                            {finding.code}
                          </span>
                        </div>
                      </div>

                      <p className="font-medium text-[var(--ink)]">
                        {finding.message}
                      </p>

                      <div className="flex items-start gap-1.5 pt-1 text-[11px] text-[var(--ink-2)]">
                        <Info className="h-3.5 w-3.5 text-[var(--primary)] shrink-0 mt-0.5" />
                        <span>
                          <strong className="text-[var(--ink)]">Recommended Action:</strong>{' '}
                          {finding.fix}
                        </span>
                      </div>
                    </div>
                  );
                })}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-[#167A4A] space-y-2">
                <ShieldCheck className="h-8 w-8 mx-auto text-[#167A4A]" />
                <p className="font-medium">
                  Zero discrepancies or integrity findings detected.
                </p>
                <p className="text-[11px] text-[var(--ink-3)]">
                  All dates, amounts, liens, and document requirements are satisfied.
                </p>
              </div>
            )}
          </div>
        </TabsContent>

        {/* Tab 4: Audit History */}
        <TabsContent value="history">
          <div className="rounded-[8px] border border-[var(--line)] bg-white p-5 space-y-4">
            <div className="flex items-center justify-between pb-3 border-b border-[var(--line)]">
              <div>
                <h3 className="text-sm font-semibold text-[var(--ink)]">
                  Immutable Audit Ledger
                </h3>
                <p className="text-[11px] text-[var(--ink-3)]">
                  Every action on this deposit, with who and when; each entry is chained to the one before
                </p>
              </div>
              <span className="text-[11px] font-mono text-[var(--ink-3)]">
                {fdr.history?.length || 0} entries
              </span>
            </div>

            {fdr.history && fdr.history.length > 0 ? (
              <div className="relative pl-6 space-y-6 before:absolute before:left-2 before:top-2 before:bottom-2 before:w-[2px] before:bg-[var(--line)]">
                {fdr.history.map((hist) => (
                  <div key={hist.id} className="relative text-xs">
                    {/* Timeline bullet */}
                    <div className="absolute -left-[27px] top-1 h-3.5 w-3.5 rounded-full border-2 border-[var(--primary)] bg-white" />

                    <div className="space-y-1">
                      <div className="flex flex-wrap items-center justify-between gap-2">
                        <span className="font-semibold text-[var(--ink)]">
                          {hist.action_label || hist.action}
                        </span>
                        <span className="font-mono text-[11px] text-[var(--ink-3)]">
                          {formatDateTime(hist.at)}
                        </span>
                      </div>

                      <div className="flex items-center gap-2 text-[11px] text-[var(--ink-2)]">
                        <span>{hist.actor_name}</span>
                        {hist.actor_role && (
                          <span className="font-mono uppercase text-[9px] bg-[var(--surface-2)] px-1 rounded border border-[var(--line)]">
                            {hist.actor_role}
                          </span>
                        )}
                      </div>

                      {/* Status Transition Pills if applicable */}
                      {hist.from_status && hist.to_status && (
                        <div className="flex items-center gap-2 pt-1">
                          <StatusPill status={hist.from_status as FdrStatus} />
                          <ArrowRight className="h-3 w-3 text-[var(--ink-3)]" />
                          <StatusPill status={hist.to_status as FdrStatus} />
                        </div>
                      )}

                      {/* Detail payload summary */}
                      {hist.detail && Object.keys(hist.detail).length > 0 && (
                        <div className="mt-1.5 p-2 rounded-[4px] bg-[var(--surface-2)] border border-[var(--line)] font-mono text-[11px] text-[var(--ink-2)]">
                          {Boolean(hist.detail.remark) && (
                            <div>Remark: {String(hist.detail.remark)}</div>
                          )}
                          {Boolean(hist.detail.reason) && (
                            <div>Reason: {String(hist.detail.reason)}</div>
                          )}
                          {Boolean(hist.detail.renewed_to) && (
                            <div>
                              Renewed into FDR #{' '}
                              {String((hist.detail.renewed_to as any)?.fdr_number)}
                            </div>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="py-8 text-center text-xs text-[var(--ink-3)]">
                No ledger activity recorded for this instrument yet.
              </div>
            )}
          </div>
        </TabsContent>
      </Tabs>

      {/* Confirmation Dialogs */}
      {/* 1. Submit for Approval */}
      <ConfirmDialog
        open={confirmAction === 'submit'}
        onOpenChange={(open) => !open && setConfirmAction(null)}
        title={fdr.status === 'rejected' ? 'Resubmit FDR for Approval' : 'Submit FDR for Approval'}
        description={
          fdr.status === 'rejected'
            ? "Remediated deposit will move to Pending approval and return to the reviewer's queue."
            : "It moves to Pending approval and appears in the reviewer's queue."
        }
        confirmLabel={fdr.status === 'rejected' ? 'Resubmit FDR' : 'Submit FDR'}
        isLoading={submitMutation.isPending}
        onConfirm={async () => {
          await submitMutation.mutateAsync();
          setConfirmAction(null);
        }}
      />

      {/* 2. Reviewer Approve */}
      <ConfirmDialog
        open={confirmAction === 'approve'}
        onOpenChange={(open) => !open && setConfirmAction(null)}
        title={fdr.status === 'release_requested' ? 'Approve Deposit Release' : 'Approve FDR Deposit'}
        description={
          fdr.status === 'release_requested'
            ? 'Authorize release of principal deposit funds to the institution. The status will move to Released.'
            : 'Verify compliance and mark this deposit as active on the bureau ledger.'
        }
        confirmLabel={fdr.status === 'release_requested' ? 'Approve Release' : 'Approve Deposit'}
        variant="default"
        showRemark={true}
        remarkLabel="Approval Remark (Optional)"
        isLoading={decisionMutation.isPending}
        onConfirm={async (remark) => {
          await decisionMutation.mutateAsync({ action: 'approve', remark });
          setConfirmAction(null);
        }}
      />

      {/* 3. Reviewer Reject */}
      <ConfirmDialog
        open={confirmAction === 'reject'}
        onOpenChange={(open) => !open && setConfirmAction(null)}
        title={fdr.status === 'release_requested' ? 'Reject Release Request' : 'Reject FDR Deposit'}
        description={
          fdr.status === 'release_requested'
            ? 'Reject the release request and keep this deposit in Approved status. An officer remark is required.'
            : 'A clear justification is required for the audit record so the submitting officer can remediate.'
        }
        confirmLabel={fdr.status === 'release_requested' ? 'Reject Release' : 'Reject Deposit'}
        variant="destructive"
        requireRemark={true}
        remarkLabel={
          fdr.status === 'release_requested'
            ? 'Reason for Rejecting Release (Required)'
            : 'Reason for Rejection (Required)'
        }
        remarkPlaceholder={
          fdr.status === 'release_requested'
            ? 'e.g. NOC not verified, pending compliance audit...'
            : 'e.g. Lien not marked to AICTE on receipt, interest rate mismatch...'
        }
        isLoading={decisionMutation.isPending}
        onConfirm={async (remark) => {
          await decisionMutation.mutateAsync({ action: 'reject', remark });
          setConfirmAction(null);
        }}
      />

      {/* 4. Request release with the checklist */}
      <RequestReleaseDialog
        open={confirmAction === 'request_release'}
        onOpenChange={(open) => !open && setConfirmAction(null)}
        isLoading={releaseMutation.isPending}
        onConfirm={async (data) => {
          await releaseMutation.mutateAsync(data);
          setConfirmAction(null);
        }}
      />

      {/* 5. Reviewer Mark Verified */}
      <ConfirmDialog
        open={confirmAction === 'verify'}
        onOpenChange={(open) => !open && setConfirmAction(null)}
        title="Mark Officer Verified"
        description="Attest that you have manually verified the physical or electronic receipt against bank records."
        confirmLabel="Record Verification"
        showRemark={true}
        remarkLabel="Verification Note"
        isLoading={verifyMutation.isPending}
        onConfirm={async (remark) => {
          await verifyMutation.mutateAsync(remark);
          setConfirmAction(null);
        }}
      />

      {/* 5b. Reviewer Bank-Confirm by Letter */}
      <ConfirmDialog
        open={confirmAction === 'bank_confirm'}
        onOpenChange={(open) => !open && setConfirmAction(null)}
        title="Record Bank Confirmation by Letter"
        description="Confirm that the bank's official confirmation letter on file has been verified and authenticated."
        confirmLabel="Confirm by Letter"
        showRemark={true}
        remarkLabel="Verification Note (Optional)"
        remarkPlaceholder="e.g. Verified against bank letter ref no..."
        isLoading={bankConfirmMutation.isPending}
        onConfirm={async (remark) => {
          await bankConfirmMutation.mutateAsync(remark);
          setConfirmAction(null);
        }}
      />

      {/* 6. Delete Document */}
      <ConfirmDialog
        open={confirmAction === 'delete_doc'}
        onOpenChange={(open) => !open && setConfirmAction(null)}
        title="Delete Document"
        description="Are you sure you want to delete this attached document? This action cannot be undone."
        confirmLabel="Delete Document"
        variant="destructive"
        isLoading={actionLoading}
        onConfirm={handleDeleteDoc}
      />
    </div>
  );
}
