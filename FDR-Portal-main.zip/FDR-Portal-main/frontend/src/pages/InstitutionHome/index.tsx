import { NavLink } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { FileText, PlusCircle, Mail } from 'lucide-react';
import { api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { inr, formatDate } from '@/lib/format';
import { Button } from '@/components/ui/button';
import { StatusPill } from '@/components/shared/StatusPill';
import type { DashboardResponse, NoticeItem } from '@/lib/types';

export default function InstitutionHomePage() {
  const { user } = useAuth();

  const { data: dashboard, isLoading } = useQuery<DashboardResponse>({
    queryKey: ['dashboard', 'institution'],
    queryFn: () => api.get<DashboardResponse>('/dashboard'),
  });

  const { data: notices } = useQuery<NoticeItem[]>({
    queryKey: ['notices', 'institution'],
    queryFn: () => api.get<NoticeItem[]>('/notices'),
  });

  if (isLoading) {
    return (
      <div className="flex h-64 items-center justify-center">
        <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-[var(--primary)] border-t-transparent" />
      </div>
    );
  }

  const kpis = dashboard?.kpis;
  const recentNotices = notices?.slice(0, 5) || [];
  const openObservations = kpis?.observations_open ?? 0;

  return (
    <div className="space-y-6">
      {/* Institution Header */}
      <div className="flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between border-b border-[var(--line)] pb-4">
        <div>
          <h1 className="text-xl font-semibold text-[var(--ink)]">
            {user?.institution_name || 'Institution Deposit Cell'}
          </h1>
          <p className="text-xs text-[var(--ink-3)]">
            Active FDRs, compliance status, and communication history for this institution.
          </p>
        </div>
        <div className="flex items-center gap-2">
          <Button asChild size="sm" className="gap-1.5">
            <NavLink to="/deposits/new">
              <PlusCircle className="h-4 w-4" />
              <span>Submit an FDR</span>
            </NavLink>
          </Button>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        <div className="rounded-lg border border-[var(--line)] bg-white p-4">
          <div className="text-xs text-[var(--ink-2)]">Open Deposits</div>
          <div className="mt-1 font-mono text-2xl font-bold text-[var(--ink)]">
            {kpis?.total_count ?? 0}
          </div>
          <div className="mt-1 text-[11px] text-[var(--ink-3)]">
            {inr(kpis?.total_amount ?? 0)} held in trust
          </div>
        </div>

        <div className="rounded-lg border border-[var(--line)] bg-white p-4">
          <div className="text-xs text-[var(--ink-2)]">Maturing in 90 Days</div>
          <div className="mt-1 font-mono text-2xl font-bold text-[var(--warn)]">
            {kpis?.maturing_90 ?? 0}
          </div>
          <div className="mt-1 text-[11px] text-[var(--ink-3)]">
            Renewal required prior to maturity
          </div>
        </div>

        <div className="rounded-lg border border-[var(--line)] bg-white p-4">
          <div className="text-xs text-[var(--ink-2)]">Overdue Deposits</div>
          <div className="mt-1 font-mono text-2xl font-bold text-[var(--risk)]">
            {kpis?.overdue ?? 0}
          </div>
          <div className="mt-1 text-[11px] text-[var(--ink-3)]">
            Lapsed instruments needing attention
          </div>
        </div>

        <div className="rounded-lg border border-[var(--line)] bg-white p-4">
          <div className="text-xs text-[var(--ink-2)]">Needs Your Reply</div>
          <div className="mt-1 font-mono text-2xl font-bold text-[var(--primary)]">
            {openObservations}
          </div>
          <div className="mt-1 text-[11px] text-[var(--ink-3)]">
            Scrutiny observations pending
          </div>
        </div>
      </div>

      {/* Section Grid: Recent Deposits & Notices */}
      <div className="grid grid-cols-1 gap-6 lg:grid-cols-2">
        {/* Recent Deposits */}
        <div className="rounded-lg border border-[var(--line)] bg-white p-4">
          <div className="flex items-center justify-between pb-3 border-b border-[var(--line)]">
            <div className="flex items-center gap-2">
              <FileText className="h-4 w-4 text-[var(--ink-2)]" />
              <h2 className="text-sm font-semibold text-[var(--ink)]">Upcoming maturities</h2>
            </div>
            <NavLink to="/deposits" className="text-xs text-[var(--primary)] hover:underline">
              View all
            </NavLink>
          </div>
          <div className="mt-3 divide-y divide-[var(--line)]">
            {dashboard?.upcoming && dashboard.upcoming.length > 0 ? (
              dashboard.upcoming.slice(0, 5).map((fdr) => (
                <div key={fdr.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <NavLink to={`/deposits/${fdr.id}`} className="font-mono font-medium text-[var(--primary)] hover:underline">
                      {fdr.fdr_number}
                    </NavLink>
                    <div className="text-[11px] text-[var(--ink-3)]">
                      {fdr.bank_name} · Matures {formatDate(fdr.maturity_date)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="font-mono font-medium">{inr(fdr.amount)}</div>
                    <StatusPill status={fdr.status} />
                  </div>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-xs text-[var(--ink-3)]">
                No deposits maturing soon.
              </div>
            )}
          </div>
        </div>

        {/* Recent Notices */}
        <div className="rounded-lg border border-[var(--line)] bg-white p-4">
          <div className="flex items-center justify-between pb-3 border-b border-[var(--line)]">
            <div className="flex items-center gap-2">
              <Mail className="h-4 w-4 text-[var(--ink-2)]" />
              <h2 className="text-sm font-semibold text-[var(--ink)]">Recent Notices</h2>
            </div>
            <NavLink to="/notices" className="text-xs text-[var(--primary)] hover:underline">
              View all
            </NavLink>
          </div>
          <div className="mt-3 divide-y divide-[var(--line)]">
            {recentNotices.length > 0 ? (
              recentNotices.map((n) => (
                <div key={n.id} className="py-2.5 flex items-center justify-between text-xs">
                  <div>
                    <span className="font-mono font-medium text-[var(--ink)]">
                      {n.reference_no}
                    </span>
                    <div className="text-[11px] text-[var(--ink-3)]">
                      {n.kind_label} · Issued {formatDate(n.issued_at)}
                    </div>
                  </div>
                  <NavLink
                    to={`/notices`}
                    className="text-xs text-[var(--primary)] hover:underline font-medium"
                  >
                    View letter
                  </NavLink>
                </div>
              ))
            ) : (
              <div className="py-8 text-center text-xs text-[var(--ink-3)]">
                No notices issued for this institution.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
