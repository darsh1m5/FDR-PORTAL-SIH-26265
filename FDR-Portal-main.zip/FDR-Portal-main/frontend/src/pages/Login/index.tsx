import React, { useState } from 'react';
import { BrandMark } from '@/components/shared/BrandMark';
import { useNavigate, useLocation } from 'react-router-dom';
import { useForm } from 'react-hook-form';
import { useAuth } from '@/lib/auth';
import type { LoginInput } from '@/lib/types';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

export default function LoginPage() {
  const { login, isAuthenticated } = useAuth();
  const navigate = useNavigate();
  const location = useLocation();

  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    setValue,
  } = useForm<LoginInput>({
    defaultValues: {
      email: '',
      password: '',
    },
  });

  // If already authenticated, redirect
  React.useEffect(() => {
    if (isAuthenticated) {
      const from = (location.state as any)?.from?.pathname || '/';
      navigate(from, { replace: true });
    }
  }, [isAuthenticated, navigate, location]);

  const onSubmit = async (data: LoginInput) => {
    if (!data.email || !data.password) {
      setError('Please provide both official email and password.');
      return;
    }

    setError(null);
    setLoading(true);
    try {
      await login(data);
      toast.success('Authentication successful');
      const from = (location.state as any)?.from?.pathname || '/';
      navigate(from, { replace: true });
    } catch (err: any) {
      setError(err?.detail || err?.message || 'Invalid credentials');
    } finally {
      setLoading(false);
    }
  };

  const [activeRoleHint, setActiveRoleHint] = useState<string>(
    'Select a demo role to populate authorized credentials.'
  );

  const selectRole = (email: string, pass: string, hint: string) => {
    setValue('email', email, { shouldValidate: true, shouldDirty: true });
    setValue('password', pass, { shouldValidate: true, shouldDirty: true });
    setError(null);
    setActiveRoleHint(hint);
  };

  return (
    <div className="flex min-h-screen w-full bg-[var(--bg)] font-sans antialiased">
      {/* Left 45% Panel (--ink background) */}
      <div className="hidden lg:flex w-[45%] flex-col justify-between bg-[var(--ink)] p-12 text-white">
        <div>
          {/* Wordmark logo */}
          <div className="flex items-center gap-3">
            <BrandMark className="h-8 w-8" />
            <div>
              <span className="text-base font-semibold tracking-tight text-white block">
                Amanat
              </span>
              <span className="text-[11px] text-white/50 block">
                Security Deposit &amp; FDR Management
              </span>
            </div>
          </div>

          <div className="mt-20 max-w-md">
            <h1 className="text-2xl font-semibold tracking-tight text-white leading-tight">
              Every deposit, every deadline, on record.
            </h1>
            <p className="mt-3 text-xs text-white/60 leading-relaxed">
              Unified institutional deposit ledger, automated maturity tracking,
              and tamper-evident audit chains for the Regulation Bureau.
            </p>
          </div>
        </div>

        {/* 3 Facts in small mono text */}
        <div className="border-t border-white/10 pt-6 space-y-3 max-w-md">
          <div className="flex items-start gap-2.5">
            <span className="font-mono text-[11px] text-[var(--primary)] font-bold">01</span>
            <span className="font-mono text-[11px] text-white/70">
              Maturity value projected with quarterly compounding.
            </span>
          </div>
          <div className="flex items-start gap-2.5">
            <span className="font-mono text-[11px] text-[var(--primary)] font-bold">02</span>
            <span className="font-mono text-[11px] text-white/70">
              Every action recorded in a tamper-evident audit trail.
            </span>
          </div>
          <div className="flex items-start gap-2.5">
            <span className="font-mono text-[11px] text-[var(--primary)] font-bold">03</span>
            <span className="font-mono text-[11px] text-white/70">
              Discrepancies flagged with the fix.
            </span>
          </div>
        </div>
      </div>

      {/* Right Side: Form Card */}
      <div className="flex flex-1 flex-col items-center justify-center p-6 md:p-12">
        <div className="w-full max-w-[400px]">
          {/* Mobile branding */}
          <div className="flex lg:hidden items-center gap-2.5 mb-8">
            <BrandMark className="h-8 w-8" />
            <div>
              <span className="text-base font-semibold text-[var(--ink)] block">
                Amanat
              </span>
              <span className="text-[11px] text-[var(--ink-3)] block">
                Security Deposit &amp; FDR Management
              </span>
            </div>
          </div>

          <div className="rounded-[8px] border border-[var(--line)] bg-white p-7 shadow-xs">
            <div className="mb-6">
              <h2 className="text-lg font-semibold text-[var(--ink)] tracking-tight">
                Sign in
              </h2>
              <p className="text-xs text-[var(--ink-3)] mt-1">
                Bureau officers and institution deposit cells sign in here
              </p>
            </div>

            {error && (
              <div className="mb-4 rounded-[6px] border border-[#F8D4D0] bg-[#FDECEA] p-2.5 text-xs text-[#B42318]">
                {error}
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} className="space-y-4">
              <div className="space-y-1.5">
                <Label htmlFor="email">Official Email</Label>
                <Input
                  id="email"
                  type="email"
                  {...register('email')}
                  placeholder="name@fdrportal.demo"
                  required
                  autoComplete="email"
                  className="font-mono text-xs"
                />
              </div>

              <div className="space-y-1.5">
                <div className="flex items-center justify-between">
                  <Label htmlFor="password">Password</Label>
                </div>
                <Input
                  id="password"
                  type="password"
                  {...register('password')}
                  placeholder="••••••••"
                  required
                  autoComplete="current-password"
                />
              </div>

              <Button
                type="submit"
                disabled={loading}
                className="w-full mt-2 h-9 text-xs"
              >
                {loading ? 'Authenticating...' : 'Sign in to portal'}
              </Button>
            </form>

            {/* Demo credential hint box below form */}
            <div className="mt-6 rounded-[6px] border border-[var(--line)] bg-[var(--surface-2)] p-3">
              <div className="text-[11px] font-medium text-[var(--ink-2)] mb-2">
                Demo logins (click to fill):
              </div>
              <div className="space-y-2">
                {/* Row 1: Bureau Roles */}
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5">
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      selectRole(
                        'admin@fdrportal.demo',
                        'Admin@2026',
                        'Administrator · Section Officer: Full bureau access, registration, bulk import, settings, notices'
                      )
                    }
                    className="text-[11px] bg-white h-7 px-1.5 justify-center font-mono"
                  >
                    Admin
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      selectRole(
                        'reviewer@fdrportal.demo',
                        'Review@2026',
                        'Reviewer · Scrutiny Officer: Verify receipts, raise observations, approve/reject submissions'
                      )
                    }
                    className="text-[11px] bg-white h-7 px-1.5 justify-center font-mono"
                  >
                    Reviewer
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      selectRole(
                        'approver@fdrportal.demo',
                        'Approve@2026',
                        'Competent Authority: Sanction or return release requests with checklist review'
                      )
                    }
                    className="text-[11px] bg-white h-7 px-1.5 justify-center font-mono"
                  >
                    Authority
                  </Button>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      selectRole(
                        'auditor@fdrportal.demo',
                        'Audit@2026',
                        'Auditor: reads every record and the audit log, runs the integrity check, changes nothing'
                      )
                    }
                    className="text-[11px] bg-white h-7 px-1.5 justify-center font-mono"
                  >
                    Auditor
                  </Button>
                </div>

                {/* Row 2: Institution */}
                <div>
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() =>
                      selectRole(
                        'deccan.crest@fdrportal.demo',
                        'Inst@2026',
                        'Institution, Deccan Crest Institute of Technology: submits its own FDRs, answers observations, applies for release'
                      )
                    }
                    className="w-full text-[11px] bg-white h-7 justify-center font-mono"
                  >
                    Institution: Deccan Crest
                  </Button>
                </div>

                {/* One-line role hint */}
                <div className="pt-1 border-t border-[var(--line)] text-[11px] text-[var(--ink-3)] leading-tight min-h-[28px] flex items-center">
                  {activeRoleHint}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
