import { useEffect, useState } from 'react';
import { QrCode } from '@/components/shared/QrCode';
import { Link, useSearchParams } from 'react-router-dom';
import { useMutation, useQuery, useQueryClient } from '@tanstack/react-query';
import { toast } from 'sonner';
import { ApiError, api } from '@/lib/api';
import { useAuth } from '@/lib/auth';
import { formatDate, relDays } from '@/lib/format';
import type {
  FdrListItem,
  InstitutionItem,
  NoticeCandidates,
  NoticeCreateInput,
  NoticeItem,
  NoticeKind,
  User,
} from '@/lib/types';
import { PageHeader } from '@/components/shared/PageHeader';
import { Money } from '@/components/shared/Money';
import { EmptyState } from '@/components/shared/EmptyState';
import { ErrorState } from '@/components/shared/ErrorState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { Tabs, TabsList, TabsTrigger } from '@/components/ui/tabs';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '@/components/ui/table';
import { cn } from '@/lib/utils';
import { isInstitution, visibleToInstitution } from '@/pages/Approvals/roleAccess';

type CandidateTab = 'maturity' | 'overdue' | 'shortfall' | 'history';

const TABS: { id: CandidateTab; label: string }[] = [
  { id: 'maturity', label: 'Maturity reminders' },
  { id: 'overdue', label: 'Overdue' },
  { id: 'shortfall', label: 'Shortfall' },
  { id: 'history', label: 'History' },
];

const KIND_FOR_TAB: Partial<Record<CandidateTab, NoticeKind>> = {
  maturity: 'maturity_reminder',
  overdue: 'overdue_notice',
  shortfall: 'shortfall_notice',
};

function isTab(value: string | null): value is CandidateTab {
  return TABS.some((tab) => tab.id === value);
}

function recordLabel(notice: NoticeItem) {
  return notice.fdr_number ?? notice.institution_name;
}

function verifyTarget(notice: NoticeItem) {
  if (!notice.verify_code) return null;
  const params = new URLSearchParams({ ref: notice.reference_no, code: notice.verify_code });
  return `${window.location.origin}/verify?${params.toString()}`;
}

export default function NoticesPage() {
  const { role, user } = useAuth();
  const isAdmin = role === 'admin';
  const queryClient = useQueryClient();
  const [params, setParams] = useSearchParams();
  const [issued, setIssued] = useState<NoticeItem | null>(null);

  const institutionUser = isInstitution(role);
  const tab: CandidateTab = isTab(params.get('tab')) ? (params.get('tab') as CandidateTab) : institutionUser ? 'history' : 'maturity';
  const noticeParam = Number(params.get('notice'));
  const noticeId = Number.isFinite(noticeParam) && noticeParam > 0 ? noticeParam : null;
  const focusInstitution = Number(params.get('institution_id'));
  const institutionFocus =
    Number.isFinite(focusInstitution) && focusInstitution > 0 ? focusInstitution : null;

  const candidates = useQuery({
    queryKey: ['notices', 'candidates'],
    queryFn: () => api.get<NoticeCandidates>('/notices/candidates'),
    enabled: !institutionUser,
  });
  useRefetchOffline(candidates.refetch);

  const history = useQuery({
    queryKey: ['notices', 'list'],
    queryFn: () => api.get<NoticeItem[]>('/notices'),
  });
  useRefetchOffline(history.refetch);

  const issue = useMutation({
    mutationFn: (body: NoticeCreateInput) => api.post<NoticeItem>('/notices', body),
    onSuccess: async (item) => {
      setIssued(item);
      const next = new URLSearchParams(params);
      next.set('notice', String(item.id));
      setParams(next, { replace: true });
      await queryClient.invalidateQueries({ queryKey: ['notices'] });
      toast.success(`${item.reference_no} issued. Print it and send it by the usual channel.`);
    },
    onError: (err) => {
      toast.error(err instanceof ApiError ? err.detail : 'The notice could not be issued.');
    },
  });

  function setTab(nextTab: string) {
    const next = new URLSearchParams(params);
    next.set('tab', nextTab);
    setParams(next);
  }

  function openLetter(id: number) {
    const next = new URLSearchParams(params);
    next.set('notice', String(id));
    setParams(next);
  }

  function closeLetter() {
    const next = new URLSearchParams(params);
    next.delete('notice');
    setParams(next);
    setIssued(null);
  }

  const letter =
    (noticeId != null && history.data?.find((item) => item.id === noticeId)) ||
    (issued && issued.id === noticeId ? issued : null) ||
    null;

  const kind = KIND_FOR_TAB[tab];

  useEffect(() => {
    if (institutionFocus == null || tab !== 'shortfall') return;
    const row = document.querySelector(`[data-institution="${institutionFocus}"]`);
    if (row instanceof HTMLElement) row.scrollIntoView({ block: 'nearest' });
  }, [institutionFocus, tab, candidates.data]);

  return (
    <div className="flex min-w-0 flex-col gap-4">
      <style>{`
        @page { size: A4; margin: 16mm; }
        @media print {
          aside, header, .no-print { display: none !important; }
          main { max-width: none !important; padding: 0 !important; overflow: visible !important; }
          #notice-letter {
            position: absolute;
            left: 0;
            top: 0;
            width: 178mm;
            height: auto;
            max-height: 250mm;
            padding: 0 !important;
            border: none !important;
            box-shadow: none !important;
            page-break-after: avoid;
            page-break-inside: avoid;
          }
        }
      `}</style>

      <div className="no-print flex flex-col gap-4">
        <PageHeader
          title="Notices"
          description={
            institutionUser
              ? 'Letters issued for your institution. Nothing is emailed.'
              : 'Print a numbered letter from the record. The officer sends it. Nothing is emailed.'
          }
          actions={
            <div className="flex items-center gap-2">
              <Button type="button" variant="outline" asChild>
                <Link to="/verify">Verify a letter</Link>
              </Button>
              {letter ? (
                <Button type="button" onClick={() => window.print()}>
                  Print
                </Button>
              ) : null}
            </div>
          }
        />

        <Tabs value={institutionUser ? 'history' : tab} onValueChange={setTab}>
          <TabsList>
            {(institutionUser ? TABS.filter((item) => item.id === 'history') : TABS).map((item) => (
              <TabsTrigger key={item.id} value={item.id}>
                {item.label}
              </TabsTrigger>
            ))}
          </TabsList>
        </Tabs>

        {tab === 'history' || institutionUser ? (
          <HistoryTable
            query={history}
            user={user}
            onView={openLetter}
          />
        ) : (
          <CandidateTable
            tab={tab}
            query={candidates}
            user={user}
            isAdmin={isAdmin}
            kind={kind}
            institutionFocus={institutionFocus}
            pendingId={issue.isPending ? issue.variables : null}
            onIssue={(body) => issue.mutate(body)}
          />
        )}
      </div>

      {noticeId != null && (
        queryFailed(history) && !letter ? (
          <ErrorState error={history.error} message={offlineNotice()} onRetry={() => history.refetch()} />
        ) : history.isLoading && !letter ? (
          <Skeleton className="h-80 w-full max-w-[210mm]" />
        ) : letter ? (
          <LetterView notice={letter} onClose={closeLetter} />
        ) : (
          <EmptyState message="No notice with that reference." actionLabel="Back to history" onAction={() => { closeLetter(); setTab('history'); }} />
        )
      )}
    </div>
  );
}

function HistoryTable({
  query,
  user,
  onView,
}: {
  query: ReturnType<typeof useQuery<NoticeItem[]>>;
  user: User | null;
  onView: (id: number) => void;
}) {
  if (queryFailed(query)) {
    return <ErrorState error={query.error} message={offlineNotice()} onRetry={() => query.refetch()} />;
  }
  if (query.isLoading) {
    return (
      <div className="flex flex-col gap-2 rounded-[8px] border border-[var(--line)] bg-white p-3">
        {Array.from({ length: 5 }).map((_, index) => (
          <Skeleton key={index} className="h-8 w-full" />
        ))}
      </div>
    );
  }
  const items = (query.data ?? []).filter((item) => visibleToInstitution(user, item));
  if (items.length === 0) {
    return <EmptyState message="No notices have been issued." />;
  }
  return (
    <div className="overflow-x-auto rounded-[8px] border border-[var(--line)] bg-white">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Reference</TableHead>
            <TableHead>Kind</TableHead>
            <TableHead>Record</TableHead>
            <TableHead>Issued by</TableHead>
            <TableHead>Date</TableHead>
            <TableHead />
          </TableRow>
        </TableHeader>
        <TableBody>
          {items.map((item) => (
            <TableRow key={item.id}>
              <TableCell className="whitespace-nowrap font-mono text-[13px] tabular-nums">
                {item.reference_no}
              </TableCell>
              <TableCell className="whitespace-nowrap text-[13px]">{item.kind_label}</TableCell>
              <TableCell className="text-[13px]">
                <span className={item.fdr_number ? 'font-mono' : undefined}>{recordLabel(item)}</span>
                {item.fdr_number && (
                  <span className="mt-0.5 block text-[12px] text-[var(--ink-3)]">{item.institution_name}</span>
                )}
              </TableCell>
              <TableCell className="whitespace-nowrap text-[13px]">{item.issued_by}</TableCell>
              <TableCell className="whitespace-nowrap text-[13px]">{formatDate(item.issued_at)}</TableCell>
              <TableCell className="text-right">
                <Button type="button" variant="outline" onClick={() => onView(item.id)}>
                  View letter
                </Button>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function CandidateTable({
  tab,
  query,
  user,
  isAdmin,
  kind,
  institutionFocus,
  pendingId,
  onIssue,
}: {
  tab: CandidateTab;
  query: ReturnType<typeof useQuery<NoticeCandidates>>;
  user: User | null;
  isAdmin: boolean;
  kind: NoticeKind | undefined;
  institutionFocus: number | null;
  pendingId: NoticeCreateInput | undefined | null;
  onIssue: (body: NoticeCreateInput) => void;
}) {
  if (queryFailed(query)) {
    return <ErrorState error={query.error} message={offlineNotice()} onRetry={() => query.refetch()} />;
  }
  if (query.isLoading) {
    return (
      <div className="flex flex-col gap-2 rounded-[8px] border border-[var(--line)] bg-white p-3">
        {Array.from({ length: 5 }).map((_, index) => (
          <Skeleton key={index} className="h-8 w-full" />
        ))}
      </div>
    );
  }

  const data = query.data;
  if (!data || !kind) {
    return <EmptyState message="No records are waiting for a notice." />;
  }

  if (tab === 'shortfall') {
    return (
      <ShortfallRows
        rows={data.shortfall.filter((row) =>
          visibleToInstitution(user, { institution_id: row.id, institution_name: row.name })
        )}
        isAdmin={isAdmin}
        focusId={institutionFocus}
        pending={pendingId?.kind === 'shortfall_notice' ? pendingId.institution_id ?? null : null}
        onIssue={onIssue}
      />
    );
  }

  const rows = (tab === 'overdue' ? data.overdue : data.maturity).filter((row) =>
    visibleToInstitution(user, { institution_id: row.institution_id, institution_name: row.institution_name })
  );
  return (
    <FdrRows
      rows={rows}
      empty={
        tab === 'overdue'
          ? 'No open deposit is overdue.'
          : 'No open deposit is inside the reminder window.'
      }
      isAdmin={isAdmin}
      kind={kind}
      pendingFdr={pendingId?.kind === kind ? pendingId.fdr_id ?? null : null}
      onIssue={onIssue}
    />
  );
}

function FdrRows({
  rows,
  empty,
  isAdmin,
  kind,
  pendingFdr,
  onIssue,
}: {
  rows: FdrListItem[];
  empty: string;
  isAdmin: boolean;
  kind: NoticeKind;
  pendingFdr: number | null;
  onIssue: (body: NoticeCreateInput) => void;
}) {
  if (rows.length === 0) return <EmptyState message={empty} />;
  return (
    <div className="overflow-x-auto rounded-[8px] border border-[var(--line)] bg-white">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>FDR</TableHead>
            <TableHead className="text-right">Amount</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Days</TableHead>
            {isAdmin && <TableHead />}
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row) => (
            <TableRow key={row.id}>
              <TableCell>
                <span className="font-mono text-[13px] tabular-nums">{row.fdr_number}</span>
                <span className="mt-0.5 block text-[12px] text-[var(--ink-3)]">{row.institution_name}</span>
              </TableCell>
              <TableCell className="text-right">
                <Money amount={row.amount} />
              </TableCell>
              <TableCell className="whitespace-nowrap text-[13px]">{formatDate(row.maturity_date)}</TableCell>
              <TableCell className="whitespace-nowrap font-mono text-[13px] tabular-nums">
                {relDays(row.days_to_maturity)}
              </TableCell>
              {isAdmin && (
                <TableCell className="text-right">
                  <Button
                    type="button"
                    variant="outline"
                    disabled={pendingFdr != null}
                    onClick={() => onIssue({ kind, fdr_id: row.id })}
                  >
                    {pendingFdr === row.id ? 'Issuing...' : 'Issue notice'}
                  </Button>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function ShortfallRows({
  rows,
  isAdmin,
  focusId,
  pending,
  onIssue,
}: {
  rows: InstitutionItem[];
  isAdmin: boolean;
  focusId: number | null;
  pending: number | null;
  onIssue: (body: NoticeCreateInput) => void;
}) {
  if (rows.length === 0) {
    return <EmptyState message="No institution is below its required deposit." />;
  }
  return (
    <div className="overflow-x-auto rounded-[8px] border border-[var(--line)] bg-white">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Institution</TableHead>
            <TableHead className="text-right">Amount</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Days</TableHead>
            {isAdmin && <TableHead />}
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((row) => (
            <TableRow
              key={row.id}
              data-institution={row.id}
              className={cn(focusId === row.id && 'bg-[var(--primary-soft)]')}
            >
              <TableCell>
                <span className="text-[13px] text-[var(--ink)]">{row.name}</span>
                <span className="mt-0.5 block font-mono text-[12px] tabular-nums text-[var(--ink-3)]">
                  {row.aicte_id}
                </span>
              </TableCell>
              <TableCell className="text-right">
                <Money amount={row.shortfall} className="text-[var(--risk)]" />
              </TableCell>
              <TableCell className="text-[13px] text-[var(--ink-3)]">—</TableCell>
              <TableCell className="text-[13px] text-[var(--ink-3)]">—</TableCell>
              {isAdmin && (
                <TableCell className="text-right">
                  <Button
                    type="button"
                    variant="outline"
                    disabled={pending != null}
                    onClick={() => onIssue({ kind: 'shortfall_notice', institution_id: row.id })}
                  >
                    {pending === row.id ? 'Issuing...' : 'Issue notice'}
                  </Button>
                </TableCell>
              )}
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </div>
  );
}

function LetterView({ notice, onClose }: { notice: NoticeItem; onClose: () => void }) {
  const { letter } = notice;
  return (
    <div className="flex flex-col gap-3">
      <div className="no-print">
        <Button type="button" variant="ghost" onClick={onClose}>
          Close letter
        </Button>
      </div>
      <article
        id="notice-letter"
        className="w-full max-w-[210mm] rounded-[8px] border border-[var(--line)] bg-white px-8 py-8 text-[var(--ink)]"
      >
        <div className="mb-6 flex flex-col items-end gap-0.5 text-right">
          <p className="text-[12px] font-medium text-[var(--ink-2)]">{notice.kind_label}</p>
          <p className="font-mono text-[13px] tabular-nums">{notice.reference_no}</p>
          <p className="text-[13px]">{formatDate(notice.issued_at)}</p>
        </div>
        <p className="mb-5 max-w-md whitespace-pre-line text-[14px] leading-relaxed">{letter.salutation}</p>
        <p className="mb-4 text-[14px] font-semibold">{letter.subject}</p>
        <div className="flex flex-col gap-3">
          {letter.body.map((paragraph, index) => (
            <p key={index} className="text-[14px] leading-relaxed">
              {paragraph}
            </p>
          ))}
        </div>
        <p className="mt-6 whitespace-pre-line text-[14px] leading-relaxed">{letter.closing}</p>
        {verifyTarget(notice) && (
          <div className="mt-6 flex items-start gap-4">
            <QrCode value={verifyTarget(notice) as string} size={88} />
            <div className="min-w-0">
              <p className="text-[12px] text-[var(--ink-2)]">Verify this letter: scan the code or open</p>
              <p className="break-all font-mono text-[12px] tabular-nums">{verifyTarget(notice)}</p>
              <p className="mt-1 font-mono text-[13px] tabular-nums">Code {notice.verify_code}</p>
            </div>
          </div>
        )}
        <p className="mt-8 border-t border-[var(--line)] pt-3 text-[12px] text-[var(--ink-3)]">
          Generated from Amanat records; not sent by email
        </p>
      </article>
    </div>
  );
}
