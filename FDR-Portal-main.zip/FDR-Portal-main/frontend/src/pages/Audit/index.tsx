import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import { useMutation, useQuery } from '@tanstack/react-query';
import { toast } from 'sonner';
import { useAuth } from '@/lib/auth';
import { ApiError, api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { formatDate, formatDateTime, formatRate, inr, ROLE_LABELS, STATUS_LABELS } from '@/lib/format';
import type {
  AuditItem,
  AuditVerifyResponse,
  FdrStatus,
  PaginatedResponse,
  Role,
} from '@/lib/types';
import { isInstitution, RoleUnavailable } from '@/pages/Approvals/roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { FilterBar } from '@/components/shared/FilterBar';
import { DataTable, type Column } from '@/components/shared/DataTable';
import { StatusPill } from '@/components/shared/StatusPill';
import { ErrorState } from '@/components/shared/ErrorState';
import { EmptyState } from '@/components/shared/EmptyState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectGroup,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';

const PAGE_SIZE = 25;

const ACTIONS: { value: string; label: string }[] = [
  { value: 'fdr.created', label: 'FDR registered' },
  { value: 'fdr.updated', label: 'Details edited' },
  { value: 'fdr.submitted', label: 'Submitted for approval' },
  { value: 'fdr.approved', label: 'Approved' },
  { value: 'fdr.rejected', label: 'Rejected' },
  { value: 'fdr.release_requested', label: 'Release requested' },
  { value: 'fdr.released', label: 'Released' },
  { value: 'fdr.release_rejected', label: 'Release request rejected' },
  { value: 'fdr.renewed', label: 'Renewed' },
  { value: 'fdr.verified', label: 'Officer-verified' },
  { value: 'fdr.bank_confirmed', label: 'Bank-confirmed (letter)' },
  { value: 'document.uploaded', label: 'Document uploaded' },
  { value: 'document.deleted', label: 'Document deleted' },
  { value: 'alert.acknowledged', label: 'Alert acknowledged' },
  { value: 'alert.run', label: 'Alert rules run' },
  { value: 'settings.updated', label: 'Alert rules changed' },
  { value: 'auth.login', label: 'Signed in' },
  { value: 'export.csv', label: 'Register exported' },
  { value: 'institution.created', label: 'Institution added' },
  { value: 'notice.issued', label: 'Notice issued' },
  { value: 'import.committed', label: 'Spreadsheet imported' },
  { value: 'alert.escalated', label: 'Alert escalated' },
  { value: 'observation.raised', label: 'Observation raised' },
  { value: 'observation.answered', label: 'Institution replied' },
  { value: 'observation.closed', label: 'Observation closed' },
];

const STATUSES = new Set<string>(Object.keys(STATUS_LABELS));

function isStatus(value: string | null): value is FdrStatus {
  return value !== null && STATUSES.has(value);
}

function roleLabel(role: Role | null) {
  if (role == null) return 'System';
  return ROLE_LABELS[role];
}

const MONEY_FIELDS = new Set([
  'amount',
  'maturity_amount',
  'required_deposit',
  'active_amount',
  'projected_value',
]);
const DATE_FIELDS = new Set(['issue_date', 'maturity_date', 'due_date']);
const RATE_FIELDS = new Set(['interest_rate', 'interest_min', 'interest_max']);
const FIELD_LABELS: Record<string, string> = {
  amount: 'Amount',
  maturity_amount: 'Printed maturity amount',
  interest_rate: 'Interest rate',
  interest_min: 'Minimum interest',
  interest_max: 'Maximum interest',
  issue_date: 'Issue date',
  maturity_date: 'Maturity date',
  reminder_days: 'Reminder days',
  overdue_grace_days: 'Days after maturity',
  pending_sla_days: 'Review time limit',
  branch: 'Branch',
  remarks: 'Remarks',
  ifsc: 'IFSC',
  lien_to_aicte: 'Lien to AICTE',
  purpose: 'Purpose',
  bank_name: 'Bank',
  bank: 'Bank',
  institution: 'Institution',
  name: 'Name',
  aicte_id: 'AICTE ID',
  filename: 'File',
  size_bytes: 'Size',
  rows: 'Rows',
  verification: 'Verification',
};

function isRecord(value: unknown): value is Record<string, unknown> {
  return typeof value === 'object' && value !== null && !Array.isArray(value);
}

function fieldLabel(field: string) {
  const words = field.split('_').join(' ');
  return FIELD_LABELS[field] ?? words.replace(/^\w/, (char: string) => char.toUpperCase());
}

function formatScalar(field: string, value: unknown): string {
  if (value == null || value === '') return '—';
  if (typeof value === 'boolean') return value ? 'Yes' : 'No';
  if (Array.isArray(value)) return value.map((item) => formatScalar(field, item)).join(', ');
  if (typeof value === 'number') {
    if (MONEY_FIELDS.has(field)) return inr(value);
    if (RATE_FIELDS.has(field)) return formatRate(value);
    return String(value);
  }
  if (typeof value === 'string') {
    if (DATE_FIELDS.has(field)) return formatDate(value);
    if (MONEY_FIELDS.has(field)) return inr(Number(value));
    if (RATE_FIELDS.has(field)) return formatRate(Number(value));
    return value;
  }
  if (isRecord(value)) {
    if ('from' in value || 'to' in value) {
      return `${formatScalar(field, value.from)} -> ${formatScalar(field, value.to)}`;
    }
    if (typeof value.fdr_number === 'string') return value.fdr_number;
  }
  return '—';
}

function formatChanges(changes: Record<string, unknown>) {
  return Object.entries(changes)
    .map(([field, change]) => `${fieldLabel(field)}: ${formatScalar(field, change)}`)
    .join('; ');
}

function detailText(detail: Record<string, unknown>) {
  const parts: string[] = [];
  const used = new Set<string>(['fdr_number']);

  if (
    typeof detail.created === 'number' &&
    typeof detail.resolved === 'number' &&
    typeof detail.open === 'number'
  ) {
    parts.push(`${detail.created} created, ${detail.resolved} resolved, ${detail.open} open`);
    used.add('created');
    used.add('resolved');
    used.add('open');
  }

  if (typeof detail.reference_no === 'string' && detail.reference_no.trim()) {
    parts.push(detail.reference_no.trim());
    used.add('reference_no');
  }
  if (typeof detail.kind === 'string') {
    const kindLabels: Record<string, string> = {
      maturity_reminder: 'Maturity reminder',
      overdue_notice: 'Overdue notice',
      shortfall_notice: 'Shortfall notice',
      release_letter: 'Release letter',
    };
    parts.push(kindLabels[detail.kind] ?? fieldLabel(detail.kind));
    used.add('kind');
  }
  if ('institution_id' in detail) used.add('institution_id');
  if (detail.imported === true) {
    parts.push('Imported from a spreadsheet');
    used.add('imported');
  }
  if (typeof detail.source_name === 'string' && detail.source_name.trim()) {
    parts.push(detail.source_name.trim());
    used.add('source_name');
  }
  if (typeof detail.count === 'number') {
    parts.push(`${detail.count.toLocaleString('en-IN')} ${detail.count === 1 ? 'draft' : 'drafts'}`);
    used.add('count');
  }
  if ('batch' in detail) used.add('batch');
  if ('ids' in detail) used.add('ids');
  if (typeof detail.remark === 'string' && detail.remark.trim()) {
    parts.push(detail.remark.trim());
    used.add('remark');
  }
  if (typeof detail.reason === 'string' && detail.reason.trim()) {
    parts.push(detail.reason.trim());
    used.add('reason');
  }
  if (isRecord(detail.changes)) {
    const changes = formatChanges(detail.changes);
    if (changes) parts.push(changes);
    used.add('changes');
  }
  if (!used.has('amount') && (typeof detail.amount === 'number' || typeof detail.amount === 'string')) {
    parts.push(inr(Number(detail.amount)));
    used.add('amount');
  }

  for (const [key, value] of Object.entries(detail)) {
    if (used.has(key) || value == null || value === '') continue;
    if (key === 'type' && typeof detail.message === 'string') continue;
    if (key === 'message' && typeof value === 'string') {
      parts.push(value);
      continue;
    }
    if (key === 'note' && typeof value === 'string') {
      parts.push(value);
      continue;
    }
    if (key === 'filename' && typeof value === 'string') {
      parts.push(value);
      continue;
    }
    if (key === 'doc_type' && typeof value === 'string') {
      const labels: Record<string, string> = {
        fdr_receipt: 'FDR receipt',
        lien_letter: 'Lien letter',
        affidavit: 'Affidavit',
        closure_certificate: 'Closure certificate',
        renewal_letter: 'Renewal letter',
        bank_confirmation: 'Bank confirmation letter',
        other: 'Other document',
      };
      parts.push(labels[value] ?? fieldLabel(value));
      continue;
    }
    if (key === 'size_bytes' && typeof value === 'number') {
      parts.push(`${value.toLocaleString('en-IN')} bytes`);
      continue;
    }
    if (key === 'rows' && typeof value === 'number') {
      parts.push(`${value} ${value === 1 ? 'row' : 'rows'}`);
      continue;
    }
    if (key === 'verification_reset' && value === true) {
      parts.push('Verification reset to submitted');
      continue;
    }
    if (key === 'renewed_to' && isRecord(value) && typeof value.fdr_number === 'string') {
      parts.push(`Renewed to ${value.fdr_number}`);
      continue;
    }
    if (key === 'renewed_from' && isRecord(value) && typeof value.fdr_number === 'string') {
      parts.push(`Renewed from ${value.fdr_number}`);
      continue;
    }
    if (key === 'fields' && Array.isArray(value)) {
      parts.push(value.map((item) => fieldLabel(String(item))).join(', '));
      continue;
    }
    if (key === 'filters' && isRecord(value)) {
      const filters = Object.entries(value)
        .filter(([, item]) => item != null && item !== '')
        .map(([field, item]) => `${fieldLabel(field)} ${formatScalar(field, item)}`);
      if (filters.length > 0) parts.push(filters.join(', '));
      continue;
    }
    if (key === 'institution' || key === 'bank' || key === 'name' || key === 'aicte_id' || key === 'verification') {
      parts.push(String(value));
      continue;
    }
    const rendered = formatScalar(key, value);
    if (rendered !== '—') parts.push(`${fieldLabel(key)}: ${rendered}`);
  }

  return parts.length > 0 ? parts.join(' · ') : '—';
}

function useDebounced(value: string, delay = 300) {
  const [debounced, setDebounced] = useState(value);
  useEffect(() => {
    const timer = window.setTimeout(() => setDebounced(value), delay);
    return () => window.clearTimeout(timer);
  }, [value, delay]);
  return debounced;
}

async function fetchAudit(args: {
  action: string;
  page: number;
  pageSize: number;
  all: boolean;
}) {
  const load = (page: number, pageSize: number) => {
    const q = new URLSearchParams();
    if (args.action !== 'all') q.set('action', args.action);
    q.set('page', String(page));
    q.set('page_size', String(pageSize));
    return api.get<PaginatedResponse<AuditItem>>(`/audit?${q.toString()}`);
  };

  if (!args.all) return load(args.page, args.pageSize);

  const first = await load(1, 200);
  const pages = Math.min(15, Math.ceil(first.total / 200));
  const rest = await Promise.all(
    Array.from({ length: Math.max(0, pages - 1) }, (_, index) => load(index + 2, 200))
  );
  const items = [first, ...rest].flatMap((page) => page.items);
  return { items, total: first.total, page: 1, page_size: items.length };
}

const columns: Column<AuditItem>[] = [
  {
    key: 'at',
    header: 'Time',
    width: '148px',
    className: 'whitespace-nowrap',
    cell: (item) => <span className="whitespace-nowrap font-mono text-[12px]">{formatDateTime(item.at)}</span>,
  },
  {
    key: 'actor',
    header: 'Actor',
    width: '1%',
    className: 'whitespace-nowrap',
    cell: (item) => (
      <span className="flex flex-col whitespace-nowrap">
        <span className="whitespace-nowrap">{item.actor_name}</span>
        <span className="whitespace-nowrap text-[12px] text-[var(--ink-3)]">{roleLabel(item.actor_role)}</span>
      </span>
    ),
  },
  {
    key: 'action',
    header: 'Action',
    width: '1%',
    className: 'whitespace-nowrap',
    cell: (item) => <span className="whitespace-nowrap">{item.action_label}</span>,
  },
  {
    key: 'fdr',
    header: 'FDR',
    width: '1%',
    className: 'whitespace-nowrap',
    cell: (item) =>
      item.fdr_id && item.fdr_number ? (
        <Link
          to={`/deposits/${item.fdr_id}`}
          className="font-mono text-[13px] text-[var(--primary)] hover:underline"
          onClick={(event) => event.stopPropagation()}
        >
          {item.fdr_number}
        </Link>
      ) : (
        <span className="text-[var(--ink-3)]">—</span>
      ),
  },
  {
    key: 'status',
    header: 'Status change',
    width: '1%',
    className: 'whitespace-nowrap',
    cell: (item) =>
      item.from_status || item.to_status ? (
        <span className="inline-flex items-center gap-1 whitespace-nowrap">
          {isStatus(item.from_status) ? (
            <StatusPill status={item.from_status} />
          ) : (
            <span className="text-[var(--ink-3)]">—</span>
          )}
          <span className="text-[var(--ink-3)]" aria-hidden>
            →
          </span>
          {isStatus(item.to_status) ? (
            <StatusPill status={item.to_status} />
          ) : (
            <span className="text-[var(--ink-3)]">—</span>
          )}
        </span>
      ) : (
        <span className="text-[var(--ink-3)]">—</span>
      ),
  },
  {
    key: 'detail',
    header: 'Detail',
    cell: (item) => {
      const text = detailText(item.detail);
      return (
        <span className="block min-w-[160px] whitespace-normal text-[12px] leading-snug text-[var(--ink-2)]" title={text}>
          {text}
        </span>
      );
    },
  },
];

export default function AuditPage() {
  const { role } = useAuth();
  const [action, setAction] = useState('all');
  const [actor, setActor] = useState('');
  const [fdrNumber, setFdrNumber] = useState('');
  const [page, setPage] = useState(1);
  const debouncedActor = useDebounced(actor.trim());
  const debouncedFdr = useDebounced(fdrNumber.trim());
  const textFilter = debouncedActor.length > 0 || debouncedFdr.length > 0;

  const audit = useQuery({
    queryKey: queryKeys.audit.list({
      action,
      actor: textFilter ? debouncedActor : '',
      fdr: textFilter ? debouncedFdr : '',
      page: textFilter ? 0 : page,
    }),
    queryFn: () =>
      fetchAudit({
        action,
        page,
        pageSize: PAGE_SIZE,
        all: textFilter,
      }),
    enabled: !isInstitution(role),
  });
  useRefetchOffline(audit.refetch);

  const verify = useMutation({
    mutationFn: () => api.get<AuditVerifyResponse>('/audit/verify'),
    onError: (err) => {
      toast.error(err instanceof ApiError ? err.detail : 'Integrity check failed.');
    },
  });

  const filtered = (audit.data?.items ?? []).filter((item) => {
    if (debouncedActor && !item.actor_name.toLowerCase().includes(debouncedActor.toLowerCase())) {
      return false;
    }
    if (debouncedFdr && !(item.fdr_number ?? '').toLowerCase().includes(debouncedFdr.toLowerCase())) {
      return false;
    }
    return true;
  });

  const rows = textFilter
    ? filtered.slice((page - 1) * PAGE_SIZE, page * PAGE_SIZE)
    : filtered;
  const total = textFilter ? filtered.length : (audit.data?.total ?? 0);

  if (isInstitution(role)) {
    return <RoleUnavailable title="Audit log" />;
  }

  function resetPage<T>(setter: (value: T) => void) {
    return (value: T) => {
      setter(value);
      setPage(1);
    };
  }

  return (
    <div className="flex min-w-0 flex-col gap-4">
      <PageHeader
        title="Audit log"
        description="Every change, export and sign-in, newest first."
        actions={
          <Button type="button" variant="outline" onClick={() => verify.mutate()} disabled={verify.isPending}>
            {verify.isPending ? 'Checking...' : 'Check the record'}
          </Button>
        }
      />

      {verify.data && (
        <p
          className={
            verify.data.intact
              ? 'rounded-[8px] border border-[var(--ok)] bg-[var(--ok-bg)] px-3 py-2 text-[13px] text-[var(--ok)]'
              : 'rounded-[8px] border border-[var(--risk)] bg-[var(--risk-bg)] px-3 py-2 text-[13px] text-[var(--risk)]'
          }
          role="status"
        >
          {verify.data.intact
            ? `Intact. ${verify.data.checked} entries checked.`
            : `Broken at entry #${verify.data.broken_at ?? '—'}.`}
        </p>
      )}

      <FilterBar
        hasActiveFilters={action !== 'all' || actor.length > 0 || fdrNumber.length > 0}
        onReset={() => {
          setAction('all');
          setActor('');
          setFdrNumber('');
          setPage(1);
        }}
        context={audit.data ? `${total} entries` : undefined}
      >
        <Select value={action} onValueChange={resetPage(setAction)}>
          <SelectTrigger className="w-[200px]" aria-label="Action">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectGroup>
              <SelectItem value="all">All actions</SelectItem>
              {ACTIONS.map((item) => (
                <SelectItem key={item.value} value={item.value}>
                  {item.label}
                </SelectItem>
              ))}
            </SelectGroup>
          </SelectContent>
        </Select>
        <Input
          value={actor}
          onChange={(event) => {
            setActor(event.target.value);
            setPage(1);
          }}
          placeholder="Actor"
          aria-label="Actor"
          className="w-[180px]"
        />
        <Input
          value={fdrNumber}
          onChange={(event) => {
            setFdrNumber(event.target.value);
            setPage(1);
          }}
          placeholder="FDR number"
          aria-label="FDR number"
          className="w-[180px] font-mono"
        />
      </FilterBar>

      {queryFailed(audit) ? (
        <ErrorState error={audit.error} message={offlineNotice()} onRetry={() => audit.refetch()} />
      ) : audit.isLoading ? (
        <DataTable columns={columns} data={[]} isLoading />
      ) : rows.length === 0 ? (
        <EmptyState
          message="No audit entries match these filters."
          actionLabel="Reset filters"
          onAction={() => {
            setAction('all');
            setActor('');
            setFdrNumber('');
            setPage(1);
          }}
        />
      ) : (
        <DataTable
          columns={columns}
          data={rows}
          page={page}
          pageSize={PAGE_SIZE}
          total={total}
          onPageChange={setPage}
        />
      )}
    </div>
  );
}
