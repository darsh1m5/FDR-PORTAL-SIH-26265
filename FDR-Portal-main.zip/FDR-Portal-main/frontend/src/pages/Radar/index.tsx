import { useEffect, useMemo, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useQuery } from '@tanstack/react-query';
import { format, parseISO } from 'date-fns';
import {
  Bar,
  CartesianGrid,
  ComposedChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from 'recharts';
import { api } from '@/lib/api';
import { queryKeys } from '@/lib/query';
import { useAuth } from '@/lib/auth';
import { inr, inrShort } from '@/lib/format';
import type { RadarMonth, RadarResponse } from '@/lib/types';
import { visibleToInstitution } from '@/pages/Approvals/roleAccess';
import { PageHeader } from '@/components/shared/PageHeader';
import { DataTable, type Column } from '@/components/shared/DataTable';
import { Money } from '@/components/shared/Money';
import { MaturityChip } from '@/components/shared/MaturityChip';
import { StatusPill } from '@/components/shared/StatusPill';
import { ErrorState } from '@/components/shared/ErrorState';
import { EmptyState } from '@/components/shared/EmptyState';
import { offlineNotice, queryFailed, useRefetchOffline } from '@/pages/Approvals/useRefetchOffline';
import { Skeleton } from '@/components/ui/skeleton';
import { cn } from '@/lib/utils';

function monthLabel(month: string) {
  return format(parseISO(`${month}-01`), 'MMM yyyy');
}

function toCrore(amount: number) {
  return Math.round((amount / 10000000) * 100) / 100;
}

const columns: Column<RadarMonth['items'][number]>[] = [
  {
    key: 'fdr_number',
    header: 'FDR number',
    cell: (item) => (
      <Link
        to={`/deposits/${item.id}`}
        className="font-mono text-[13px] text-[var(--primary)] hover:underline"
        onClick={(event) => event.stopPropagation()}
      >
        {item.fdr_number}
      </Link>
    ),
  },
  {
    key: 'institution',
    header: 'Institution',
    cell: (item) => item.institution_name,
  },
  {
    key: 'amount',
    header: 'Principal',
    align: 'right',
    cell: (item) => <Money amount={item.amount} />,
  },
  {
    key: 'projected',
    header: 'Projected',
    align: 'right',
    cell: (item) => <Money amount={item.projected_value} />,
  },
  {
    key: 'maturity',
    header: 'Maturity',
    cell: (item) => <MaturityChip days={item.days_to_maturity} />,
  },
  {
    key: 'status',
    header: 'Status',
    className: 'whitespace-nowrap',
    cell: (item) => <StatusPill status={item.status} />,
  },
];

export default function RadarPage() {
  const navigate = useNavigate();
  const { user } = useAuth();
  const [selected, setSelected] = useState<string | null>(null);
  const opened = useRef(false);
  const stripRef = useRef<HTMLDivElement>(null);
  const radar = useQuery({
    queryKey: queryKeys.radar(12),
    queryFn: () => api.get<RadarResponse>('/radar?months=12'),
  });
  useRefetchOffline(radar.refetch);

  const months = useMemo(() => {
    const source = radar.data?.months ?? [];
    const scoped = user?.role === 'institution';
    if (!scoped) return source;
    return source.map((month) => {
      const items = month.items.filter((item) =>
        visibleToInstitution(user, { institution_name: item.institution_name })
      );
      return {
        ...month,
        items,
        count: items.length,
        principal: items.reduce((sum, item) => sum + item.amount, 0),
        projected: items.reduce((sum, item) => sum + item.projected_value, 0),
      };
    });
  }, [radar.data, user]);
  useEffect(() => {
    if (opened.current || selected != null) return;
    const first = months.find((month) => month.count > 0);
    if (!first) return;
    opened.current = true;
    setSelected(first.month);
  }, [months, selected]);
  useEffect(() => {
    const strip = stripRef.current;
    if (!strip || !selected) return;
    const button = strip.querySelector<HTMLButtonElement>('[aria-pressed="true"]');
    if (!button) return;
    const pad = 12;
    const left = button.offsetLeft - pad;
    const right = button.offsetLeft + button.offsetWidth + pad;
    if (left < strip.scrollLeft) strip.scrollLeft = Math.max(0, left);
    else if (right > strip.scrollLeft + strip.clientWidth) {
      strip.scrollLeft = right - strip.clientWidth;
    }
  }, [selected, months]);
  const soon = useMemo(
    () => months.flatMap((month) => month.items).filter((item) => item.days_to_maturity <= 90),
    [months]
  );
  const soonPrincipal = soon.reduce((sum, item) => sum + item.amount, 0);
  const chartData = months.map((month) => ({
    month: month.month,
    label: format(parseISO(`${month.month}-01`), 'MMM'),
    principalCr: toCrore(month.principal),
    projectedCr: toCrore(month.projected),
    principal: month.principal,
    projected: month.projected,
  }));
  const active = months.find((month) => month.month === selected) ?? null;
  const totalCount = months.reduce((sum, month) => sum + month.count, 0);

  return (
    <div className="flex w-full max-w-[calc(100vw-2rem)] flex-col gap-4 md:max-w-[calc(100vw-240px-3rem)]">
      <PageHeader
        title="Maturity Radar"
        description={
          user?.role === 'institution'
            ? 'Principal and projected value of your deposits maturing over the next 12 months.'
            : 'Principal and projected value maturing over the next 12 months.'
        }
      />

      {queryFailed(radar) ? (
        <ErrorState error={radar.error} message={offlineNotice()} onRetry={() => radar.refetch()} />
      ) : radar.isLoading ? (
        <div className="flex flex-col gap-3">
          <Skeleton className="h-6 w-80" />
          <Skeleton className="h-28 w-full" />
          <Skeleton className="h-64 w-full" />
        </div>
      ) : (
        <>
          <p className="text-[14px] text-[var(--ink)]">
            <Money amount={soonPrincipal} compact /> matures in the next 90 days across {soon.length}{' '}
            {soon.length === 1 ? 'deposit' : 'deposits'}.
          </p>

          {totalCount === 0 ? (
            <EmptyState message="No open deposits mature in the next 12 months." />
          ) : (
            <>
              <div
                ref={stripRef}
                className="w-full max-w-full overflow-x-auto rounded-[8px] border border-[var(--line)] bg-white"
              >
                <div className="flex w-max gap-2 p-3">
                  {months.map((month) => {
                    const on = month.month === selected;
                    return (
                      <button
                        key={month.month}
                        type="button"
                        aria-pressed={on}
                        onClick={() => setSelected(month.month)}
                        className={cn(
                          'flex min-w-[112px] flex-col gap-0.5 rounded-[6px] border px-2.5 py-2 text-left transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-[var(--primary)]',
                          on
                            ? 'border-[var(--primary)] bg-[var(--primary-soft)]'
                            : 'border-[var(--line)] bg-white hover:bg-[var(--surface-2)]'
                        )}
                      >
                        <span className="text-[12px] font-medium text-[var(--ink)]">
                          {monthLabel(month.month)}
                        </span>
                        <span className="font-mono text-[13px] tabular-nums text-[var(--ink)]">
                          {month.count}
                        </span>
                        <span className="font-mono text-[12px] text-[var(--ink-2)]" title={inr(month.principal)}>
                          {inrShort(month.principal)}
                        </span>
                        <span className="font-mono text-[12px] text-[var(--ink-3)]" title={inr(month.projected)}>
                          {inrShort(month.projected)}
                        </span>
                      </button>
                    );
                  })}
                </div>
              </div>

              <div className="rounded-[8px] border border-[var(--line)] bg-white p-4">
                <div className="mb-3 flex items-center justify-between gap-3">
                  <h2 className="text-[16px] font-semibold text-[var(--ink)]">Amount due each month</h2>
                  <div className="flex items-center gap-4 text-[12px] text-[var(--ink-2)]">
                    <span className="inline-flex items-center gap-1.5">
                      <span className="size-2 bg-[var(--primary)]" />
                      Principal
                    </span>
                    <span className="inline-flex items-center gap-1.5">
                      <span className="size-2 bg-[var(--ink-3)]" />
                      Projected
                    </span>
                  </div>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <ComposedChart data={chartData} margin={{ top: 8, right: 12, left: 8, bottom: 0 }}>
                      <CartesianGrid strokeDasharray="3 3" stroke="var(--line)" vertical={false} />
                      <XAxis
                        dataKey="label"
                        tick={{ fontSize: 12, fill: 'var(--ink-3)' }}
                        axisLine={{ stroke: 'var(--line)' }}
                        tickLine={false}
                      />
                      <YAxis
                        tick={{ fontSize: 12, fill: 'var(--ink-3)', fontFamily: 'IBM Plex Mono' }}
                        axisLine={{ stroke: 'var(--line)' }}
                        tickLine={false}
                        tickFormatter={(value: number) => inrShort(value * 10000000)}
                        width={84}
                      />
                      <Tooltip
                        content={({ active, payload, label }) => {
                          if (!active || !payload?.length) return null;
                          const row = payload[0]?.payload as (typeof chartData)[number] | undefined;
                          if (!row) return null;
                          return (
                            <div className="rounded-[6px] border border-[var(--line)] bg-white p-2.5 text-[12px]">
                              <div className="mb-1 font-medium text-[var(--ink)]">{label}</div>
                              <div className="font-mono text-[var(--primary)]">Principal {inr(row.principal)}</div>
                              <div className="font-mono text-[var(--ink-2)]">Projected {inr(row.projected)}</div>
                            </div>
                          );
                        }}
                      />
                      <Bar
                        dataKey="principalCr"
                        fill="var(--primary)"
                        radius={[3, 3, 0, 0]}
                        maxBarSize={28}
                        onClick={(row: { month?: string }) => {
                          if (row.month) setSelected(row.month);
                        }}
                      />
                      <Bar
                        dataKey="projectedCr"
                        fill="var(--ink-3)"
                        radius={[3, 3, 0, 0]}
                        maxBarSize={28}
                        onClick={(row: { month?: string }) => {
                          if (row.month) setSelected(row.month);
                        }}
                      />
                    </ComposedChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {active ? (
                <div className="flex flex-col gap-2">
                  <h2 className="text-[16px] font-semibold text-[var(--ink)]">
                    {monthLabel(active.month)}
                  </h2>
                  {active.items.length === 0 ? (
                    <EmptyState
                      message={`No deposits mature in ${monthLabel(active.month)}.`}
                      actionLabel="Clear month"
                      onAction={() => setSelected(null)}
                    />
                  ) : (
                    <DataTable
                      columns={columns}
                      data={active.items}
                      onRowClick={(item) => navigate(`/deposits/${item.id}`)}
                    />
                  )}
                </div>
              ) : (
                <p className="text-[13px] text-[var(--ink-3)]">Select a month to list its deposits.</p>
              )}
            </>
          )}
        </>
      )}
    </div>
  );
}
