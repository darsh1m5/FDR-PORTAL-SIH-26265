/**
 * USAGE NOTE: ConfirmDialog
 * -----------------------------------------------------------------------------
 * Modal confirmation dialog for high-stakes financial operations:
 * (Approve, Reject, Request Release, Renew, Acknowledge alert, Delete doc).
 * Supports an optional or mandatory "Remark / Reason" text field.
 * For instance, a remark is mandatory when rejecting a submission or requesting release.
 *
 * Example Usage:
 *   <ConfirmDialog
 *     open={isOpen}
 *     onOpenChange={setIsOpen}
 *     title="Reject Deposit"
 *     description="Provide a justification for rejecting this FDR."
 *     confirmLabel="Reject FDR"
 *     variant="destructive"
 *     requireRemark={true}
 *     remarkPlaceholder="Enter bureau audit reason (required)..."
 *     onConfirm={(remark) => handleReject(remark)}
 *   />
 * -----------------------------------------------------------------------------
 */

import React, { useState } from 'react';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Textarea } from '@/components/ui/textarea';
import { Label } from '@/components/ui/label';

interface ConfirmDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  title: string;
  description?: string;
  confirmLabel?: string;
  cancelLabel?: string;
  variant?: 'default' | 'destructive' | 'secondary';
  requireRemark?: boolean;
  showRemark?: boolean;
  remarkLabel?: string;
  remarkPlaceholder?: string;
  isLoading?: boolean;
  onConfirm: (remark?: string) => void | Promise<void>;
}

export const ConfirmDialog: React.FC<ConfirmDialogProps> = ({
  open,
  onOpenChange,
  title,
  description,
  confirmLabel = 'Confirm',
  cancelLabel = 'Cancel',
  variant = 'default',
  requireRemark = false,
  showRemark = false,
  remarkLabel = 'Remark',
  remarkPlaceholder = 'Enter reason or remark...',
  isLoading = false,
  onConfirm,
}) => {
  const [remark, setRemark] = useState('');
  const needsRemark = showRemark || requireRemark;
  const isConfirmDisabled = isLoading || (requireRemark && !remark.trim());

  const handleConfirm = async () => {
    if (requireRemark && !remark.trim()) return;
    await onConfirm(remark.trim() || undefined);
    setRemark('');
  };

  const handleOpenChange = (newOpen: boolean) => {
    if (!newOpen) {
      setRemark('');
    }
    onOpenChange(newOpen);
  };

  return (
    <Dialog open={open} onOpenChange={handleOpenChange}>
      <DialogContent className="sm:max-w-[420px]">
        <DialogHeader>
          <DialogTitle>{title}</DialogTitle>
          {description && <DialogDescription>{description}</DialogDescription>}
        </DialogHeader>

        {needsRemark && (
          <div className="space-y-1.5 py-1">
            <Label htmlFor="dialog-remark">
              {remarkLabel} {requireRemark && <span className="text-[var(--risk)]">*</span>}
            </Label>
            <Textarea
              id="dialog-remark"
              value={remark}
              onChange={(e) => setRemark(e.target.value)}
              onKeyDown={(e) => {
                if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && !isConfirmDisabled) {
                  e.preventDefault();
                  handleConfirm();
                }
              }}
              placeholder={remarkPlaceholder}
              rows={3}
              className="resize-none"
              autoFocus={requireRemark}
            />
          </div>
        )}

        <DialogFooter className="gap-2 sm:gap-0">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={() => handleOpenChange(false)}
            disabled={isLoading}
          >
            {cancelLabel}
          </Button>
          <Button
            type="button"
            variant={variant}
            size="sm"
            onClick={handleConfirm}
            disabled={isConfirmDisabled}
          >
            {isLoading ? 'Processing...' : confirmLabel}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
};
