import { cn } from '@/lib/utils';

/** Amanat mark: an "A" over a base line, deposits held on record. Plain on purpose, no emblem. */
export function BrandMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={cn('h-7 w-7 shrink-0', className)} role="img" aria-label="Amanat">
      <rect width="32" height="32" rx="6" fill="var(--primary)" />
      <path
        d="M9.5 22.5 16 8.5l6.5 14M11.9 17.4h8.2"
        fill="none"
        stroke="#fff"
        strokeWidth="2.4"
        strokeLinecap="round"
        strokeLinejoin="round"
      />
      <path d="M8 25.5h16" stroke="#fff" strokeOpacity="0.55" strokeWidth="1.6" strokeLinecap="round" />
    </svg>
  );
}
