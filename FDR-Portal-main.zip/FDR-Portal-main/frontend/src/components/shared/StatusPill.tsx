/**
 * USAGE NOTE: StatusPill
 * -----------------------------------------------------------------------------
 * Displays the canonical lifecycle status of an FDR deposit.
 * Pill height is fixed at 22px with pill radius (9999px), 12px text, and an indicator dot.
 * All colors match the financial status token matrix.
 *
 * Example Usage:
 *   <StatusPill status="pending_approval" />
 *   <StatusPill status={deposit.status} className="ml-2" />
 *
 * Supported Statuses:
 *   draft, pending_approval, approved, rejected, release_requested, released, renewed
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { cn } from '@/lib/utils';
import type { FdrStatus } from '@/lib/types';
import { STATUS_LABELS } from '@/lib/format';

interface StatusPillProps {
  status: FdrStatus;
  className?: string;
  showDot?: boolean;
}

const STATUS_STYLES: Record<
  FdrStatus,
  { bg: string; text: string; dot: string }
> = {
  draft: {
    bg: 'bg-[#EEF1F5]',
    text: 'text-[#475467]',
    dot: 'bg-[#7A8496]',
  },
  pending_approval: {
    bg: 'bg-[#E8F1FB]',
    text: 'text-[#0B5CAD]',
    dot: 'bg-[#0B5CAD]',
  },
  approved: {
    bg: 'bg-[#E7F5EE]',
    text: 'text-[#167A4A]',
    dot: 'bg-[#167A4A]',
  },
  rejected: {
    bg: 'bg-[#FDECEA]',
    text: 'text-[#B42318]',
    dot: 'bg-[#B42318]',
  },
  release_requested: {
    bg: 'bg-[#EFEDFB]',
    text: 'text-[#5B4BB7]',
    dot: 'bg-[#5B4BB7]',
  },
  released: {
    bg: 'bg-[#E7F5EE]',
    text: 'text-[#167A4A]',
    dot: 'bg-[#167A4A]',
  },
  renewed: {
    bg: 'bg-[#EEF1F5]',
    text: 'text-[#475467]',
    dot: 'bg-[#7A8496]',
  },
};

export const StatusPill: React.FC<StatusPillProps> = ({
  status,
  className,
  showDot = true,
}) => {
  const style = STATUS_STYLES[status] || STATUS_STYLES.draft;
  const label = STATUS_LABELS[status] || status;

  return (
    <span
      className={cn(
        'inline-flex h-[22px] items-center gap-1.5 rounded-full px-2 text-[11.5px] font-medium leading-none select-none shrink-0 whitespace-nowrap',
        style.bg,
        style.text,
        className
      )}
    >
      {showDot && (
        <span
          className={cn('h-1.5 w-1.5 rounded-full shrink-0', style.dot)}
          aria-hidden="true"
        />
      )}
      <span>{label}</span>
    </span>
  );
};
