/**
 * USAGE NOTE: Money
 * -----------------------------------------------------------------------------
 * Standardized Indian Rupee money display component for Amanat.
 * Formats numbers into Indian numbering system (e.g., ₹12,50,000 or compact ₹4.82 Cr).
 * Uses monospace font with tabular-nums for aligned columns.
 * If 'compact' is enabled, an optional tooltip displays the exact unrounded value.
 *
 * Example Usage:
 *   <Money amount={deposit.amount} />
 *   <Money amount={124500000} compact />
 *   <Money amount={shortfall} className="text-[var(--risk)]" />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { cn } from '@/lib/utils';
import { inr, inrShort } from '@/lib/format';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface MoneyProps {
  amount: number | null | undefined;
  compact?: boolean;
  className?: string;
  showTooltip?: boolean;
}

export const Money: React.FC<MoneyProps> = ({
  amount,
  compact = false,
  className,
  showTooltip = true,
}) => {
  if (amount === null || amount === undefined || isNaN(amount)) {
    return <span className={cn('font-mono tabular-nums text-xs text-[var(--ink-3)]', className)}>₹0</span>;
  }

  if (compact) {
    const compactText = inrShort(amount);
    const exactText = inr(amount);

    if (showTooltip && compactText !== exactText) {
      return (
        <TooltipProvider>
          <Tooltip>
            <TooltipTrigger asChild>
              <span className={cn('font-mono tabular-nums cursor-help font-medium', className)}>
                {compactText}
              </span>
            </TooltipTrigger>
            <TooltipContent className="font-mono text-xs">
              {exactText}
            </TooltipContent>
          </Tooltip>
        </TooltipProvider>
      );
    }

    return (
      <span className={cn('font-mono tabular-nums font-medium', className)}>
        {compactText}
      </span>
    );
  }

  return (
    <span className={cn('font-mono tabular-nums font-medium', className)}>
      {inr(amount)}
    </span>
  );
};
