/**
 * USAGE NOTE: PageHeader
 * -----------------------------------------------------------------------------
 * Standard page title container for all Amanat screens.
 * Layout:
 *   - Left side: 20px page title (semi-bold) + one-line description in --ink-3 (#7A8496).
 *   - Right side: Action buttons (e.g. New FDR, Export CSV, Run Alerts, Filter toggle).
 * Maintains visual rhythm and consistent spacing without loud hero banners.
 *
 * Example Usage:
 *   <PageHeader
 *     title="Deposits Register"
 *     description="Active security deposits, intake FDRs and pending compliance records"
 *     actions={<Button onClick={openModal}>New FDR</Button>}
 *   />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { cn } from '@/lib/utils';

interface PageHeaderProps {
  title: string;
  description?: string;
  actions?: React.ReactNode;
  children?: React.ReactNode;
  className?: string;
}

export const PageHeader: React.FC<PageHeaderProps> = ({
  title,
  description,
  actions,
  children,
  className,
}) => {
  return (
    <div className={cn('flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-4 mb-4 border-b border-[var(--line)]', className)}>
      <div>
        <h1 className="text-[20px] font-semibold text-[var(--ink)] tracking-tight leading-snug">
          {title}
        </h1>
        {description && (
          <p className="text-xs text-[var(--ink-3)] mt-0.5">
            {description}
          </p>
        )}
      </div>

      {(actions || children) && (
        <div className="flex items-center gap-2 self-start sm:self-auto shrink-0">
          {actions}
          {children}
        </div>
      )}
    </div>
  );
};
