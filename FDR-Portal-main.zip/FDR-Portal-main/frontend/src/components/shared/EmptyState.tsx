/**
 * USAGE NOTE: EmptyState
 * -----------------------------------------------------------------------------
 * Clean, restrained empty state view for table and list containers.
 * Rules:
 *   - Exactly one concise line of explanatory text + one clear call-to-action button.
 *   - No stock vector illustrations, no 3D graphics, no cartoon characters.
 *   - Officer voice: short, factual, and direct.
 *
 * Example Usage:
 *   <EmptyState
 *     message="No deposits match the selected filter criteria."
 *     actionLabel="Reset filters"
 *     onAction={resetFilters}
 *   />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface EmptyStateProps {
  message: string;
  actionLabel?: string;
  onAction?: () => void;
  className?: string;
}

export const EmptyState: React.FC<EmptyStateProps> = ({
  message,
  actionLabel,
  onAction,
  className,
}) => {
  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center p-8 text-center rounded-[8px] border border-dashed border-[var(--line)] bg-[var(--surface-2)]/60 my-4',
        className
      )}
    >
      <p className="text-xs text-[var(--ink-2)] max-w-md">
        {message}
      </p>

      {actionLabel && onAction && (
        <Button
          variant="outline"
          size="sm"
          onClick={onAction}
          className="mt-3"
        >
          {actionLabel}
        </Button>
      )}
    </div>
  );
};
