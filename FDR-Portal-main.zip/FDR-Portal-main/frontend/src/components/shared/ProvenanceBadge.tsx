/**
 * USAGE NOTE: ProvenanceBadge
 * -----------------------------------------------------------------------------
 * Communicates the authenticity and audit status of an FDR deposit record.
 * Data verification states:
 *   - "submitted"       : Grey outline badge indicating unverified self-submission.
 *   - "officer_verified": Green badge with Check icon for manual bureau verification.
 *   - "bank_confirmed"  : Disabled badge with explicit tooltip stating bank API is
 *                         not connected in prototype. Never fake live bank verification!
 *
 * Example Usage:
 *   <ProvenanceBadge verification="submitted" />
 *   <ProvenanceBadge verification="officer_verified" />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { Check } from 'lucide-react';
import { cn } from '@/lib/utils';
import type { VerificationStatus } from '@/lib/types';

interface ProvenanceBadgeProps {
  verification: VerificationStatus | 'bank_confirmed';
  className?: string;
}

export const ProvenanceBadge: React.FC<ProvenanceBadgeProps> = ({
  verification,
  className,
}) => {
  if (verification === 'officer_verified') {
    return (
      <span
        className={cn(
          'inline-flex items-center gap-1 rounded-[4px] bg-[#E7F5EE] border border-[#C5E9D5] px-1.5 py-0.5 text-[10.5px] font-medium text-[#167A4A] select-none whitespace-nowrap shrink-0',
          className
        )}
      >
        <Check className="h-3 w-3 stroke-[2.5]" />
        <span>Officer-verified</span>
      </span>
    );
  }

  if (verification === 'bank_confirmed') {
    return (
      <span
        className={cn(
          'inline-flex items-center gap-1 rounded-[4px] bg-[#E7F5EE] border border-[#C5E9D5] px-1.5 py-0.5 text-[10.5px] font-medium text-[#167A4A] select-none whitespace-nowrap shrink-0',
          className
        )}
      >
        <Check className="h-3 w-3 stroke-[2.5]" />
        <span>Bank-confirmed (letter)</span>
      </span>
    );
  }

  // default: submitted
  return (
    <span
      className={cn(
        'inline-flex items-center gap-1 rounded-[4px] bg-white border border-[var(--line)] px-1.5 py-0.5 text-[10.5px] font-medium text-[var(--ink-2)] select-none whitespace-nowrap shrink-0',
        className
      )}
    >
      <span>Submitted</span>
    </span>
  );
};
