/**
 * USAGE NOTE: DateText
 * -----------------------------------------------------------------------------
 * Displays calendar dates consistently formatted as "12 Mar 2027" in Indian administrative format.
 * Supports date-time display for audit logs ("12 Mar 2027, 14:30") and optional
 * relative maturity chip ("in 23 days" / "5 days overdue") rendered alongside.
 * Never outputs arbitrary browser-localized dates.
 *
 * Example Usage:
 *   <DateText date={deposit.maturity_date} />
 *   <DateText date={deposit.maturity_date} daysToMaturity={deposit.days_to_maturity} />
 *   <DateText date={auditItem.at} withTime />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { cn } from '@/lib/utils';
import { formatDate, formatDateTime } from '@/lib/format';
import { MaturityChip } from './MaturityChip';

interface DateTextProps {
  date: string | Date | null | undefined;
  withTime?: boolean;
  daysToMaturity?: number | null;
  className?: string;
}

export const DateText: React.FC<DateTextProps> = ({
  date,
  withTime = false,
  daysToMaturity,
  className,
}) => {
  if (!date) {
    return <span className="text-xs text-[var(--ink-3)]">—</span>;
  }

  const formatted = withTime ? formatDateTime(date) : formatDate(date);

  return (
    <span className={cn('inline-flex items-center gap-2 whitespace-nowrap', className)}>
      <span className="text-xs text-[var(--ink)] font-normal">{formatted}</span>
      {daysToMaturity !== undefined && daysToMaturity !== null && (
        <MaturityChip days={daysToMaturity} />
      )}
    </span>
  );
};
