import React, { useEffect, useState } from 'react';
import QRCode from 'qrcode';
import { cn } from '@/lib/utils';

interface QrCodeProps {
  value: string;
  size?: number;
  className?: string;
  /** Optional text printed under the code, e.g. the verification code. */
  showCode?: string;
}

/**
 * A real, scannable QR code (ISO/IEC 18004) for a verify URL, rendered as an image.
 * Medium error correction so a printed and photocopied letter still scans.
 */
export const QrCode: React.FC<QrCodeProps> = ({ value, size = 96, className, showCode }) => {
  const [src, setSrc] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    QRCode.toDataURL(value, { errorCorrectionLevel: 'M', margin: 1, width: size * 2 })
      .then((url) => {
        if (active) setSrc(url);
      })
      .catch(() => {
        if (active) setSrc(null);
      });
    return () => {
      active = false;
    };
  }, [value, size]);

  return (
    <div className={cn('inline-flex flex-col items-center gap-1', className)}>
      {src ? (
        <img src={src} width={size} height={size} alt="QR code to verify this letter" />
      ) : (
        <div style={{ width: size, height: size }} className="border border-[var(--line)]" aria-hidden />
      )}
      {showCode && <span className="font-mono text-[11px] tabular-nums text-[var(--ink-2)]">{showCode}</span>}
    </div>
  );
};
