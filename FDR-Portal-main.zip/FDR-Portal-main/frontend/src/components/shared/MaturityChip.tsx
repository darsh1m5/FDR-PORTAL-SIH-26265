/**
 * USAGE NOTE: MaturityChip
 * -----------------------------------------------------------------------------
 * Displays relative maturity status (e.g., "in 23 days", "5 days overdue", "today")
 * styled according to the maturity state color palette.
 * Overdue items are highlighted in risk red (#B42318), upcoming due dates in warning amber
 * (#B45309), healthy active deposits in green (#167A4A), and closed in neutral grey.
 *
 * Example Usage:
 *   <MaturityChip days={deposit.days_to_maturity} state={deposit.maturity_state} />
 *   <MaturityChip days={14} /> // auto-derives state if omitted
 *
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { cn } from '@/lib/utils';
import type { MaturityState } from '@/lib/types';
import { relDays } from '@/lib/format';

interface MaturityChipProps {
  days: number | null | undefined;
  state?: MaturityState;
  className?: string;
}

export const MaturityChip: React.FC<MaturityChipProps> = ({
  days,
  state,
  className,
}) => {
  if (days === null || days === undefined) {
    return <span className="text-xs text-[var(--ink-3)]">—</span>;
  }

  // Derive state if not explicitly passed
  let resolvedState: MaturityState = state || 'active';
  if (!state) {
    if (days < 0) resolvedState = 'matured';
    else if (days <= 7) resolvedState = 'due_7';
    else if (days <= 30) resolvedState = 'due_30';
    else if (days <= 60) resolvedState = 'due_60';
    else if (days <= 90) resolvedState = 'due_90';
    else resolvedState = 'active';
  }

  // Closed state (released/renewed/rejected) shows "Closed", not overdue days
  if (resolvedState === 'closed') {
    return (
      <span
        className={cn(
          'inline-flex items-center rounded-[4px] border border-transparent px-1.5 py-0.5 text-[10.5px] font-mono leading-none select-none whitespace-nowrap shrink-0 bg-[#EEF1F5] text-[#475467]',
          className
        )}
      >
        Closed
      </span>
    );
  }

  let colorClasses = 'bg-[#E7F5EE] text-[#167A4A] border-transparent';
  if (resolvedState === 'matured') {
    colorClasses = 'bg-[#FDECEA] text-[#B42318] border-[#F8D4D0] font-semibold';
  } else if (
    resolvedState === 'due_7' ||
    resolvedState === 'due_30' ||
    resolvedState === 'due_60' ||
    resolvedState === 'due_90'
  ) {
    colorClasses = 'bg-[#FEF3E2] text-[#B45309] border-[#F8E1BE]';
  }

  const text = relDays(days);

  return (
    <span
      className={cn(
        'inline-flex items-center rounded-[4px] border px-1.5 py-0.5 text-[10.5px] font-mono leading-none select-none whitespace-nowrap shrink-0',
        colorClasses,
        className
      )}
    >
      {text}
    </span>
  );
};
