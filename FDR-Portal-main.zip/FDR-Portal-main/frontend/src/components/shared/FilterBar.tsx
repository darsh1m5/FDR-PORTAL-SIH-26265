/**
 * USAGE NOTE: FilterBar
 * -----------------------------------------------------------------------------
 * Top filter and search container for registers and data views.
 * Design guidelines:
 *   - Search input with Search icon and debounce support.
 *   - Clean inline select filter slots.
 *   - "Reset / Clear filters" action when any filter is active.
 *   - Summary context counter ("45 deposits · ₹6.4 Cr").
 *
 * Example Usage:
 *   <FilterBar
 *     searchValue={query}
 *     onSearchChange={setQuery}
 *     searchPlaceholder="Search FDR number, institution or AICTE ID..."
 *     context="45 deposits · ₹6.4 Cr"
 *     onReset={resetAll}
 *   >
 *     <Select value={status} onValueChange={setStatus}>...</Select>
 *   </FilterBar>
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { Search, X } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';

interface FilterBarProps {
  searchValue?: string;
  onSearchChange?: (val: string) => void;
  searchPlaceholder?: string;
  context?: string | React.ReactNode;
  children?: React.ReactNode;
  actions?: React.ReactNode;
  onReset?: () => void;
  hasActiveFilters?: boolean;
  className?: string;
}

export const FilterBar: React.FC<FilterBarProps> = ({
  searchValue = '',
  onSearchChange,
  searchPlaceholder = 'Search records...',
  context,
  children,
  actions,
  onReset,
  hasActiveFilters = false,
  className,
}) => {
  return (
    <div
      className={cn(
        'flex flex-col gap-3 rounded-[8px] border border-[var(--line)] bg-white p-3 shadow-2xs mb-4',
        className
      )}
    >
      <div className="flex flex-col md:flex-row md:items-center justify-between gap-2.5">
        <div className="flex flex-1 flex-wrap items-center gap-2">
          {onSearchChange && (
            <div className="relative w-full sm:w-64 md:w-72">
              <Search className="absolute left-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-[var(--ink-3)]" />
              <Input
                value={searchValue}
                onChange={(e) => onSearchChange(e.target.value)}
                placeholder={searchPlaceholder}
                className="pl-8 text-xs"
              />
              {searchValue && (
                <button
                  type="button"
                  onClick={() => onSearchChange('')}
                  className="absolute right-2 top-1/2 -translate-y-1/2 text-[var(--ink-3)] hover:text-[var(--ink)]"
                >
                  <X className="h-3 w-3" />
                </button>
              )}
            </div>
          )}

          {children}

          {hasActiveFilters && onReset && (
            <Button
              variant="ghost"
              size="sm"
              onClick={onReset}
              className="h-8 px-2 text-[11px] text-[var(--ink-3)] hover:text-[var(--ink)]"
            >
              <X className="mr-1 h-3 w-3" />
              Reset filters
            </Button>
          )}
        </div>

        {(context || actions) && (
          <div className="flex items-center justify-between md:justify-end gap-3 shrink-0 pt-1 md:pt-0">
            {context && (
              <span className="text-xs font-medium text-[var(--ink-2)]">
                {context}
              </span>
            )}
            {actions}
          </div>
        )}
      </div>
    </div>
  );
};
