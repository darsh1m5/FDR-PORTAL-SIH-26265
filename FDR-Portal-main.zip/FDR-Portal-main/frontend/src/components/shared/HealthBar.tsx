/**
 * USAGE NOTE: HealthBar
 * -----------------------------------------------------------------------------
 * Displays the FDR Integrity Health Score (0–100) using a 4-segment bar and monospace value.
 * Uses linear segmented indicators rather than circular gauges.
 * Colors:
 *   Score >= 85 : Healthy green (#167A4A)
 *   Score 60-84 : Warning amber (#B45309)
 *   Score < 60  : Risk red (#B42318)
 *
 * Example Usage:
 *   <HealthBar score={deposit.health_score} />
 *   <HealthBar score={institution.health_score} showValue={false} />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { cn } from '@/lib/utils';

interface HealthBarProps {
  score: number | null | undefined;
  className?: string;
  showValue?: boolean;
  size?: 'sm' | 'default';
}

export const HealthBar: React.FC<HealthBarProps> = ({
  score = 100,
  className,
  showValue = true,
  size = 'default',
}) => {
  const safeScore = Math.max(0, Math.min(100, score ?? 100));

  let color = 'bg-[#167A4A]';
  let textColor = 'text-[#167A4A]';
  if (safeScore < 60) {
    color = 'bg-[#B42318]';
    textColor = 'text-[#B42318]';
  } else if (safeScore < 85) {
    color = 'bg-[#B45309]';
    textColor = 'text-[#B45309]';
  }

  // Calculate segment fills for 4 segments (each represents 25 points)
  // segment 1: 0-25, segment 2: 26-50, segment 3: 51-75, segment 4: 76-100
  const getSegmentFill = (segIndex: number) => {
    const threshold = (segIndex + 1) * 25;
    if (safeScore >= threshold) return '100%';
    const segStart = segIndex * 25;
    if (safeScore <= segStart) return '0%';
    const pct = ((safeScore - segStart) / 25) * 100;
    return `${pct}%`;
  };

  const barHeight = size === 'sm' ? 'h-1.5' : 'h-2';
  const barWidth = size === 'sm' ? 'w-10' : 'w-16';

  return (
    <div className={cn('inline-flex items-center gap-1.5 select-none', className)}>
      <div className={cn('flex items-center gap-0.5', barWidth, barHeight)}>
        {[0, 1, 2, 3].map((i) => {
          const fill = getSegmentFill(i);
          return (
            <div
              key={i}
              className={cn(
                'relative flex-1 rounded-[1px] bg-[var(--line)] overflow-hidden',
                barHeight
              )}
            >
              <div
                className={cn('h-full transition-all duration-300', color)}
                style={{ width: fill }}
              />
            </div>
          );
        })}
      </div>
      {showValue && (
        <span
          className={cn(
            'font-mono text-xs font-semibold tabular-nums',
            textColor
          )}
        >
          {safeScore}
        </span>
      )}
    </div>
  );
};
