/**
 * USAGE NOTE: KpiTile
 * -----------------------------------------------------------------------------
 * Executive KPI summary tile specifications:
 *   - Label: 12px text in --ink-2 (#4A5567)
 *   - Value: 28px monospace (IBM Plex Mono 500) tabular-nums
 *   - Context line: 12px text in --ink-3 with optional trend or badge
 *   - Tooltip support for exact rupee amount when using compact notation (e.g. ₹4.82 Cr)
 *   - Optional click handler or link to filtered register
 *   - Never uses heavy cards, glowing gradients, or large radii
 *
 * Example Usage:
 *   <KpiTile label="Total Value" value="₹64.2 Cr" tooltipExact="₹64,20,50,000" context="Across 14 institutions" href="/deposits" />
 *   <KpiTile label="Pending Approvals" value="8" alert={true} href="/approvals" />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { Link } from 'react-router-dom';
import { cn } from '@/lib/utils';
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from '@/components/ui/tooltip';

interface KpiTileProps {
  label: string;
  value: React.ReactNode;
  context?: string;
  tooltipExact?: string;
  href?: string;
  onClick?: () => void;
  className?: string;
  alert?: boolean;
  valueColor?: string;
}

export const KpiTile: React.FC<KpiTileProps> = ({
  label,
  value,
  context,
  tooltipExact,
  href,
  onClick,
  className,
  alert = false,
  valueColor,
}) => {
  const content = (
    <div
      className={cn(
        'group flex flex-col justify-between rounded-[8px] border border-[var(--line)] bg-white p-4 transition-colors',
        (href || onClick) && 'hover:border-[#CCD2DB] hover:bg-[var(--surface-2)] cursor-pointer',
        className
      )}
      onClick={onClick}
    >
      <div className="flex items-center justify-between">
        <span className="text-[12px] font-medium text-[var(--ink-2)] truncate">
          {label}
        </span>
        {alert && (
          <span className="h-2 w-2 rounded-full bg-[var(--risk)] animate-pulse" />
        )}
      </div>

      <div className="my-1.5">
        {tooltipExact ? (
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <span
                  className={cn(
                    'font-mono text-[28px] font-medium leading-tight tracking-tight tabular-nums block truncate',
                    valueColor || 'text-[var(--ink)]'
                  )}
                >
                  {value}
                </span>
              </TooltipTrigger>
              <TooltipContent className="font-mono text-xs">
                {tooltipExact}
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        ) : (
          <span
            className={cn(
              'font-mono text-[28px] font-medium leading-tight tracking-tight tabular-nums block truncate',
              valueColor || 'text-[var(--ink)]'
            )}
          >
            {value}
          </span>
        )}
      </div>

      {context && (
        <span className="text-[12px] text-[var(--ink-3)] truncate">
          {context}
        </span>
      )}
    </div>
  );

  if (href) {
    return <Link to={href} className="block no-underline">{content}</Link>;
  }

  return content;
};
