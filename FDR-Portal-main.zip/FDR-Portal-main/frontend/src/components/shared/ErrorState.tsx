/**
 * USAGE NOTE: ErrorState
 * -----------------------------------------------------------------------------
 * Provides a quiet, informative failure presentation when API calls fail or data
 * cannot be retrieved.
 * Design guidelines:
 *   - Factual officer tone: never cute, never overly apologetic.
 *   - Displays specific backend error detail (e.g. from error.message or response.detail).
 *   - Provides an immediate "Retry" button.
 *
 * Example Usage:
 *   <ErrorState error={error} onRetry={() => refetch()} />
 *   <ErrorState message="Could not load verification logs." onRetry={reload} />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { AlertTriangle, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';

interface ErrorStateProps {
  error?: Error | unknown;
  message?: string;
  onRetry?: () => void;
  className?: string;
}

export const ErrorState: React.FC<ErrorStateProps> = ({
  error,
  message,
  onRetry,
  className,
}) => {
  let displayMessage = message;
  if (!displayMessage) {
    if (error instanceof Error) {
      displayMessage = error.message;
    } else if (typeof error === 'string') {
      displayMessage = error;
    } else {
      displayMessage = 'An unexpected system error occurred while processing the request.';
    }
  }

  return (
    <div
      className={cn(
        'flex flex-col items-center justify-center p-6 text-center rounded-[8px] border border-[#F8D4D0] bg-[#FDECEA]/40 my-4',
        className
      )}
    >
      <div className="flex items-center gap-2 text-[#B42318] mb-1.5">
        <AlertTriangle className="h-4 w-4 shrink-0" />
        <span className="text-xs font-semibold">System Communication Error</span>
      </div>

      <p className="text-xs text-[var(--ink-2)] max-w-md font-mono">
        {displayMessage}
      </p>

      {onRetry && (
        <Button
          variant="outline"
          size="sm"
          onClick={onRetry}
          className="mt-3 gap-1.5 border-[#E3E7EC] hover:bg-white"
        >
          <RefreshCw className="h-3 w-3" />
          <span>Retry request</span>
        </Button>
      )}
    </div>
  );
};
