/**
 * USAGE NOTE: DataTable
 * -----------------------------------------------------------------------------
 * Canonical data table component across all Amanat registers and queues.
 * Design specifications:
 *   - 44px rows, sticky header on --surface-2 (#F9FAFB).
 *   - Monospace tabular-nums for numeric/money columns.
 *   - Whole row click navigation.
 *   - Integrated sorting indicator (asc/desc/none).
 *   - Loading skeleton state with simulated table rows.
 *   - Empty state fallback with custom message.
 *   - Built-in pagination controls with page count and item totals.
 *
 * Example Usage:
 *   <DataTable
 *     columns={columns}
 *     data={items}
 *     isLoading={isLoading}
 *     onRowClick={(row) => navigate(`/deposits/${row.id}`)}
 *     total={totalCount}
 *     page={page}
 *     pageSize={pageSize}
 *     onPageChange={setPage}
 *   />
 * -----------------------------------------------------------------------------
 */

import React from 'react';
import { ChevronDown, ChevronUp, ChevronsUpDown, ChevronLeft, ChevronRight } from 'lucide-react';
import { cn } from '@/lib/utils';
import {
  Table,
  TableHeader,
  TableBody,
  TableRow,
  TableHead,
  TableCell,
} from '@/components/ui/table';
import { Button } from '@/components/ui/button';
import { Skeleton } from '@/components/ui/skeleton';
import { EmptyState } from './EmptyState';

export interface Column<T> {
  key: string;
  header: string;
  cell: (item: T, index: number) => React.ReactNode;
  sortable?: boolean;
  align?: 'left' | 'center' | 'right';
  className?: string;
  width?: string;
}

interface DataTableProps<T> {
  columns: Column<T>[];
  data: T[] | undefined;
  isLoading?: boolean;
  onRowClick?: (item: T) => void;
  emptyMessage?: string;
  emptyActionLabel?: string;
  emptyOnAction?: () => void;
  sortBy?: string;
  sortOrder?: 'asc' | 'desc';
  onSort?: (key: string) => void;
  page?: number;
  pageSize?: number;
  total?: number;
  onPageChange?: (newPage: number) => void;
  className?: string;
}

export function DataTable<T>({
  columns,
  data = [],
  isLoading = false,
  onRowClick,
  emptyMessage = 'No records found.',
  emptyActionLabel,
  emptyOnAction,
  sortBy,
  sortOrder,
  onSort,
  page,
  pageSize = 15,
  total,
  onPageChange,
  className,
}: DataTableProps<T>) {
  const totalPages = total !== undefined ? Math.ceil(total / pageSize) : 1;
  const currentPage = page ?? 1;

  return (
    <div className={cn('rounded-[8px] border border-[var(--line)] bg-white overflow-hidden flex flex-col', className)}>
      <div className="overflow-x-auto">
        <Table>
          <TableHeader>
            <TableRow className="hover:bg-transparent">
              {columns.map((col) => {
                const isSorted = sortBy === col.key;
                return (
                  <TableHead
                    key={col.key}
                    style={{ width: col.width }}
                    className={cn(
                      col.align === 'right' && 'text-right',
                      col.align === 'center' && 'text-center',
                      col.sortable && 'cursor-pointer select-none hover:text-[var(--ink)]',
                      col.className
                    )}
                    onClick={() => col.sortable && onSort && onSort(col.key)}
                  >
                    <div
                      className={cn(
                        'inline-flex items-center gap-1.5',
                        col.align === 'right' && 'justify-end w-full'
                      )}
                    >
                      <span>{col.header}</span>
                      {col.sortable && (
                        <span className="text-[var(--ink-3)]">
                          {isSorted ? (
                            sortOrder === 'asc' ? (
                              <ChevronUp className="h-3.5 w-3.5 text-[var(--primary)]" />
                            ) : (
                              <ChevronDown className="h-3.5 w-3.5 text-[var(--primary)]" />
                            )
                          ) : (
                            <ChevronsUpDown className="h-3 w-3 opacity-40" />
                          )}
                        </span>
                      )}
                    </div>
                  </TableHead>
                );
              })}
            </TableRow>
          </TableHeader>

          <TableBody>
            {isLoading ? (
              // Loading skeleton rows
              Array.from({ length: 6 }).map((_, rIdx) => (
                <TableRow key={`skeleton-${rIdx}`}>
                  {columns.map((_, cIdx) => (
                    <TableCell key={`col-${cIdx}`}>
                      <Skeleton className="h-4 w-full max-w-[120px]" />
                    </TableCell>
                  ))}
                </TableRow>
              ))
            ) : data.length === 0 ? (
              <TableRow>
                <TableCell colSpan={columns.length} className="h-48 text-center p-0">
                  <EmptyState
                    message={emptyMessage}
                    actionLabel={emptyActionLabel}
                    onAction={emptyOnAction}
                  />
                </TableCell>
              </TableRow>
            ) : (
              data.map((item, idx) => (
                <TableRow
                  key={(item as any)?.id ?? idx}
                  className={cn(
                    onRowClick && 'cursor-pointer hover:bg-[var(--surface-2)] transition-colors'
                  )}
                  onClick={() => onRowClick && onRowClick(item)}
                >
                  {columns.map((col) => (
                    <TableCell
                      key={col.key}
                      className={cn(
                        col.align === 'right' && 'text-right font-mono tabular-nums',
                        col.align === 'center' && 'text-center',
                        col.className
                      )}
                    >
                      {col.cell(item, idx)}
                    </TableCell>
                  ))}
                </TableRow>
              ))
            )}
          </TableBody>
        </Table>
      </div>

      {/* Pagination Footer */}
      {total !== undefined && onPageChange && total > 0 && (
        <div className="flex items-center justify-between px-3 py-2 border-t border-[var(--line)] bg-[var(--surface-2)]/50 text-xs text-[var(--ink-2)]">
          <div className="text-[11px] text-[var(--ink-3)] font-mono">
            Showing {Math.min((currentPage - 1) * pageSize + 1, total)}–
            {Math.min(currentPage * pageSize, total)} of {total} records
          </div>

          <div className="flex items-center gap-1">
            <Button
              variant="outline"
              size="icon-sm"
              disabled={currentPage <= 1 || isLoading}
              onClick={() => onPageChange(currentPage - 1)}
              aria-label="Previous page"
            >
              <ChevronLeft className="h-3.5 w-3.5" />
            </Button>
            <span className="px-2 text-xs font-mono tabular-nums">
              {currentPage} / {Math.max(1, totalPages)}
            </span>
            <Button
              variant="outline"
              size="icon-sm"
              disabled={currentPage >= totalPages || isLoading}
              onClick={() => onPageChange(currentPage + 1)}
              aria-label="Next page"
            >
              <ChevronRight className="h-3.5 w-3.5" />
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}
