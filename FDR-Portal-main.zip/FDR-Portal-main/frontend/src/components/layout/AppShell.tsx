import React, { useState, useEffect } from 'react';
import { BrandMark } from '@/components/shared/BrandMark';
import { NavLink, Outlet, useLocation, useNavigate } from 'react-router-dom';
import {
  LayoutDashboard,
  Radar,
  FileText,
  CheckSquare,
  Bell,
  Activity,
  Building2,
  History,
  FileSpreadsheet,
  Settings,
  Search,
  LogOut,
  Menu,
  X,
  FileUp,
  Mail,
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { cn } from '@/lib/utils';
import { useAuth } from '@/lib/auth';
import { api } from '@/lib/api';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import {
  CommandDialog,
  CommandInput,
  CommandList,
  CommandEmpty,
  CommandGroup,
  CommandItem,
} from '@/components/ui/command';
import type { ApprovalsResponse, AlertItem, FdrListItem, InstitutionItem, Role } from '@/lib/types';
import { ROLE_LABELS } from '@/lib/format';

interface NavItem {
  label: string;
  to: string;
  icon: React.ElementType;
  badge?: number | null;
  adminOnly?: boolean;
  allowedRoles?: Role[];
}

interface NavGroup {
  title: string;
  items: NavItem[];
}

export const AppShell: React.FC = () => {
  const { user, logout } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);
  const [searchOpen, setSearchOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Fetch pending approvals count for nav badge
  const { data: approvalsData } = useQuery<ApprovalsResponse>({
    queryKey: ['approvals', 'badge'],
    queryFn: () => api.get<ApprovalsResponse>('/approvals'),
    staleTime: 30000,
    retry: false,
    // Institutions have no approvals queue; asking would only return 403.
    enabled: !!user && user.role !== 'institution',
  });

  // Fetch active alerts count for nav badge & top bar bell
  const { data: alertsData } = useQuery<AlertItem[]>({
    queryKey: ['alerts', 'badge'],
    queryFn: () => api.get<AlertItem[]>('/alerts?state=open'),
    staleTime: 30000,
    retry: false,
  });

  // Search query results for Ctrl+K command dialog
  const { data: searchFdrs } = useQuery<{ items: FdrListItem[] }>({
    queryKey: ['fdrs', 'quicksearch', searchQuery],
    queryFn: () => api.get<{ items: FdrListItem[] }>(`/fdrs?q=${encodeURIComponent(searchQuery)}&page_size=5`),
    enabled: searchOpen && searchQuery.length >= 2,
    staleTime: 10000,
  });

  const { data: searchInstitutions } = useQuery<InstitutionItem[]>({
    queryKey: ['institutions', 'quicksearch', searchQuery],
    queryFn: () => api.get<InstitutionItem[]>(`/institutions?q=${encodeURIComponent(searchQuery)}`),
    enabled: searchOpen && searchQuery.length >= 2,
    staleTime: 10000,
  });

  // Ctrl+K keybinding
  useEffect(() => {
    const down = (e: KeyboardEvent) => {
      if (e.key === 'k' && (e.metaKey || e.ctrlKey)) {
        e.preventDefault();
        setSearchOpen((open) => !open);
      }
    };
    document.addEventListener('keydown', down);
    return () => document.removeEventListener('keydown', down);
  }, []);

  // Close mobile drawer on route change
  useEffect(() => {
    setMobileMenuOpen(false);
  }, [location.pathname]);

  const [fdrBreadcrumb, setFdrBreadcrumb] = useState<string | null>(null);

  // Listen for FDR title updates from detail page
  useEffect(() => {
    const handleFdrTitle = (e: Event) => {
      const customEvent = e as CustomEvent<string>;
      if (customEvent.detail) setFdrBreadcrumb(customEvent.detail);
    };
    window.addEventListener('fdr-loaded', handleFdrTitle);
    return () => window.removeEventListener('fdr-loaded', handleFdrTitle);
  }, []);

  // Reset fdrBreadcrumb when leaving deposits detail
  useEffect(() => {
    if (!location.pathname.startsWith('/deposits/')) {
      setFdrBreadcrumb(null);
    }
  }, [location.pathname]);

  const pendingApprovalsCount = approvalsData?.items?.length ?? 0;
  // Match dashboard open_alerts count: all active/unacknowledged alerts
  const openAlertsCount = alertsData?.length ?? 0;

  const navGroups: NavGroup[] = [
    {
      title: 'Overview',
      items: [
        { label: 'Dashboard', to: '/', icon: LayoutDashboard },
        {
          label: 'Maturity Radar',
          to: '/radar',
          icon: Radar,
          allowedRoles: ['admin', 'reviewer', 'approver', 'auditor', 'institution'],
        },
      ],
    },
    {
      title: 'Deposits',
      items: [
        { label: 'Register', to: '/deposits', icon: FileText },
        {
          label: 'Imports',
          to: '/imports',
          icon: FileUp,
          adminOnly: true,
        },
        {
          label: 'Approvals',
          to: '/approvals',
          icon: CheckSquare,
          badge: pendingApprovalsCount > 0 ? pendingApprovalsCount : null,
          allowedRoles: ['admin', 'reviewer', 'approver', 'auditor'],
        },
        {
          label: 'Alerts',
          to: '/alerts',
          icon: Bell,
          badge: openAlertsCount > 0 ? openAlertsCount : null,
        },
        {
          label: 'Health Check',
          to: '/health',
          icon: Activity,
          allowedRoles: ['admin', 'reviewer', 'approver', 'auditor'],
        },
      ],
    },
    {
      title: 'Records',
      items: [
        {
          label: 'Institutions',
          to: '/institutions',
          icon: Building2,
          allowedRoles: ['admin', 'reviewer', 'approver', 'auditor', 'institution'],
        },
        { label: 'Notices', to: '/notices', icon: Mail },
        {
          label: 'Audit Log',
          to: '/audit',
          icon: History,
          allowedRoles: ['admin', 'reviewer', 'approver', 'auditor'],
        },
        { label: 'Reports', to: '/reports', icon: FileSpreadsheet },
      ],
    },
    {
      title: 'Admin',
      items: [
        {
          label: 'Settings',
          to: '/settings',
          icon: Settings,
          allowedRoles: ['admin', 'reviewer', 'approver', 'auditor'],
        },
      ],
    },
  ];

  // Helper for breadcrumbs
  const getBreadcrumbs = () => {
    const p = location.pathname;
    if (p === '/') return [{ label: 'Dashboard' }];
    if (p === '/deposits') return [{ label: 'Deposits', to: '/deposits' }, { label: 'Register' }];
    if (p === '/deposits/new') return [{ label: 'Deposits', to: '/deposits' }, { label: 'New Deposit' }];
    if (p.startsWith('/deposits/') && p.endsWith('/edit')) return [{ label: 'Deposits', to: '/deposits' }, { label: 'Edit' }];
    if (p.startsWith('/deposits/') && p.endsWith('/renew')) return [{ label: 'Deposits', to: '/deposits' }, { label: 'Renew' }];
    if (p.startsWith('/deposits/')) {
      const fdrNum = fdrBreadcrumb || (location.state as any)?.fdrNumber;
      return [{ label: 'Deposits', to: '/deposits' }, { label: fdrNum || 'Not found' }];
    }
    if (p === '/imports') return [{ label: 'Deposits', to: '/deposits' }, { label: 'Spreadsheet Import' }];
    if (p === '/approvals') return [{ label: 'Deposits' }, { label: 'Approvals' }];
    if (p === '/alerts') return [{ label: 'Deposits' }, { label: 'Alerts' }];
    if (p === '/radar') return [{ label: 'Overview' }, { label: 'Maturity Radar' }];
    if (p === '/health') return [{ label: 'Deposits' }, { label: 'Health Check' }];
    if (p === '/institutions') return [{ label: 'Records' }, { label: 'Institutions' }];
    if (p.startsWith('/institutions/')) return [{ label: 'Institutions', to: '/institutions' }, { label: 'Detail' }];
    if (p === '/notices') return [{ label: 'Records' }, { label: 'Notices & Letters' }];
    if (p === '/audit') return [{ label: 'Records' }, { label: 'Audit Log' }];
    if (p === '/reports') return [{ label: 'Records' }, { label: 'Reports' }];
    if (p === '/settings') return [{ label: 'Admin' }, { label: 'Settings' }];
    return [{ label: 'Portal' }];
  };

  const breadcrumbs = getBreadcrumbs();

  const sidebarContent = (
    <div className="flex h-full flex-col justify-between bg-[var(--ink)] text-white">
      <div>
        {/* Brand Header */}
        <div className="flex h-14 items-center gap-2.5 px-4 border-b border-white/10">
          <BrandMark className="h-7 w-7" />
          <div className="flex flex-col">
            <span className="text-[13px] font-semibold tracking-tight text-white leading-tight">
              Amanat
            </span>
            <span className="text-[10px] text-white/50 leading-tight">
              Security Deposit &amp; FDR Management
            </span>
          </div>
        </div>

        {/* Navigation Groups */}
        <div className="space-y-4 px-2.5 py-4 overflow-y-auto">
          {navGroups.map((group) => {
            const visibleItems = group.items.filter((item) => {
              if (item.adminOnly && user?.role !== 'admin') return false;
              if (item.allowedRoles && (!user?.role || !item.allowedRoles.includes(user.role))) return false;
              return true;
            });
            if (visibleItems.length === 0) return null;

            return (
              <div key={group.title}>
                <div className="px-2 pb-1 text-[10px] font-semibold uppercase tracking-wider text-white/40">
                  {group.title}
                </div>
                <div className="space-y-0.5">
                  {visibleItems.map((item) => {
                    const Icon = item.icon;
                    return (
                      <NavLink
                        key={item.to}
                        to={item.to}
                        end={item.to === '/'}
                        className={({ isActive }) =>
                          cn(
                            'group flex items-center justify-between rounded-[4px] px-2 py-1.5 text-xs font-medium text-white/70 transition-colors hover:bg-white/5 hover:text-white',
                            isActive &&
                              'bg-[var(--primary)]/15 text-white border-l-2 border-[var(--primary)] -ml-[2px] font-semibold'
                          )
                        }
                      >
                        <div className="flex items-center gap-2.5">
                          <Icon className="h-4 w-4 shrink-0 opacity-75 group-hover:opacity-100" />
                          <span>{item.label}</span>
                        </div>
                        {item.badge !== undefined && item.badge !== null && (
                          <span
                            className={cn(
                              'rounded-full px-1.5 py-0.2 text-[10px] font-mono font-semibold',
                              item.label === 'Alerts'
                                ? 'bg-[var(--risk)] text-white'
                                : 'bg-[var(--primary)] text-white'
                            )}
                          >
                            {item.badge}
                          </span>
                        )}
                      </NavLink>
                    );
                  })}
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* User Session Footer in Sidebar */}
      <div className="border-t border-white/10 p-3">
        <div className="flex items-center justify-between">
          <div className="flex flex-col min-w-0 pr-2">
            <span className="text-xs font-medium text-white truncate">
              {user?.name || 'Authorized Officer'}
            </span>
            {user?.institution_name && (
              <span className="text-[10px] text-white/70 truncate block">
                {user.institution_name}
              </span>
            )}
            <div className="flex items-center gap-1.5 mt-0.5">
              <span className="text-[10px] text-white/50 truncate font-mono">
                {user?.email}
              </span>
            </div>
          </div>
          <Button
            variant="ghost"
            size="icon-sm"
            onClick={logout}
            className="text-white/60 hover:text-white hover:bg-white/10 shrink-0"
            title="Sign out"
          >
            <LogOut className="h-3.5 w-3.5" />
          </Button>
        </div>
      </div>
    </div>
  );

  return (
    <div className="flex min-h-screen bg-[var(--bg)] text-[var(--ink)] antialiased">
      {/* Desktop Sidebar (240px) */}
      <aside className="hidden md:flex md:w-[240px] md:flex-col md:fixed md:inset-y-0 z-30">
        {sidebarContent}
      </aside>

      {/* Mobile Drawer */}
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-50 flex md:hidden">
          <div
            className="fixed inset-0 bg-black/50"
            onClick={() => setMobileMenuOpen(false)}
          />
          <div className="relative flex w-[240px] flex-col">
            <button
              onClick={() => setMobileMenuOpen(false)}
              className="absolute right-2 top-2 p-1 text-white z-10"
              aria-label="Close menu"
            >
              <X className="h-5 w-5" />
            </button>
            {sidebarContent}
          </div>
        </div>
      )}

      {/* Main Content Area */}
      <div className="flex flex-1 flex-col md:pl-[240px] min-w-0 overflow-x-hidden">
        {/* Top Bar (56px) */}
        <header className="sticky top-0 z-20 flex h-14 items-center justify-between border-b border-[var(--line)] bg-white px-4 md:px-6">
          {/* Left: Mobile trigger & Breadcrumb */}
          <div className="flex items-center gap-3">
            <Button
              variant="ghost"
              size="icon-sm"
              className="md:hidden"
              onClick={() => setMobileMenuOpen(true)}
              aria-label="Open navigation menu"
            >
              <Menu className="h-4 w-4" />
            </Button>

            <nav className="flex items-center gap-1.5 text-xs text-[var(--ink-2)]" aria-label="Breadcrumb">
              {breadcrumbs.map((crumb, idx) => (
                <React.Fragment key={idx}>
                  {idx > 0 && <span className="text-[var(--ink-3)]">/</span>}
                  {crumb.to ? (
                    <NavLink
                      to={crumb.to}
                      className="hover:text-[var(--primary)] text-[var(--ink-3)] transition-colors"
                    >
                      {crumb.label}
                    </NavLink>
                  ) : (
                    <span className="font-medium text-[var(--ink)]">
                      {crumb.label}
                    </span>
                  )}
                </React.Fragment>
              ))}
            </nav>
          </div>

          {/* Right: Search, Alerts, User chip */}
          <div className="flex items-center gap-2 sm:gap-3">
            {/* Global Search Button (Ctrl+K) */}
            <button
              type="button"
              onClick={() => setSearchOpen(true)}
              className="hidden sm:flex items-center gap-2 rounded-[6px] border border-[var(--line)] bg-[var(--surface-2)] px-2.5 py-1 text-xs text-[var(--ink-3)] hover:border-[#CCD2DB] hover:text-[var(--ink-2)] transition-colors cursor-pointer"
            >
              <Search className="h-3.5 w-3.5" />
              <span>Search FDRs or institutions...</span>
              <kbd className="rounded border border-[var(--line)] bg-white px-1.5 py-0.2 text-[10px] font-mono text-[var(--ink-3)]">
                Ctrl K
              </kbd>
            </button>

            {/* Mobile Search Icon */}
            <Button
              variant="ghost"
              size="icon-sm"
              className="sm:hidden"
              onClick={() => setSearchOpen(true)}
              aria-label="Search"
            >
              <Search className="h-4 w-4 text-[var(--ink-2)]" />
            </Button>

            {/* Alerts Bell with count */}
            <NavLink
              to="/alerts"
              className="relative inline-flex h-8 w-8 items-center justify-center rounded-[6px] border border-[var(--line)] text-[var(--ink-2)] hover:bg-[var(--surface-2)] transition-colors"
              title="Alerts"
            >
              <Bell className="h-4 w-4" />
              {openAlertsCount > 0 && (
                <span className="absolute -right-1 -top-1 flex h-4 min-w-[16px] items-center justify-center rounded-full bg-[var(--risk)] px-1 font-mono text-[10px] font-bold text-white">
                  {openAlertsCount}
                </span>
              )}
            </NavLink>

            {/* User Chip with Role Badge */}
            <div className="flex items-center gap-2 pl-2 border-l border-[var(--line)]">
              <div className="flex flex-col text-right">
                <span className="hidden sm:inline-block text-xs font-medium text-[var(--ink)] leading-tight">
                  {user?.name}
                </span>
                {user?.institution_name && (
                  <span className="hidden sm:inline-block text-[10px] text-[var(--ink-2)] truncate max-w-[160px] leading-tight">
                    {user.institution_name}
                  </span>
                )}
              </div>
              <Badge
                variant={user?.role === 'admin' ? 'primarySoft' : 'secondary'}
                className="font-medium text-[10px]"
              >
                {user?.role ? (ROLE_LABELS[user.role] || user.role) : 'officer'}
              </Badge>
            </div>
          </div>
        </header>

        {/* Page Content Container */}
        <main className="flex-1 p-4 md:p-6 max-w-[1440px] w-full mx-auto min-w-0">
          <Outlet />
        </main>
      </div>

      {/* Ctrl+K Command Dialog */}
      <CommandDialog open={searchOpen} onOpenChange={setSearchOpen}>
        <CommandInput
          placeholder="Search by FDR number, institution name, or AICTE ID..."
          value={searchQuery}
          onValueChange={setSearchQuery}
        />
        <CommandList>
          <CommandEmpty>No matching records found.</CommandEmpty>

          {/* Quick navigation */}
          <CommandGroup heading="Navigation">
            <CommandItem
              onSelect={() => {
                navigate('/deposits');
                setSearchOpen(false);
              }}
            >
              <FileText className="mr-2 h-4 w-4" />
              <span>Deposits Register</span>
            </CommandItem>
            <CommandItem
              onSelect={() => {
                navigate('/approvals');
                setSearchOpen(false);
              }}
            >
              <CheckSquare className="mr-2 h-4 w-4" />
              <span>Approvals Queue</span>
            </CommandItem>
            <CommandItem
              onSelect={() => {
                navigate('/radar');
                setSearchOpen(false);
              }}
            >
              <Radar className="mr-2 h-4 w-4" />
              <span>Maturity Radar</span>
            </CommandItem>
            <CommandItem
              onSelect={() => {
                navigate('/institutions');
                setSearchOpen(false);
              }}
            >
              <Building2 className="mr-2 h-4 w-4" />
              <span>Institutions Directory</span>
            </CommandItem>
          </CommandGroup>

          {/* FDR results */}
          {searchFdrs && searchFdrs.items.length > 0 && (
            <CommandGroup heading="Deposits">
              {searchFdrs.items.map((fdr) => (
                <CommandItem
                  key={fdr.id}
                  value={`${fdr.fdr_number} ${fdr.institution_name} ${fdr.bank_name}`}
                  onSelect={() => {
                    navigate(`/deposits/${fdr.id}`);
                    setSearchOpen(false);
                  }}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <span className="font-mono font-medium">{fdr.fdr_number}</span>
                    <span className="text-[var(--ink-3)] text-xs truncate max-w-[200px]">
                      {fdr.institution_name}
                    </span>
                  </div>
                  <span className="font-mono text-[11px] text-[var(--ink-2)]">
                    ₹{Number(fdr.amount).toLocaleString('en-IN')}
                  </span>
                </CommandItem>
              ))}
            </CommandGroup>
          )}

          {/* Institution results */}
          {searchInstitutions && searchInstitutions.length > 0 && (
            <CommandGroup heading="Institutions">
              {searchInstitutions.slice(0, 5).map((inst) => (
                <CommandItem
                  key={inst.id}
                  value={`${inst.name} ${inst.aicte_id} ${inst.city} ${inst.state}`}
                  onSelect={() => {
                    navigate(`/institutions/${inst.id}`);
                    setSearchOpen(false);
                  }}
                  className="flex items-center justify-between"
                >
                  <div className="flex items-center gap-2">
                    <Building2 className="h-3.5 w-3.5 text-[var(--ink-3)]" />
                    <span>{inst.name}</span>
                  </div>
                  <span className="font-mono text-[10px] text-[var(--ink-3)]">
                    {inst.aicte_id}
                  </span>
                </CommandItem>
              ))}
            </CommandGroup>
          )}
        </CommandList>
      </CommandDialog>
    </div>
  );
};
