import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"
import { cn } from "@/lib/utils"

const badgeVariants = cva(
  "inline-flex items-center rounded-[4px] px-1.5 py-0.5 text-[11px] font-medium transition-colors select-none",
  {
    variants: {
      variant: {
        default:
          "bg-[var(--primary)] text-white",
        secondary:
          "bg-[var(--surface-2)] text-[var(--ink-2)] border border-[var(--line)]",
        outline:
          "border border-[var(--line)] text-[var(--ink-2)] bg-white",
        primarySoft:
          "bg-[var(--primary-soft)] text-[var(--primary)] border border-transparent",
        ok:
          "bg-[var(--ok-bg)] text-[var(--ok)] border border-transparent",
        warn:
          "bg-[var(--warn-bg)] text-[var(--warn)] border border-transparent",
        risk:
          "bg-[var(--risk-bg)] text-[var(--risk)] border border-transparent",
        info:
          "bg-[var(--info-bg)] text-[var(--info)] border border-transparent",
        violet:
          "bg-[var(--violet-bg)] text-[var(--violet)] border border-transparent",
      },
    },
    defaultVariants: {
      variant: "default",
    },
  }
)

export interface BadgeProps
  extends React.HTMLAttributes<HTMLDivElement>,
    VariantProps<typeof badgeVariants> {}

function Badge({ className, variant, ...props }: BadgeProps) {
  return (
    <div className={cn(badgeVariants({ variant }), className)} {...props} />
  )
}

export { Badge, badgeVariants }
