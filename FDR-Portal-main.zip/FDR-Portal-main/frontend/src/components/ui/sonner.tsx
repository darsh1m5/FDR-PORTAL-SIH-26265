import { Toaster as Sonner } from "sonner"

type ToasterProps = React.ComponentProps<typeof Sonner>

const Toaster = ({ ...props }: ToasterProps) => {
  return (
    <Sonner
      position="bottom-right"
      className="toaster group"
      toastOptions={{
        classNames: {
          toast:
            "group toast group-[.toaster]:bg-white group-[.toaster]:text-[var(--ink)] group-[.toaster]:border-[var(--line)] group-[.toaster]:shadow-md group-[.toaster]:rounded-[6px] group-[.toaster]:text-xs font-sans",
          description: "group-[.toast]:text-[var(--ink-2)] group-[.toast]:text-[11px]",
          actionButton:
            "group-[.toast]:bg-[var(--primary)] group-[.toast]:text-white font-medium text-xs",
          cancelButton:
            "group-[.toast]:bg-[var(--surface-2)] group-[.toast]:text-[var(--ink-2)] text-xs",
          error: "group-[.toaster]:border-[var(--risk)] group-[.toaster]:text-[var(--risk)]",
          success: "group-[.toaster]:border-[var(--ok)] group-[.toaster]:text-[var(--ok)]",
        },
      }}
      {...props}
    />
  )
}

export { Toaster }
