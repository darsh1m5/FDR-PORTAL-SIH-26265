import { cn } from "@/lib/utils"

function Skeleton({
  className,
  ...props
}: React.HTMLAttributes<HTMLDivElement>) {
  return (
    <div
      className={cn("animate-pulse rounded-[4px] bg-[var(--surface-2)] border border-[var(--line)]", className)}
      {...props}
    />
  )
}

export { Skeleton }
