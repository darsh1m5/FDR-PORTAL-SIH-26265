import { lazy, Suspense } from 'react';
import { createBrowserRouter, Navigate } from 'react-router-dom';
import { AppShell } from '@/components/layout/AppShell';
import { RequireRole, useAuth } from '@/lib/auth';
import LoginPage from '@/pages/Login';
import DashboardPage from '@/pages/Dashboard';
import DepositsPage from '@/pages/Deposits';
import DepositDetailPage from '@/pages/DepositDetail';
import DepositFormPage from '@/pages/DepositForm';
import InstitutionHomePage from '@/pages/InstitutionHome';
import VerifyPage from '@/pages/Verify';

// Lazy load Cursor's pages
const ApprovalsPage = lazy(() => import('@/pages/Approvals'));
const AlertsPage = lazy(() => import('@/pages/Alerts'));
const RadarPage = lazy(() => import('@/pages/Radar'));
const HealthCheckPage = lazy(() => import('@/pages/HealthCheck'));
const InstitutionsPage = lazy(() => import('@/pages/Institutions'));
const InstitutionDetailPage = lazy(() => import('@/pages/Institutions/detail'));
const AuditPage = lazy(() => import('@/pages/Audit'));
const ReportsPage = lazy(() => import('@/pages/Reports'));
const SettingsPage = lazy(() => import('@/pages/Settings'));
const ImportsPage = lazy(() => import('@/pages/Imports'));
const NoticesPage = lazy(() => import('@/pages/Notices'));

const PageFallback = () => (
  <div className="flex h-48 w-full items-center justify-center">
    <div className="inline-block h-5 w-5 animate-spin rounded-full border-2 border-[var(--primary)] border-t-transparent" />
  </div>
);

const RootDashboard = () => {
  const { user } = useAuth();
  if (user?.role === 'institution') {
    return <InstitutionHomePage />;
  }
  return <DashboardPage />;
};

export const router = createBrowserRouter([
  {
    path: '/login',
    element: <LoginPage />,
  },
  {
    path: '/verify',
    element: <VerifyPage />,
  },
  {
    path: '/',
    element: (
      <RequireRole>
        <AppShell />
      </RequireRole>
    ),
    children: [
      {
        index: true,
        element: <RootDashboard />,
      },
      {
        path: 'deposits',
        element: <DepositsPage />,
      },
      {
        path: 'deposits/new',
        element: (
          <RequireRole role={['admin', 'institution']}>
            <DepositFormPage mode="create" />
          </RequireRole>
        ),
      },
      {
        path: 'deposits/:id',
        element: <DepositDetailPage />,
      },
      {
        path: 'deposits/:id/edit',
        element: (
          <RequireRole role={['admin', 'institution']}>
            <DepositFormPage mode="edit" />
          </RequireRole>
        ),
      },
      {
        path: 'deposits/:id/renew',
        element: (
          <RequireRole role="admin">
            <DepositFormPage mode="renew" />
          </RequireRole>
        ),
      },
      {
        path: 'imports',
        element: (
          <RequireRole role="admin">
            <Suspense fallback={<PageFallback />}>
              <ImportsPage />
            </Suspense>
          </RequireRole>
        ),
      },
      {
        path: 'approvals',
        element: (
          <RequireRole role={['admin', 'reviewer', 'approver', 'auditor']}>
            <Suspense fallback={<PageFallback />}>
              <ApprovalsPage />
            </Suspense>
          </RequireRole>
        ),
      },
      {
        path: 'alerts',
        element: (
          <Suspense fallback={<PageFallback />}>
            <AlertsPage />
          </Suspense>
        ),
      },
      {
        path: 'radar',
        element: (
          <RequireRole role={['admin', 'reviewer', 'approver', 'auditor', 'institution']}>
            <Suspense fallback={<PageFallback />}>
              <RadarPage />
            </Suspense>
          </RequireRole>
        ),
      },
      {
        path: 'health',
        element: (
          <RequireRole role={['admin', 'reviewer', 'approver', 'auditor']}>
            <Suspense fallback={<PageFallback />}>
              <HealthCheckPage />
            </Suspense>
          </RequireRole>
        ),
      },
      {
        path: 'institutions',
        element: (
          <RequireRole role={['admin', 'reviewer', 'approver', 'auditor', 'institution']}>
            <Suspense fallback={<PageFallback />}>
              <InstitutionsPage />
            </Suspense>
          </RequireRole>
        ),
      },
      {
        path: 'institutions/:id',
        element: (
          <RequireRole role={['admin', 'reviewer', 'approver', 'auditor', 'institution']}>
            <Suspense fallback={<PageFallback />}>
              <InstitutionDetailPage />
            </Suspense>
          </RequireRole>
        ),
      },
      {
        path: 'audit',
        element: (
          <RequireRole role={['admin', 'reviewer', 'approver', 'auditor']}>
            <Suspense fallback={<PageFallback />}>
              <AuditPage />
            </Suspense>
          </RequireRole>
        ),
      },
      {
        path: 'reports',
        element: (
          <Suspense fallback={<PageFallback />}>
            <ReportsPage />
          </Suspense>
        ),
      },
      {
        path: 'notices',
        element: (
          <Suspense fallback={<PageFallback />}>
            <NoticesPage />
          </Suspense>
        ),
      },
      {
        path: 'settings',
        element: (
          <RequireRole role={['admin', 'reviewer', 'approver', 'auditor']}>
            <Suspense fallback={<PageFallback />}>
              <SettingsPage />
            </Suspense>
          </RequireRole>
        ),
      },
      {
        path: '*',
        element: <Navigate to="/" replace />,
      },
    ],
  },
]);
