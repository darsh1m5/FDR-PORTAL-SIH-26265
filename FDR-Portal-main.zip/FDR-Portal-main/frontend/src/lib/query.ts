/**
 * TanStack Query Configuration and Key Factories for Amanat
 * Configured with caching and key factories for portal data management
 */

import { QueryClient } from '@tanstack/react-query';
import { ApiError } from '@/lib/api';

export const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      staleTime: 60 * 1000, // 1 minute fresh
      gcTime: 5 * 60 * 1000, // 5 minutes in cache
      refetchOnWindowFocus: false,
      retry: (count, err) => !(err instanceof ApiError && err.status >= 400 && err.status < 500) && count < 2,
    },
  },
});

export const queryKeys = {
  auth: {
    me: ['auth', 'me'] as const,
  },
  meta: ['meta'] as const,
  dashboard: ['dashboard'] as const,
  fdrs: {
    all: ['fdrs'] as const,
    list: (params?: Record<string, any>) => ['fdrs', 'list', params] as const,
    detail: (id: number | string) => ['fdrs', 'detail', Number(id)] as const,
  },
  institutions: {
    all: ['institutions'] as const,
    list: (q?: string) => ['institutions', 'list', { q }] as const,
    detail: (id: number | string) => ['institutions', 'detail', Number(id)] as const,
  },
  approvals: ['approvals'] as const,
  alerts: {
    all: ['alerts'] as const,
    list: (params?: Record<string, any>) => ['alerts', 'list', params] as const,
  },
  audit: {
    all: ['audit'] as const,
    list: (params?: Record<string, any>) => ['audit', 'list', params] as const,
    verify: ['audit', 'verify'] as const,
  },
  settings: ['settings'] as const,
  radar: (months?: number) => ['radar', { months: months ?? 12 }] as const,
  findings: (severity?: string) => ['findings', { severity }] as const,
};
