/**
 * Shared Type Definitions for Amanat
 * Type interfaces for data models, API payloads, and state representations
 * All agents and pages import from here - do not redefine!
 */

export type Role = 'admin' | 'reviewer' | 'approver' | 'auditor' | 'institution';

export interface User {
  id: number;
  name: string;
  email: string;
  role: Role;
  institution_id?: number | null;
  institution_name?: string | null;
  is_active?: boolean;
  created_at?: string;
}

export type UserOut = User;

export interface AuthResponse {
  access_token: string;
  token_type: 'bearer';
  user: User;
}

export interface LoginInput {
  email: string;
  password: string;
}

export type InstitutionType =
  | 'Engineering'
  | 'Management'
  | 'Pharmacy'
  | 'Architecture'
  | 'Polytechnic';

export interface InstitutionItem {
  id: number;
  name: string;
  aicte_id: string;
  city: string;
  state: string;
  type: InstitutionType;
  required_deposit: number;
  fdr_count: number;
  active_amount: number;
  health_score: number | null;
  shortfall: number;
}

export interface InstitutionDetail extends InstitutionItem {
  fdrs: FdrListItem[];
  users_count?: number;
}

export interface InstitutionInput {
  name: string;
  aicte_id: string;
  city: string;
  state: string;
  type: InstitutionType;
  required_deposit: number;
}

export type Purpose =
  | 'security_deposit'
  | 'additional_intake'
  | 'performance_security'
  | 'other';

export type FdrStatus =
  | 'draft'
  | 'pending_approval'
  | 'approved'
  | 'rejected'
  | 'release_requested'
  | 'released'
  | 'renewed';

export type VerificationStatus = 'submitted' | 'officer_verified' | 'bank_confirmed';

export type MaturityState =
  | 'matured'
  | 'due_7'
  | 'due_30'
  | 'due_60'
  | 'due_90'
  | 'active'
  | 'closed';

export type FindingSeverity = 'critical' | 'warning' | 'info';

export interface Finding {
  code: string;
  severity: FindingSeverity;
  message: string;
  fix: string;
}

export type DocumentType =
  | 'fdr_receipt'
  | 'lien_letter'
  | 'affidavit'
  | 'closure_certificate'
  | 'renewal_letter'
  | 'bank_confirmation'
  | 'other';

export interface DocumentItem {
  id: number;
  filename: string;
  content_type: string;
  size_bytes: number;
  uploaded_by: string | null;
  uploaded_at: string;
  doc_type?: DocumentType;
  doc_type_label?: string;
  sha256?: string;
}

export interface ObservationItem {
  id: number;
  text: string;
  author_name: string;
  author_role: Role | null;
  created_at: string;
  response: string | null;
  responded_by: string | null;
  responded_at: string | null;
  status: 'open' | 'answered' | 'closed';
}

export interface ObservationCreateInput {
  text: string;
}

export interface ObservationRespondInput {
  response: string;
}

export interface AuditItem {
  id: number;
  at: string;
  actor_name: string;
  actor_role: Role | null;
  action: string;
  action_label: string;
  entity: string;
  entity_id: number | null;
  fdr_id: number | null;
  fdr_number: string | null;
  from_status: string | null;
  to_status: string | null;
  detail: Record<string, unknown>;
}

export interface FdrListItem {
  id: number;
  fdr_number: string;
  institution_id: number;
  institution_name: string;
  bank_name: string;
  amount: number;
  issue_date: string;
  maturity_date: string;
  interest_rate: number;
  purpose: Purpose;
  status: FdrStatus;
  verification: VerificationStatus;
  days_to_maturity: number;
  maturity_state: MaturityState;
  health_score: number;
  findings_count: number;
  document_count: number;
}

export interface FdrInput {
  fdr_number: string;
  institution_id: number;
  bank_name: string;
  branch?: string;
  ifsc?: string;
  amount: number;
  issue_date: string;
  maturity_date: string;
  interest_rate: number;
  maturity_amount?: number;
  purpose: Purpose;
  lien_to_aicte: boolean;
  remarks?: string;
}

export type AllowedAction =
  | 'edit'
  | 'submit'
  | 'approve'
  | 'reject'
  | 'request_release'
  | 'renew'
  | 'verify'
  | 'upload'
  | 'sanction_release'
  | 'return_release'
  | 'observe'
  | 'respond'
  | 'bank_confirm';

export interface FdrDetail extends FdrListItem {
  branch: string | null;
  ifsc: string | null;
  maturity_amount: number | null;
  lien_to_aicte: boolean;
  remarks: string | null;
  projected_value: number;
  findings: Finding[];
  documents: DocumentItem[];
  history: AuditItem[];
  renewed_from: { id: number; fdr_number: string } | null;
  renewed_to: { id: number; fdr_number: string } | null;
  created_by: string;
  created_at: string;
  updated_at: string;
  allowed_actions: AllowedAction[];
  release_checklist?: ReleaseChecklist | null;
  release_ready?: boolean | null;
  lineage?: LineageItem[];
  notices_count?: number;
  observations_open?: number;
}

export interface PaginatedResponse<T> {
  items: T[];
  total: number;
  page: number;
  page_size: number;
  total_amount?: number;
}

export interface MetaResponse {
  banks: string[];
  purposes: { value: Purpose; label: string }[];
  statuses: { value: FdrStatus; label: string }[];
  institution_types: string[];
  roles: { value: Role; label: string }[];
  document_types?: { value: DocumentType; label: string }[];
}

export interface DashboardKpis {
  total_count: number;
  total_amount: number;
  active_count: number;
  active_amount: number;
  pending_approvals: number;
  release_requests: number;
  maturing_30: number;
  maturing_90: number;
  overdue: number;
  open_alerts: number;
  avg_health: number | null;
  escalated_alerts?: number;
  observations_open?: number;
}

export interface DashboardStatusBreakdown {
  status: FdrStatus;
  label: string;
  count: number;
  amount: number;
}

export interface DashboardBankConcentration {
  bank: string;
  count: number;
  amount: number;
}

export interface DashboardTimelineItem {
  month: string;
  count: number;
  amount: number;
}

export interface DashboardResponse {
  kpis: DashboardKpis;
  by_status: DashboardStatusBreakdown[];
  by_bank: DashboardBankConcentration[];
  timeline: DashboardTimelineItem[];
  upcoming: FdrListItem[];
  activity: AuditItem[];
}

export interface ApprovalsItem {
  fdr: FdrListItem;
  kind: 'approval' | 'release';
  requested_at: string;
  requested_by: string;
  waiting_days: number;
  reason: string | null;
  release_checklist?: ReleaseChecklist | null;
  release_ready?: boolean | null;
}

export interface ApprovalsResponse {
  items: ApprovalsItem[];
}

export type AlertSeverity = 'info' | 'warning' | 'critical';
export type AlertType =
  | 'maturity_upcoming'
  | 'matured_overdue'
  | 'pending_too_long'
  | 'discrepancy';

export interface AlertItem {
  id: number;
  fdr_id: number;
  fdr_number: string;
  institution_name: string;
  type: AlertType;
  severity: AlertSeverity;
  message: string;
  due_date: string | null;
  days: number | null;
  created_at: string;
  acknowledged_at: string | null;
  acknowledged_by: string | null;
  escalated?: boolean;
  escalated_at?: string | null;
  age_days?: number;
}

export interface AlertRunResponse {
  created: number;
  resolved: number;
  open: number;
}

export interface Settings {
  reminder_days: number[];
  overdue_grace_days: number;
  pending_sla_days: number;
  interest_min: number;
  interest_max: number;
  escalate_after_days?: number;
}

export interface AuditVerifyResponse {
  intact: boolean;
  checked: number;
  broken_at: number | null;
}

export interface RadarItem {
  id: number;
  fdr_number: string;
  institution_name: string;
  amount: number;
  projected_value: number;
  maturity_date: string;
  days_to_maturity: number;
  status: FdrStatus;
}

export interface RadarMonth {
  month: string;
  count: number;
  principal: number;
  projected: number;
  items: RadarItem[];
}

export interface RadarResponse {
  months: RadarMonth[];
}

export interface FindingGroup {
  fdr_id: number;
  fdr_number: string;
  institution_name: string;
  status: FdrStatus;
  health_score: number;
  findings: Finding[];
}

export interface ReleaseChecklist {
  affidavit_received: boolean;
  no_pending_complaints: boolean;
  institution_closure_certificate: boolean | null;
  matured_or_lock_in_complete: boolean;
  bank_discharge_noted: boolean;
}

export interface RequestReleaseInput {
  reason: string;
  checklist?: ReleaseChecklist;
}

export interface LineageItem {
  id: number;
  fdr_number: string;
  status: FdrStatus;
  issue_date: string;
  maturity_date: string;
  amount: number;
}

export interface ImportRow {
  row: number;
  status: 'valid' | 'warning' | 'error';
  data: FdrInput | null;
  institution_name: string | null;
  errors: string[];
  findings: Finding[];
}

export interface ImportPreview {
  rows: ImportRow[];
  valid_count: number;
  error_count: number;
  warning_count: number;
}

export interface ImportCommitInput {
  rows: FdrInput[];
  source_name: string;
}

export interface ImportCommitResponse {
  created: number;
  batch: string;
  ids: number[];
}

export type NoticeKind =
  | 'maturity_reminder'
  | 'overdue_notice'
  | 'shortfall_notice'
  | 'release_letter';

export interface NoticeLetter {
  subject: string;
  salutation: string;
  body: string[];
  closing: string;
}

export interface NoticeItem {
  id: number;
  reference_no: string;
  kind: NoticeKind;
  kind_label: string;
  issued_at: string;
  issued_by: string;
  fdr_id: number | null;
  fdr_number: string | null;
  institution_id: number | null;
  institution_name: string;
  letter: NoticeLetter;
  verify_code?: string;
}

export interface NoticeVerifyResponse {
  valid: boolean;
  reference_no?: string;
  kind_label?: string;
  issued_at?: string;
  institution_name?: string;
  fdr_number?: string | null;
}

export interface NoticeCandidates {
  maturity: FdrListItem[];
  overdue: FdrListItem[];
  shortfall: InstitutionItem[];
}

export interface NoticeCreateInput {
  kind: NoticeKind;
  fdr_id?: number;
  institution_id?: number;
}

export interface MonthlyMetric {
  month: string;
  decided: number;
  avg_turnaround_days: number | null;
}

export interface BureauMetrics {
  approval_turnaround_days: number | null;
  release_turnaround_days: number | null;
  pending_over_sla: number;
  verification_rate: number;
  document_coverage: number;
  renewal_on_time_rate: number | null;
  data_quality_rate: number;
  alert_ack_median_hours: number | null;
  bank_confirmed_share?: number | null;
  monthly: MonthlyMetric[];
}
