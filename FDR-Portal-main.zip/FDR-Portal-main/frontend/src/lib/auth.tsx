/**
 * Authentication Context and Role Guards for Amanat
 * Manages JWT session, login, logout, and role-based permissions.
 */

import React, { createContext, useContext, useEffect, useState, useCallback } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import type { User, Role, LoginInput, AuthResponse } from './types';
import { api, getToken, setToken, removeToken } from './api';
import { queryClient } from './query';

interface AuthContextType {
  user: User | null;
  role: Role | null;
  token: string | null;
  isAuthenticated: boolean;
  isLoading: boolean;
  login: (input: LoginInput) => Promise<void>;
  logout: () => void;
  refreshUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

// Set by an explicit sign-out so the next person starts on a clean login,
// instead of being sent back to the previous user's last page.
let signedOutOnPurpose = false;

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [token, setTokenState] = useState<string | null>(getToken());
  const [isLoading, setIsLoading] = useState<boolean>(true);

  const logout = useCallback(() => {
    signedOutOnPurpose = true;
    removeToken();
    setTokenState(null);
    setUser(null);
    queryClient.clear();
  }, []);

  const refreshUser = useCallback(async () => {
    const currentToken = getToken();
    if (!currentToken) {
      setUser(null);
      setIsLoading(false);
      return;
    }

    try {
      const currentUser = await api.get<User>('/auth/me');
      setUser(currentUser);
    } catch {
      logout();
    } finally {
      setIsLoading(false);
    }
  }, [logout]);

  useEffect(() => {
    refreshUser();
  }, [refreshUser]);

  const login = async (input: LoginInput) => {
    setIsLoading(true);
    try {
      const data = await api.post<AuthResponse>('/auth/login', input);
      queryClient.clear();
      setToken(data.access_token);
      setTokenState(data.access_token);
      setUser(data.user);
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <AuthContext.Provider
      value={{
        user,
        role: user?.role ?? null,
        token,
        isAuthenticated: !!user && !!token,
        isLoading,
        login,
        logout,
        refreshUser,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
};

export function useAuth(): AuthContextType {
  const context = useContext(AuthContext);
  if (!context) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}

interface RequireRoleProps {
  role?: Role | Role[];
  children: React.ReactNode;
}

/**
 * Route guard component: redirects unauthenticated users to /login,
 * and displays an access denied message if role requirement is not met.
 */
export const RequireRole: React.FC<RequireRoleProps> = ({ role, children }) => {
  const { user, isAuthenticated, isLoading } = useAuth();
  const location = useLocation();
  const navigate = useNavigate();

  useEffect(() => {
    if (!isLoading && !isAuthenticated) {
      if (signedOutOnPurpose) {
        signedOutOnPurpose = false;
        navigate('/login', { replace: true });
      } else {
        navigate('/login', { state: { from: location }, replace: true });
      }
    }
  }, [isLoading, isAuthenticated, navigate, location]);

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-bg">
        <div className="text-center">
          <div className="inline-block h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
          <p className="mt-3 text-xs text-ink-3">Authenticating...</p>
        </div>
      </div>
    );
  }

  if (!isAuthenticated) {
    return null;
  }

  if (role) {
    const allowed = Array.isArray(role) ? role.includes(user!.role) : user!.role === role;
    if (!allowed) {
      return (
        <div className="flex flex-col items-center justify-center p-12 text-center">
          <div className="rounded-md border border-line bg-surface p-8 max-w-md shadow-xs">
            <h2 className="text-base font-semibold text-ink">Access Restricted</h2>
            <p className="mt-2 text-sm text-ink-2">
              Your role ({user?.role}) does not have permission to access this section.
            </p>
          </div>
        </div>
      );
    }
  }

  return <>{children}</>;
};
