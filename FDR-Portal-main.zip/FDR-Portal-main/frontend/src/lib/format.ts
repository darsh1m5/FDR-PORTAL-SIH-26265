/**
 * Formatting helpers for Indian currency, dates, relative days, and labels.
 * Standard formatting utilities for financial values, dates, and labels.
 */

import { format, parseISO, isValid } from 'date-fns';
import type { FdrStatus, Purpose, VerificationStatus, MaturityState, FindingSeverity, Role } from './types';

/**
 * Format a number as Indian Rupees: e.g. ₹12,50,000
 * No decimals unless value is less than 1,000
 */
export function inr(val: number | null | undefined): string {
  if (val === null || val === undefined || isNaN(val)) return '₹0';
  const hasDecimals = Math.abs(val) < 1000 && val % 1 !== 0;
  return new Intl.NumberFormat('en-IN', {
    style: 'currency',
    currency: 'INR',
    maximumFractionDigits: hasDecimals ? 2 : 0,
    minimumFractionDigits: hasDecimals ? 2 : 0,
  }).format(val);
}

/**
 * Format large rupee amounts compactly: e.g. ₹4.82 Cr, ₹12.50 L, ₹45,000
 */
export function inrShort(val: number | null | undefined): string {
  if (val === null || val === undefined || isNaN(val)) return '₹0';
  const abs = Math.abs(val);
  const sign = val < 0 ? '-' : '';

  if (abs >= 10000000) {
    // 1 Crore = 10,000,000
    const cr = abs / 10000000;
    return `${sign}₹${cr.toFixed(2)} Cr`;
  }
  if (abs >= 100000) {
    // 1 Lakh = 100,000
    const lakh = abs / 100000;
    return `${sign}₹${lakh.toFixed(2)} L`;
  }
  if (abs >= 1000) {
    const k = abs / 1000;
    return `${sign}₹${k.toFixed(1)} K`;
  }
  return inr(val);
}

/**
 * Format ISO date string or Date object as "12 Mar 2027"
 */
export function formatDate(val: string | Date | null | undefined): string {
  if (!val) return '—';
  try {
    const d = typeof val === 'string' ? parseISO(val) : val;
    if (!isValid(d)) return typeof val === 'string' ? val : '—';
    return format(d, 'dd MMM yyyy');
  } catch {
    return typeof val === 'string' ? val : '—';
  }
}

/**
 * Short date format with time for audits: "12 Mar 2027, 14:30"
 */
export function formatDateTime(val: string | Date | null | undefined): string {
  if (!val) return '—';
  try {
    const d = typeof val === 'string' ? parseISO(val) : val;
    if (!isValid(d)) return typeof val === 'string' ? val : '—';
    return format(d, 'dd MMM yyyy, HH:mm');
  } catch {
    return typeof val === 'string' ? val : '—';
  }
}

/**
 * Format days to maturity as relative chip text:
 * "in 23 days", "5 days overdue", "today"
 */
export function relDays(days: number | null | undefined): string {
  if (days === null || days === undefined) return '';
  if (days === 0) return 'today';
  if (days > 0) return `in ${days} ${days === 1 ? 'day' : 'days'}`;
  const overdue = Math.abs(days);
  return `${overdue} ${overdue === 1 ? 'day' : 'days'} overdue`;
}

/**
 * Canonical display labels for FDR lifecycle statuses
 */
export const STATUS_LABELS: Record<FdrStatus, string> = {
  draft: 'Draft',
  pending_approval: 'Pending approval',
  approved: 'Approved',
  rejected: 'Rejected',
  release_requested: 'Release requested',
  released: 'Released',
  renewed: 'Renewed',
};

/**
 * Purpose label map
 */
export const PURPOSE_LABELS: Record<Purpose, string> = {
  security_deposit: 'Security deposit',
  additional_intake: 'Additional intake',
  performance_security: 'Performance security',
  other: 'Other',
};

/**
 * Role display labels
 */
export const ROLE_LABELS: Record<Role, string> = {
  admin: 'Administrator',
  reviewer: 'Reviewer',
  approver: 'Competent Authority',
  auditor: 'Auditor',
  institution: 'Institution',
};

/**
 * Verification label map
 */
export const VERIFICATION_LABELS: Record<VerificationStatus, string> = {
  submitted: 'Submitted',
  officer_verified: 'Officer-verified',
  bank_confirmed: 'Bank-confirmed (letter)',
};

/**
 * Maturity state labels
 */
export const MATURITY_STATE_LABELS: Record<MaturityState, string> = {
  matured: 'Matured overdue',
  due_7: 'Due in 7 days',
  due_30: 'Due in 30 days',
  due_60: 'Due in 60 days',
  due_90: 'Due in 90 days',
  active: 'Active',
  closed: 'Closed',
};

/**
 * Finding severity labels
 */
export const SEVERITY_LABELS: Record<FindingSeverity, string> = {
  critical: 'Critical',
  warning: 'Warning',
  info: 'Advisory',
};

/**
 * Format interest rate with always 2 decimal places: e.g. 7.00%
 */
export function formatRate(val: number | null | undefined): string {
  if (val === null || val === undefined || isNaN(Number(val))) return '—';
  return `${Number(val).toFixed(2)}%`;
}

