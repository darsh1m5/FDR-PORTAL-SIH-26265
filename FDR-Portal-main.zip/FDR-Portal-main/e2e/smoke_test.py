"""E2E Smoke Test and Screenshot Automation for Amanat.

Flow per SIH26265 client specification (ZC-4):
1. Admin login (Section Officer)
2. View and capture Dashboard (KPIs, charts, activity)
3. Register new FDR with live quarterly compound preview -> Save as Draft
4. Verify Draft status -> Submit for Approval
5. Sign out -> Reviewer login (Scrutiny Officer)
6. Open Approvals Queue -> Open FDR -> Approve with audit remark
7. Verify Approved status -> Inspect Audit Timeline
8. Verify global audit hash chain integrity ("Intact")
9. View Alerts centre & active monitoring
10. Export CSV from Deposits register
11. Capture every feature screen for the User Manual (Radar, Health, Institutions, Reports, Settings, Login)
"""

import json
import os
import sys
import time
import argparse
import socket
import subprocess
import tempfile
import urllib.request
from contextlib import contextmanager
from pathlib import Path
from playwright.sync_api import sync_playwright, expect

if sys.stdout and hasattr(sys.stdout, 'reconfigure'):
    sys.stdout.reconfigure(encoding='utf-8', errors='replace')

SCREENSHOTS_DIR = Path(__file__).resolve().parent / "screenshots"


def is_port_open(port: int, host: str = "127.0.0.1") -> bool:
    try:
        with socket.create_connection((host, port), timeout=1):
            return True
    except (socket.error, ConnectionRefusedError):
        return False


@contextmanager
def managed_server(port: int = 8010):
    project_root = Path(__file__).resolve().parent.parent
    frontend_dir = project_root / "frontend"
    dist_dir = frontend_dir / "dist"
    backend_dir = project_root / "backend"

    # Build frontend bundle if missing
    if not (dist_dir / "index.html").is_file():
        print("Building frontend bundle for E2E server...")
        npm_cmd = "npm.cmd" if sys.platform == "win32" else "npm"
        subprocess.run([npm_cmd, "run", "build"], cwd=str(frontend_dir), check=True)
        print("Frontend build complete.")

    # Temporary database and upload directory
    temp_dir = tempfile.TemporaryDirectory()
    tmp_path = Path(temp_dir.name)
    tmp_db = tmp_path / "e2e.db"
    tmp_uploads = tmp_path / "uploads"
    tmp_uploads.mkdir(parents=True, exist_ok=True)

    db_url = f"sqlite:///{tmp_db.resolve().as_posix()}"

    # Locate Python executable
    venv_py = backend_dir / ".venv" / "Scripts" / "python.exe"
    if not venv_py.is_file():
        venv_py = backend_dir / ".venv" / "bin" / "python"
    py_exe = str(venv_py) if venv_py.is_file() else sys.executable

    env = os.environ.copy()
    env["DATABASE_URL"] = db_url
    env["UPLOAD_DIR"] = str(tmp_uploads.resolve())
    env["RUN_SCHEDULER"] = "0"
    env["AUTO_SEED"] = "1"
    env["PYTHONPATH"] = str(backend_dir)
    env["FRONTEND_DIST"] = str(dist_dir.resolve())

    print(f"\n[E2E Server] Starting isolated backend on port {port}...")
    print(f"  DATABASE_URL: {db_url}")
    print(f"  UPLOAD_DIR: {tmp_uploads}")

    server_log_path = tmp_path / "server.log"
    server_log_file = open(server_log_path, "w", encoding="utf-8")

    proc = subprocess.Popen(
        [py_exe, "-m", "uvicorn", "app.main:app", "--port", str(port), "--host", "127.0.0.1"],
        cwd=str(backend_dir),
        env=env,
        stdout=server_log_file,
        stderr=subprocess.STDOUT,
    )

    base_url = f"http://localhost:{port}"

    def read_server_log() -> str:
        try:
            server_log_file.flush()
            if server_log_path.is_file():
                return server_log_path.read_text(encoding="utf-8", errors="replace")
        except Exception:
            pass
        return "<unable to read server log>"

    # Wait for server to become responsive
    start_time = time.time()
    server_ready = False
    while time.time() - start_time < 35:
        if proc.poll() is not None:
            log_content = read_server_log()
            try:
                server_log_file.close()
            except Exception:
                pass
            raise RuntimeError(
                f"E2E backend terminated prematurely (exit code {proc.returncode}):\n{log_content}"
            )
        try:
            with urllib.request.urlopen(f"{base_url}/api/health", timeout=1) as resp:
                if resp.status == 200:
                    server_ready = True
                    break
        except Exception:
            time.sleep(0.3)

    if not server_ready:
        proc.kill()
        try:
            proc.wait(timeout=3)
        except Exception:
            pass
        log_content = read_server_log()
        try:
            server_log_file.close()
        except Exception:
            pass
        raise TimeoutError(f"E2E backend on port {port} did not respond within 35 seconds.\nServer log:\n{log_content}")

    print(f"[E2E Server] Isolated server is healthy and ready at {base_url}.")

    try:
        yield base_url
    except Exception as exc:
        print(f"\n[E2E Server] Test run encountered error: {exc}")
        print(f"[E2E Server] --- Server Log ({server_log_path}) ---")
        print(read_server_log())
        print(f"[E2E Server] --- End Server Log ---")
        raise
    finally:
        print(f"\n[E2E Server] Stopping isolated backend (PID {proc.pid})...")
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        try:
            server_log_file.close()
        except Exception:
            pass
        try:
            temp_dir.cleanup()
        except Exception:
            pass


def run_smoke_test(base_url: str, headless: bool = True):
    SCREENSHOTS_DIR.mkdir(parents=True, exist_ok=True)
    print(f"\n=======================================================")
    print(f" Starting Amanat E2E Smoke Test")
    print(f" Target Base URL: {base_url}")
    print(f" Headless: {headless}")
    print(f" Screenshots: {SCREENSHOTS_DIR}")
    print(f"=======================================================\n")

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=headless)
        # Handover resolution (1440x900)
        context = browser.new_context(
            viewport={"width": 1440, "height": 900},
            accept_downloads=True,
        )
        page = context.new_page()

        # Step 0: Login page screenshot
        print("[1/10] Testing Login Page & Demo Autofill...")
        page.goto(f"{base_url}/login")
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(SCREENSHOTS_DIR / "15_login_page.png"))

        # Test "Use admin" prefill
        page.click('button:has-text("Admin")')
        page.wait_for_timeout(200)
        email_val = page.input_value('input[type="email"]')
        assert email_val == "admin@fdrportal.demo", f"Expected admin email, got {email_val}"

        # Submit login form
        page.click('button:has-text("Sign in to portal")')
        page.wait_for_url(f"{base_url}/", timeout=10000)
        page.wait_for_load_state("networkidle")
        print("  ✓ Admin logged in successfully")

        # Step 1: Dashboard
        print("\n[2/10] Verifying Dashboard & Capturing Screenshot...")
        page.wait_for_selector("text=Institutional Deposit Dashboard")
        page.wait_for_selector("text=12-Month Maturity Pipeline")
        page.wait_for_timeout(500)
        page.screenshot(path=str(SCREENSHOTS_DIR / "01_dashboard.png"))
        print("  ✓ Dashboard rendered with 8 KPIs, timeline chart, and activity stream")

        # Step 2: Register New FDR
        print("\n[3/10] Registering New FDR (Draft flow)...")
        unique_suffix = int(time.time()) % 100000
        fdr_num = f"FDR-2026-DEMO{unique_suffix:05d}"

        page.click('button:has-text("New Deposit")')
        page.wait_for_url(f"{base_url}/deposits/new")
        page.wait_for_load_state("networkidle")
        page.wait_for_selector("text=Record New FDR Deposit")

        # Select Institution via Combobox
        page.click('button[role="combobox"]')
        page.wait_for_selector('[cmdk-item]')
        page.click('[cmdk-item]:first-child')

        # Fill Instrument & Bank
        page.fill("#fdr_number", fdr_num)

        # Select Bank (State Bank of India)
        page.click('button:has-text("Select bank name")')
        page.click('[role="option"]:has-text("State Bank of India")')

        page.fill("#branch", "Nariman Point Branch, Mumbai")
        page.fill("#ifsc", "SBIN0001234")

        # Financial parameters
        page.fill("#amount", "5000000")  # ₹50,00,000
        page.fill("#interest_rate", "7.25")

        # Capture form with live projected maturity value
        page.wait_for_timeout(400)
        page.screenshot(path=str(SCREENSHOTS_DIR / "02_fdr_form_draft.png"))

        # Save as Draft
        page.click('button:has-text("Save as Draft")')
        page.wait_for_selector("text=created as draft", timeout=10000)
        page.wait_for_load_state("networkidle")
        page.wait_for_timeout(500)

        # Verify FDR Detail in Draft Status
        expect(page.get_by_text("Draft", exact=True).first).to_be_visible()
        expect(page.get_by_text(fdr_num).first).to_be_visible()
        expect(page.get_by_text("Bank-confirmed").first).to_be_visible()
        page.screenshot(path=str(SCREENSHOTS_DIR / "03_fdr_detail_draft.png"))
        print(f"  ✓ FDR {fdr_num} successfully saved in Draft status")

        # Step 3: Submit for Approval
        print("\n[4/10] Submitting FDR for Reviewer Decision...")
        page.click('button:has-text("Submit for Approval")')
        page.wait_for_selector('text=It moves to Pending approval and appears in the reviewer\'s queue.')
        page.click('button:has-text("Submit FDR")')

        page.wait_for_timeout(500)
        expect(page.get_by_text("Pending approval", exact=True).first).to_be_visible()
        page.screenshot(path=str(SCREENSHOTS_DIR / "04_fdr_detail_pending.png"))
        print("  ✓ FDR advanced to Pending approval")

        # Step 4: Sign out as Admin
        print("\n[5/10] Signing Out Admin...")
        page.click('button[title="Sign out"]')
        page.wait_for_url(f"{base_url}/login")
        print("  ✓ Signed out")

        # Step 5: Reviewer Sign In & Approvals Queue
        print("\n[6/10] Reviewer Sign In & Approvals Processing...")
        page.click('button:has-text("Reviewer")')
        page.wait_for_timeout(200)
        page.click('button:has-text("Sign in to portal")')
        page.wait_for_selector('button[title="Sign out"]')
        page.wait_for_load_state("networkidle")

        # Navigate to Approvals Queue
        page.click('a[href="/approvals"]')
        page.wait_for_url(f"{base_url}/approvals")
        page.wait_for_selector('h1:has-text("Approvals")')
        page.wait_for_selector('table')
        page.wait_for_load_state("networkidle")
        page.screenshot(path=str(SCREENSHOTS_DIR / "05_approvals_queue.png"))
        print("  ✓ Approvals queue loaded with pending instruments and SLA indicators")

        # Click on the submitted FDR to open drawer, then open full record
        page.locator(f"text={fdr_num}").first.click()
        page.wait_for_selector('text=Open full record')
        page.click('text=Open full record')
        page.wait_for_url(f"{base_url}/deposits/*")
        page.wait_for_load_state("networkidle")
        page.wait_for_selector('button:has-text("Approve")', timeout=15000)
        fdr_detail_url = page.url

        # Path 1: Reviewer Rejection & Mandatory Remark Enforcement
        print("  Testing Reviewer Rejection & Remark Validation...")
        page.click('button:has-text("Reject")')
        page.wait_for_selector('text=Reject FDR Deposit')
        # Verify empty remark is blocked
        expect(page.locator('button:has-text("Reject Deposit")')).to_be_disabled()
        page.fill("#dialog-remark", "Statutory lien endorsement missing on physical instrument receipt.")
        expect(page.locator('button:has-text("Reject Deposit")')).to_be_enabled()
        page.click('button:has-text("Reject Deposit")')
        page.wait_for_timeout(500)
        expect(page.get_by_text("Rejected", exact=True).first).to_be_visible()
        print(f"  ✓ Reviewer rejected FDR {fdr_num} with mandatory audit remark (empty blocked)")

        # Path 2: Admin Resubmits Rejected FDR
        print("  Testing Admin Resubmission of Rejected FDR...")
        page.click('button[title="Sign out"]')
        page.wait_for_url(f"{base_url}/login")
        page.click('button:has-text("Admin")')
        page.click('button:has-text("Sign in to portal")')
        page.wait_for_selector('button[title="Sign out"]')
        page.goto(fdr_detail_url)
        page.wait_for_load_state("networkidle")
        expect(page.get_by_text("Rejected", exact=True).first).to_be_visible()

        page.click('button:has-text("Resubmit for Approval")')
        page.wait_for_selector('text=Resubmit FDR for Approval')
        page.click('button:has-text("Resubmit FDR")')
        page.wait_for_timeout(500)
        expect(page.get_by_text("Pending approval", exact=True).first).to_be_visible()
        print("  ✓ Admin resubmitted rejected FDR for approval")

        # Path 3: Reviewer Approves Resubmitted FDR
        page.click('button[title="Sign out"]')
        page.wait_for_url(f"{base_url}/login")
        page.click('button:has-text("Reviewer")')
        page.click('button:has-text("Sign in to portal")')
        page.wait_for_selector('button[title="Sign out"]')
        page.goto(fdr_detail_url)
        page.wait_for_load_state("networkidle")
        page.wait_for_selector('button:has-text("Approve")', timeout=15000)

        # Mark Verified first if allowed
        if page.locator('button:has-text("Mark Verified")').is_visible():
            page.click('button:has-text("Mark Verified")')
            page.wait_for_selector('text=Mark Officer Verified')
            page.click('button:has-text("Record Verification")')
            page.wait_for_timeout(500)

        # Approve the FDR
        page.click('button:has-text("Approve")')
        page.wait_for_selector('text=Approve FDR Deposit')
        page.fill("#dialog-remark", "Verified instrument receipt against bureau guidelines and statutory mandate.")
        page.click('button:has-text("Approve Deposit")')

        page.wait_for_timeout(600)
        expect(page.get_by_text("Approved", exact=True).first).to_be_visible()
        page.screenshot(path=str(SCREENSHOTS_DIR / "06_fdr_detail_approved.png"))
        print(f"  ✓ Reviewer approved FDR {fdr_num}")

        # Path 4: Admin Renews Approved FDR (Linked Both Ways)
        print("\nTesting FDR Renewal Flow...")
        page.click('button[title="Sign out"]')
        page.wait_for_url(f"{base_url}/login")
        page.click('button:has-text("Admin")')
        page.click('button:has-text("Sign in to portal")')
        page.wait_for_selector('button[title="Sign out"]')
        page.goto(fdr_detail_url)
        page.wait_for_load_state("networkidle")
        expect(page.get_by_text("Approved", exact=True).first).to_be_visible()

        page.click('button:has-text("Renew FDR")')
        page.wait_for_url(f"{fdr_detail_url}/renew")
        page.wait_for_load_state("networkidle")
        expect(page.locator('#fdr_number')).to_have_value(f"{fdr_num}-R")

        page.click('button:has-text("Confirm Renewal")')
        page.wait_for_selector("text=renewed", timeout=10000)
        page.wait_for_load_state("networkidle")
        replacement_fdr_url = page.url
        assert replacement_fdr_url != fdr_detail_url

        # Check replacement banner on new FDR
        expect(page.get_by_text("Replacement FDR", exact=False).first).to_be_visible()
        expect(page.get_by_text(fdr_num).first).to_be_visible()
        expect(page.get_by_text("Pending approval", exact=True).first).to_be_visible()

        # Click link back to original FDR
        page.locator(f'a:has-text("{fdr_num}")').first.click()
        page.wait_for_url(fdr_detail_url)
        page.wait_for_load_state("networkidle")

        # Verify old FDR is Renewed and has superseded banner
        expect(page.get_by_text("Renewed", exact=True).first).to_be_visible()
        expect(page.get_by_text("Superseded by Renewal", exact=False).first).to_be_visible()
        print(f"  ✓ Renewal confirmed: replacement FDR linked both ways with original instrument")

        # Step 6: Verify FDR History & Audit Timeline
        print("\n[7/10] Checking Audit Trail & State Transitions...")
        page.click('button:has-text("Audit Timeline")')
        page.wait_for_timeout(500)
        expect(page.get_by_text("Renewed").first).to_be_visible()
        expect(page.get_by_text("Approved").first).to_be_visible()
        expect(page.get_by_text("Submitted for approval").first).to_be_visible()
        expect(page.get_by_text("FDR registered").first).to_be_visible()
        page.screenshot(path=str(SCREENSHOTS_DIR / "07_fdr_history_timeline.png"))
        print("  ✓ Audit timeline displays sequential state transitions with timestamp and actor")

        # Step 7: Global Audit Log Integrity Verification
        print("\n[8/10] Verifying SHA-256 Audit Hash Chain Integrity...")
        page.click('a[href="/audit"]')
        page.wait_for_url(f"{base_url}/audit")
        page.wait_for_selector('button:has-text("Check the record"), button:has-text("Verify integrity")', timeout=10000)
        page.click('button:has-text("Check the record"), button:has-text("Verify integrity")')
        page.wait_for_selector("text=Intact.", timeout=10000)
        page.wait_for_timeout(400)
        page.screenshot(path=str(SCREENSHOTS_DIR / "08_audit_log_verified.png"))
        print("  ✓ Global audit hash chain recomputed: verified Intact")

        # Step 8: Alerts Centre
        print("\n[9/10] Inspecting Alerts Centre & Active Thresholds...")
        page.click('aside a[href="/alerts"]')
        page.wait_for_url(f"{base_url}/alerts")
        page.wait_for_selector('h1:has-text("Alerts")', timeout=10000)
        page.wait_for_selector("table tbody tr")
        page.wait_for_timeout(300)
        page.screenshot(path=str(SCREENSHOTS_DIR / "09_alerts_page.png"))
        print("  ✓ Alerts centre rendered with grouped severity buckets")

        # Step 9: Deposits Register & CSV Export
        print("\n[10/10] Exporting CSV & Capturing Feature Screens...")
        page.click('aside a[href="/deposits"]')
        page.wait_for_url(f"{base_url}/deposits")
        page.wait_for_selector("text=Deposits Register")
        page.wait_for_selector("table tbody tr")
        page.wait_for_timeout(300)
        page.screenshot(path=str(SCREENSHOTS_DIR / "10_deposits_register.png"))

        # Trigger CSV download
        with page.expect_download() as download_info:
            page.click('button:has-text("Export CSV")')
        download = download_info.value
        csv_path = SCREENSHOTS_DIR / "exported_deposits.csv"
        download.save_as(str(csv_path))
        assert csv_path.stat().st_size > 0, "Downloaded CSV file is empty"
        print(f"  ✓ CSV export verified ({csv_path.stat().st_size} bytes downloaded)")

        # Verify 404 state on non-existent deposit
        print("\nTesting 404 Handling on Missing Deposit (/deposits/99999)...")
        page.goto(f"{base_url}/deposits/99999")
        page.wait_for_selector("text=Deposit Record Not Found", timeout=10000)
        expect(page.get_by_text("Deposit Record Not Found")).to_be_visible()
        expect(page.get_by_text("No deposit with ID 99999. Check the link or search the register.")).to_be_visible()
        expect(page.locator('nav[aria-label="Breadcrumb"]').get_by_text("Not found")).to_be_visible()
        page.click('button:has-text("Return to Deposits Register")')
        page.wait_for_url(f"{base_url}/deposits")
        page.wait_for_selector("text=Deposits Register")
        page.wait_for_selector("table tbody tr")
        print("  ✓ 404 state verified with return navigation to register")

        # Verify layout at 1440x900 and 1366x768 (no table horizontal overflow)
        print("\nVerifying Viewport Layouts (1440x900 & 1366x768)...")
        for vp_w, vp_h in [(1440, 900), (1366, 768)]:
            page.set_viewport_size({"width": vp_w, "height": vp_h})
            page.wait_for_timeout(200)
            fits = page.evaluate("() => { const t = document.querySelector('main table'); return t ? t.scrollWidth <= t.parentElement.clientWidth : true; }")
            assert fits, f"Table horizontal overflow detected at {vp_w}x{vp_h}"
        page.set_viewport_size({"width": 1440, "height": 900})
        page.wait_for_timeout(200)
        print("  ✓ Register table fits containers at 1366x768 and 1440x900 without page scroll")

        # Capture remaining main pages for Handover Manual
        # 11. Maturity Radar
        page.click('aside a[href="/radar"]')
        page.wait_for_url(f"{base_url}/radar")
        page.wait_for_selector("text=matures in the next 90 days across")
        page.wait_for_timeout(400)
        page.screenshot(path=str(SCREENSHOTS_DIR / "11_maturity_radar.png"))
        print("  ✓ Captured Maturity Radar screen")

        # 12. Health Check
        page.click('aside a[href="/health"]')
        page.wait_for_url(f"{base_url}/health")
        page.wait_for_selector("text=Average score")
        page.wait_for_selector("table tbody tr")
        page.wait_for_timeout(400)
        page.screenshot(path=str(SCREENSHOTS_DIR / "12_health_check.png"))
        print("  ✓ Captured Health Check screen")

        # 13. Institutions Directory
        page.click('aside a[href="/institutions"]')
        page.wait_for_url(f"{base_url}/institutions")
        page.wait_for_selector("table tbody tr")
        page.wait_for_timeout(300)
        page.screenshot(path=str(SCREENSHOTS_DIR / "13_institutions_directory.png"))
        print("  ✓ Captured Institutions Directory screen")

        # 14. Reports
        page.click('aside a[href="/reports"]')
        page.wait_for_url(f"{base_url}/reports")
        page.wait_for_selector("text=All active")
        page.wait_for_selector("table tbody tr")
        page.wait_for_timeout(400)
        page.screenshot(path=str(SCREENSHOTS_DIR / "14_reports_presets.png"))
        print("  ✓ Captured Reports screen")

        # 15. Settings (Reviewer read-only)
        page.click('aside a[href="/settings"]')
        page.wait_for_url(f"{base_url}/settings")
        page.wait_for_selector("text=Reminder days")
        page.wait_for_timeout(300)
        page.screenshot(path=str(SCREENSHOTS_DIR / "16_settings_rules.png"))
        print("  ✓ Captured Settings screen")

        # 16. Bulk Import (Preview + Commit of sample_import.csv)
        print("\n[11/13] Testing Bulk Import CSV Workflow (Preview & Commit)...")
        # Ensure Admin is logged in
        page.click('button[title="Sign out"]')
        page.wait_for_url(f"{base_url}/login")
        page.click('button:has-text("Admin")')
        page.click('button:has-text("Sign in to portal")')
        page.wait_for_selector('button[title="Sign out"]')

        page.click('aside a[href="/imports"]')
        page.wait_for_url(f"{base_url}/imports")
        page.wait_for_selector('h1:has-text("Spreadsheet Import")', timeout=10000)

        fixture_path = Path(__file__).resolve().parent.parent / "backend" / "tests" / "fixtures" / "sample_import.csv"
        assert fixture_path.exists(), f"Missing fixture: {fixture_path}"

        page.set_input_files('input[type="file"]', str(fixture_path))
        page.wait_for_selector('button:has-text("Import 10 rows as drafts")', timeout=10000)
        expect(page.locator('button:has-text("Import 10 rows as drafts")')).to_be_visible()

        page.click('button:has-text("Import 10 rows as drafts")')
        page.wait_for_selector("text=Batch Import Completed", timeout=10000)
        expect(page.get_by_text("Batch Import Completed")).to_be_visible()
        page.screenshot(path=str(SCREENSHOTS_DIR / "17_bulk_import_complete.png"))
        print("  ✓ Bulk import previewed and committed 10 valid rows as drafts")

        # 17. Round R 5-Role Full Lifecycle Flow
        # (Institution -> Reviewer Observation -> Reply -> Verify & Approve -> Release Request -> Reviewer Refusal -> Approver Sanction -> Notice Public Verify -> Auditor View)
        print("\n[12/13] Testing Round R 5-Role Full Lifecycle Flow...")

        # Setup minimal PDF receipt fixture in temp
        minimal_pdf_bytes = (
            b"%PDF-1.4\n"
            b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n"
            b"2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n"
            b"trailer << /Size 3 /Root 1 0 R >>\n%%EOF\n"
        )
        receipt_pdf = Path(__file__).resolve().parent / "temp_receipt.pdf"
        receipt_pdf.write_bytes(minimal_pdf_bytes)

        try:
            # (a) Institution signs in, views home, submits an FDR with receipt
            print("  (a) Institution Login & Submission with Receipt...")
            page.click('button[title="Sign out"]')
            page.wait_for_url(f"{base_url}/login")
            page.click('button:has-text("Deccan Crest")')
            page.click('button:has-text("Sign in to portal")')
            page.wait_for_selector('button[title="Sign out"]')
            page.wait_for_selector('text=Deccan Crest Institute of Technology', timeout=10000)
            page.screenshot(path=str(SCREENSHOTS_DIR / "19_institution_home.png"))

            page.goto(f"{base_url}/deposits/new")
            page.wait_for_selector("text=Record New FDR Deposit")
            rnd_num = f"DC-2026-RND{int(time.time()) % 100000:05d}"
            page.fill("#fdr_number", rnd_num)
            page.click('button:has-text("Select bank name")')
            page.click('[role="option"]:has-text("State Bank of India")')
            page.fill("#branch", "FC Road Branch, Pune")
            page.fill("#ifsc", "SBIN0001234")
            page.fill("#amount", "3500000")
            page.fill("#interest_rate", "7.20")
            page.click('button:has-text("Save as Draft")')
            page.wait_for_selector("text=created as draft", timeout=10000)
            rnd_fdr_url = page.url
            rnd_fdr_id = int(rnd_fdr_url.split("/")[-1])
            print(f"    ✓ Institution created draft FDR #{rnd_fdr_id} ({rnd_num})")

            # Attach receipt document
            page.click('button[role="tab"]:has-text("Documents")')
            page.locator('input[type="file"]').set_input_files(str(receipt_pdf))
            page.wait_for_selector("text=temp_receipt.pdf", timeout=10000)
            print("    ✓ Receipt document attached")

            # Submit for approval
            page.click('button:has-text("Submit for Approval")')
            page.wait_for_selector('button:has-text("Submit FDR")')
            page.click('button:has-text("Submit FDR")')
            page.wait_for_selector("text=Pending approval", timeout=10000)
            print("    ✓ Submitted for approval")

            # (b) Reviewer raises an observation
            print("  (b) Reviewer Raises Scrutiny Observation...")
            page.click('button[title="Sign out"]')
            page.wait_for_url(f"{base_url}/login")
            page.click('button:has-text("Reviewer")')
            page.click('button:has-text("Sign in to portal")')
            page.wait_for_selector('button[title="Sign out"]')

            page.goto(rnd_fdr_url)
            page.wait_for_load_state("networkidle")
            page.click('button[role="tab"]:has-text("Observations")')
            page.wait_for_selector('button:has-text("Raise Observation")')
            page.fill('textarea[placeholder*="Enter observation"]', "Please submit branch confirmation letter verifying lien marking.")
            page.click('button:has-text("Raise Observation")')
            page.wait_for_selector("text=Open", timeout=10000)
            page.screenshot(path=str(SCREENSHOTS_DIR / "20_observation_raised.png"))
            print("    ✓ Reviewer posted scrutiny query; observation marked Open")

            # (c) Institution replies
            print("  (c) Institution Replies to Observation...")
            page.click('button[title="Sign out"]')
            page.wait_for_url(f"{base_url}/login")
            page.click('button:has-text("Deccan Crest")')
            page.click('button:has-text("Sign in to portal")')
            page.wait_for_selector('button[title="Sign out"]')

            page.goto(rnd_fdr_url)
            page.wait_for_load_state("networkidle")
            page.click('button[role="tab"]:has-text("Observations")')
            page.wait_for_selector('button:has-text("Submit Reply")')
            page.fill('textarea[placeholder*="Type official reply"]', "Branch letter requested; provisional receipt verified on file.")
            page.click('button:has-text("Submit Reply")')
            page.wait_for_selector("text=Answered", timeout=10000)
            print("    ✓ Institution submitted reply; observation marked Answered")

            # (d) Reviewer attaches nothing extra, verifies and approves
            print("  (d) Reviewer Closes Observation, Verifies, and Approves...")
            page.click('button[title="Sign out"]')
            page.wait_for_url(f"{base_url}/login")
            page.click('button:has-text("Reviewer")')
            page.click('button:has-text("Sign in to portal")')
            page.wait_for_selector('button[title="Sign out"]')

            page.goto(rnd_fdr_url)
            page.wait_for_load_state("networkidle")
            page.click('button[role="tab"]:has-text("Observations")')
            page.wait_for_selector('button:has-text("Mark Observation Closed")')
            page.click('button:has-text("Mark Observation Closed")')
            page.wait_for_selector("text=Closed", timeout=10000)

            # Verification
            page.click('button:has-text("Mark Verified")')
            page.wait_for_selector('button:has-text("Record Verification")')
            page.click('button:has-text("Record Verification")')
            page.wait_for_selector("text=Officer-verified", timeout=10000)

            # Approve
            page.click('button:has-text("Approve")')
            page.wait_for_selector('button:has-text("Approve Deposit")')
            page.fill("#dialog-remark", "Scrutiny complete; observation closed and deposit verified.")
            page.click('button:has-text("Approve Deposit")')
            page.wait_for_selector("text=Approved", timeout=10000)
            print("    ✓ Reviewer verified and approved FDR")

            # (e) Admin requests release with full checklist
            print("  (e) Admin Requests Release with Full Checklist...")
            page.click('button[title="Sign out"]')
            page.wait_for_url(f"{base_url}/login")
            page.click('button:has-text("Admin")')
            page.click('button:has-text("Sign in to portal")')
            page.wait_for_selector('button[title="Sign out"]')

            page.goto(rnd_fdr_url)
            page.wait_for_load_state("networkidle")
            page.click('button:has-text("Request Release")')
            page.wait_for_selector("text=Request Deposit Release")
            page.fill("#release-reason", "Mandatory tenure completed with all regulatory compliances satisfied.")
            checklist_boxes = page.locator('div[role="dialog"] input[type="checkbox"]')
            for i in range(checklist_boxes.count()):
                checklist_boxes.nth(i).check()
            page.click('div[role="dialog"] button[type="submit"]')
            page.wait_for_selector("text=Release requested", timeout=10000)
            expect(page.get_by_text("Checklist complete")).to_be_visible()
            print("    ✓ Admin requested release with complete checklist")

            # (f) Reviewer is refused sanction
            print("  (f) Verifying Reviewer Sanction Refusal...")
            page.click('button[title="Sign out"]')
            page.wait_for_url(f"{base_url}/login")
            page.click('button:has-text("Reviewer")')
            page.click('button:has-text("Sign in to portal")')
            page.wait_for_selector('button[title="Sign out"]')

            page.goto(rnd_fdr_url)
            page.wait_for_load_state("networkidle")
            expect(page.locator('button:has-text("Approve Release")')).to_have_count(0)
            expect(page.locator('button:has-text("Sanction release")')).to_have_count(0)

            # Direct API check: Reviewer cannot sanction release (403 Forbidden)
            rev_login_data = json.dumps({"email": "reviewer@fdrportal.demo", "password": "Review@2026"}).encode()
            rev_req = urllib.request.Request(
                f"{base_url}/api/auth/login",
                data=rev_login_data,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(rev_req) as resp:
                rev_jwt = json.loads(resp.read().decode())["access_token"]

            approve_req = urllib.request.Request(
                f"{base_url}/api/fdrs/{rnd_fdr_id}/decision",
                data=json.dumps({"action": "approve", "remark": "Attempted sanction"}).encode(),
                headers={"Authorization": f"Bearer {rev_jwt}", "Content-Type": "application/json"}
            )
            try:
                urllib.request.urlopen(approve_req)
                raise AssertionError("Expected 403 Forbidden for reviewer approving release")
            except urllib.error.HTTPError as err:
                assert err.code == 403, f"Expected 403, got {err.code}"
                print("    ✓ Reviewer sanction attempt refused with 403 Forbidden")

            # (g) Approver sanctions release
            print("  (g) Approver Sanctions Release...")
            page.click('button[title="Sign out"]')
            page.wait_for_url(f"{base_url}/login")
            page.click('button:has-text("Authority")')
            page.click('button:has-text("Sign in to portal")')
            page.wait_for_selector('button[title="Sign out"]')

            page.goto(rnd_fdr_url)
            page.wait_for_load_state("networkidle")
            page.wait_for_selector('button:has-text("Approve Release")', timeout=10000)
            page.click('button:has-text("Approve Release")')
            page.wait_for_selector('text=Approve Deposit Release')
            page.fill("#dialog-remark", "Compliance confirmed: release sanctioned under delegated authority.")
            page.click('div[role="dialog"] button:has-text("Approve Release")')
            page.wait_for_selector("text=Released", timeout=10000)
            page.screenshot(path=str(SCREENSHOTS_DIR / "18_fdr_released.png"))
            print(f"    ✓ Approver sanctioned release: FDR #{rnd_fdr_id} moved to Released")

            # (h) Notice issued and public /verify URL returns valid
            print("  (h) Notice Issuance and Public Verification...")
            # Login admin via API for issuing notice
            adm_login_data = json.dumps({"email": "admin@fdrportal.demo", "password": "Admin@2026"}).encode()
            adm_req = urllib.request.Request(
                f"{base_url}/api/auth/login",
                data=adm_login_data,
                headers={"Content-Type": "application/json"}
            )
            with urllib.request.urlopen(adm_req) as resp:
                adm_jwt = json.loads(resp.read().decode())["access_token"]

            notice_payload = json.dumps({
                "kind": "release_letter",
                "fdr_id": rnd_fdr_id
            }).encode()
            notice_req = urllib.request.Request(
                f"{base_url}/api/notices",
                data=notice_payload,
                headers={"Authorization": f"Bearer {adm_jwt}", "Content-Type": "application/json"}
            )
            with urllib.request.urlopen(notice_req) as resp:
                assert resp.status == 201
                notice_data = json.loads(resp.read().decode())
                ref_no = notice_data["reference_no"]
                verify_code = notice_data["verify_code"]
                assert ref_no.startswith("FDRP/NOT/2026/")
                assert verify_code and len(verify_code) == 16
                print(f"    ✓ Notice {ref_no} issued with verification code {verify_code}")

            # Public unauthenticated API check (valid)
            verify_url = f"{base_url}/api/public/verify-notice?ref={urllib.parse.quote(ref_no)}&code={urllib.parse.quote(verify_code)}"
            with urllib.request.urlopen(verify_url) as resp:
                v_res = json.loads(resp.read().decode())
                assert v_res["valid"] is True
                assert v_res["reference_no"] == ref_no

            # Public unauthenticated API check (invalid code)
            bad_verify_url = f"{base_url}/api/public/verify-notice?ref={urllib.parse.quote(ref_no)}&code=0000000000000000"
            with urllib.request.urlopen(bad_verify_url) as resp:
                bad_res = json.loads(resp.read().decode())
                assert bad_res["valid"] is False

            # Public UI Page Check (/verify)
            page.goto(f"{base_url}/verify?ref={urllib.parse.quote(ref_no)}&code={urllib.parse.quote(verify_code)}")
            page.wait_for_selector("text=Official Record Verified Intact", timeout=10000)
            expect(page.get_by_text(ref_no)).to_be_visible()
            page.screenshot(path=str(SCREENSHOTS_DIR / "21_public_verify_notice.png"))
            print(f"    ✓ Public /verify page verified {ref_no} as authentic and intact")

            # (i) Auditor can open audit log but sees no action buttons
            print("  (i) Auditor Read-Only Access & Integrity Verification...")
            page.evaluate("() => { localStorage.clear(); }")
            page.goto(f"{base_url}/login")
            page.wait_for_selector('button:has-text("Auditor")', timeout=10000)
            page.click('button:has-text("Auditor")')
            page.click('button:has-text("Sign in to portal")')
            page.wait_for_selector('button[title="Sign out"]')

            page.click('aside a[href="/audit"]')
            page.wait_for_url(f"{base_url}/audit")
            page.wait_for_selector('h1:has-text("Audit Log")')
            page.wait_for_selector("table tbody tr")
            page.screenshot(path=str(SCREENSHOTS_DIR / "22_auditor_view.png"))

            # Assert auditor has no mutation controls
            expect(page.locator('button:has-text("New Deposit")')).to_have_count(0)
            expect(page.locator('button:has-text("Run checks")')).to_have_count(0)
            expect(page.locator('button:has-text("Save settings")')).to_have_count(0)
            expect(page.locator('button:has-text("Issue notice")')).to_have_count(0)
            expect(page.locator('button:has-text("Sanction release")')).to_have_count(0)
            print("    ✓ Auditor view verified: audit log accessible, all mutation buttons absent")

        finally:
            if receipt_pdf.exists():
                try:
                    receipt_pdf.unlink()
                except Exception:
                    pass

        browser.close()

    print("\n=======================================================")
    print(" ALL E2E SMOKE TESTS PASSED CLEANLY! ✓")
    print(f" Screenshots written to: {SCREENSHOTS_DIR}")
    print("=======================================================\n")


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run Amanat Playwright smoke tests")
    parser.add_argument(
        "--base-url",
        default=None,
        help="Base URL of FDR portal application (default: start isolated server on port 8010)",
    )
    parser.add_argument(
        "--headed",
        action="store_true",
        help="Run browser in headed mode (default: headless)",
    )
    args = parser.parse_args()

    if args.base_url:
        run_smoke_test(base_url=args.base_url, headless=not args.headed)
    else:
        with managed_server(port=8010) as server_url:
            run_smoke_test(base_url=server_url, headless=not args.headed)
