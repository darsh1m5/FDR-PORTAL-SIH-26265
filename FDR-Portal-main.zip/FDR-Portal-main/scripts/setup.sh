#!/usr/bin/env bash
# Amanat: one-time setup for macOS/Linux.
# Creates backend/.venv, installs backend requirements and frontend packages.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "=== Amanat setup ==="

if ! command -v python3 >/dev/null 2>&1; then
    echo "ERROR: python3 was not found. Install Python 3.11 or newer first." >&2
    exit 1
fi
if ! python3 -c 'import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)'; then
    echo "ERROR: Python 3.11 or newer is required (older versions lack features the backend uses)." >&2
    exit 1
fi
if ! command -v npm >/dev/null 2>&1; then
    echo "ERROR: npm was not found. Install Node.js 20 or newer first." >&2
    exit 1
fi

if [ ! -d backend/.venv ]; then
    echo "[1/3] Creating Python virtual environment in backend/.venv ..."
    python3 -m venv backend/.venv
else
    echo "[1/3] Using existing virtual environment in backend/.venv"
fi

echo "[2/3] Installing backend requirements ..."
backend/.venv/bin/python -m pip install --upgrade pip
backend/.venv/bin/python -m pip install -r backend/requirements.txt

echo "[3/3] Installing frontend packages ..."
(cd frontend && npm install)

echo
echo "Setup complete."
echo "Start the app with scripts/run.sh"
echo "Demo logins: admin@fdrportal.demo / Admin@2026"
echo "             reviewer@fdrportal.demo / Review@2026"
