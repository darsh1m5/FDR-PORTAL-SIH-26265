@echo off
rem Amanat: start backend (port 8000) and frontend (port 5173) together.
setlocal
cd /d "%~dp0.."

if not exist backend\.venv\Scripts\python.exe (
    echo Backend is not set up yet. Run scripts\setup.bat first.
    exit /b 1
)
if not exist frontend\node_modules (
    echo Frontend is not set up yet. Run scripts\setup.bat first.
    exit /b 1
)

echo === Amanat ===
echo   App:       http://localhost:5173
echo   API docs:  http://localhost:8000/docs
echo   Logins:    admin@fdrportal.demo / Admin@2026
echo              reviewer@fdrportal.demo / Review@2026
echo.
echo Two windows will open: the API server and the web app.
echo Close those windows (or press Ctrl+C inside them) to stop.

start "Amanat backend" /D "%~dp0..\backend" cmd /k ".venv\Scripts\python -m uvicorn app.main:app --port 8000"
timeout /t 2 /nobreak >nul
start "Amanat frontend" /D "%~dp0..\frontend" cmd /k "npm run dev"
exit /b 0
