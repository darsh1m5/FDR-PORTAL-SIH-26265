#!/usr/bin/env bash
# Amanat: start backend (port 8000) and frontend (port 5173) together.
set -uo pipefail
cd "$(dirname "$0")/.."

if [ ! -x backend/.venv/bin/python ]; then
    echo "Backend is not set up yet. Run scripts/setup.sh first." >&2
    exit 1
fi
if [ ! -d frontend/node_modules ]; then
    echo "Frontend is not set up yet. Run scripts/setup.sh first." >&2
    exit 1
fi

echo "=== Amanat ==="
echo "  App:       http://localhost:5173"
echo "  API docs:  http://localhost:8000/docs"
echo "  Logins:    admin@fdrportal.demo / Admin@2026"
echo "             reviewer@fdrportal.demo / Review@2026"
echo "  Press Ctrl+C to stop both servers."
echo

BACK_PID=""
FRONT_PID=""
cleanup() {
    [ -n "$BACK_PID" ] && kill "$BACK_PID" 2>/dev/null
    [ -n "$FRONT_PID" ] && kill "$FRONT_PID" 2>/dev/null
    return 0
}
trap cleanup EXIT INT TERM

(cd backend && exec .venv/bin/python -m uvicorn app.main:app --port 8000) &
BACK_PID=$!
sleep 2
(cd frontend && exec npm run dev) &
FRONT_PID=$!
wait
