@echo off
rem Amanat: one-time setup for Windows.
rem Creates backend\.venv, installs backend requirements and frontend packages.
setlocal
cd /d "%~dp0.."

echo === Amanat setup ===

where python >nul 2>nul
if errorlevel 1 (
    echo ERROR: Python was not found on PATH. Install Python 3.11 or newer first.
    exit /b 1
)
python -c "import sys; raise SystemExit(0 if sys.version_info >= (3, 11) else 1)"
if errorlevel 1 (
    echo ERROR: Python 3.11 or newer is required ^(older versions lack features the backend uses^).
    exit /b 1
)

where npm >nul 2>nul
if errorlevel 1 (
    echo ERROR: npm was not found on PATH. Install Node.js 20 or newer first.
    exit /b 1
)

if not exist backend\.venv (
    echo [1/3] Creating Python virtual environment in backend\.venv ...
    python -m venv backend\.venv
    if errorlevel 1 goto :fail
) else (
    echo [1/3] Using existing virtual environment in backend\.venv
)

echo [2/3] Installing backend requirements ...
backend\.venv\Scripts\python -m pip install --upgrade pip
if errorlevel 1 goto :fail
backend\.venv\Scripts\python -m pip install -r backend\requirements.txt
if errorlevel 1 goto :fail

echo [3/3] Installing frontend packages ...
pushd frontend
call npm install
if errorlevel 1 (
    popd
    goto :fail
)
popd

echo.
echo Setup complete.
echo Start the app with scripts\run.bat
echo Demo logins: admin@fdrportal.demo / Admin@2026
echo              reviewer@fdrportal.demo / Review@2026
exit /b 0

:fail
echo.
echo Setup FAILED - see the messages above.
exit /b 1
