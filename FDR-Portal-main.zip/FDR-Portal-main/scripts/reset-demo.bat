@echo off
rem Amanat: delete the demo database and uploads so the next start re-seeds.
setlocal
cd /d "%~dp0.."

echo This deletes the demo database (backend\data\fdr.db) and every uploaded
echo file (backend\uploads). The next start creates fresh demo data.
choice /C YN /M "Continue"
if errorlevel 2 exit /b 0

if exist backend\data\fdr.db     del /q backend\data\fdr.db
if exist backend\data\fdr.db-wal del /q backend\data\fdr.db-wal
if exist backend\data\fdr.db-shm del /q backend\data\fdr.db-shm
if exist backend\uploads for %%f in (backend\uploads\*) do del /q "%%f"

echo Done. Run scripts\run.bat to start with fresh demo data.
exit /b 0
