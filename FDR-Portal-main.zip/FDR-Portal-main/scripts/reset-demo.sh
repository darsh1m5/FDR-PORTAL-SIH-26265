#!/usr/bin/env bash
# Amanat: delete the demo database and uploads so the next start re-seeds.
set -euo pipefail
cd "$(dirname "$0")/.."

echo "This deletes the demo database (backend/data/fdr.db) and every uploaded"
echo "file (backend/uploads). The next start creates fresh demo data."
read -r -p "Continue? [y/N] " reply
case "$reply" in
    [yY]|[yY][eE][sS]) ;;
    *) echo "Cancelled."; exit 0 ;;
esac

rm -f backend/data/fdr.db backend/data/fdr.db-wal backend/data/fdr.db-shm
if [ -d backend/uploads ]; then
    find backend/uploads -mindepth 1 -maxdepth 1 -type f -delete
fi

echo "Done. Run scripts/run.sh to start with fresh demo data."
