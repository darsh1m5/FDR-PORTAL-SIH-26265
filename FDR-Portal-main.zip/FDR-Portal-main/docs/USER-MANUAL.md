# Amanat: User Manual

*Security Deposit and FDR Management Portal: prototype for SIH26265 (AICTE, Regulation Bureau).*

## 1. What it does

Amanat keeps every security deposit and Fixed Deposit Receipt in one
register, warns before deposits mature, moves each instrument through
approval, renewal and release, and records every action in a tamper-evident
audit trail.

## 2. Quick start

**Prerequisites:** Python 3.11 or newer (`python --version`) and Node.js 20 or newer (`node --version`).

1. Run the one-time setup:
   - Windows: `scripts\setup.bat`
   - macOS / Linux: `bash scripts/setup.sh`
   *(Creates virtual environment in `backend\.venv`, installs backend requirements, and installs frontend packages)*
2. Start the development servers:
   - Windows: `scripts\run.bat`
   - macOS / Linux: `bash scripts/run.sh`
3. Open **http://localhost:5173** in the browser (interactive API docs at **http://localhost:8000/docs**).
   On initial startup, the SQLite database auto-seeds with 14 institutions, 44 multi-state FDRs with 18 months of history, documents, and alerts.

## 3. Demo logins

| Role | Role Title | Email | Password | Allowed Access |
|---|---|---|---|---|
| Administrator | Section Officer | `admin@fdrportal.demo` | `Admin@2026` | Bureau-wide operations, FDR registration, bulk imports, settings, notices |
| Reviewer | Scrutiny Officer | `reviewer@fdrportal.demo` | `Review@2026` | Document verification, scrutiny observations, approval/rejection of submissions |
| Competent Authority | Approver | `approver@fdrportal.demo` | `Approve@2026` | Sanction or return release requests after checking the release checklist |
| Auditor | Audit Officer | `auditor@fdrportal.demo` | `Audit@2026` | Reads every record and the audit log, runs the integrity check, exports; changes nothing |
| Institution | Deccan Crest Institute | `deccan.crest@fdrportal.demo` | `Inst@2026` | Scoped deposit submission, observation replies, and release requests |

## 4. Five-minute demo script

1. Sign in as **Administrator**. Dashboard: total deposits, active FDRs, maturing in 30/90 days, pending approvals.
2. **Register a new FDR** (Deposits → New). Watch the projected maturity value update as you type. Save: it appears as *Draft*.
3. Upload the FDR scan, then **Submit for approval**. It now shows *Pending approval* and counts on the dashboard.
4. Open **Alerts**: deposits maturing within the configured windows are flagged; change the rule in **Settings** and re-run.
5. Sign in as **Reviewer** → **Approvals** → open the FDR → **Verify** and **Approve** (or Reject with a remark).
6. Open the FDR's **History**: every step with who, when and the status change. **Audit log → Verify integrity** shows *Intact*.
7. Innovation: **Health Check** (worst deposits first, with the exact issue and fix) and **Maturity Radar** (12-month view with projected payouts).
8. **Reports → Export CSV** of any filtered view.

## 5. Requirement traceability

| # | Your requirement | Delivered as | Where | How to test | Status |
|---|---|---|---|---|---|
| R1 | Dashboard with totals, active FDRs, upcoming maturities, pending approvals | KPI tiles, timeline, status/bank breakdown, maturing-next table, activity | Dashboard | Sign in as Administrator or Reviewer. Click **Dashboard** in the sidebar. Observe 8 KPI tiles (Total Portfolio, Active Value, Pending Approvals, Release Requests, Due in 30 Days, Due in 90 Days, Matured Overdue, Average Health), the 12-month maturity timeline chart, bank and status distribution, the Maturing Next table, and the recent activity list. Click any KPI tile or table row to drill down into filtered register views. | Done |
| R2 | Registration, editing, search, filter, view | Register with search/filters/sort, form with validation, detail page | Deposits | Click **Register** in the sidebar. Search by FDR number, institution name, or AICTE ID in the search bar. Filter using the Status, Window, Bank, Institution, or Provenance dropdowns. Click column headers (such as FDR Number or Amount) to sort. Click any row to open the full deposit detail. On an eligible deposit, click **Edit** in the top action bar to modify fields and click **Save Changes**. | Done |
| R3 | All listed fields | All fields + branch, IFSC, lien flag, printed maturity amount, remarks | Deposit form | Click **Register** in the sidebar, then click **New FDR** (or navigate to `/deposits/new`). Verify form sections: Institution Selection, Instrument & Bank Details (FDR Number, Bank, Branch, IFSC), Financial Terms (Amount, Issue Date, Maturity Date, Interest Rate, Maturity Value on Receipt), and Purpose & Compliance (Purpose, Lien marked to AICTE checkbox, Bureau Remarks). Observe the live Projected maturity value card update dynamically with quarterly compounding as numbers and dates are entered. | Done |
| R4 | Pending, approved, rejected, renewed, released | Draft → Pending → Approved/Rejected; Release; Renew with linked new FDR | Detail, Approvals | 1) In the deposit form, fill details and click **Save as Draft** (creates Draft). 2) On deposit detail, click **Submit for Approval** (moves to Pending approval). 3) Sign in as Reviewer, open **Approvals** in the sidebar, click the row to open the review drawer, and click **Approve** (or **Reject** with a mandatory remark). 4) Open an approved deposit, click **Renew FDR** to open the prefilled renewal form and click **Confirm Renewal** (linking old and new records bidirectional), or click **Request Release** with a reason and the checklist. | Done |
| R5 | Maturity and overdue alerts, configurable | Alert engine with editable reminder days, overdue and review-SLA alerts | Alerts, Settings | Click **Alerts** in the sidebar to view alerts grouped by severity (Critical, Warning, Advisory) across Open and Acknowledged tabs. Click **Acknowledge** on any individual alert row, or select multiple rows and click **Acknowledge selected**. As Administrator, click **Run checks now** to run the engine on demand. Open **Settings** in the sidebar, adjust reminder day thresholds (e.g. 90, 60, 30, 7) or Review SLA days, click **Save settings**, and observe the alert engine instantly recalculate alerts. | Done |
| R6 | Document attachments where feasible | Upload/download/delete PDF, JPG, PNG per FDR | Detail → Documents | Open any deposit detail page and click the **Documents** tab. Click **Upload Document** and select a valid receipt file (PDF, JPG, or PNG up to 10 MB). Verify the uploaded file appears in the list with filename, size, date, and uploader. Click the download icon button to download the file, or click the delete icon button to remove it with confirmation. | Done |
| R7 | Audit history | Per-FDR timeline and global audit log | Detail, Audit log | 1) Open any deposit detail page and select the **Audit Timeline** tab to view chronological events (Created, Submitted, Approved, Verified) with actor, status change, and timestamp. 2) Click **Audit Log** in the sidebar to inspect the global append-only ledger with action, actor, and deposit filters. Click **Verify integrity** in the page header to verify the SHA-256 hash chain, confirming "Intact. N entries checked." | Done |
| R8 | Login, Administrator and Reviewer | JWT login, role-aware screens and API | Login | Navigate to `/login`. Click **Admin** to prefill admin credentials and click **Sign in to portal** (grants registration, New FDR, and Settings modification). Click **Sign out** in the lower left navigation footer. Click **Reviewer** and click **Sign in to portal** (grants Approvals queue decision rights and Mark Verified actions, while Settings is read-only). Unauthenticated API requests return 401/403. | Done |
| R9 | Backend and database, persistent | FastAPI + SQLAlchemy + SQLite | - | Backend runs on FastAPI with SQLite database at `backend/data/fdr.db`. Restarting the application preserves all deposits, audit logs, and settings intact. From `backend`, run `.venv\Scripts\python -m pytest` (Windows) or `.venv/bin/python -m pytest` (macOS/Linux) to run the 60 automated unit and integration tests. | Done |
| R10 | Sample data and export | Seeded institutions and FDRs; CSV export; printable report | Reports, Deposits | 1) Click **Register** in the sidebar and click **Export CSV** in the header to download the filtered register with UTF-8 BOM. 2) Click **Reports** in the sidebar to view five preset registers (Active deposits, Maturing in 90 days, Pending approval, Released this year, Below required deposit), click **Download CSV** on any preset, or click **Print summary** in the header for a clean printable layout. | Done |
| D1 | Source code, README, setup | This repository | README | Follow `README.md` step-by-step: run `scripts\setup.bat` (or `bash scripts/setup.sh`) and `scripts\run.bat` (or `bash scripts/run.sh`). Verify clean directory structure, comprehensive documentation, and zero-configuration launch. | Done |
| D2 | Demo credentials, seed data | Section 3; auto-seeded on first run | - | Run `scripts\run.bat` (or `bash scripts/run.sh`). Verify the database seeds the five Section 3 logins (Administrator, Reviewer, Competent Authority, Auditor, Institution) and 44 realistic multi-state institutional FDRs on first boot. | Done |
| D3 | Basic testing | Backend tests + browser smoke test | `backend/tests`, `e2e` | 1) In `backend`, run `.venv\Scripts\python -m pytest` (105 tests pass in about 20 s). 2) From the project root, run `backend\.venv\Scripts\python e2e\smoke_test.py` (13 browser steps pass in about 55 s and 22 screenshots are saved to `e2e/screenshots/`; it uses its own temporary database, so the demo data is not changed). See the README Testing section for the one-time Playwright install. | Done |
| D4 | Architecture walkthrough | Section 8 | - | Read Section 8 of this manual (components, backend modules, security). With the backend running, open http://localhost:8000/docs for the live API reference with every endpoint and its request and response shapes. | Done |

## 6. Added from our side (innovation)

| Feature | What it does | Why it matters for SIH26265 | How to test | Status |
|---|---|---|---|---|
| Health Check | Scores every FDR 0-100 with explainable rules (date errors, duplicates, shortfall vs required deposit, no lien to AICTE, missing document, bad IFSC, rate out of band, printed vs computed maturity mismatch, matured but unresolved) and shows the fix | Statement capability 3: discrepancy detection | Open **Health Check** in the sidebar. Inspect the overall average score, distribution buckets, and worst-performing deposits table. Click any deposit finding to view rule deduction details, remediation steps, and direct link to the instrument. | Done |
| Provenance badge | Submitted vs Officer-verified; Bank-confirmed reserved for a real bank integration | Statement asks to separate submitted from confirmed data | Open any deposit detail page. Check provenance pill displays *Submitted* or *Officer verified* with verification timestamp and officer remark. *Bank-confirmed* is displayed in grey indicating mock bank verification not connected in prototype. | Done |
| Maturity Radar | 12-month plan of maturities with projected payouts and cash-flow chart | Capability 4: timely renewal monitoring | Open **Maturity Radar** in the sidebar. View the 12-month timeline with monthly principal and projected amounts. Click on any month pill to view the table of maturing instruments for that month with direct links to deposits. | Done |
| Tamper-evident audit | Hash-chained audit entries with one-click integrity check | Capability 9: traceable, accountable records | Open **Audit log** in the sidebar. Click **Check the record** (or Verify integrity). The system verifies SHA-256 hash chains across all entries and displays green Intact badge with count of verified records. | Done |
| Spreadsheet import | Upload an existing CSV of FDRs; each row is validated and checked by the Health Check rules before saving; valid rows become drafts | Statement: records scattered in spreadsheets; capability 1 and 3 | Click **Imports** in sidebar (or navigate to `/imports`). Click **Download Template (CSV)** to inspect standard structure. Select `backend/tests/fixtures/sample_import.csv`. Inspect row status breakdown (Valid, Warning, Error), pre-import Health Check findings, and click **Import 10 rows as drafts**. Verify successful batch creation with register link. | Done |
| Release readiness checklist | Release request records the release conditions; the Competent Authority cannot sanction it until every applicable item is ticked | Capability 6: release and refund workflow | On an approved deposit, click **Request Release**. Give the reason and complete the 5-point checklist (affidavit, no pending complaints, closure certificate, lock-in tenure complete, bank discharge). Submit request. Opening the deposit displays the complete checklist; Competent Authority sanctions release. | Done |
| Notices and letters | Numbered reminder, overdue, shortfall and release letters generated from the record, printable, logged in the audit trail (not emailed) | Capability 6 and 7; replaces manual letters | Navigate to **/notices** in sidebar. Switch between candidate tabs (**Maturity reminders**, **Overdue**, **Shortfall**) or **History**. As Administrator, click **Issue notice** on any candidate row, or click **View letter** in History (or issue via API for a released/maturing deposit). View formal A4 letter with reference number (`FDRP/NOT/2026/NNNN`), official salutation, formatted INR currency, and closing. | Done |
| Alert escalation | Alerts not acknowledged in time are flagged Escalated and shown first | Capability 7: alerts and escalation | In **Settings**, view or update **Escalate after (days)** (default 3 days). Alerts open longer than the threshold receive an **Escalated** badge and sort to the top within severity groups. Open **Alerts** and toggle the **Escalated only** filter button. | Done |
| Bureau performance | Approval and release turnaround, verification rate, document coverage, on-time renewals, data quality, alert response time, 6-month trend | Statement asks for measurable gains | Open **Dashboard** and view the 4-number Bureau Operating Performance strip (approval turnaround, verification rate, document coverage, on-time renewals) with plain explanations. Click any tile or navigate to **Reports** under the **Bureau performance** heading to see comprehensive bureau metrics, 6-month historical trend, and SLA compliance. | Done |
| Document types and full lineage | Scans tagged by type; the whole renewal chain on each deposit | Capability 2 and 5 | 1) On deposit detail, in **Documents** tab, upload a file selecting a document type (FDR receipt, Lien letter, Affidavit, Closure certificate). Each file shows its specific type badge. 2) For renewed deposits, view the Section 3 **Lineage Chain** showing horizontal chronological links from original instrument to replacement. | Done |
| Five roles | Administrator, Reviewer, Competent Authority, Auditor and Institution logins, each seeing and doing only what its role allows | Statement: institutions and officials; authorised release; access control (capability 9) | On the login screen, use the demo quick-fill buttons to test each role. Institution lands on Institution Home and sees only their own deposits; Reviewer sees submissions and observation controls; Approver sees release requests; Auditor has read-only access with action buttons hidden; Administrator has full operational control. | Done |
| Scrutiny observations | Officer raises a question on a deposit, the institution replies in the portal, the officer closes it | Statement: "record scrutiny observations" | Sign in as Reviewer and open a pending deposit. In the **Observations** tab, click **Raise observation** and post a query (marks status *Open*). Sign in as Institution, open the deposit, and click **Submit Reply** to post clarifications (marks *Answered*). Sign in as Reviewer and click **Mark Observation Closed** (marks *Closed*). | Done |
| Bank confirmation by letter | Officer attaches the bank's confirmation letter and marks the deposit Bank-confirmed; no bank API is claimed | Statement: distinguish submitted from bank-confirmed data | On deposit detail, in **Documents** tab, upload a document with type *Bank confirmation letter*. The **Bank-confirm** header action activates for the Reviewer. Clicking it confirms the instrument with a solid *Bank-confirmed (letter on file)* provenance badge. (Attempting to bank-confirm without an attached letter displays a blocking tooltip). | Done |
| Maker-checker release | Release is sanctioned only by the Competent Authority, never by the officer who requested it | Capability 6: authorised release | On an approved deposit, Administrator or Institution requests release with the 5-point checklist. Sign in as Reviewer: release sanction buttons are absent and API returns 403. Sign in as Competent Authority (`approver@fdrportal.demo`): review the checklist and click **Sanction release** (or **Return** with a remark). | Done |
| Document fingerprint | Every scan is fingerprinted; the same file on two deposits is flagged; downloads are checked for tampering | Capability 2 and 9 | Upload a receipt PDF to an FDR; inspect the short SHA-256 hash displayed in the Documents tab. Upload the identical file to another FDR: Health Check immediately flags `DOCUMENT_REUSED` (critical finding, -30 points). Downloading any document verifies the `X-Integrity: verified` response header. | Done |
| QR-verifiable letters | Each numbered letter carries a QR code and code that anyone can check on a public page | Capability 6 and 9 | Issue any official letter via `/notices` or API. The generated letter displays an HMAC-SHA256 verification code and QR code pointing to `/verify?ref=...&code=...`. Navigate to the public unauthenticated `/verify` page to confirm the authentic record badge and details. | Done |

## 7. How this compares

| | Amanat (this) | Typical FD tracker (FDMaker, Invest Plus) | Corporate guarantee suite (Finora) | Other SIH prototypes |
|---|---|---|---|---|
| Regulator view across institutions | Yes | No | No | Yes |
| Approval, release and renewal workflow | Yes | No | Partly | Yes |
| Configurable maturity alerts | Yes | Yes | Yes | Yes |
| Explainable discrepancy score | Yes | No | No | Rules, usually without a score |
| Tamper-evident audit check | Yes | No | No | Some |
| Everything shown actually works | Yes | Yes | Yes | Often simulated integrations |

## 8. Architecture

React (Vite, TypeScript) talks to a FastAPI REST API over `/api`. FastAPI
uses SQLAlchemy with a SQLite file, stores uploads on disk, signs JWTs for
login, runs the alert engine on startup, every 10 minutes and after each
change, and writes a hash-chained audit entry for every action.

```
Browser (React + TypeScript, Vite)
   │  /api/*  JSON, Bearer token
   ▼
FastAPI  ── routers (thin) ──► workflow.py   status machine, 403/409 rules
   │                          rules.py      maturity state, projected value, findings, health score
   │                          alerts.py     alert engine (startup, every 10 min, after each change)
   │                          audit.py      append-only SHA-256 hash chain + integrity check
   ▼
SQLAlchemy 2 ──► SQLite file backend/data/fdr.db      uploads ──► backend/uploads/
```

**Backend modules** (`backend/app/`)

| File | Role |
|---|---|
| `main.py` | App factory, CORS, routers under `/api`, startup (create tables, seed if empty, alert run), 10-minute alert loop, serves the built frontend |
| `config.py` | Settings from environment or `.env`; IST "today" for all date maths |
| `models.py` | Tables: users, institutions, fdrs, documents, alerts, settings, audit_logs |
| `schemas.py` | Request and response shapes (Pydantic v2) |
| `security.py` | bcrypt passwords, 12-hour JWT, role checks (Administrator, Reviewer) |
| `workflow.py` | Draft → Pending approval → Approved / Rejected; release; renewal; verification |
| `rules.py` | Days to maturity, maturity window, quarterly-compounded projected value, 10 discrepancy rules, 0-100 health score |
| `alerts.py` | Maturity reminders at the configured days, overdue, review taking too long, critical discrepancies; auto-resolves when the condition clears |
| `audit.py` | `hash = sha256(previous hash + entry)`; "Verify integrity" recomputes the whole chain |
| `routers/` | One file per API area: auth, meta, dashboard, institutions, fdrs, documents, approvals, alerts, settings, audit, radar, findings |

**API reference**: start the backend and open http://localhost:8000/docs for
the live, clickable API documentation.

**Security in the prototype**: passwords are stored only as bcrypt hashes;
every API call except sign-in needs a valid token; every action is checked
against the user's role on the server, not only hidden in the screen; uploads
are limited to real PDF/JPG/PNG files up to 10 MB and stored under random
names.

## 9. Known limitations (honest)

- Email/SMS alerts are not sent; alerts appear inside the portal.
- No bank or NeSL verification API is connected; "Bank-confirmed" is reserved for that.
- Single-file SQLite database; suited to a demo, not to many concurrent users.
- Two roles only (Administrator, Reviewer).
- Notices and letters are generated and printed from the portal; they are not emailed or posted by the system.
- Spreadsheet import reads CSV files (in Excel: File, Save As, CSV UTF-8). Native .xlsx upload is next phase.
- Institutions cannot log in yet, so they send renewed receipts to the Bureau, which uploads them.
- `npm install` reports one advisory in the form-validation library (very large inputs can use much browser memory). It affects only the officer's own browser; the fix is a major upgrade planned for the next phase.
- Setup and run scripts were tested on a fresh Windows machine; the macOS/Linux scripts follow the same steps but were not run on a Mac for this delivery.

## 10. Roadmap

Institution self-service login · email/SMS and escalation matrix · NeSL e-BG
and bank verification adapters · OCR to pre-fill FDR details from scans ·
multi-level sign-off for release · PostgreSQL and cloud deployment.
