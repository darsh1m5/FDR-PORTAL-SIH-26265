"""Rule-driven alert engine.

`run_alerts` works out which alerts should be open right now, opens the missing
ones, refreshes the text of the ones still open and auto-resolves the ones whose
condition no longer holds. It is idempotent, so it can run on startup, every few
minutes and after every change.
"""

from dataclasses import dataclass
from datetime import date, datetime

from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.audit import _hold_chain_lock, write_audit
from app.config import utcnow
from app.constants import OPEN_STATUSES
from app.models import (
    Alert,
    AlertType,
    AuditEntity,
    AuditLog,
    Fdr,
    FdrStatus,
    Observation,
    ObservationStatus,
    Severity,
)
from app.rules import RuleContext, findings_for, get_settings

AlertKey = tuple[int, AlertType, int]


@dataclass(frozen=True)
class AlertRun:
    created: int
    resolved: int
    open: int


@dataclass(frozen=True)
class _Wanted:
    severity: Severity
    message: str
    due_date: date | None
    days: int | None


def display_date(value: date) -> str:
    """Indian display format used across the UI, alerts and exports: 08 Oct 2026."""
    return value.strftime("%d %b %Y")


def _plural(n: int, word: str) -> str:
    return f"{n} {word}{'' if n == 1 else 's'}"


def waiting_since(db: Session, fdrs: list[Fdr]) -> dict[int, tuple[datetime, int | None, dict]]:
    """When (and by whom) each FDR entered its current status, from the audit log."""
    result: dict[int, tuple[datetime, int | None, dict]] = {}
    if not fdrs:
        return result
    by_id = {f.id: f for f in fdrs}
    rows = db.execute(
        select(AuditLog.fdr_id, AuditLog.at, AuditLog.actor_id, AuditLog.detail, AuditLog.to_status)
        .where(AuditLog.fdr_id.in_(by_id))
        .where(AuditLog.to_status.is_not(None))
        .where((AuditLog.from_status.is_(None)) | (AuditLog.from_status != AuditLog.to_status))
        .order_by(AuditLog.id)
    )
    for fdr_id, at, actor_id, detail, to_status in rows:
        if to_status == by_id[fdr_id].status.value:
            result[fdr_id] = (at, actor_id, detail or {})
    for fdr in fdrs:
        result.setdefault(fdr.id, (fdr.updated_at, fdr.created_by_id, {}))
    return result


def _wanted_alerts(db: Session) -> dict[AlertKey, _Wanted]:
    cfg = get_settings(db)
    ctx = RuleContext.load(db)
    reminder_days = sorted({int(d) for d in cfg.reminder_days if int(d) > 0})
    horizon = max(reminder_days) if reminder_days else -1
    grace = int(cfg.overdue_grace_days)
    sla = int(cfg.pending_sla_days)
    wanted: dict[AlertKey, _Wanted] = {}

    fdrs = db.scalars(
        select(Fdr).options(selectinload(Fdr.institution)).where(Fdr.status.in_(OPEN_STATUSES))
    ).all()
    pending = [f for f in fdrs if f.status in (FdrStatus.pending_approval, FdrStatus.release_requested)]
    since = waiting_since(db, pending)
    now = utcnow()

    for fdr in fdrs:
        days = (fdr.maturity_date - ctx.on).days
        name = fdr.institution.name
        when = display_date(fdr.maturity_date)

        if 0 <= days <= horizon:
            bucket = next(d for d in reminder_days if days <= d)
            severity = (
                Severity.critical if bucket <= 7 else Severity.warning if bucket <= 30 else Severity.info
            )
            in_words = "today" if days == 0 else f"in {_plural(days, 'day')}"
            wanted[(fdr.id, AlertType.maturity_upcoming, bucket)] = _Wanted(
                severity,
                f"FDR {fdr.fdr_number} ({name}) matures {in_words}, on {when}.",
                fdr.maturity_date,
                days,
            )
        elif days < -grace and fdr.status != FdrStatus.release_requested:
            wanted[(fdr.id, AlertType.matured_overdue, 0)] = _Wanted(
                Severity.critical,
                f"FDR {fdr.fdr_number} ({name}) matured on {when}, "
                f"{_plural(-days, 'day')} ago, and is neither renewed nor released.",
                fdr.maturity_date,
                days,
            )

        if fdr.id in since:
            entered_at = since[fdr.id][0]
            waited = (now - entered_at).days
            if waited > sla:
                kind = "approval" if fdr.status == FdrStatus.pending_approval else "release decision"
                bucket = 0 if fdr.status == FdrStatus.pending_approval else 1
                wanted[(fdr.id, AlertType.pending_too_long, bucket)] = _Wanted(
                    Severity.warning,
                    f"FDR {fdr.fdr_number} ({name}) has waited {_plural(waited, 'day')} for {kind}; "
                    f"the target is {_plural(sla, 'day')}.",
                    None,
                    waited,
                )

        # MATURED_UNRESOLVED is already raised as a matured_overdue alert above.
        critical = [
            f
            for f in findings_for(fdr, ctx)
            if f.severity == Severity.critical and f.code != "MATURED_UNRESOLVED"
        ]
        if critical:
            summary = "; ".join(f.message.rstrip(".") for f in critical)
            wanted[(fdr.id, AlertType.discrepancy, 0)] = _Wanted(
                Severity.critical,
                f"FDR {fdr.fdr_number} ({name}): {summary}."[:300],
                None,
                None,
            )

    open_obs = db.scalars(
        select(Observation)
        .options(selectinload(Observation.fdr).selectinload(Fdr.institution))
        .where(Observation.status == ObservationStatus.open)
    ).all()
    for obs in open_obs:
        if obs.fdr and obs.fdr.status in OPEN_STATUSES:
            waited = (now - obs.created_at).days
            if waited > sla:
                name = obs.fdr.institution.name
                wanted[(obs.fdr_id, AlertType.observation_unanswered, obs.id)] = _Wanted(
                    Severity.warning,
                    f"FDR {obs.fdr.fdr_number} ({name}): observation has been unanswered for {_plural(waited, 'day')}.",
                    None,
                    waited,
                )

    return wanted


def run_alerts(db: Session) -> AlertRun:
    """Reconcile alerts with the current data. The caller commits."""
    # Take the audit lock first, as request paths do, so the scheduler never waits in the opposite order.
    _hold_chain_lock(db)
    wanted = _wanted_alerts(db)
    now = utcnow()
    created = resolved = 0

    existing = db.scalars(select(Alert)).all()
    open_by_key: dict[AlertKey, Alert] = {}
    user_acknowledged: set[AlertKey] = set()
    for alert in existing:
        key = (alert.fdr_id, alert.type, alert.bucket)
        if alert.acknowledged_at is None:
            open_by_key[key] = alert
        elif not alert.auto_resolved:
            user_acknowledged.add(key)

    for key, alert in open_by_key.items():
        if key not in wanted:
            alert.acknowledged_at = now
            alert.acknowledged_by_id = None
            alert.auto_resolved = True
            resolved += 1

    for key, spec in wanted.items():
        alert = open_by_key.get(key)
        if alert is not None:
            alert.severity = spec.severity
            alert.message = spec.message
            alert.due_date = spec.due_date
            alert.days = spec.days
            continue
        if key in user_acknowledged:
            continue
        fdr_id, alert_type, bucket = key
        db.add(
            Alert(
                fdr_id=fdr_id,
                type=alert_type,
                bucket=bucket,
                severity=spec.severity,
                message=spec.message,
                due_date=spec.due_date,
                days=spec.days,
                created_at=now,
            )
        )
        created += 1

    db.flush()

    # Alert escalation: flag open alerts older than escalate_after_days
    cfg = get_settings(db)
    escalate_after_days = getattr(cfg, "escalate_after_days", 3) or 3
    open_alerts_stmt = select(Alert).where(Alert.acknowledged_at.is_(None))
    for open_alert in db.scalars(open_alerts_stmt).all():
        age_days = (now - open_alert.created_at).days if open_alert.created_at else 0
        if age_days >= escalate_after_days:
            if not open_alert.escalated:
                open_alert.escalated = True
                open_alert.escalated_at = now
                write_audit(
                    db,
                    actor=None,
                    action="alert.escalated",
                    entity=AuditEntity.alert,
                    entity_id=open_alert.id,
                    fdr_id=open_alert.fdr_id,
                    detail={
                        "type": open_alert.type.value if hasattr(open_alert.type, "value") else str(open_alert.type),
                        "message": open_alert.message,
                        "age_days": age_days,
                    },
                )

    db.flush()
    open_count = db.scalar(select(func.count(Alert.id)).where(Alert.acknowledged_at.is_(None))) or 0
    return AlertRun(created=created, resolved=resolved, open=open_count)


def commit_with_alerts(db: Session) -> None:
    """Re-run the engine after a change so alerts reflect it, then commit both together."""
    run_alerts(db)
    db.commit()
