"""FastAPI application: routers, CORS, startup tasks and the built frontend."""

import asyncio
import hashlib
import importlib
import importlib.util
import logging
from collections.abc import AsyncIterator
from contextlib import asynccontextmanager, suppress

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse, JSONResponse
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func, inspect, select, text
from sqlalchemy.orm import Session

from app import models  # noqa: F401  (registers tables on Base.metadata)
from app.alerts import run_alerts
from app.config import settings
from app.db import Base, SessionLocal, engine
from app.models import Role, User
from app.routers import (
    alerts,
    approvals,
    audit,
    auth,
    dashboard,
    documents,
    fdrs,
    findings,
    imports,
    institutions,
    meta,
    metrics,
    notices,
    observations,
    radar,
)
from app.routers import settings as settings_router
from app.rules import get_settings
from app.security import hash_password

logger = logging.getLogger("fdr_portal")

# Used only when the demo seed module is not present, so sign-in always works.
_BOOTSTRAP_USERS = (
    ("Section Officer", "admin@fdrportal.demo", "Admin@2026", Role.admin),
    ("Scrutiny Officer", "reviewer@fdrportal.demo", "Review@2026", Role.reviewer),
)


def _seed_if_empty(db: Session) -> None:
    if db.scalar(select(func.count(User.id))):
        return
    if settings.auto_seed and importlib.util.find_spec("app.seed") is not None:
        importlib.import_module("app.seed").run(db)
        db.commit()
        return
    for name, email, password, role in _BOOTSTRAP_USERS:
        db.add(User(name=name, email=email, password_hash=hash_password(password), role=role))
    db.commit()


def _ensure_schema_columns(bind_engine) -> None:
    inspector = inspect(bind_engine)
    tables = set(inspector.get_table_names())
    with bind_engine.connect() as conn:
        if "users" in tables:
            cols = {c["name"] for c in inspector.get_columns("users")}
            if "institution_id" not in cols:
                conn.execute(text("ALTER TABLE users ADD COLUMN institution_id INTEGER REFERENCES institutions(id)"))
        if "settings" in tables:
            cols = {c["name"] for c in inspector.get_columns("settings")}
            if "escalate_after_days" not in cols:
                conn.execute(text("ALTER TABLE settings ADD COLUMN escalate_after_days INTEGER DEFAULT 3"))
        if "alerts" in tables:
            cols = {c["name"] for c in inspector.get_columns("alerts")}
            if "escalated" not in cols:
                conn.execute(text("ALTER TABLE alerts ADD COLUMN escalated BOOLEAN DEFAULT 0"))
            if "escalated_at" not in cols:
                conn.execute(text("ALTER TABLE alerts ADD COLUMN escalated_at DATETIME"))
        if "fdrs" in tables:
            cols = {c["name"] for c in inspector.get_columns("fdrs")}
            if "release_checklist" not in cols:
                conn.execute(text("ALTER TABLE fdrs ADD COLUMN release_checklist JSON"))
            if "release_ready" not in cols:
                conn.execute(text("ALTER TABLE fdrs ADD COLUMN release_ready BOOLEAN"))
        if "documents" in tables:
            cols = {c["name"] for c in inspector.get_columns("documents")}
            if "doc_type" not in cols:
                conn.execute(text("ALTER TABLE documents ADD COLUMN doc_type VARCHAR(32) DEFAULT 'fdr_receipt'"))
            if "sha256" not in cols:
                conn.execute(text("ALTER TABLE documents ADD COLUMN sha256 VARCHAR(64)"))
        conn.commit()


def _ensure_demo_users(db: Session) -> None:
    """Idempotently insert missing demo users for Round R."""
    if not db.scalar(select(User).where(User.email == "approver@fdrportal.demo")):
        db.add(
            User(
                name="Competent Authority",
                email="approver@fdrportal.demo",
                password_hash=hash_password("Approve@2026"),
                role=Role.approver,
            )
        )
    if not db.scalar(select(User).where(User.email == "auditor@fdrportal.demo")):
        db.add(
            User(
                name="Audit Officer",
                email="auditor@fdrportal.demo",
                password_hash=hash_password("Audit@2026"),
                role=Role.auditor,
            )
        )
    inst_specs = [
        ("deccan.crest@fdrportal.demo", "Deccan Crest"),
        ("kaveri.delta@fdrportal.demo", "Kaveri Delta"),
        ("bundelkhand.skills@fdrportal.demo", "Bundelkhand Skills"),
    ]
    for email, match_name in inst_specs:
        if not db.scalar(select(User).where(User.email == email)):
            inst = db.scalar(select(models.Institution).where(models.Institution.name.ilike(f"%{match_name}%")))
            if inst:
                db.add(
                    User(
                        name=f"Deposit Cell, {inst.name}",
                        email=email,
                        password_hash=hash_password("Inst@2026"),
                        role=Role.institution,
                        institution_id=inst.id,
                    )
                )
    db.flush()


def _backfill_document_hashes(db: Session) -> None:
    docs = db.scalars(select(models.Document).where(models.Document.sha256.is_(None))).all()
    for doc in docs:
        p = settings.upload_dir / doc.stored_name
        if p.is_file():
            doc.sha256 = hashlib.sha256(p.read_bytes()).hexdigest()
    if docs:
        db.commit()


def init_database() -> None:
    """Create tables, seed demo data on first run, then bring alerts up to date."""
    Base.metadata.create_all(bind=engine)
    _ensure_schema_columns(engine)
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    with SessionLocal() as db:
        _seed_if_empty(db)
        _ensure_demo_users(db)
        _backfill_document_hashes(db)
        get_settings(db)
        run_alerts(db)
        db.commit()


def _scheduled_alert_run() -> None:
    with SessionLocal() as db:
        run_alerts(db)
        db.commit()


async def _alert_loop() -> None:
    while True:
        await asyncio.sleep(settings.alert_interval_seconds)
        try:
            await asyncio.to_thread(_scheduled_alert_run)
        except Exception:
            logger.exception("Scheduled alert run failed")


@asynccontextmanager
async def lifespan(_app: FastAPI) -> AsyncIterator[None]:
    await asyncio.to_thread(init_database)
    task = asyncio.create_task(_alert_loop()) if settings.run_scheduler else None
    try:
        yield
    finally:
        if task is not None:
            task.cancel()
            with suppress(asyncio.CancelledError):
                await task


def _readable(exc: RequestValidationError) -> str:
    parts: list[str] = []
    for error in exc.errors():
        location = [str(p) for p in error.get("loc", ()) if p not in ("body", "query", "path")]
        message = str(error.get("msg", "Invalid value")).removeprefix("Value error, ")
        field = location[-1].replace("_", " ") if location else ""
        parts.append(f"{field.capitalize()}: {message}" if field else message)
    return "; ".join(parts) or "Invalid request"


async def _validation_handler(_request: Request, exc: RequestValidationError) -> JSONResponse:
    return JSONResponse(
        status_code=422,
        content={"detail": _readable(exc), "errors": jsonable_errors(exc)},
    )


def jsonable_errors(exc: RequestValidationError) -> list[dict[str, object]]:
    return [
        {"loc": [str(p) for p in e.get("loc", ())], "msg": str(e.get("msg", "")), "type": e.get("type", "")}
        for e in exc.errors()
    ]


def _mount_frontend(app: FastAPI) -> None:
    """Serve `frontend/dist` at `/` when a production build exists."""
    dist = settings.frontend_dist
    index = dist / "index.html"
    if not index.is_file():
        return
    if (dist / "assets").is_dir():
        app.mount("/assets", StaticFiles(directory=dist / "assets"), name="assets")

    @app.get("/{path:path}", include_in_schema=False)
    def spa(path: str) -> FileResponse:
        if path == "api" or path.startswith("api/"):
            raise HTTPException(status_code=404, detail="Not found")
        candidate = (dist / path).resolve()
        if path and candidate.is_file() and dist.resolve() in candidate.parents:
            return FileResponse(candidate)
        return FileResponse(index)


def create_app() -> FastAPI:
    app = FastAPI(
        title="Amanat API",
        version="1.0.0",
        description="Security Deposit and FDR Management Portal",
        lifespan=lifespan,
    )
    app.add_middleware(
        CORSMiddleware,
        allow_origins=settings.cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
        expose_headers=["Content-Disposition", "X-Integrity"],
    )
    app.add_exception_handler(RequestValidationError, _validation_handler)  # type: ignore[arg-type]

    @app.get("/api/health", tags=["meta"])
    def health() -> dict[str, str]:
        return {"status": "ok"}

    for module in (
        auth,
        meta,
        dashboard,
        institutions,
        fdrs,
        documents,
        approvals,
        alerts,
        settings_router,
        audit,
        radar,
        findings,
        imports,
        metrics,
        notices,
        observations,
    ):
        app.include_router(module.router, prefix="/api")

    app.include_router(notices.public_router, prefix="/api")

    _mount_frontend(app)
    return app


app = create_app()
