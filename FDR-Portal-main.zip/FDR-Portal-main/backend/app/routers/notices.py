import hashlib
import hmac
from decimal import Decimal
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session, selectinload

from app.audit import _hold_chain_lock, write_audit
from app.config import settings, today, utcnow
from app.constants import ACTIVE_STATUSES, OPEN_STATUSES
from app.db import get_db
from app.models import AuditEntity, Fdr, FdrStatus, Institution, Notice, NoticeKind, Role
from app.queries import FdrFilters, list_fdr_items
from app.rules import RuleContext, get_settings
from app.schemas import (
    FdrListItem,
    InstitutionItem,
    NoticeCandidates,
    NoticeCreateIn,
    NoticeItem,
    NoticeLetter,
    NoticeVerifyOut,
)
from app.security import AdminUser, CurrentUser

router = APIRouter(prefix="/notices", tags=["notices"])
public_router = APIRouter(prefix="/public", tags=["public"])


def compute_verify_code(ref: str, issued_at, entity_id: int | None, subject: str) -> str:
    iso = issued_at.isoformat() if hasattr(issued_at, "isoformat") else str(issued_at)
    msg = f"{ref}:{iso}:{entity_id or ''}:{subject}"
    return hmac.new(settings.secret_key.encode(), msg.encode(), hashlib.sha256).hexdigest()[:16]


@public_router.get("/verify-notice", response_model=NoticeVerifyOut)
def verify_notice(ref: str, code: str, db: Annotated[Session, Depends(get_db)]) -> NoticeVerifyOut:
    ref = (ref or "").strip()
    code = (code or "").strip()
    if not ref or not code:
        return NoticeVerifyOut(valid=False)
    notice = db.scalar(
        select(Notice)
        .options(
            selectinload(Notice.fdr).selectinload(Fdr.institution),
            selectinload(Notice.institution),
        )
        .where(Notice.reference_no == ref)
    )
    if not notice:
        return NoticeVerifyOut(valid=False)
    entity_id = notice.fdr_id or notice.institution_id
    expected = compute_verify_code(notice.reference_no, notice.issued_at, entity_id, notice.subject)
    if not hmac.compare_digest(expected.lower(), code.lower()):
        return NoticeVerifyOut(valid=False)
    inst_name = (
        notice.institution.name
        if notice.institution
        else (notice.fdr.institution.name if notice.fdr and notice.fdr.institution else None)
    )
    fdr_no = notice.fdr.fdr_number if notice.fdr else None
    return NoticeVerifyOut(
        valid=True,
        reference_no=notice.reference_no,
        kind_label=notice.kind_label,
        issued_at=notice.issued_at,
        institution_name=inst_name,
        fdr_number=fdr_no,
    )


def format_inr(amount: Decimal | float) -> str:
    """Format a rupee amount with Indian comma groupings: ₹12,50,000."""
    amt = int(round(float(amount)))
    s = str(amt)
    if len(s) <= 3:
        return f"₹{s}"
    last3 = s[-3:]
    rest = s[:-3]
    parts = []
    while len(rest) > 2:
        parts.insert(0, rest[-2:])
        rest = rest[:-2]
    if rest:
        parts.insert(0, rest)
    parts.append(last3)
    return f"₹{','.join(parts)}"


def display_date(d) -> str:
    return d.strftime("%d %b %Y")


def _serialize_notice(n: Notice) -> NoticeItem:
    fdr_number = n.fdr.fdr_number if n.fdr else None
    inst_name = n.institution.name if n.institution else (n.fdr.institution.name if n.fdr else "")
    issued_by_name = n.issued_by.name if n.issued_by else "System"
    entity_id = n.fdr_id or n.institution_id
    code = compute_verify_code(n.reference_no, n.issued_at, entity_id, n.subject)
    return NoticeItem(
        id=n.id,
        reference_no=n.reference_no,
        kind=n.kind,
        kind_label=n.kind_label,
        issued_at=n.issued_at,
        issued_by=issued_by_name,
        fdr_id=n.fdr_id,
        fdr_number=fdr_number,
        institution_id=n.institution_id,
        institution_name=inst_name,
        letter=NoticeLetter(
            subject=n.subject,
            salutation=n.salutation,
            body=n.body,
            closing=n.closing,
        ),
        verify_code=code,
    )


@router.get("/candidates", response_model=NoticeCandidates)
def candidates(db: Annotated[Session, Depends(get_db)], user: CurrentUser) -> NoticeCandidates:
    if user.role == Role.institution:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Notice candidates are not available for institutions",
        )
    ctx = RuleContext.load(db)
    cfg = get_settings(db)
    reminder_days = sorted({int(d) for d in cfg.reminder_days if int(d) > 0})
    max_reminder = max(reminder_days) if reminder_days else 90

    all_items = [item for _, item in list_fdr_items(db, FdrFilters(), ctx)]
    open_items = [i for i in all_items if i.status in OPEN_STATUSES]

    # Maturity candidates: open, due within max reminder day
    maturity = [i for i in open_items if 0 <= i.days_to_maturity <= max_reminder]

    # Overdue candidates: matured and open
    overdue = [i for i in open_items if i.days_to_maturity < 0]

    # Shortfall candidates: institutions with shortfall > 0
    institutions = db.scalars(select(Institution).order_by(Institution.name)).all()
    from collections import defaultdict
    by_inst: dict[int, list[FdrListItem]] = defaultdict(list)
    for i in all_items:
        by_inst[i.institution_id].append(i)

    shortfall_items: list[InstitutionItem] = []
    for inst in institutions:
        sf = ctx.shortfall(inst.id)
        if sf > 0:
            fdrs = by_inst[inst.id]
            open_scores = [f.health_score for f in fdrs if f.status in OPEN_STATUSES]
            shortfall_items.append(
                InstitutionItem(
                    id=inst.id,
                    name=inst.name,
                    aicte_id=inst.aicte_id,
                    city=inst.city,
                    state=inst.state,
                    type=inst.type,
                    required_deposit=float(inst.required_deposit),
                    fdr_count=len(fdrs),
                    active_amount=sum(f.amount for f in fdrs if f.status in ACTIVE_STATUSES),
                    health_score=round(sum(open_scores) / len(open_scores)) if open_scores else None,
                    shortfall=sf,
                )
            )

    return NoticeCandidates(maturity=maturity, overdue=overdue, shortfall=shortfall_items)


@router.post("", response_model=NoticeItem, status_code=status.HTTP_201_CREATED)
def issue_notice(body: NoticeCreateIn, db: Annotated[Session, Depends(get_db)], user: AdminUser) -> NoticeItem:
    # Exactly one of fdr_id or institution_id
    if (body.fdr_id is None and body.institution_id is None) or (
        body.fdr_id is not None and body.institution_id is not None
    ):
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Exactly one of fdr_id or institution_id must be provided",
        )

    fdr: Fdr | None = None
    inst: Institution | None = None

    if body.kind == NoticeKind.shortfall_notice:
        if body.institution_id is None:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Shortfall notice requires institution_id",
            )
        inst = db.get(Institution, body.institution_id)
        if inst is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Institution not found")
    else:
        if body.fdr_id is None:
            label = body.kind.replace("_", " ").capitalize()
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"{label} requires fdr_id",
            )
        fdr = db.get(Fdr, body.fdr_id, options=[selectinload(Fdr.institution)])
        if fdr is None:
            raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="FDR not found")
        inst = fdr.institution
        if body.kind == NoticeKind.release_letter and fdr.status != FdrStatus.released:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Release letter can only be issued for released deposits",
            )

    now = utcnow()
    # Hold the audit lock before reading the sequence so two quick requests cannot share a number.
    _hold_chain_lock(db)
    next_seq = (db.scalar(select(func.coalesce(func.max(Notice.id), 0))) or 0) + 1
    ref_no = f"FDRP/NOT/{today().year}/{next_seq:04d}"

    salutation = f"To the Principal / Director, {inst.name}, {inst.city}, {inst.state}"
    closing = "Yours faithfully,\n\nSection Officer, Regulation Bureau"

    if body.kind == NoticeKind.maturity_reminder:
        kind_label = "Maturity reminder"
        subject = f"Maturity of security deposit FDR No. {fdr.fdr_number}"
        branch = f", {fdr.branch}" if fdr.branch else ""
        letter_body = [
            f"Our register shows that Fixed Deposit Receipt No. {fdr.fdr_number} of {fdr.bank_name}{branch},"
            f" for {format_inr(fdr.amount)}, held as security deposit for {inst.name}, matures on"
            f" {display_date(fdr.maturity_date)}.",
            f"Please arrange with {fdr.bank_name} to renew the deposit, or to replace it with a fresh FDR,"
            " before the maturity date, with the lien or joint name in favour of AICTE continued.",
            "Kindly send a copy of the renewed or replacement receipt to this Bureau so that the register"
            " can be updated.",
        ]
    elif body.kind == NoticeKind.overdue_notice:
        kind_label = "Overdue notice"
        subject = f"Matured security deposit FDR No. {fdr.fdr_number}: renewal awaited"
        letter_body = [
            f"Fixed Deposit Receipt No. {fdr.fdr_number} of {fdr.bank_name}, for {format_inr(fdr.amount)},"
            f" held as security deposit for {inst.name}, matured on {display_date(fdr.maturity_date)}."
            " Our register does not show a renewal or replacement.",
            "Please renew the deposit or furnish a replacement FDR with the lien or joint name in favour of"
            " AICTE, and send a copy of the receipt to this Bureau within fifteen days of this letter.",
            "If the deposit has already been renewed, please send the renewed receipt so that the register"
            " can be corrected.",
        ]
    elif body.kind == NoticeKind.shortfall_notice:
        kind_label = "Shortfall notice"
        subject = f"Shortfall in security deposit: {inst.name} ({inst.aicte_id})"
        ctx = RuleContext.load(db)
        held_amount = ctx.held_by_institution.get(inst.id, 0.0)
        shortfall = ctx.shortfall(inst.id)
        letter_body = [
            f"The security deposit recorded as required for {inst.name} is {format_inr(inst.required_deposit)}."
            f" Deposits held in our register total {format_inr(held_amount)}, which is"
            f" {format_inr(shortfall)} short of the required amount.",
            f"Please furnish an additional FDR for at least {format_inr(shortfall)}, with the lien or joint"
            " name in favour of AICTE, and send a copy of the receipt to this Bureau within thirty days of"
            " this letter.",
            "If a deposit has been made that is not reflected above, please send its receipt so that the"
            " register can be corrected.",
        ]
    elif body.kind == NoticeKind.release_letter:
        kind_label = "Release letter"
        subject = f"Release of security deposit FDR No. {fdr.fdr_number}"
        letter_body = [
            f"The request for release of Fixed Deposit Receipt No. {fdr.fdr_number} of {fdr.bank_name},"
            f" for {format_inr(fdr.amount)}, held as security deposit for {inst.name}, has been approved"
            " and the deposit is marked as released in our register.",
            f"The lien or joint name in favour of AICTE on this deposit may now be discharged with"
            f" {fdr.bank_name}. Please quote the reference number above in any correspondence with the bank.",
        ]
    else:
        raise HTTPException(status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="Invalid notice kind")

    notice = Notice(
        reference_no=ref_no,
        kind=body.kind,
        kind_label=kind_label,
        issued_at=now,
        issued_by_id=user.id,
        fdr_id=fdr.id if fdr else None,
        institution_id=inst.id if inst else None,
        subject=subject,
        salutation=salutation,
        body=letter_body,
        closing=closing,
    )
    db.add(notice)
    db.flush()

    write_audit(
        db,
        actor=user,
        action="notice.issued",
        entity=AuditEntity.notice,
        entity_id=notice.id,
        fdr_id=notice.fdr_id,
        detail={
            "reference_no": notice.reference_no,
            "kind": notice.kind.value,
            "institution_id": inst.id if inst else None,
        },
    )
    db.commit()
    db.refresh(notice)
    return _serialize_notice(notice)


@router.get("", response_model=list[NoticeItem])
def list_notices(
    db: Annotated[Session, Depends(get_db)],
    user: CurrentUser,
    fdr_id: int | None = None,
    institution_id: int | None = None,
) -> list[NoticeItem]:
    stmt = (
        select(Notice)
        .options(
            selectinload(Notice.fdr).selectinload(Fdr.institution),
            selectinload(Notice.institution),
            selectinload(Notice.issued_by),
        )
        .order_by(Notice.id.desc())
    )
    if user.role == Role.institution:
        stmt = stmt.where(
            or_(
                Notice.institution_id == user.institution_id,
                Notice.fdr.has(Fdr.institution_id == user.institution_id),
            )
        )
    elif institution_id is not None:
        stmt = stmt.where(Notice.institution_id == institution_id)
    if fdr_id is not None:
        stmt = stmt.where(Notice.fdr_id == fdr_id)
    notices = db.scalars(stmt).all()
    return [_serialize_notice(n) for n in notices]
