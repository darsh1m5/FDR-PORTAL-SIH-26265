"""Alerts centre: list, acknowledge, run the engine now."""

from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import case, select
from sqlalchemy.orm import Session, selectinload

from app.alerts import run_alerts
from app.audit import write_audit
from app.config import utcnow
from app.db import get_db
from app.models import Alert, AlertType, AuditEntity, Fdr, Role, Severity
from app.schemas import AlertItem, AlertRunOut
from app.security import AdminUser, CurrentUser
from app.serializers import alert_item

router = APIRouter(prefix="/alerts", tags=["alerts"])

Db = Annotated[Session, Depends(get_db)]

_SEVERITY_RANK = case(
    (Alert.severity == Severity.critical, 0),
    (Alert.severity == Severity.warning, 1),
    else_=2,
)


def _options():  # type: ignore[no-untyped-def]
    return [
        selectinload(Alert.fdr).selectinload(Fdr.institution),
        selectinload(Alert.acknowledged_by),
    ]


@router.get("", response_model=list[AlertItem])
def list_alerts(
    db: Db,
    user: CurrentUser,
    state: Literal["open", "acknowledged", "all"] = "open",
    severity: Severity | None = None,
    type: AlertType | None = None,
) -> list[AlertItem]:
    stmt = select(Alert).options(*_options())
    if user.role == Role.institution:
        stmt = stmt.join(Alert.fdr).where(Fdr.institution_id == user.institution_id)
    if state == "open":
        stmt = stmt.where(Alert.acknowledged_at.is_(None))
    elif state == "acknowledged":
        stmt = stmt.where(Alert.acknowledged_at.is_not(None))
    if severity is not None:
        stmt = stmt.where(Alert.severity == severity)
    if type is not None:
        stmt = stmt.where(Alert.type == type)
    if state == "open":
        stmt = stmt.order_by(_SEVERITY_RANK, Alert.escalated.desc(), Alert.days.is_(None), Alert.days, Alert.id)
    else:
        stmt = stmt.order_by(Alert.acknowledged_at.is_(None).desc(), Alert.acknowledged_at.desc(), Alert.id.desc())
    return [alert_item(a) for a in db.scalars(stmt).all()]


@router.post("/{alert_id}/acknowledge", response_model=AlertItem)
def acknowledge(alert_id: int, db: Db, user: CurrentUser) -> AlertItem:
    if user.role == Role.auditor:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Auditors cannot acknowledge alerts",
        )
    alert = db.get(Alert, alert_id, options=_options())
    if alert is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")
    if user.role == Role.institution and alert.fdr.institution_id != user.institution_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Alert not found")
    if alert.acknowledged_at is not None:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="Alert is already acknowledged")
    alert.acknowledged_at = utcnow()
    alert.acknowledged_by_id = user.id
    db.flush()
    write_audit(
        db,
        actor=user,
        action="alert.acknowledged",
        entity=AuditEntity.alert,
        entity_id=alert.id,
        fdr_id=alert.fdr_id,
        detail={"type": alert.type, "message": alert.message},
    )
    db.commit()
    db.refresh(alert)
    return alert_item(alert)


@router.post("/run", response_model=AlertRunOut)
def run_now(db: Db, user: AdminUser) -> AlertRunOut:
    result = run_alerts(db)
    write_audit(
        db,
        actor=user,
        action="alert.run",
        entity=AuditEntity.alert,
        detail={"created": result.created, "resolved": result.resolved, "open": result.open},
    )
    db.commit()
    return AlertRunOut(created=result.created, resolved=result.resolved, open=result.open)
