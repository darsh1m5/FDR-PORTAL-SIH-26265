"""Bulk import FDRs from spreadsheet (CSV)."""

import csv
import io
import uuid
from datetime import date, datetime
from decimal import Decimal
from typing import Annotated

from fastapi import (
    APIRouter,
    Depends,
    File,
    HTTPException,
    Response,
    UploadFile,
    status,
)
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.alerts import commit_with_alerts
from app.audit import write_audit
from app.constants import BANKS, IFSC_RE
from app.db import get_db
from app.models import AuditEntity, Fdr, FdrStatus, Institution, Purpose, Verification
from pydantic import ValidationError

from app.security import AdminUser
from app.rules import (
    RuleContext,
    Severity,
    _number_key,
    projected_value,
)
from app.schemas import (
    FdrInput,
    Finding,
    ImportCommitIn,
    ImportCommitOut,
    ImportPreview,
    ImportRow,
)

router = APIRouter(prefix="/imports", tags=["imports"])

Db = Annotated[Session, Depends(get_db)]
MAX_ROWS = 500

CSV_HEADER = [
    "FDR number",
    "AICTE ID",
    "Bank",
    "Branch",
    "IFSC",
    "Amount (INR)",
    "Issue date",
    "Maturity date",
    "Interest rate (% p.a.)",
    "Printed maturity amount (INR)",
    "Purpose",
    "Lien to AICTE",
    "Remarks",
]
CSV_BOM = b"\xef\xbb\xbf"

_BANK_SHORT_FORMS: dict[str, str] = {
    "sbi": "State Bank of India",
    "state bank of india": "State Bank of India",
    "state bank": "State Bank of India",
    "bob": "Bank of Baroda",
    "bank of baroda": "Bank of Baroda",
    "pnb": "Punjab National Bank",
    "punjab national bank": "Punjab National Bank",
    "canara": "Canara Bank",
    "canara bank": "Canara Bank",
    "union": "Union Bank of India",
    "union bank": "Union Bank of India",
    "union bank of india": "Union Bank of India",
    "boi": "Bank of India",
    "bank of india": "Bank of India",
    "indian bank": "Indian Bank",
    "hdfc": "HDFC Bank",
    "hdfc bank": "HDFC Bank",
    "icici": "ICICI Bank",
    "icici bank": "ICICI Bank",
    "axis": "Axis Bank",
    "axis bank": "Axis Bank",
    "kotak": "Kotak Mahindra Bank",
    "kotak mahindra": "Kotak Mahindra Bank",
    "kotak mahindra bank": "Kotak Mahindra Bank",
    "idbi": "IDBI Bank",
    "idbi bank": "IDBI Bank",
    "indusind": "IndusInd Bank",
    "indusind bank": "IndusInd Bank",
    "yes": "Yes Bank",
    "yes bank": "Yes Bank",
    "federal": "Federal Bank",
    "federal bank": "Federal Bank",
    "cbi": "Central Bank of India",
    "central bank": "Central Bank of India",
    "central bank of india": "Central Bank of India",
    "iob": "Indian Overseas Bank",
    "indian overseas bank": "Indian Overseas Bank",
    "uco": "UCO Bank",
    "uco bank": "UCO Bank",
    "bom": "Bank of Maharashtra",
    "bank of maharashtra": "Bank of Maharashtra",
    "psb": "Punjab & Sind Bank",
    "punjab & sind bank": "Punjab & Sind Bank",
    "punjab and sind bank": "Punjab & Sind Bank",
}

_PURPOSE_MAP: dict[str, Purpose] = {
    "security_deposit": Purpose.security_deposit,
    "security deposit": Purpose.security_deposit,
    "additional_intake": Purpose.additional_intake,
    "additional intake": Purpose.additional_intake,
    "performance_security": Purpose.performance_security,
    "performance security": Purpose.performance_security,
    "other": Purpose.other,
}


def _resolve_bank(raw: str) -> str | None:
    norm = raw.strip().lower()
    if norm in _BANK_SHORT_FORMS:
        return _BANK_SHORT_FORMS[norm]
    for b in BANKS:
        if b.lower() == norm:
            return b
    return None


def _resolve_purpose(raw: str) -> Purpose | None:
    norm = raw.strip().lower()
    if not norm:
        return Purpose.security_deposit
    return _PURPOSE_MAP.get(norm)


def _resolve_lien(raw: str) -> bool:
    norm = raw.strip().lower()
    return norm in ("yes", "y", "true", "1")


def _parse_date(value: str) -> date | None:
    val = value.strip()
    if not val:
        return None
    for fmt in (
        "%Y-%m-%d",
        "%d/%m/%Y",
        "%d-%m-%Y",
        "%d %b %Y",
        "%d %B %Y",
        "%d-%b-%Y",
        "%d/%m/%y",
        "%d-%m-%y",
    ):
        try:
            return datetime.strptime(val, fmt).date()
        except ValueError:
            continue
    return None


@router.get("/template.csv")
def get_template(_user: AdminUser) -> Response:
    output = io.StringIO()
    writer = csv.writer(output)
    writer.writerow(CSV_HEADER)
    content = CSV_BOM + output.getvalue().encode("utf-8")
    return Response(
        content=content,
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition": 'attachment; filename="fdr-import-template.csv"'
        },
    )


@router.post("/preview", response_model=ImportPreview)
async def preview_import(
    db: Db,
    _user: AdminUser,
    file: UploadFile = File(...),
) -> ImportPreview:
    content = await file.read(2 * 1024 * 1024 + 1)
    if len(content) > 2 * 1024 * 1024:
        raise HTTPException(
            status_code=status.HTTP_413_REQUEST_ENTITY_TOO_LARGE,
            detail="File size exceeds the 2 MB limit",
        )
    if not content:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY, detail="The file is empty"
        )

    try:
        text = content.decode("utf-8-sig")
    except UnicodeDecodeError:
        try:
            text = content.decode("latin-1")
        except UnicodeDecodeError as exc:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail="Unable to decode file. Please upload a UTF-8 CSV.",
            ) from exc

    try:
        reader = list(csv.reader(io.StringIO(text)))
    except csv.Error as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"The file is not a readable CSV: {exc}",
        ) from exc
    if not reader:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="The CSV file is empty",
        )

    header = [h.strip() for h in reader[0]]
    data_rows = [r for r in reader[1:] if any(cell.strip() for cell in r)]
    if len(data_rows) > MAX_ROWS:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="Spreadsheet contains more than 500 rows",
        )

    # Column index resolution: the exact template header wins; keywords are only a fallback,
    # skipping columns already claimed, so "Lien to AICTE" can never be read as "AICTE ID".
    lowered = [h.lower() for h in header]
    claimed: set[int] = {
        i for i, h in enumerate(lowered) if h in {c.lower() for c in CSV_HEADER}
    }

    def find_idx(*keywords: str) -> int | None:
        exact = keywords[0]
        if exact in lowered:
            return lowered.index(exact)
        for i, col_l in enumerate(lowered):
            if i not in claimed and any(k in col_l for k in keywords[1:]):
                claimed.add(i)
                return i
        return None

    idx_fdr = find_idx("fdr number", "fdr_number", "receipt no", "fdr no")
    idx_aicte = find_idx("aicte id", "aicte_id", "aicte code", "permanent id")
    idx_bank = find_idx("bank", "bank name")
    idx_branch = find_idx("branch", "branch")
    idx_ifsc = find_idx("ifsc", "ifsc")
    idx_amount = find_idx("amount (inr)", "principal", "deposit amount")
    idx_issue = find_idx("issue date", "issue_date", "date of issue")
    idx_maturity = find_idx("maturity date", "maturity_date", "date of maturity")
    idx_rate = find_idx("interest rate (% p.a.)", "interest rate", "rate")
    idx_printed = find_idx(
        "printed maturity amount (inr)", "printed maturity", "maturity value"
    )
    idx_purpose = find_idx("purpose", "purpose")
    idx_lien = find_idx("lien to aicte", "lien")
    idx_remarks = find_idx("remarks", "remark")

    # Preload institutions
    institutions_by_aicte: dict[str, Institution] = {
        inst.aicte_id.strip(): inst for inst in db.scalars(select(Institution)).all()
    }
    ctx = RuleContext.load(db)

    # Count occurrences within file for duplicate detection
    file_duplicates: dict[tuple[str, str], int] = {}
    for r in data_rows:
        num = (
            r[idx_fdr].strip().upper()
            if idx_fdr is not None and idx_fdr < len(r)
            else ""
        )
        b_raw = (
            r[idx_bank].strip() if idx_bank is not None and idx_bank < len(r) else ""
        )
        b_res = _resolve_bank(b_raw) or b_raw
        if num and b_res:
            key = _number_key(num, b_res)
            file_duplicates[key] = file_duplicates.get(key, 0) + 1

    rows_out: list[ImportRow] = []
    valid_count = 0
    warning_count = 0
    error_count = 0

    for row_idx, r in enumerate(data_rows, start=1):
        errors: list[str] = []
        findings: list[Finding] = []

        def get_val(idx: int | None) -> str:
            if idx is not None and idx < len(r):
                return r[idx].strip()
            return ""

        raw_fdr = get_val(idx_fdr)
        raw_aicte = get_val(idx_aicte)
        raw_bank = get_val(idx_bank)
        raw_branch = get_val(idx_branch) or None
        raw_ifsc = get_val(idx_ifsc) or None
        raw_amount = get_val(idx_amount)
        raw_issue = get_val(idx_issue)
        raw_maturity = get_val(idx_maturity)
        raw_rate = get_val(idx_rate)
        raw_printed = get_val(idx_printed)
        raw_purpose = get_val(idx_purpose)
        raw_lien = get_val(idx_lien)
        raw_remarks = get_val(idx_remarks) or None

        if not raw_fdr:
            errors.append("FDR number cannot be empty")

        inst = institutions_by_aicte.get(raw_aicte)
        if not raw_aicte:
            errors.append("AICTE ID cannot be empty")
        elif not inst:
            errors.append(f"Unknown AICTE ID '{raw_aicte}'")

        resolved_bank = _resolve_bank(raw_bank) if raw_bank else None
        if not raw_bank:
            errors.append("Bank cannot be empty")
        elif not resolved_bank:
            errors.append(f"Unknown bank '{raw_bank}'")

        amount_val: float | None = None
        try:
            cleaned_amt = raw_amount.replace(",", "").replace("₹", "").strip()
            amount_val = float(cleaned_amt)
            if amount_val <= 0:
                errors.append("Amount must be greater than zero")
        except ValueError:
            errors.append(f"Invalid amount '{raw_amount}'")

        issue_val = _parse_date(raw_issue)
        if not raw_issue:
            errors.append("Issue date cannot be empty")
        elif not issue_val:
            errors.append(f"Invalid issue date '{raw_issue}'")

        maturity_val = _parse_date(raw_maturity)
        if not raw_maturity:
            errors.append("Maturity date cannot be empty")
        elif not maturity_val:
            errors.append(f"Invalid maturity date '{raw_maturity}'")

        if issue_val and maturity_val and maturity_val <= issue_val:
            errors.append("Maturity date must be after issue date")

        rate_val: float | None = None
        try:
            cleaned_rate = raw_rate.replace("%", "").strip()
            rate_val = float(cleaned_rate)
            if not 0 < rate_val <= 20:
                errors.append("Interest rate must be above 0 and at most 20% p.a.")
        except ValueError:
            errors.append(f"Invalid interest rate '{raw_rate}'")

        printed_val: float | None = None
        if raw_printed:
            try:
                cleaned_p = raw_printed.replace(",", "").replace("₹", "").strip()
                printed_val = float(cleaned_p)
            except ValueError:
                errors.append(f"Invalid printed maturity amount '{raw_printed}'")

        purpose_val = _resolve_purpose(raw_purpose)
        if raw_purpose and not purpose_val:
            errors.append(f"Invalid purpose '{raw_purpose}'")
        purpose_val = purpose_val or Purpose.security_deposit

        lien_val = _resolve_lien(raw_lien)

        if raw_ifsc and not IFSC_RE.match(raw_ifsc):
            errors.append(f"Invalid IFSC format '{raw_ifsc}'")

        if errors:
            rows_out.append(
                ImportRow(
                    row=row_idx,
                    status="error",
                    data=None,
                    institution_name=inst.name if inst else None,
                    errors=errors,
                    findings=[],
                )
            )
            error_count += 1
            continue

        # Valid input object
        assert inst is not None
        assert resolved_bank is not None
        assert amount_val is not None
        assert issue_val is not None
        assert maturity_val is not None
        assert rate_val is not None

        try:
            fdr_input = FdrInput(
                fdr_number=raw_fdr,
                institution_id=inst.id,
                bank_name=resolved_bank,
                branch=raw_branch,
                ifsc=raw_ifsc,
                amount=amount_val,
                issue_date=issue_val,
                maturity_date=maturity_val,
                interest_rate=rate_val,
                maturity_amount=printed_val,
                purpose=purpose_val,
                lien_to_aicte=lien_val,
                remarks=raw_remarks,
            )
        except ValidationError as exc:
            messages = [
                str(e.get("msg", "Invalid value")).removeprefix("Value error, ")
                for e in exc.errors()
            ]
            fields = [
                str(e["loc"][-1]).replace("_", " ")
                for e in exc.errors()
                if e.get("loc")
            ]
            rows_out.append(
                ImportRow(
                    row=row_idx,
                    status="error",
                    data=None,
                    institution_name=inst.name,
                    errors=[f"{f.capitalize()}: {m}" for f, m in zip(fields, messages, strict=False)]
                    or messages,
                    findings=[],
                )
            )
            error_count += 1
            continue

        # Health Check findings for row
        key = _number_key(raw_fdr, resolved_bank)
        if ctx.duplicates.get(key, 0) > 0 or file_duplicates.get(key, 0) > 1:
            findings.append(
                Finding(
                    code="DUPLICATE_NUMBER",
                    severity=Severity.critical,
                    message=f"Duplicate deposit number {raw_fdr} at {resolved_bank}.",
                    fix="Confirm against the paper receipt and update the deposit number.",
                )
            )

        if not lien_val:
            findings.append(
                Finding(
                    code="NO_LIEN",
                    severity=Severity.warning,
                    message="Lien or joint name in favour of AICTE is not marked.",
                    fix="Get the bank to mark a lien to AICTE, then update the record.",
                )
            )

        if rate_val < ctx.interest_min or rate_val > ctx.interest_max:
            findings.append(
                Finding(
                    code="RATE_OUT_OF_BAND",
                    severity=Severity.info,
                    message=f"Interest rate {rate_val:.2f}% is outside expected {ctx.interest_min:.2f}-{ctx.interest_max:.2f}% band.",
                    fix="Confirm the rate on the receipt.",
                )
            )

        if printed_val is not None and issue_val < maturity_val:
            computed = projected_value(amount_val, rate_val, issue_val, maturity_val)
            if computed > 0 and abs(printed_val - computed) / computed > 0.01:
                findings.append(
                    Finding(
                        code="VALUE_MISMATCH",
                        severity=Severity.warning,
                        message="Printed maturity amount differs from the value computed with quarterly compounding.",
                        fix="Check the rate, dates and amount against receipt.",
                    )
                )

        if ctx.shortfall(inst.id) > 0:
            findings.append(
                Finding(
                    code="BELOW_REQUIRED",
                    severity=Severity.warning,
                    message="Institution's deposits held are below the required amount.",
                    fix="Collect the remaining security deposit to meet regulatory requirements.",
                )
            )

        row_status = "warning" if findings else "valid"
        if row_status == "warning":
            warning_count += 1
        else:
            valid_count += 1

        rows_out.append(
            ImportRow(
                row=row_idx,
                status=row_status,
                data=fdr_input,
                institution_name=inst.name,
                errors=[],
                findings=findings,
            )
        )

    return ImportPreview(
        rows=rows_out,
        valid_count=valid_count,
        warning_count=warning_count,
        error_count=error_count,
    )


@router.post("/commit", response_model=ImportCommitOut)
def commit_import(
    body: ImportCommitIn,
    db: Db,
    user: AdminUser,
) -> ImportCommitOut:
    if not body.rows:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No rows provided for import",
        )

    batch = f"IMP-{datetime.now().strftime('%Y%m%d%H%M%S')}-{uuid.uuid4().hex[:6]}"
    institutions_by_id = {
        inst.id: inst for inst in db.scalars(select(Institution)).all()
    }

    # Re-validate all rows server-side
    for idx, row in enumerate(body.rows, start=1):
        if not row.fdr_number or not row.fdr_number.strip():
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Row {idx}: FDR number cannot be empty",
            )
        if row.institution_id not in institutions_by_id:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Row {idx}: Unknown institution ID {row.institution_id}",
            )
        if row.bank_name not in BANKS and not _resolve_bank(row.bank_name):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Row {idx}: Unknown bank '{row.bank_name}'",
            )
        if row.amount <= 0:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Row {idx}: Amount must be greater than zero",
            )
        if row.maturity_date <= row.issue_date:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Row {idx}: Maturity date must be after issue date",
            )
        if row.interest_rate < 0:
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Row {idx}: Interest rate cannot be negative",
            )
        if row.ifsc and not IFSC_RE.match(row.ifsc):
            raise HTTPException(
                status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
                detail=f"Row {idx}: Invalid IFSC format '{row.ifsc}'",
            )

    created_ids: list[int] = []
    for row in body.rows:
        bank = _resolve_bank(row.bank_name) or row.bank_name
        fdr = Fdr(
            fdr_number=row.fdr_number.strip(),
            institution_id=row.institution_id,
            bank_name=bank,
            branch=row.branch.strip() if row.branch else None,
            ifsc=row.ifsc.strip().upper() if row.ifsc else None,
            amount=Decimal(str(row.amount)),
            issue_date=row.issue_date,
            maturity_date=row.maturity_date,
            interest_rate=Decimal(str(row.interest_rate)),
            maturity_amount=Decimal(str(row.maturity_amount))
            if row.maturity_amount is not None
            else None,
            purpose=row.purpose,
            lien_to_aicte=row.lien_to_aicte,
            remarks=row.remarks.strip() if row.remarks else None,
            status=FdrStatus.draft,
            verification=Verification.submitted,
            created_by_id=user.id,
        )
        db.add(fdr)
        db.flush()
        created_ids.append(fdr.id)

        write_audit(
            db,
            actor=user,
            action="fdr.created",
            entity=AuditEntity.fdr,
            entity_id=fdr.id,
            fdr_id=fdr.id,
            to_status=fdr.status,
            detail={"imported": True, "batch": batch, "source_name": body.source_name},
        )

    # One import.committed audit row
    write_audit(
        db,
        actor=user,
        action="import.committed",
        entity=AuditEntity.import_entity,
        entity_id=None,
        detail={
            "batch": batch,
            "source_name": body.source_name,
            "count": len(created_ids),
            "ids": created_ids,
        },
    )

    commit_with_alerts(db)

    return ImportCommitOut(
        created=len(created_ids),
        batch=batch,
        ids=created_ids,
    )
