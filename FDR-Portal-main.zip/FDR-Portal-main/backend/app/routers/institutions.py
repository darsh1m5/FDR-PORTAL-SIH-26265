"""Institutions with their deposits, score and shortfall against the required deposit."""

from collections import defaultdict
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from app.alerts import commit_with_alerts
from app.audit import write_audit
from app.constants import ACTIVE_STATUSES, OPEN_STATUSES
from app.db import get_db
from app.models import AuditEntity, Institution, Role, User
from app.queries import FdrFilters, list_fdr_items
from app.rules import RuleContext
from app.schemas import FdrListItem, InstitutionDetail, InstitutionInput, InstitutionItem
from app.security import AdminUser, CurrentUser

router = APIRouter(prefix="/institutions", tags=["institutions"])

Db = Annotated[Session, Depends(get_db)]


def _item(inst: Institution, fdrs: list[FdrListItem], ctx: RuleContext) -> InstitutionItem:
    open_scores = [f.health_score for f in fdrs if f.status in OPEN_STATUSES]
    return InstitutionItem(
        id=inst.id,
        name=inst.name,
        aicte_id=inst.aicte_id,
        city=inst.city,
        state=inst.state,
        type=inst.type,
        required_deposit=float(inst.required_deposit),
        fdr_count=len(fdrs),
        active_amount=sum(f.amount for f in fdrs if f.status in ACTIVE_STATUSES),
        health_score=round(sum(open_scores) / len(open_scores)) if open_scores else None,
        shortfall=ctx.shortfall(inst.id),
    )


@router.get("", response_model=list[InstitutionItem])
def list_institutions(db: Db, user: CurrentUser, q: str | None = None) -> list[InstitutionItem]:
    if user.role == Role.institution:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Institutions list is not available for institutions",
        )
    ctx = RuleContext.load(db)
    stmt = select(Institution).order_by(Institution.name)
    if q and q.strip():
        needle = f"%{q.strip()}%"
        stmt = stmt.where(
            or_(
                Institution.name.ilike(needle),
                Institution.aicte_id.ilike(needle),
                Institution.city.ilike(needle),
                Institution.state.ilike(needle),
            )
        )
    institutions = db.scalars(stmt).all()
    by_institution: dict[int, list[FdrListItem]] = defaultdict(list)
    for _, item in list_fdr_items(db, FdrFilters(), ctx):
        by_institution[item.institution_id].append(item)
    return [_item(inst, by_institution[inst.id], ctx) for inst in institutions]


@router.get("/{institution_id}", response_model=InstitutionDetail)
def get_institution(institution_id: int, db: Db, user: CurrentUser) -> InstitutionDetail:
    if user.role == Role.institution and user.institution_id != institution_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Institution not found")
    inst = db.get(Institution, institution_id)
    if inst is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Institution not found")
    ctx = RuleContext.load(db)
    fdrs = [item for _, item in list_fdr_items(db, FdrFilters(institution_id=inst.id), ctx)]
    users_cnt = db.scalar(select(func.count(User.id)).where(User.institution_id == inst.id)) or 0
    return InstitutionDetail(**_item(inst, fdrs, ctx).model_dump(), fdrs=fdrs, users_count=users_cnt)


@router.post("", response_model=InstitutionItem, status_code=status.HTTP_201_CREATED)
def create_institution(body: InstitutionInput, db: Db, user: AdminUser) -> InstitutionItem:
    exists = db.scalar(
        select(func.count(Institution.id)).where(func.lower(Institution.aicte_id) == body.aicte_id.lower())
    )
    if exists:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="An institution with this AICTE ID already exists")
    inst = Institution(**body.model_dump())
    db.add(inst)
    db.flush()
    write_audit(
        db,
        actor=user,
        action="institution.created",
        entity=AuditEntity.institution,
        entity_id=inst.id,
        detail={"name": inst.name, "aicte_id": inst.aicte_id},
    )
    commit_with_alerts(db)
    return _item(inst, [], RuleContext.load(db))
