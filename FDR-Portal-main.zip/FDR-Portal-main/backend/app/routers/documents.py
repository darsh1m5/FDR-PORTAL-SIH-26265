import hashlib
import uuid
from pathlib import Path
from typing import Annotated

from fastapi import APIRouter, Depends, Form, HTTPException, UploadFile, status
from fastapi.responses import FileResponse
from sqlalchemy.orm import Session, selectinload

from app.alerts import commit_with_alerts
from app.audit import write_audit
from app.config import settings
from app.db import get_db
from app.models import AuditEntity, Document, DocumentType, FdrStatus, Role
from app.routers.fdrs import load_fdr
from app.schemas import DocumentItem
from app.security import AdminOrInstitutionUser, CurrentUser
from app.serializers import document_item

router = APIRouter(tags=["documents"])

Db = Annotated[Session, Depends(get_db)]

ALLOWED_TYPES: dict[str, str] = {
    "application/pdf": ".pdf",
    "image/jpeg": ".jpg",
    "image/png": ".png",
}
_EXTENSION_TYPES = {".pdf": "application/pdf", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png"}
_SIGNATURES: dict[str, tuple[bytes, ...]] = {
    "application/pdf": (b"%PDF",),
    "image/jpeg": (b"\xff\xd8\xff",),
    "image/png": (b"\x89PNG\r\n\x1a\n",),
}


def _content_type(upload: UploadFile) -> str:
    declared = (upload.content_type or "").lower()
    if declared == "image/jpg":
        declared = "image/jpeg"
    if declared in ALLOWED_TYPES:
        return declared
    by_extension = _EXTENSION_TYPES.get(Path(upload.filename or "").suffix.lower())
    if by_extension:
        return by_extension
    raise HTTPException(status_code=415, detail="Only PDF, JPG or PNG files can be uploaded")


def _stored_path(stored_name: str) -> Path:
    return settings.upload_dir / stored_name


def _load_document(db: Session, document_id: int) -> Document:
    doc = db.get(Document, document_id, options=[selectinload(Document.fdr)])
    if doc is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    return doc


@router.post("/fdrs/{fdr_id}/documents", response_model=DocumentItem, status_code=status.HTTP_201_CREATED)
def upload_document(
    fdr_id: int,
    file: UploadFile,
    db: Db,
    user: AdminOrInstitutionUser,
    doc_type: Annotated[DocumentType, Form()] = DocumentType.fdr_receipt,
) -> DocumentItem:
    fdr = load_fdr(db, fdr_id, user)
    if user.role == Role.institution and fdr.status not in (FdrStatus.draft, FdrStatus.rejected):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Institutions can only upload documents for draft or rejected deposits",
        )
    if user.role == Role.institution and doc_type == DocumentType.bank_confirmation:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="The bank's confirmation letter is attached by the Bureau, not by the institution",
        )
    if fdr.status in (FdrStatus.released, FdrStatus.renewed):
        raise HTTPException(status_code=409, detail="Documents cannot be added to a closed deposit")
    content_type = _content_type(file)
    data = file.file.read(settings.max_upload_bytes + 1)
    if len(data) > settings.max_upload_bytes:
        raise HTTPException(status_code=413, detail="File is larger than 10 MB")
    if not data:
        raise HTTPException(status_code=422, detail="The file is empty")
    if not data.startswith(_SIGNATURES[content_type]):
        raise HTTPException(status_code=415, detail="The file content does not match a PDF, JPG or PNG")
    original = Path(file.filename or "document").name[:255] or "document"
    stored_name = f"{uuid.uuid4().hex}{ALLOWED_TYPES[content_type]}"
    settings.upload_dir.mkdir(parents=True, exist_ok=True)
    _stored_path(stored_name).write_bytes(data)
    file_sha256 = hashlib.sha256(data).hexdigest()
    doc = Document(
        fdr_id=fdr.id,
        filename=original,
        stored_name=stored_name,
        content_type=content_type,
        size_bytes=len(data),
        uploaded_by_id=user.id,
        doc_type=doc_type,
        sha256=file_sha256,
    )
    db.add(doc)
    db.flush()
    write_audit(
        db,
        actor=user,
        action="document.uploaded",
        entity=AuditEntity.document,
        entity_id=doc.id,
        fdr_id=fdr.id,
        detail={"filename": original, "size_bytes": len(data), "doc_type": doc_type.value},
    )
    try:
        commit_with_alerts(db)
    except Exception:
        _stored_path(stored_name).unlink(missing_ok=True)
        raise
    db.refresh(doc)
    return document_item(doc)


@router.get("/documents/{document_id}/download", response_class=FileResponse)
def download_document(document_id: int, db: Db, user: CurrentUser) -> FileResponse:
    doc = _load_document(db, document_id)
    if user.role == Role.institution and doc.fdr.institution_id != user.institution_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    path = _stored_path(doc.stored_name)
    if not path.is_file():
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="The stored file is missing")
    data = path.read_bytes()
    rehashed = hashlib.sha256(data).hexdigest()
    integrity = "verified" if (doc.sha256 and rehashed == doc.sha256) else "mismatch"
    return FileResponse(
        path,
        media_type=doc.content_type,
        filename=doc.filename,
        headers={"X-Integrity": integrity},
    )


@router.delete("/documents/{document_id}", status_code=status.HTTP_204_NO_CONTENT)
def delete_document(document_id: int, db: Db, user: AdminOrInstitutionUser) -> None:
    doc = _load_document(db, document_id)
    if user.role == Role.institution and doc.fdr.institution_id != user.institution_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Document not found")
    if user.role == Role.institution and doc.fdr.status not in (FdrStatus.draft, FdrStatus.rejected):
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Institutions can only delete documents for draft or rejected deposits",
        )
    if doc.fdr.status in (FdrStatus.released, FdrStatus.renewed):
        raise HTTPException(status_code=409, detail="Documents of a closed deposit cannot be deleted")
    stored = _stored_path(doc.stored_name)
    write_audit(
        db,
        actor=user,
        action="document.deleted",
        entity=AuditEntity.document,
        entity_id=doc.id,
        fdr_id=doc.fdr_id,
        detail={"filename": doc.filename},
    )
    db.delete(doc)
    commit_with_alerts(db)
    stored.unlink(missing_ok=True)

