"""Maturity Radar: what matures each month ahead, with projected payout."""

from typing import Annotated

from fastapi import APIRouter, Depends, Query
from sqlalchemy.orm import Session

from app.constants import OPEN_STATUSES
from app.db import get_db
from app.models import Role
from app.queries import FdrFilters, list_fdr_items
from app.rules import RuleContext, fdr_projected_value
from app.routers.dashboard import month_keys
from app.schemas import RadarItem, RadarMonth, RadarOut
from app.security import CurrentUser

router = APIRouter(tags=["innovation"])


@router.get("/radar", response_model=RadarOut)
def radar(
    db: Annotated[Session, Depends(get_db)],
    user: CurrentUser,
    months: Annotated[int, Query(ge=1, le=36)] = 12,
) -> RadarOut:
    ctx = RuleContext.load(db)
    buckets: dict[str, list[RadarItem]] = {k: [] for k in month_keys(ctx.on, months)}
    inst_id = user.institution_id if user.role == Role.institution else None
    open_filter = FdrFilters(status=",".join(s.value for s in OPEN_STATUSES), institution_id=inst_id)
    for fdr, item in list_fdr_items(db, open_filter, ctx):
        key = f"{fdr.maturity_date.year:04d}-{fdr.maturity_date.month:02d}"
        if key not in buckets or item.days_to_maturity < 0:
            continue
        buckets[key].append(
            RadarItem(
                id=fdr.id,
                fdr_number=fdr.fdr_number,
                institution_name=item.institution_name,
                amount=item.amount,
                projected_value=fdr_projected_value(fdr),
                maturity_date=fdr.maturity_date,
                days_to_maturity=item.days_to_maturity,
                status=fdr.status,
            )
        )
    return RadarOut(
        months=[
            RadarMonth(
                month=key,
                count=len(rows),
                principal=round(sum(r.amount for r in rows), 2),
                projected=round(sum(r.projected_value for r in rows), 2),
                items=rows,
            )
            for key, rows in buckets.items()
        ]
    )
