"""Reference lists for forms and filters."""

from fastapi import APIRouter

from app.constants import (
    BANKS,
    DOCUMENT_TYPE_LABELS,
    INSTITUTION_TYPES,
    PURPOSE_LABELS,
    ROLE_LABELS,
    STATUS_LABELS,
)
from app.schemas import MetaOut, Option
from app.security import CurrentUser

router = APIRouter(tags=["meta"])


@router.get("/meta", response_model=MetaOut)
def meta(_user: CurrentUser) -> MetaOut:
    return MetaOut(
        banks=BANKS,
        purposes=[Option(value=k.value, label=v) for k, v in PURPOSE_LABELS.items()],
        statuses=[Option(value=k.value, label=v) for k, v in STATUS_LABELS.items()],
        institution_types=INSTITUTION_TYPES,
        roles=[Option(value=k.value, label=v) for k, v in ROLE_LABELS.items()],
        document_types=[Option(value=k.value, label=v) for k, v in DOCUMENT_TYPE_LABELS.items()],
    )
