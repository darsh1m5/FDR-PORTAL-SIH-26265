"""Reviewer queue: submissions and release requests waiting for a decision."""

from typing import Annotated, Literal

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.alerts import waiting_since
from app.config import utcnow
from app.db import get_db
from app.models import Fdr, FdrStatus, Role, User
from app.rules import RuleContext
from app.schemas import ApprovalItem, ApprovalsOut, ReleaseChecklist
from app.security import CurrentUser
from app.serializers import fdr_list_item

router = APIRouter(tags=["approvals"])


@router.get("/approvals", response_model=ApprovalsOut)
def approvals(
    db: Annotated[Session, Depends(get_db)],
    user: CurrentUser,
    sort: Literal["date", "risk"] = "date",
) -> ApprovalsOut:
    if user.role == Role.institution:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Approvals queue is not available for institutions",
        )
    ctx = RuleContext.load(db)
    fdrs = db.scalars(
        select(Fdr)
        .options(selectinload(Fdr.institution), selectinload(Fdr.renewed_from))
        .where(Fdr.status.in_([FdrStatus.pending_approval, FdrStatus.release_requested]))
    ).all()
    since = waiting_since(db, list(fdrs))
    actor_ids = {actor for _, actor, _ in since.values() if actor is not None}
    names = {
        uid: name for uid, name in db.execute(select(User.id, User.name).where(User.id.in_(actor_ids)))
    }
    now = utcnow()
    items: list[ApprovalItem] = []
    for fdr in fdrs:
        at, actor_id, detail = since[fdr.id]
        if fdr.status == FdrStatus.release_requested:
            kind, reason = "release", detail.get("reason")
            checklist = ReleaseChecklist(**fdr.release_checklist) if fdr.release_checklist else None
            ready = fdr.release_ready
        else:
            kind = "approval"
            reason = f"Renewal of FDR {fdr.renewed_from.fdr_number}" if fdr.renewed_from else None
            checklist = None
            ready = None
        items.append(
            ApprovalItem(
                fdr=fdr_list_item(fdr, ctx),
                kind=kind,
                requested_at=at,
                requested_by=names.get(actor_id, "System") if actor_id else "System",
                waiting_days=max(0, (now - at).days),
                reason=reason,
                release_checklist=checklist,
                release_ready=ready,
            )
        )
    if sort == "risk":
        items.sort(key=lambda i: (i.fdr.health_score, i.requested_at, i.fdr.id))
    else:
        items.sort(key=lambda i: (i.requested_at, i.fdr.id))
    return ApprovalsOut(items=items)
