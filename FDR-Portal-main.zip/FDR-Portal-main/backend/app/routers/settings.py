"""Alert rules and the plausible interest-rate band."""

from decimal import Decimal
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session

from app.alerts import commit_with_alerts
from app.audit import write_audit
from app.db import get_db
from app.models import AuditEntity, Setting
from app.rules import get_settings
from app.schemas import SettingsIO
from app.security import AdminUser, BureauUser

router = APIRouter(prefix="/settings", tags=["settings"])

Db = Annotated[Session, Depends(get_db)]


def _out(row: Setting) -> SettingsIO:
    return SettingsIO(
        reminder_days=list(row.reminder_days),
        overdue_grace_days=row.overdue_grace_days,
        pending_sla_days=row.pending_sla_days,
        interest_min=float(row.interest_min),
        interest_max=float(row.interest_max),
        escalate_after_days=row.escalate_after_days or 3,
    )


@router.get("", response_model=SettingsIO)
def read_settings(db: Db, _user: BureauUser) -> SettingsIO:
    row = get_settings(db)
    db.commit()
    return _out(row)


@router.put("", response_model=SettingsIO)
def update_settings(body: SettingsIO, db: Db, user: AdminUser) -> SettingsIO:
    row = get_settings(db)
    before = _out(row).model_dump()
    row.reminder_days = body.reminder_days
    row.overdue_grace_days = body.overdue_grace_days
    row.pending_sla_days = body.pending_sla_days
    row.interest_min = Decimal(str(body.interest_min))
    row.interest_max = Decimal(str(body.interest_max))
    if body.escalate_after_days is not None:
        row.escalate_after_days = body.escalate_after_days
    after = body.model_dump()
    changes = {k: {"from": before[k], "to": after[k]} for k in after if before[k] != after[k]}
    if changes:
        write_audit(
            db,
            actor=user,
            action="settings.updated",
            entity=AuditEntity.settings,
            entity_id=row.id,
            detail={"changes": changes},
        )
    commit_with_alerts(db)
    return _out(row)
