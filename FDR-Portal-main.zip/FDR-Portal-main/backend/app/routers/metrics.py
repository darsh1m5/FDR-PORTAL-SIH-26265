"""Bureau performance metrics: turnaround, verification, coverage, data quality."""

import statistics
from datetime import date, datetime, timedelta
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.alerts import waiting_since
from app.config import IST, utcnow
from app.constants import OPEN_STATUSES
from app.db import get_db
from app.models import Alert, AuditLog, Fdr, FdrStatus, Role, Severity, Verification
from app.rules import RuleContext, findings_for, get_settings
from app.schemas import BureauMetrics, MonthlyMetric
from app.security import CurrentUser

router = APIRouter(prefix="/metrics", tags=["metrics"])


def last_6_months(ref_date: date) -> list[str]:
    y, m = ref_date.year, ref_date.month
    months = []
    for i in range(5, -1, -1):
        cur_m = m - i
        cur_y = y
        while cur_m <= 0:
            cur_m += 12
            cur_y -= 1
        months.append(f"{cur_y:04d}-{cur_m:02d}")
    return months


@router.get("", response_model=BureauMetrics)
def read_metrics(db: Annotated[Session, Depends(get_db)], user: CurrentUser) -> BureauMetrics:
    now = utcnow()
    cutoff_180 = now - timedelta(days=180)
    ctx = RuleContext.load(db)
    cfg = get_settings(db)
    sla_days = getattr(cfg, "pending_sla_days", 7) or 7
    inst_id = user.institution_id if user.role == Role.institution else None

    # 1. Pending over SLA
    pending_stmt = select(Fdr).where(Fdr.status.in_([FdrStatus.pending_approval, FdrStatus.release_requested]))
    if inst_id:
        pending_stmt = pending_stmt.where(Fdr.institution_id == inst_id)
    pending_fdrs = db.scalars(pending_stmt).all()
    since = waiting_since(db, pending_fdrs)
    pending_over_sla = 0
    for f in pending_fdrs:
        if f.id in since:
            entered_at = since[f.id][0]
            if (now - entered_at).days > sla_days:
                pending_over_sla += 1

    # 2. Verification rate (officer-verified + bank_confirmed share of approved + release requested)
    held_stmt = select(Fdr).where(Fdr.status.in_([FdrStatus.approved, FdrStatus.release_requested]))
    if inst_id:
        held_stmt = held_stmt.where(Fdr.institution_id == inst_id)
    held_fdrs = db.scalars(held_stmt).all()
    if held_fdrs:
        verified_count = sum(
            1 for f in held_fdrs if f.verification in (Verification.officer_verified, Verification.bank_confirmed)
        )
        verification_rate = round(100.0 * verified_count / len(held_fdrs), 1)
        bank_confirmed_count = sum(
            1 for f in held_fdrs if f.verification == Verification.bank_confirmed
        )
        bank_confirmed_share = round(100.0 * bank_confirmed_count / len(held_fdrs), 1)
    else:
        verification_rate = 100.0
        bank_confirmed_share = None

    # 3. Document coverage (open FDRs with an fdr_receipt)
    open_stmt = select(Fdr).options(selectinload(Fdr.documents)).where(Fdr.status.in_(OPEN_STATUSES))
    if inst_id:
        open_stmt = open_stmt.where(Fdr.institution_id == inst_id)
    open_fdrs = db.scalars(open_stmt).all()
    if open_fdrs:
        with_receipt = 0
        for f in open_fdrs:
            has_receipt = any(
                getattr(d, "doc_type", None) in (None, "fdr_receipt")
                for d in f.documents
            )
            if has_receipt:
                with_receipt += 1
        document_coverage = round(100.0 * with_receipt / len(open_fdrs), 1)
    else:
        document_coverage = 100.0

    # 4. Renewal on-time rate (renewals done on or before the old maturity date)
    renewal_stmt = (
        select(AuditLog.at, Fdr.maturity_date)
        .join(Fdr, Fdr.id == AuditLog.fdr_id)
        .where(AuditLog.action == "fdr.renewed")
    )
    if inst_id:
        renewal_stmt = renewal_stmt.where(Fdr.institution_id == inst_id)
    renewals = db.execute(renewal_stmt).all()
    if renewals:
        on_time_count = sum(1 for at, maturity in renewals if at.astimezone(IST).date() <= maturity)
        renewal_on_time_rate = round(100.0 * on_time_count / len(renewals), 1)
    else:
        renewal_on_time_rate = None

    # 5. Data quality rate (open FDRs with no critical finding)
    if open_fdrs:
        clean_count = 0
        for f in open_fdrs:
            findings = findings_for(f, ctx)
            if not any(fnd.severity == Severity.critical for fnd in findings):
                clean_count += 1
        data_quality_rate = round(100.0 * clean_count / len(open_fdrs), 1)
    else:
        data_quality_rate = 100.0

    # 6. Alert acknowledgement median hours
    acked_stmt = select(Alert).where(
        Alert.acknowledged_at.is_not(None),
        Alert.auto_resolved.is_(False),
    )
    if inst_id:
        acked_stmt = acked_stmt.join(Alert.fdr).where(Fdr.institution_id == inst_id)
    acked_alerts = db.scalars(acked_stmt).all()
    durations_hours = []
    for a in acked_alerts:
        if a.created_at and a.acknowledged_at and a.acknowledged_at >= a.created_at:
            durations_hours.append((a.acknowledged_at - a.created_at).total_seconds() / 3600.0)
    alert_ack_median_hours = round(statistics.median(durations_hours), 1) if durations_hours else None

    # 7. Turnarounds and monthly trends from audit log
    audit_stmt = select(AuditLog).order_by(AuditLog.id.asc())
    if inst_id:
        audit_stmt = (
            select(AuditLog)
            .join(Fdr, Fdr.id == AuditLog.fdr_id)
            .where(Fdr.institution_id == inst_id)
            .order_by(AuditLog.id.asc())
        )
    audit_rows = db.scalars(audit_stmt).all()

    approval_turnarounds_180: list[float] = []
    release_turnarounds_180: list[float] = []

    months_list = last_6_months(ctx.on)
    monthly_turnarounds: dict[str, list[float]] = {m: [] for m in months_list}
    monthly_counts: dict[str, int] = {m: 0 for m in months_list}

    pending_approval_at: dict[int, datetime] = {}
    release_requested_at: dict[int, datetime] = {}

    for row in audit_rows:
        fid = row.fdr_id
        if not fid:
            continue

        moved = row.from_status != row.to_status
        if row.action == "fdr.submitted" or (moved and row.to_status == "pending_approval"):
            pending_approval_at[fid] = row.at
        elif row.action in ("fdr.approved", "fdr.rejected"):
            entered = pending_approval_at.pop(fid, None)
            if entered and row.at >= entered:
                t_days = max(0.0, (row.at - entered).total_seconds() / 86400.0)
                if row.at >= cutoff_180:
                    approval_turnarounds_180.append(t_days)
                m_key = row.at.strftime("%Y-%m")
                if m_key in monthly_turnarounds:
                    monthly_turnarounds[m_key].append(t_days)
                    monthly_counts[m_key] += 1
            else:
                m_key = row.at.strftime("%Y-%m")
                if m_key in monthly_counts:
                    monthly_counts[m_key] += 1

        elif row.action == "fdr.release_requested" or (moved and row.to_status == "release_requested"):
            release_requested_at[fid] = row.at
        elif row.action in ("fdr.released", "fdr.release_rejected"):
            entered = release_requested_at.pop(fid, None)
            if entered and row.at >= entered:
                t_days = max(0.0, (row.at - entered).total_seconds() / 86400.0)
                if row.at >= cutoff_180:
                    release_turnarounds_180.append(t_days)
                m_key = row.at.strftime("%Y-%m")
                if m_key in monthly_turnarounds:
                    monthly_turnarounds[m_key].append(t_days)
                    monthly_counts[m_key] += 1
            else:
                m_key = row.at.strftime("%Y-%m")
                if m_key in monthly_counts:
                    monthly_counts[m_key] += 1

    approval_turnaround_days = (
        round(sum(approval_turnarounds_180) / len(approval_turnarounds_180), 1)
        if approval_turnarounds_180
        else None
    )
    release_turnaround_days = (
        round(sum(release_turnarounds_180) / len(release_turnarounds_180), 1)
        if release_turnarounds_180
        else None
    )

    monthly = []
    for m in months_list:
        decided = monthly_counts[m]
        t_list = monthly_turnarounds[m]
        avg_t = round(sum(t_list) / len(t_list), 1) if t_list else None
        monthly.append(MonthlyMetric(month=m, decided=decided, avg_turnaround_days=avg_t))

    return BureauMetrics(
        approval_turnaround_days=approval_turnaround_days,
        release_turnaround_days=release_turnaround_days,
        pending_over_sla=pending_over_sla,
        verification_rate=verification_rate,
        document_coverage=document_coverage,
        renewal_on_time_rate=renewal_on_time_rate,
        data_quality_rate=data_quality_rate,
        alert_ack_median_hours=alert_ack_median_hours,
        bank_confirmed_share=bank_confirmed_share,
        monthly=monthly,
    )
