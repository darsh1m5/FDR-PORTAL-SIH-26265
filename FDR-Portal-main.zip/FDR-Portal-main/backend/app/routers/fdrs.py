"""Deposits register: list, export, create, edit and the status machine actions."""

import csv
import io
from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from fastapi.responses import Response
from sqlalchemy.orm import Session, selectinload

from app.alerts import commit_with_alerts, display_date
from app.audit import write_audit
from app.config import today
from app.constants import PURPOSE_LABELS, STATUS_LABELS, VERIFICATION_LABELS
from app.db import get_db
from app.models import (
    AuditEntity,
    AuditLog,
    DocumentType,
    Fdr,
    FdrStatus,
    Role,
    User,
    Verification,
)
from app.queries import FdrFilters, list_fdr_items
from app.rules import RuleContext, fdr_projected_value
from app.schemas import (
    DecisionIn,
    FdrDetail,
    FdrInput,
    FdrPage,
    FdrPatch,
    ReleaseIn,
    RenewInput,
    VerifyIn,
)
from app.security import AdminOrInstitutionUser, AdminUser, CurrentUser, ReviewerUser
from app.serializers import fdr_detail
from app import workflow

router = APIRouter(prefix="/fdrs", tags=["fdrs"])

Db = Annotated[Session, Depends(get_db)]
Filters = Annotated[FdrFilters, Depends()]


def load_fdr(db: Session, fdr_id: int, user: User | None = None) -> Fdr:
    fdr = db.get(
        Fdr,
        fdr_id,
        options=[
            selectinload(Fdr.institution),
            selectinload(Fdr.documents),
            selectinload(Fdr.created_by),
            selectinload(Fdr.observations),
        ],
    )
    if fdr is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Deposit not found")
    if user is not None and user.role == Role.institution and fdr.institution_id != user.institution_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Deposit not found")
    return fdr


def _detail(db: Session, fdr_id: int, user: User) -> FdrDetail:
    db.expire_all()
    return fdr_detail(db, load_fdr(db, fdr_id, user), user)


@router.get("", response_model=FdrPage)
def list_fdrs(
    db: Db,
    user: CurrentUser,
    filters: Filters,
    page: Annotated[int, Query(ge=1)] = 1,
    page_size: Annotated[int, Query(ge=1, le=500)] = 20,
) -> FdrPage:
    if user.role == Role.institution:
        filters.institution_id = user.institution_id
    rows = list_fdr_items(db, filters)
    start = (page - 1) * page_size
    return FdrPage(
        items=[item for _, item in rows[start : start + page_size]],
        total=len(rows),
        page=page,
        page_size=page_size,
        total_amount=round(sum(item.amount for _, item in rows), 2),
    )


CSV_BOM = chr(0xFEFF)  # lets Excel open the UTF-8 file with the ₹ sign and Indian names intact
CSV_HEADER = [
    "FDR number",
    "Institution",
    "AICTE ID",
    "Bank",
    "Branch",
    "IFSC",
    "Amount (INR)",
    "Issue date",
    "Maturity date",
    "Days to maturity",
    "Interest rate (% p.a.)",
    "Printed maturity amount (INR)",
    "Projected value (INR)",
    "Purpose",
    "Lien to AICTE",
    "Status",
    "Verification",
    "Health score",
    "Findings",
    "Documents",
    "Remarks",
]


def _sanitize_csv_cell(val: object) -> object:
    if isinstance(val, str) and len(val) > 0 and val[0] in ("=", "+", "-", "@", "\t", "\r"):
        try:
            float(val)
            return val
        except ValueError:
            return f"'{val}"
    return val


@router.get("/export.csv", response_class=Response)
def export_csv(db: Db, user: CurrentUser, filters: Filters) -> Response:
    if user.role == Role.institution:
        filters.institution_id = user.institution_id
    rows = list_fdr_items(db, filters)
    buffer = io.StringIO()
    writer = csv.writer(buffer, lineterminator="\r\n")
    writer.writerow(CSV_HEADER)
    for fdr, item in rows:
        row = [
            fdr.fdr_number,
            fdr.institution.name,
            fdr.institution.aicte_id,
            fdr.bank_name,
            fdr.branch or "",
            fdr.ifsc or "",
            f"{fdr.amount:.2f}",
            display_date(fdr.issue_date),
            display_date(fdr.maturity_date),
            item.days_to_maturity,
            f"{fdr.interest_rate:.2f}",
            f"{fdr.maturity_amount:.2f}" if fdr.maturity_amount is not None else "",
            f"{fdr_projected_value(fdr):.2f}",
            PURPOSE_LABELS[fdr.purpose],
            "Yes" if fdr.lien_to_aicte else "No",
            STATUS_LABELS[fdr.status],
            VERIFICATION_LABELS.get(fdr.verification, "Submitted"),
            item.health_score,
            item.findings_count,
            item.document_count,
            fdr.remarks or "",
        ]
        writer.writerow([_sanitize_csv_cell(cell) for cell in row])
    applied = {k: v for k, v in vars(filters).items() if v not in (None, "", "maturity_date", "asc")}
    write_audit(
        db,
        actor=user,
        action="export.csv",
        entity=AuditEntity.export,
        detail={"rows": len(rows), "filters": applied},
    )
    db.commit()
    filename = f"fdr-register-{today().isoformat()}.csv"
    return Response(
        content=CSV_BOM + buffer.getvalue(),
        media_type="text/csv; charset=utf-8",
        headers={"Content-Disposition": f'attachment; filename="{filename}"'},
    )


@router.post("", response_model=FdrDetail, status_code=status.HTTP_201_CREATED)
def create_fdr(body: FdrInput, db: Db, user: AdminOrInstitutionUser) -> FdrDetail:
    if user.role == Role.institution:
        body.institution_id = user.institution_id
    fdr = workflow.create_fdr(db, body, user)
    commit_with_alerts(db)
    return _detail(db, fdr.id, user)


@router.get("/{fdr_id}", response_model=FdrDetail)
def get_fdr(fdr_id: int, db: Db, user: CurrentUser) -> FdrDetail:
    return fdr_detail(db, load_fdr(db, fdr_id, user), user, RuleContext.load(db))


@router.patch("/{fdr_id}", response_model=FdrDetail)
def update_fdr(fdr_id: int, body: FdrPatch, db: Db, user: AdminOrInstitutionUser) -> FdrDetail:
    fdr = load_fdr(db, fdr_id, user)
    if user.role == Role.institution:
        if fdr.status not in (FdrStatus.draft, FdrStatus.rejected):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Institutions can only edit draft or rejected deposits",
            )
        if body.institution_id is not None and body.institution_id != user.institution_id:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Cannot assign deposit to another institution",
            )
    workflow.update_fdr(db, fdr, body, user)
    commit_with_alerts(db)
    return _detail(db, fdr_id, user)


@router.post("/{fdr_id}/submit", response_model=FdrDetail)
def submit_fdr(fdr_id: int, db: Db, user: AdminOrInstitutionUser) -> FdrDetail:
    fdr = load_fdr(db, fdr_id, user)
    if user.role == Role.institution:
        if fdr.status not in (FdrStatus.draft, FdrStatus.rejected):
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Institutions can only submit draft or rejected deposits",
            )
    workflow.submit(db, fdr, user)
    commit_with_alerts(db)
    return _detail(db, fdr_id, user)


@router.post("/{fdr_id}/decision", response_model=FdrDetail)
def decide_fdr(fdr_id: int, body: DecisionIn, db: Db, user: CurrentUser) -> FdrDetail:
    fdr = load_fdr(db, fdr_id, user)
    if fdr.status == FdrStatus.pending_approval:
        if user.role != Role.reviewer:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only a Reviewer can decide submissions",
            )
    elif fdr.status == FdrStatus.release_requested:
        if user.role != Role.approver:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Only the Competent Authority can sanction or return a release request",
            )
        last_req = (
            db.query(AuditLog)
            .filter(AuditLog.fdr_id == fdr.id, AuditLog.action == "fdr.release_requested")
            .order_by(AuditLog.id.desc())
            .first()
        )
        if last_req and last_req.actor_id == user.id:
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="The officer who requested the release cannot sanction it",
            )
    else:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Nothing to decide: the deposit is '{STATUS_LABELS[fdr.status]}'",
        )
    workflow.decide(db, fdr, body, user)
    commit_with_alerts(db)
    return _detail(db, fdr_id, user)


@router.post("/{fdr_id}/request-release", response_model=FdrDetail)
def request_release(fdr_id: int, body: ReleaseIn, db: Db, user: AdminOrInstitutionUser) -> FdrDetail:
    fdr = load_fdr(db, fdr_id, user)
    if user.role == Role.institution and fdr.status != FdrStatus.approved:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Only an approved deposit can be released",
        )
    if user.role == Role.institution and body.checklist is None:
        raise HTTPException(
            status_code=422,
            detail="Complete the release checklist before applying for release",
        )
    workflow.request_release(db, fdr, body, user)
    commit_with_alerts(db)
    return _detail(db, fdr_id, user)


@router.post("/{fdr_id}/renew", response_model=FdrDetail, status_code=status.HTTP_201_CREATED)
def renew_fdr(fdr_id: int, body: RenewInput, db: Db, user: AdminUser) -> FdrDetail:
    old = load_fdr(db, fdr_id, user)
    data = FdrInput.model_validate({**body.model_dump(), "institution_id": old.institution_id})
    replacement = workflow.renew(db, old, data, user)
    commit_with_alerts(db)
    return _detail(db, replacement.id, user)


@router.post("/{fdr_id}/verify", response_model=FdrDetail)
def verify_fdr(fdr_id: int, db: Db, user: ReviewerUser, body: VerifyIn | None = None) -> FdrDetail:
    workflow.verify(db, load_fdr(db, fdr_id, user), body.remark if body else None, user)
    commit_with_alerts(db)
    return _detail(db, fdr_id, user)


@router.post("/{fdr_id}/bank-confirm", response_model=FdrDetail)
def bank_confirm_fdr(
    fdr_id: int, db: Db, user: ReviewerUser, body: VerifyIn | None = None
) -> FdrDetail:
    fdr = load_fdr(db, fdr_id, user)
    if fdr.status in (FdrStatus.released, FdrStatus.renewed):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Cannot bank-confirm a closed deposit",
        )
    if fdr.verification == Verification.bank_confirmed:
        raise HTTPException(status_code=status.HTTP_409_CONFLICT, detail="This deposit is already bank-confirmed")
    has_letter = any(
        doc.doc_type == DocumentType.bank_confirmation
        and doc.uploaded_by is not None
        and doc.uploaded_by.role != Role.institution
        for doc in fdr.documents
    )
    if not has_letter:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="A bank confirmation letter attached by the Bureau is required before confirming",
        )
    fdr.verification = Verification.bank_confirmed
    detail = {"remark": body.remark} if (body and body.remark) else {}
    write_audit(
        db,
        actor=user,
        action="fdr.bank_confirmed",
        entity=AuditEntity.fdr,
        entity_id=fdr.id,
        fdr_id=fdr.id,
        from_status=fdr.status,
        to_status=fdr.status,
        detail=detail,
    )
    commit_with_alerts(db)
    return _detail(db, fdr_id, user)

