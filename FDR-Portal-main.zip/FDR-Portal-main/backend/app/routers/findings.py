"""Health Check: deposits with discrepancy findings, worst first."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.db import get_db
from app.models import Fdr, Role, Severity
from app.rules import RuleContext, findings_for, health_score
from app.schemas import FindingsRow
from app.security import CurrentUser

router = APIRouter(tags=["innovation"])


@router.get("/findings", response_model=list[FindingsRow])
def findings(
    db: Annotated[Session, Depends(get_db)],
    user: CurrentUser,
    severity: Severity | None = None,
) -> list[FindingsRow]:
    if user.role == Role.institution:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Health check across institutions is not available for institutions",
        )
    ctx = RuleContext.load(db)
    rows: list[FindingsRow] = []
    for fdr in db.scalars(select(Fdr).options(selectinload(Fdr.institution))).all():
        found = findings_for(fdr, ctx)
        if not found:
            continue
        if severity is not None and not any(f.severity == severity for f in found):
            continue
        rows.append(
            FindingsRow(
                fdr_id=fdr.id,
                fdr_number=fdr.fdr_number,
                institution_name=fdr.institution.name,
                status=fdr.status,
                health_score=health_score(found),
                findings=found,
            )
        )
    rows.sort(key=lambda r: (r.health_score, r.fdr_number))
    return rows
