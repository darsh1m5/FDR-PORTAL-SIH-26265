"""Dashboard figures. Every number matches a register filter."""

from collections import defaultdict
from datetime import date
from typing import Annotated

from fastapi import APIRouter, Depends
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.constants import ACTIVE_STATUSES, OPEN_STATUSES, STATUS_LABELS
from app.db import get_db
from app.models import (
    Alert,
    AuditLog,
    Fdr,
    FdrStatus,
    Observation,
    ObservationStatus,
    Role,
)
from app.queries import FdrFilters, list_fdr_items
from app.rules import RuleContext
from app.schemas import BankBucket, DashboardOut, Kpis, StatusBucket, TimelineMonth
from app.security import CurrentUser
from app.serializers import audit_items, audit_query

router = APIRouter(tags=["dashboard"])


def month_keys(start: date, months: int) -> list[str]:
    keys: list[str] = []
    year, month = start.year, start.month
    for _ in range(months):
        keys.append(f"{year:04d}-{month:02d}")
        month += 1
        if month > 12:
            year, month = year + 1, 1
    return keys


@router.get("/dashboard", response_model=DashboardOut)
def dashboard(db: Annotated[Session, Depends(get_db)], user: CurrentUser) -> DashboardOut:
    ctx = RuleContext.load(db)
    inst_filter = user.institution_id if user.role == Role.institution else None
    items = [item for _, item in list_fdr_items(db, FdrFilters(institution_id=inst_filter), ctx)]
    open_items = [i for i in items if i.status in OPEN_STATUSES]
    active = [i for i in items if i.status in ACTIVE_STATUSES]

    by_status = []
    for status_value, label in STATUS_LABELS.items():
        group = [i for i in items if i.status == status_value]
        by_status.append(
            StatusBucket(status=status_value, label=label, count=len(group), amount=sum(i.amount for i in group))
        )

    banks: dict[str, list[float]] = defaultdict(list)
    for i in open_items:
        banks[i.bank_name].append(i.amount)
    by_bank = sorted(
        (BankBucket(bank=b, count=len(a), amount=sum(a)) for b, a in banks.items()),
        key=lambda b: (-b.amount, b.bank),
    )

    keys = month_keys(ctx.on, 12)
    timeline_map = {k: [0, 0.0] for k in keys}
    for i in open_items:
        key = f"{i.maturity_date.year:04d}-{i.maturity_date.month:02d}"
        if key in timeline_map and i.days_to_maturity >= 0:
            timeline_map[key][0] += 1
            timeline_map[key][1] += i.amount
    timeline = [TimelineMonth(month=k, count=int(v[0]), amount=v[1]) for k, v in timeline_map.items()]

    upcoming = sorted(
        (i for i in open_items if i.days_to_maturity >= 0), key=lambda i: (i.maturity_date, i.id)
    )[:8]

    if user.role == Role.institution:
        activity = db.scalars(
            audit_query()
            .join(AuditLog.fdr)
            .where(AuditLog.action != "auth.login", Fdr.institution_id == user.institution_id)
            .order_by(AuditLog.id.desc())
            .limit(10)
        ).all()
        open_alerts = (
            db.scalar(
                select(func.count(Alert.id))
                .join(Alert.fdr)
                .where(Alert.acknowledged_at.is_(None), Fdr.institution_id == user.institution_id)
            )
            or 0
        )
        escalated_alerts = (
            db.scalar(
                select(func.count(Alert.id))
                .join(Alert.fdr)
                .where(
                    Alert.acknowledged_at.is_(None),
                    Alert.escalated.is_(True),
                    Fdr.institution_id == user.institution_id,
                )
            )
            or 0
        )
        open_observations = (
            db.scalar(
                select(func.count(Observation.id))
                .join(Observation.fdr)
                .where(
                    Observation.status == ObservationStatus.open,
                    Fdr.institution_id == user.institution_id,
                )
            )
            or 0
        )
    else:
        activity = db.scalars(
            audit_query().where(AuditLog.action != "auth.login").order_by(AuditLog.id.desc()).limit(10)
        ).all()
        open_alerts = db.scalar(select(func.count(Alert.id)).where(Alert.acknowledged_at.is_(None))) or 0
        escalated_alerts = (
            db.scalar(
                select(func.count(Alert.id)).where(
                    Alert.acknowledged_at.is_(None), Alert.escalated.is_(True)
                )
            )
            or 0
        )
        open_observations = (
            db.scalar(select(func.count(Observation.id)).where(Observation.status == ObservationStatus.open))
            or 0
        )

    kpis = Kpis(
        total_count=len(open_items),
        total_amount=sum(i.amount for i in open_items),
        active_count=len(active),
        active_amount=sum(i.amount for i in active),
        pending_approvals=sum(1 for i in items if i.status == FdrStatus.pending_approval),
        release_requests=sum(1 for i in items if i.status == FdrStatus.release_requested),
        maturing_30=sum(1 for i in items if i.maturity_state in ("due_7", "due_30")),
        maturing_90=sum(1 for i in items if i.maturity_state in ("due_7", "due_30", "due_60", "due_90")),
        overdue=sum(1 for i in items if i.maturity_state == "matured"),
        open_alerts=open_alerts,
        avg_health=round(sum(i.health_score for i in open_items) / len(open_items)) if open_items else None,
        escalated_alerts=escalated_alerts,
        observations_open=open_observations,
    )
    return DashboardOut(
        kpis=kpis,
        by_status=by_status,
        by_bank=by_bank,
        timeline=timeline,
        upcoming=upcoming,
        activity=audit_items(activity),
    )
