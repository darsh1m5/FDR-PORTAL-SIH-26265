"""Scrutiny observations (queries and replies) between Reviewer and Institution/Admin."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, status
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.alerts import commit_with_alerts
from app.audit import write_audit
from app.config import utcnow
from app.db import get_db
from app.models import AuditEntity, FdrStatus, Observation, ObservationStatus, Role
from app.routers.fdrs import load_fdr
from app.schemas import ObservationIn, ObservationItem, ObservationRespondIn
from app.security import AdminOrInstitutionUser, CurrentUser, ReviewerUser
from app.serializers import observation_item

router = APIRouter(tags=["observations"])

Db = Annotated[Session, Depends(get_db)]


@router.get("/fdrs/{fdr_id}/observations", response_model=list[ObservationItem])
def list_observations(fdr_id: int, db: Db, user: CurrentUser) -> list[ObservationItem]:
    fdr = load_fdr(db, fdr_id, user)
    rows = db.scalars(
        select(Observation)
        .options(selectinload(Observation.author), selectinload(Observation.responded_by))
        .where(Observation.fdr_id == fdr.id)
        .order_by(Observation.created_at.asc(), Observation.id.asc())
    ).all()
    return [observation_item(o) for o in rows]


@router.post(
    "/fdrs/{fdr_id}/observations",
    response_model=ObservationItem,
    status_code=status.HTTP_201_CREATED,
)
def raise_observation(
    fdr_id: int, body: ObservationIn, db: Db, user: ReviewerUser
) -> ObservationItem:
    fdr = load_fdr(db, fdr_id, user)
    if fdr.status in (FdrStatus.released, FdrStatus.renewed):
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Cannot raise an observation on a closed deposit",
        )
    obs = Observation(
        fdr_id=fdr.id,
        author_id=user.id,
        text=body.text.strip(),
        status=ObservationStatus.open,
    )
    db.add(obs)
    db.flush()
    write_audit(
        db,
        actor=user,
        action="observation.raised",
        entity=AuditEntity.observation,
        entity_id=obs.id,
        fdr_id=fdr.id,
        detail={"text": obs.text[:200]},
    )
    commit_with_alerts(db)
    db.refresh(obs)
    return observation_item(obs)


@router.post("/observations/{observation_id}/respond", response_model=ObservationItem)
def respond_observation(
    observation_id: int, body: ObservationRespondIn, db: Db, user: AdminOrInstitutionUser
) -> ObservationItem:
    obs = db.get(
        Observation,
        observation_id,
        options=[
            selectinload(Observation.fdr),
            selectinload(Observation.author),
            selectinload(Observation.responded_by),
        ],
    )
    if obs is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Observation not found")
    if user.role == Role.institution and obs.fdr.institution_id != user.institution_id:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Observation not found")
    if obs.status != ObservationStatus.open:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail=f"Only open observations can be answered (current: '{obs.status.value}')",
        )
    obs.response = body.response.strip()
    obs.responded_by_id = user.id
    obs.responded_at = utcnow()
    obs.status = ObservationStatus.answered
    db.flush()
    write_audit(
        db,
        actor=user,
        action="observation.answered",
        entity=AuditEntity.observation,
        entity_id=obs.id,
        fdr_id=obs.fdr_id,
        detail={"response": obs.response[:200]},
    )
    commit_with_alerts(db)
    db.refresh(obs)
    return observation_item(obs)


@router.post("/observations/{observation_id}/close", response_model=ObservationItem)
def close_observation(observation_id: int, db: Db, user: ReviewerUser) -> ObservationItem:
    obs = db.get(
        Observation,
        observation_id,
        options=[
            selectinload(Observation.fdr),
            selectinload(Observation.author),
            selectinload(Observation.responded_by),
        ],
    )
    if obs is None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND, detail="Observation not found")
    if obs.status == ObservationStatus.closed:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Observation is already closed",
        )
    obs.status = ObservationStatus.closed
    db.flush()
    write_audit(
        db,
        actor=user,
        action="observation.closed",
        entity=AuditEntity.observation,
        entity_id=obs.id,
        fdr_id=obs.fdr_id,
        detail={},
    )
    commit_with_alerts(db)
    db.refresh(obs)
    return observation_item(obs)
