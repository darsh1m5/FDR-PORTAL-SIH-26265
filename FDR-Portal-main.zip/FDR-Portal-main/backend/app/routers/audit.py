"""Global audit log and the integrity check."""

from typing import Annotated

from fastapi import APIRouter, Depends, HTTPException, Query, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.audit import verify_chain
from app.db import get_db
from app.models import AuditEntity, AuditLog, Role
from app.schemas import AuditItem, AuditVerifyOut, Page
from app.security import CurrentUser
from app.serializers import audit_items, audit_query

router = APIRouter(prefix="/audit", tags=["audit"])

Db = Annotated[Session, Depends(get_db)]


@router.get("", response_model=Page[AuditItem])
def list_audit(
    db: Db,
    user: CurrentUser,
    fdr_id: int | None = None,
    action: str | None = None,
    actor_id: int | None = None,
    entity: AuditEntity | None = None,
    page: Annotated[int, Query(ge=1)] = 1,
    page_size: Annotated[int, Query(ge=1, le=200)] = 50,
) -> Page[AuditItem]:
    if user.role == Role.institution:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Audit log is not available for institutions",
        )
    conditions = []
    if fdr_id is not None:
        conditions.append(AuditLog.fdr_id == fdr_id)
    if action:
        # "fdr" matches every fdr.* action; a full name matches exactly.
        conditions.append(AuditLog.action == action if "." in action else AuditLog.action.like(f"{action}.%"))
    if actor_id is not None:
        conditions.append(AuditLog.actor_id == actor_id)
    if entity:
        conditions.append(AuditLog.entity == entity)
    total = db.scalar(select(func.count(AuditLog.id)).where(*conditions)) or 0
    rows = db.scalars(
        audit_query()
        .where(*conditions)
        .order_by(AuditLog.id.desc())
        .offset((page - 1) * page_size)
        .limit(page_size)
    ).all()
    return Page[AuditItem](items=audit_items(rows), total=total, page=page, page_size=page_size)


@router.get("/verify", response_model=AuditVerifyOut)
def verify(db: Db, user: CurrentUser) -> AuditVerifyOut:
    if user.role == Role.institution:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Audit log is not available for institutions",
        )
    report = verify_chain(db)
    return AuditVerifyOut(intact=report.intact, checked=report.checked, broken_at=report.broken_at)
