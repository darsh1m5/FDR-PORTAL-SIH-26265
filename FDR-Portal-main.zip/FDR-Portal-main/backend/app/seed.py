"""Demo data for Amanat.

`run(db)` is called on first startup (only when the users table is empty) and
fills the portal with a realistic, self-consistent bureau history:

- the two demo logins (Section Officer / Scrutiny Officer),
- 14 fictional institutions across Indian states,
- 44 FDRs over ten banks with a deliberate status mix, maturity spread and a
  set of planted discrepancies for the Health Check (no lien, duplicate
  number, bad IFSC, printed-value mismatches, one rate outside the band, one
  institution below its required deposit, several without documents),
- backdated audit rows for every step, written in chronological order so the
  hash chain stays valid,
- small generated one-page PDF receipts for about 16 FDRs,
- one alert-engine pass at the end.

All names are invented. Dates are relative to today, so the demo always shows
matured, due-soon and healthy deposits. Amounts are rupees.
"""

from __future__ import annotations

import random
import uuid
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.alerts import run_alerts
from app.audit import write_audit
from app.config import settings, today
from app.models import (
    AuditEntity,
    Document,
    DocumentType,
    Fdr,
    FdrStatus,
    Institution,
    InstitutionType,
    Purpose,
    Role,
    User,
    Verification,
)
from app.rules import projected_value
from app.security import hash_password

# Days ago when the bureau started using the portal; every audit row falls in
# the window [PORTAL_OPEN_DAYS_AGO, today].
PORTAL_OPEN_DAYS_AGO = 541

_RNG = random.Random(20261026)

_FDR_NUMBER_CODES = {
    "State Bank of India": "SB",
    "Bank of Baroda": "BOB",
    "Punjab National Bank": "PNB",
    "Canara Bank": "CNR",
    "Union Bank of India": "UBI",
    "Bank of India": "BOI",
    "Indian Bank": "IBL",
    "HDFC Bank": "HDF",
    "ICICI Bank": "ICI",
    "Axis Bank": "AXB",
}

_IFSC_PREFIX = {
    "State Bank of India": "SBIN",
    "Bank of Baroda": "BARB",
    "Punjab National Bank": "PUNB",
    "Canara Bank": "CNRB",
    "Union Bank of India": "UBIN",
    "Bank of India": "BKID",
    "Indian Bank": "IDIB",
    "HDFC Bank": "HDFC",
    "ICICI Bank": "ICIC",
    "Axis Bank": "UTIB",
}

_USERS = (
    ("Section Officer", "admin@fdrportal.demo", "Admin@2026", Role.admin),
    ("Scrutiny Officer", "reviewer@fdrportal.demo", "Review@2026", Role.reviewer),
    ("Competent Authority", "approver@fdrportal.demo", "Approve@2026", Role.approver),
    ("Audit Officer", "auditor@fdrportal.demo", "Audit@2026", Role.auditor),
)

# name, aicte_id, city, state, type, required deposit (rupees)
_INSTITUTIONS = (
    ("Deccan Crest Institute of Technology", "1-4413298712", "Pune", "Maharashtra", "Engineering", 12_000_000),
    ("Kaveri Delta College of Engineering", "1-4411720455", "Tiruchirappalli", "Tamil Nadu", "Engineering", 7_500_000),
    ("Aravalli Institute of Management Studies", "1-4412087734", "Jaipur", "Rajasthan", "Management", 6_000_000),
    ("Godavari Valley College of Pharmacy", "1-4410345619", "Nashik", "Maharashtra", "Pharmacy", 3_500_000),
    ("Malwa Plateau Institute of Technology", "1-4412990821", "Indore", "Madhya Pradesh", "Engineering", 9_000_000),
    ("Hooghly Riverside Polytechnic", "1-4410672348", "Howrah", "West Bengal", "Polytechnic", 5_000_000),
    ("Chera Hills Institute of Management", "1-4411559026", "Kochi", "Kerala", "Management", 5_000_000),
    ("Narmada Greenfield School of Architecture", "1-4412813467", "Ahmedabad", "Gujarat", "Architecture", 4_000_000),
    ("Bundelkhand Skills Polytechnic", "1-4409823115", "Jhansi", "Uttar Pradesh", "Polytechnic", 8_000_000),
    ("Musi Riverside Institute of Technology", "1-4411437290", "Hyderabad", "Telangana", "Engineering", 9_000_000),
    ("Vindhya Springs College of Engineering", "1-4412175638", "Bhopal", "Madhya Pradesh", "Engineering", 7_000_000),
    ("Coastal Karnataka College of Pharmacy", "1-4410095842", "Mangaluru", "Karnataka", "Pharmacy", 3_000_000),
    ("Ganga Plain Institute of Management", "1-4411948273", "Lucknow", "Uttar Pradesh", "Management", 5_500_000),
    ("Saurashtra Peninsula Institute of Technology", "1-4410567381", "Rajkot", "Gujarat", "Engineering", 6_500_000),
)

# Lifecycle offsets are days before today. A row's status follows from which
# offsets are present: submitted/approved/rejected/requested/released/renewed.
# `printed` controls the maturity amount on the receipt: None (not printed),
# "exact" (matches the computed value), "high"/"low" (planted mismatch).
_FDRS: list[dict[str, Any]] = [
    # --- matured but still approved: the overdue backlog ---------------------
    dict(key="M1", inst=5, bank="State Bank of India", branch="Indore M.G. Road",
         amount=6_500_000, rate="6.85", issue_ago=370, tenure=1,
         created_ago=366, submitted_ago=358, approved_ago=354, verified_ago=330, doc_ago=350,
         printed="exact"),
    dict(key="M2", inst=1, bank="HDFC Bank", branch="Shivajinagar, Pune",
         amount=8_200_000, rate="7.10", issue_ago=383, tenure=1,
         created_ago=379, submitted_ago=371, approved_ago=367, verified_ago=350, doc_ago=374,
         printed="exact"),
    dict(key="M3", inst=10, bank="Punjab National Bank", branch="Ameerpet, Hyderabad",
         amount=5_400_000, rate="6.60", issue_ago=405, tenure=1,
         created_ago=401, submitted_ago=393, approved_ago=389,
         remarks="Renewal under examination."),
    # --- maturing within 7 days ----------------------------------------------
    dict(key="W1", inst=2, bank="Canara Bank", branch="Thillai Nagar, Tiruchirappalli",
         amount=4_800_000, rate="7.25", issue_ago=362, tenure=1,
         created_ago=358, submitted_ago=350, approved_ago=346, verified_ago=320, doc_ago=354,
         printed="exact"),
    dict(key="W2", inst=7, bank="Axis Bank", branch="Kaloor, Kochi",
         amount=3_900_000, rate="7.00", issue_ago=360, tenure=1,
         created_ago=356, submitted_ago=348, approved_ago=344, doc_ago=352,
         printed="exact"),
    dict(key="W3", inst=11, bank="Bank of Baroda", branch="New Market, Bhopal",
         amount=7_200_000, rate="6.90", issue_ago=358, tenure=1,
         created_ago=354, submitted_ago=346, approved_ago=342, verified_ago=300,
         printed="exact"),
    dict(key="W4", inst=13, bank="Indian Bank", branch="Hazratganj, Lucknow",
         amount=5_600_000, rate="7.15", issue_ago=363, tenure=1,
         created_ago=359, submitted_ago=3, printed="exact"),
    # --- maturing within 30 days ---------------------------------------------
    dict(key="X1", inst=3, bank="State Bank of India", branch="MI Road, Jaipur",
         amount=6_100_000, rate="6.75", issue_ago=353, tenure=1,
         created_ago=349, submitted_ago=341, approved_ago=337, verified_ago=310, doc_ago=345,
         printed="exact"),
    dict(key="X2", inst=14, bank="Union Bank of India", branch="Kalawad Road, Rajkot",
         amount=6_800_000, rate="7.05", issue_ago=348, tenure=1, lien=False,
         created_ago=344, submitted_ago=336, approved_ago=332, updated_ago=200,
         printed="exact"),
    dict(key="X3", inst=4, bank="Bank of India", branch="College Road, Nashik",
         amount=3_500_000, rate="7.30", issue_ago=344, tenure=1,
         created_ago=340, remarks="Awaiting the original receipt before submission."),
    dict(key="X4", inst=8, bank="ICICI Bank", branch="Navrangpura, Ahmedabad",
         amount=4_400_000, rate="6.95", issue_ago=339, tenure=1,
         created_ago=335, submitted_ago=327, approved_ago=323,
         printed="high"),
    dict(key="X5", inst=12, bank="Canara Bank", branch="Hampankatta, Mangaluru",
         amount=2_900_000, rate="7.20", issue_ago=336, tenure=1,
         created_ago=332, submitted_ago=324, approved_ago=320, verified_ago=290,
         printed="exact"),
    # --- maturing in 60-90 days ----------------------------------------------
    dict(key="Y1", inst=1, bank="State Bank of India", branch="Camp, Pune",
         amount=9_000_000, rate="6.80", issue_ago=302, tenure=1,
         created_ago=298, submitted_ago=290, approved_ago=286, verified_ago=260, doc_ago=294,
         printed="exact"),
    dict(key="Y2", inst=5, bank="Punjab National Bank", branch="Bhawarkuan, Indore",
         amount=7_700_000, rate="7.00", issue_ago=294, tenure=1,
         created_ago=290, submitted_ago=282, approved_ago=278,
         number="PNB/2026/00431", printed="exact"),
    dict(key="Y3", inst=9, bank="Bank of Baroda", branch="Sipri Bazar, Jhansi",
         amount=4_500_000, rate="6.85", issue_ago=288, tenure=1,
         created_ago=284, submitted_ago=2, printed="exact"),
    dict(key="Y4", inst=6, bank="Bank of India", branch="Howrah Maidan, Howrah",
         amount=3_300_000, rate="7.35", issue_ago=282, tenure=1,
         created_ago=278, submitted_ago=270, approved_ago=266, requested_ago=6,
         reason="Funds required for an accredited laboratory upgrade.",
         remarks="Checked against the original receipt.", printed="exact"),
    dict(key="Y5", inst=10, bank="Axis Bank", branch="Banjara Hills, Hyderabad",
         amount=8_100_000, rate="7.60", issue_ago=277, tenure=1, lien=False,
         created_ago=273, submitted_ago=265, approved_ago=261, verified_ago=230, doc_ago=269,
         purpose=Purpose.performance_security, printed="exact"),
    dict(key="Y6", inst=13, bank="HDFC Bank", branch="Gomti Nagar, Lucknow",
         amount=6_300_000, rate="2.75", issue_ago=275, tenure=1,
         created_ago=271, submitted_ago=263, approved_ago=259,
         printed="exact"),
    # --- healthy book: approved, maturing later ------------------------------
    dict(key="L1", inst=1, bank="Bank of Baroda", branch="Kothrud, Pune",
         amount=5_500_000, rate="7.10", issue_ago=330, tenure=5,
         created_ago=326, submitted_ago=318, approved_ago=314, verified_ago=280,
         purpose=Purpose.additional_intake, printed="exact"),
    dict(key="L2", inst=2, bank="State Bank of India", branch="Bharathiyar Salai, Tiruchirappalli",
         amount=7_400_000, rate="6.65", issue_ago=500, tenure=10,
         created_ago=496, submitted_ago=488, approved_ago=484, verified_ago=450, doc_ago=492,
         printed="low"),
    dict(key="L3", inst=3, bank="ICICI Bank", branch="C-Scheme, Jaipur",
         amount=4_100_000, rate="7.00", issue_ago=260, tenure=3,
         created_ago=256, submitted_ago=248, approved_ago=244, printed="exact"),
    dict(key="L4", inst=4, bank="Bank of Baroda", branch="Nashik Road, Nashik",
         amount=3_800_000, rate="7.15", issue_ago=200, tenure=2,
         created_ago=196, submitted_ago=188, approved_ago=184, updated_ago=150,
         printed="exact"),
    dict(key="L5", inst=6, bank="Canara Bank", branch="Shibpur, Howrah",
         amount=3_100_000, rate="7.25", issue_ago=160, tenure=2,
         created_ago=156, submitted_ago=148, approved_ago=144, verified_ago=120, doc_ago=152,
         printed="exact"),
    dict(key="L6", inst=7, bank="Union Bank of India", branch="Marine Drive, Kochi",
         amount=4_700_000, rate="6.85", issue_ago=120, tenure=4,
         created_ago=116, submitted_ago=108, approved_ago=104,
         ifsc="UBIN09876", printed="exact"),
    dict(key="L7", inst=8, bank="Axis Bank", branch="CG Road, Ahmedabad",
         amount=4_200_000, rate="7.40", issue_ago=100, tenure=1,
         created_ago=96, submitted_ago=88, approved_ago=84, printed="exact"),
    dict(key="L8", inst=12, bank="Indian Bank", branch="Kadri, Mangaluru",
         amount=2_600_000, rate="7.50", issue_ago=75, tenure=1,
         created_ago=71, submitted_ago=63, approved_ago=59, verified_ago=40, doc_ago=67,
         printed="exact"),
    # --- drafts ---------------------------------------------------------------
    dict(key="D1", inst=11, bank="State Bank of India", branch="Arera Colony, Bhopal",
         amount=5_900_000, rate="7.05", issue_ago=4, tenure=5,
         created_ago=2, remarks="Waiting for the original receipt scan."),
    dict(key="D2", inst=14, bank="Bank of India", branch="Race Course, Rajkot",
         amount=5_000_000, rate="6.90", issue_ago=8, tenure=3,
         created_ago=6, purpose=Purpose.other),
    dict(key="D3", inst=5, bank="Punjab National Bank", branch="Palasia, Indore",
         amount=6_600_000, rate="6.80", issue_ago=12, tenure=2,
         created_ago=9, number="PNB/2026/00431", printed="exact"),
    # --- fresh submissions ----------------------------------------------------
    dict(key="P4", inst=7, bank="State Bank of India", branch="Willingdon Island, Kochi",
         amount=5_200_000, rate="6.95", issue_ago=45, tenure=2,
         created_ago=41, submitted_ago=1, printed="exact"),
    # --- release cycle --------------------------------------------------------
    dict(key="RQ1", inst=2, bank="Axis Bank", branch="Thiruvanaikoil, Tiruchirappalli",
         amount=4_000_000, rate="7.20", issue_ago=225, tenure=1,
         created_ago=221, submitted_ago=213, approved_ago=209, requested_ago=3,
         reason="Course discontinued; deposit to be refunded as per AICTE norms.",
         printed="exact"),
    dict(key="RQ2", inst=6, bank="Indian Bank", branch="Belur, Howrah",
         amount=3_400_000, rate="7.10", issue_ago=155, tenure=1,
         created_ago=151, submitted_ago=143, approved_ago=139, requested_ago=1,
         reason="Institution shifted campus; a fresh deposit is lodged with another bank.",
         printed="exact"),
    dict(key="RL1", inst=3, bank="HDFC Bank", branch="Tonk Road, Jaipur",
         amount=4_600_000, rate="7.00", issue_ago=465, tenure=1,
         created_ago=461, submitted_ago=453, approved_ago=449, verified_ago=420,
         requested_ago=75, released_ago=60, doc_ago=457, printed="exact",
         reason="Programme withdrawn; the deposit is no longer required."),
    dict(key="RL2", inst=9, bank="Canara Bank", branch="Nagra, Jhansi",
         amount=4_000_000, rate="6.80", issue_ago=495, tenure=1,
         created_ago=491, submitted_ago=483, approved_ago=479, verified_ago=440,
         requested_ago=100, released_ago=90,
         reason="Institution merged with a neighbouring polytechnic; deposit refunded."),
    dict(key="RL3", inst=10, bank="State Bank of India", branch="Madhapur, Hyderabad",
         amount=7_000_000, rate="6.75", issue_ago=395, tenure=1,
         created_ago=391, submitted_ago=383, approved_ago=379,
         requested_ago=15, released_ago=8, doc_ago=387, printed="exact",
         reason="Replaced by a higher-value deposit held with the same branch."),
    # --- rejected -------------------------------------------------------------
    dict(key="RJ1", inst=9, bank="Punjab National Bank", branch="Gwalior Road, Jhansi",
         amount=4_000_000, rate="6.90", issue_ago=55, tenure=2,
         created_ago=51, submitted_ago=40, rejected_ago=32,
         remark="Receipt copy not legible; re-submit with a clear scan."),
    dict(key="RJ2", inst=11, bank="ICICI Bank", branch="MP Nagar, Bhopal",
         amount=5_500_000, rate="7.30", issue_ago=70, tenure=1,
         created_ago=66, submitted_ago=50, rejected_ago=44,
         remark="Printed maturity amount does not match the computed value."),
    dict(key="RJ3", inst=13, bank="Bank of Baroda", branch="Aliganj, Lucknow",
         amount=4_800_000, rate="7.00", issue_ago=90, tenure=3,
         created_ago=86, submitted_ago=66, rejected_ago=58,
         remark="Institution name on the receipt differs from the register."),
    # --- renewals: the old FDR plus its linked replacement --------------------
    dict(key="N1", inst=5, bank="State Bank of India", branch="Vijay Nagar, Indore",
         amount=6_000_000, rate="7.25", issue_ago=440, tenure=1,
         created_ago=436, submitted_ago=428, approved_ago=424, verified_ago=400,
         renewed_ago=78, doc_ago=432, printed="exact"),
    dict(key="N1R", inst=5, bank="State Bank of India", branch="Vijay Nagar, Indore",
         amount=6_440_000, rate="7.10", issue_ago=78, tenure=5,
         created_ago=78, submitted_ago=77, renews="N1", doc_ago=75, printed="exact"),
    dict(key="N2", inst=8, bank="ICICI Bank", branch="Prahlad Nagar, Ahmedabad",
         amount=3_900_000, rate="7.35", issue_ago=410, tenure=1,
         created_ago=406, submitted_ago=398, approved_ago=394, verified_ago=370,
         renewed_ago=48, doc_ago=402, printed="exact"),
    dict(key="N2R", inst=8, bank="ICICI Bank", branch="Prahlad Nagar, Ahmedabad",
         amount=4_230_000, rate="7.15", issue_ago=48, tenure=3,
         created_ago=48, submitted_ago=47, renews="N2", printed="exact"),
    dict(key="N3", inst=14, bank="Union Bank of India", branch="Yagnik Road, Rajkot",
         amount=6_200_000, rate="6.95", issue_ago=750, tenure=2,
         created_ago=PORTAL_OPEN_DAYS_AGO - 1, submitted_ago=532, approved_ago=528,
         verified_ago=500, renewed_ago=18, doc_ago=536, printed="exact"),
    dict(key="N3R", inst=14, bank="Union Bank of India", branch="Yagnik Road, Rajkot",
         amount=7_120_000, rate="7.00", issue_ago=18, tenure=4,
         created_ago=18, submitted_ago=17, renews="N3", printed="exact"),
]

# fdr_number serial bases per bank, so auto numbers look bank-issued.
_NUMBER_BASE = {
    "State Bank of India": 18_470, "Bank of Baroda": 30_215, "Punjab National Bank": 4_310,
    "Canara Bank": 52_108, "Union Bank of India": 26_549, "Bank of India": 41_732,
    "Indian Bank": 33_906, "HDFC Bank": 7_845, "ICICI Bank": 15_623, "Axis Bank": 60_914,
}


def _add_years(day: date, years: int) -> date:
    try:
        return day.replace(year=day.year + years)
    except ValueError:  # 29 February
        return day.replace(year=day.year + years, day=28)


def _at(days_ago: int) -> datetime:
    """A deterministic office-hours timestamp the given number of days ago (UTC)."""
    day = today() - timedelta(days=days_ago)
    return datetime(
        day.year, day.month, day.day, _RNG.randint(9, 17), _RNG.randint(0, 59),
        tzinfo=timezone.utc,
    )


def _receipt_pdf(bank: str, branch: str, number: str, institution: str, amount: Decimal,
                 issue: date, maturity: date, rate: Decimal, maturity_amount: Decimal | None,
                 lien: bool) -> bytes:
    """A minimal one-page PDF that stands in for a scanned FDR receipt."""
    lines: list[tuple[str, int, bool]] = [
        (bank, 16, True),
        (f"Branch: {branch}", 11, False),
        ("FIXED DEPOSIT RECEIPT", 14, True),
        (f"Receipt No: {number}", 11, False),
        (f"Depositor: {institution}", 11, False),
        (f"Principal: Rs. {float(amount):,.2f}", 11, False),
        (f"Date of Issue: {issue.strftime('%d %b %Y')}", 11, False),
        (f"Date of Maturity: {maturity.strftime('%d %b %Y')}", 11, False),
        (f"Rate of Interest: {rate}% p.a. (quarterly compounding)", 11, False),
        (f"Maturity Amount: Rs. {float(maturity_amount):,.2f}" if maturity_amount
         else "Maturity Amount: as per the statement of deposit", 11, False),
        ("Held in joint name with lien marked to AICTE" if lien else "Not lien marked", 11, False),
        ("Sample receipt generated for the demonstration dataset.", 9, False),
    ]
    escaped: list[str] = []
    y = 780
    for text, size, bold in lines:
        font = "/F2" if bold else "/F1"
        safe = text.replace("\\", r"\\").replace("(", r"\(").replace(")", r"\)")
        escaped.append(f"BT {font} {size} Tf 60 {y} Td ({safe}) Tj ET")
        y -= 24
    stream = "\n".join(escaped).encode("latin-1", "replace")
    objects = [
        b"<< /Type /Catalog /Pages 2 0 R >>",
        b"<< /Type /Pages /Kids [3 0 R] /Count 1 >>",
        b"<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] "
        b"/Resources << /Font << /F1 4 0 R /F2 5 0 R >> >> /Contents 6 0 R >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>",
        b"<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica-Bold >>",
        b"<< /Length " + str(len(stream)).encode() + b" >>\nstream\n" + stream + b"\nendstream",
    ]
    out = bytearray(b"%PDF-1.4\n")
    offsets: list[int] = []
    for n, body in enumerate(objects, start=1):
        offsets.append(len(out))
        out += f"{n} 0 obj\n".encode() + body + b"\nendobj\n"
    xref_at = len(out)
    out += f"xref\n0 {len(objects) + 1}\n".encode()
    out += b"0000000000 65535 f \n"
    for offset in offsets:
        out += f"{offset:010d} 00000 n \n".encode()
    out += (
        f"trailer\n<< /Size {len(objects) + 1} /Root 1 0 R >>\nstartxref\n{xref_at}\n%%EOF\n"
    ).encode()
    return bytes(out)


def _seed(db: Session) -> None:
    admin = User(
        name=_USERS[0][0], email=_USERS[0][1], password_hash=hash_password(_USERS[0][2]),
        role=_USERS[0][3], created_at=_at(PORTAL_OPEN_DAYS_AGO),
    )
    reviewer = User(
        name=_USERS[1][0], email=_USERS[1][1], password_hash=hash_password(_USERS[1][2]),
        role=_USERS[1][3], created_at=_at(PORTAL_OPEN_DAYS_AGO),
    )
    approver = User(
        name=_USERS[2][0], email=_USERS[2][1], password_hash=hash_password(_USERS[2][2]),
        role=_USERS[2][3], created_at=_at(PORTAL_OPEN_DAYS_AGO),
    )
    auditor = User(
        name=_USERS[3][0], email=_USERS[3][1], password_hash=hash_password(_USERS[3][2]),
        role=_USERS[3][3], created_at=_at(PORTAL_OPEN_DAYS_AGO),
    )
    db.add_all([admin, reviewer, approver, auditor])
    db.flush()

    institutions: list[Institution] = []
    for name, aicte_id, city, state, type_name, required in _INSTITUTIONS:
        institutions.append(Institution(
            name=name, aicte_id=aicte_id, city=city, state=state,
            type=InstitutionType(type_name), required_deposit=Decimal(required),
            created_at=_at(PORTAL_OPEN_DAYS_AGO),
        ))
    db.add_all(institutions)
    db.flush()

    inst_deccan = User(
        name=f"Deposit Cell, {institutions[0].name}",
        email="deccan.crest@fdrportal.demo",
        password_hash=hash_password("Inst@2026"),
        role=Role.institution,
        institution_id=institutions[0].id,
        created_at=_at(PORTAL_OPEN_DAYS_AGO),
    )
    inst_kaveri = User(
        name=f"Deposit Cell, {institutions[1].name}",
        email="kaveri.delta@fdrportal.demo",
        password_hash=hash_password("Inst@2026"),
        role=Role.institution,
        institution_id=institutions[1].id,
        created_at=_at(PORTAL_OPEN_DAYS_AGO),
    )
    inst_bundelkhand = User(
        name=f"Deposit Cell, {institutions[8].name}",
        email="bundelkhand.skills@fdrportal.demo",
        password_hash=hash_password("Inst@2026"),
        role=Role.institution,
        institution_id=institutions[8].id,
        created_at=_at(PORTAL_OPEN_DAYS_AGO),
    )
    db.add_all([inst_deccan, inst_kaveri, inst_bundelkhand])
    db.flush()

    # Audit events are collected first and written in chronological order at
    # the end, because the chain order is the row-id order.
    events: list[tuple[datetime, dict[str, Any]]] = []

    def add_event(at: datetime, **kwargs: Any) -> None:
        events.append((at, kwargs))

    for index, inst in enumerate(institutions):
        add_event(
            _at(PORTAL_OPEN_DAYS_AGO) + timedelta(minutes=index),
            actor=admin, action="institution.created", entity=AuditEntity.institution,
            entity_id=inst.id, detail={"name": inst.name, "aicte_id": inst.aicte_id},
        )

    ordered = sorted(_FDRS, key=lambda spec: spec["created_ago"], reverse=True)
    by_key: dict[str, Fdr] = {}
    counters: dict[str, int] = {}
    for spec in ordered:
        bank = spec["bank"]
        issue = today() - timedelta(days=spec["issue_ago"])
        maturity = _add_years(issue, spec["tenure"])
        number: str = spec.get("number") or ""
        if not number:
            counters[bank] = counters.get(bank, _NUMBER_BASE[bank]) + 13
            number = f"{_FDR_NUMBER_CODES[bank]}/{issue.year}/{counters[bank]:05d}"
        digits = f"{spec['inst']:02d}{counters.get(bank, 1) % 10000:04d}"
        ifsc = spec.get("ifsc") or f"{_IFSC_PREFIX[bank]}0{digits}"
        created = _at(spec["created_ago"])
        fdr = Fdr(
            fdr_number=number, institution_id=institutions[spec["inst"] - 1].id,
            bank_name=bank, branch=spec["branch"], ifsc=ifsc,
            amount=Decimal(spec["amount"]), issue_date=issue, maturity_date=maturity,
            interest_rate=Decimal(spec["rate"]),
            purpose=spec.get("purpose", Purpose.security_deposit),
            lien_to_aicte=spec.get("lien", True),
            status=FdrStatus.draft, verification=Verification.submitted,
            remarks=spec.get("remarks"), created_by_id=admin.id, created_at=created,
        )
        db.add(fdr)
        by_key[spec["key"]] = fdr
        if not spec.get("renews"):  # replacements get their renewal-flavoured event below
            add_event(
                created, actor=admin, action="fdr.created", entity=AuditEntity.fdr,
                note_fdr=fdr, note_from=None, note_to=FdrStatus.draft,
                detail={"fdr_number": number, "institution": institutions[spec["inst"] - 1].name,
                        "bank": bank, "amount": float(spec["amount"])},
            )
    db.flush()

    for spec in _FDRS:
        if spec.get("renews"):
            by_key[spec["key"]].renewed_from_id = by_key[spec["renews"]].id
    db.flush()

    def lifecycle(spec: dict[str, Any]) -> None:
        fdr = by_key[spec["key"]]
        if spec.get("renews"):
            old = by_key[spec["renews"]]
            add_event(
                _at(spec["created_ago"]), actor=admin, action="fdr.created",
                entity=AuditEntity.fdr, note_fdr=fdr, note_from=None, note_to=FdrStatus.draft,
                detail={"fdr_number": fdr.fdr_number, "note": f"Renewal of {old.fdr_number}",
                        "amount": float(spec["amount"])},
            )
        if "submitted_ago" in spec:
            add_event(
                _at(spec["submitted_ago"]), actor=admin, action="fdr.submitted",
                entity=AuditEntity.fdr, note_fdr=fdr,
                note_from=FdrStatus.draft, note_to=FdrStatus.pending_approval,
            )
        if "approved_ago" in spec:
            add_event(
                _at(spec["approved_ago"]), actor=reviewer, action="fdr.approved",
                entity=AuditEntity.fdr, note_fdr=fdr,
                note_from=FdrStatus.pending_approval, note_to=FdrStatus.approved,
            )
        if "rejected_ago" in spec:
            add_event(
                _at(spec["rejected_ago"]), actor=reviewer, action="fdr.rejected",
                entity=AuditEntity.fdr, note_fdr=fdr, detail={"remark": spec["remark"]},
                note_from=FdrStatus.pending_approval, note_to=FdrStatus.rejected,
            )
        if "requested_ago" in spec:
            add_event(
                _at(spec["requested_ago"]), actor=admin, action="fdr.release_requested",
                entity=AuditEntity.fdr, note_fdr=fdr, detail={"reason": spec["reason"]},
                note_from=FdrStatus.approved, note_to=FdrStatus.release_requested,
            )
        if "released_ago" in spec:
            add_event(
                _at(spec["released_ago"]), actor=reviewer, action="fdr.released",
                entity=AuditEntity.fdr, note_fdr=fdr,
                note_from=FdrStatus.release_requested, note_to=FdrStatus.released,
            )
        if "renewed_ago" in spec:
            replacement = next(s for s in _FDRS if s.get("renews") == spec["key"])
            new_fdr = by_key[replacement["key"]]
            add_event(
                _at(spec["renewed_ago"]), actor=admin, action="fdr.renewed",
                entity=AuditEntity.fdr, note_fdr=fdr,
                note_from=FdrStatus.approved, note_to=FdrStatus.renewed,
                detail={"renewed_to": {"id": new_fdr.id, "fdr_number": new_fdr.fdr_number}},
            )
        if "verified_ago" in spec:
            add_event(
                _at(spec["verified_ago"]), actor=reviewer, action="fdr.verified",
                entity=AuditEntity.fdr, note_fdr=fdr,
                detail={"verification": "officer_verified"},
            )
        if "updated_ago" in spec:
            add_event(
                _at(spec["updated_ago"]), actor=admin, action="fdr.updated",
                entity=AuditEntity.fdr, note_fdr=fdr,
                detail={"fields": ["branch", "remarks"]},
            )

    # Final status, verification flag and printed maturity amount per row.
    for spec in _FDRS:
        fdr = by_key[spec["key"]]
        if "renewed_ago" in spec:
            fdr.status = FdrStatus.renewed
        elif "released_ago" in spec:
            fdr.status = FdrStatus.released
        elif "rejected_ago" in spec:
            fdr.status = FdrStatus.rejected
        elif "requested_ago" in spec:
            fdr.status = FdrStatus.release_requested
        elif "approved_ago" in spec:
            fdr.status = FdrStatus.approved
        elif "submitted_ago" in spec:
            fdr.status = FdrStatus.pending_approval
        else:
            fdr.status = FdrStatus.draft
        fdr.verification = Verification.officer_verified if "verified_ago" in spec else Verification.submitted
        printed = spec.get("printed")
        if printed:
            value = projected_value(fdr.amount, fdr.interest_rate, fdr.issue_date, fdr.maturity_date)
            if printed == "high":
                value *= 1.09
            elif printed == "low":
                value *= 0.94
            fdr.maturity_amount = Decimal(str(round(value, 2)))

    # Sample receipt PDFs; written after the printed values above so the
    # document matches (or deliberately mismatches, for the two planted ones).
    for spec in _FDRS:
        if "doc_ago" not in spec:
            continue
        fdr = by_key[spec["key"]]
        pdf = _receipt_pdf(
            fdr.bank_name, fdr.branch or "", fdr.fdr_number,
            institutions[spec["inst"] - 1].name, fdr.amount,
            fdr.issue_date, fdr.maturity_date, fdr.interest_rate, fdr.maturity_amount,
            fdr.lien_to_aicte,
        )
        stored_name = f"{uuid.uuid4().hex}.pdf"
        (settings.upload_dir / stored_name).write_bytes(pdf)
        document = Document(
            fdr_id=fdr.id, filename=f"{fdr.fdr_number.replace('/', '-')}-receipt.pdf",
            stored_name=stored_name, content_type="application/pdf", size_bytes=len(pdf),
            uploaded_by_id=admin.id, uploaded_at=_at(spec["doc_ago"]),
            doc_type=DocumentType.fdr_receipt,
        )
        db.add(document)
        db.flush()
        add_event(
            _at(spec["doc_ago"]), actor=admin, action="document.uploaded",
            entity=AuditEntity.document, entity_id=document.id, fdr_id=fdr.id,
            detail={"filename": document.filename, "doc_type": "fdr_receipt"},
        )

    for spec in _FDRS:
        lifecycle(spec)

    events.sort(key=lambda item: item[0])
    last_touch: dict[int, datetime] = {}
    for at, kwargs in events:
        fdr_row: Fdr | None = kwargs.pop("note_fdr", None)
        from_status = kwargs.pop("note_from", None)
        to_status = kwargs.pop("note_to", None)
        if fdr_row is not None:
            kwargs["fdr_id"] = fdr_row.id
            if kwargs.get("entity") is AuditEntity.fdr:
                kwargs["entity_id"] = fdr_row.id
            if fdr_row.id not in last_touch or at > last_touch[fdr_row.id]:
                last_touch[fdr_row.id] = at
        write_audit(
            db, actor=kwargs.pop("actor"), at=at,
            from_status=from_status.value if from_status else None,
            to_status=to_status.value if to_status else None,
            **kwargs,
        )

    for fdr in by_key.values():
        fdr.updated_at = last_touch.get(fdr.id, fdr.created_at)


def run(db: Session) -> None:
    """Seed the demo data once. Safe to call again: it does nothing when users exist."""
    if db.scalar(select(func.count(User.id))):
        return
    _seed(db)
    db.commit()
    run_alerts(db)
    db.commit()
