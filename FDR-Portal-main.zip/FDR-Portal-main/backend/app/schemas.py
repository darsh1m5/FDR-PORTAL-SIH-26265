"""Pydantic request and response models for the REST API."""

from datetime import date, datetime
from decimal import Decimal
from typing import Any, Generic, Literal, TypeVar

from pydantic import BaseModel, ConfigDict, Field, field_validator, model_validator

from app.constants import IFSC_RE
from app.models import (
    AlertType,
    FdrStatus,
    InstitutionType,
    Purpose,
    Role,
    Severity,
    Verification,
    NoticeKind,
    DocumentType,
    ObservationStatus,
)

T = TypeVar("T")

MaturityState = Literal["matured", "due_7", "due_30", "due_60", "due_90", "active", "closed"]
AllowedAction = Literal[
    "edit",
    "submit",
    "approve",
    "reject",
    "request_release",
    "renew",
    "verify",
    "upload",
    "sanction_release",
    "return_release",
    "observe",
    "respond",
    "bank_confirm",
]


class Page(BaseModel, Generic[T]):
    items: list[T]
    total: int
    page: int
    page_size: int


# ---------- auth / meta ----------


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)

    id: int
    name: str
    email: str
    role: Role
    institution_id: int | None = None
    institution_name: str | None = None

    @model_validator(mode="before")
    @classmethod
    def _extract_institution(cls, data: Any) -> Any:
        if hasattr(data, "institution") and getattr(data, "institution", None):
            inst = getattr(data, "institution")
            if isinstance(data, dict):
                data["institution_name"] = inst.name
            else:
                return {
                    "id": data.id,
                    "name": data.name,
                    "email": data.email,
                    "role": data.role,
                    "institution_id": data.institution_id,
                    "institution_name": inst.name,
                }
        return data


class LoginIn(BaseModel):
    email: str = Field(min_length=3, max_length=200)
    password: str = Field(min_length=1, max_length=200)


class LoginOut(BaseModel):
    access_token: str
    token_type: Literal["bearer"] = "bearer"
    user: UserOut


class Option(BaseModel):
    value: str
    label: str


class MetaOut(BaseModel):
    banks: list[str]
    purposes: list[Option]
    statuses: list[Option]
    institution_types: list[str]
    roles: list[Option]
    document_types: list[Option] = Field(default_factory=list)


# ---------- shared pieces ----------


class Finding(BaseModel):
    code: str
    severity: Severity
    message: str
    fix: str


class FdrRef(BaseModel):
    id: int
    fdr_number: str


class DocumentItem(BaseModel):
    id: int
    filename: str
    content_type: str
    size_bytes: int
    uploaded_by: str | None
    uploaded_at: datetime
    doc_type: DocumentType = DocumentType.fdr_receipt
    doc_type_label: str = "FDR receipt"
    sha256: str | None = None


class ObservationItem(BaseModel):
    id: int
    fdr_id: int
    text: str
    author_name: str
    author_role: Role
    created_at: datetime
    response: str | None = None
    responded_by: str | None = None
    responded_at: datetime | None = None
    status: ObservationStatus


class ObservationIn(BaseModel):
    text: str = Field(min_length=3, max_length=2000)


class ObservationRespondIn(BaseModel):
    response: str = Field(min_length=3, max_length=2000)


class AuditItem(BaseModel):
    id: int
    at: datetime
    actor_name: str
    actor_role: Role | None
    action: str
    action_label: str
    entity: str
    entity_id: int | None
    fdr_id: int | None
    fdr_number: str | None
    from_status: str | None
    to_status: str | None
    detail: dict[str, Any]


# ---------- FDRs ----------


class FdrListItem(BaseModel):
    id: int
    fdr_number: str
    institution_id: int
    institution_name: str
    bank_name: str
    amount: float
    issue_date: date
    maturity_date: date
    interest_rate: float
    purpose: Purpose
    status: FdrStatus
    verification: Verification
    days_to_maturity: int
    maturity_state: MaturityState
    health_score: int
    findings_count: int
    document_count: int


class FdrPage(Page[FdrListItem]):
    """Register page plus the principal of every row matching the filters (not just this page)."""

    total_amount: float


class ReleaseChecklist(BaseModel):
    affidavit_received: bool
    no_pending_complaints: bool
    institution_closure_certificate: bool | None = None
    matured_or_lock_in_complete: bool
    bank_discharge_noted: bool


class LineageItem(BaseModel):
    id: int
    fdr_number: str
    status: FdrStatus
    issue_date: date
    maturity_date: date
    amount: float


class FdrDetail(FdrListItem):
    branch: str | None
    ifsc: str | None
    maturity_amount: float | None
    lien_to_aicte: bool
    remarks: str | None
    projected_value: float
    findings: list[Finding]
    documents: list[DocumentItem]
    history: list[AuditItem]
    renewed_from: FdrRef | None
    renewed_to: FdrRef | None
    created_by: str
    created_at: datetime
    updated_at: datetime
    allowed_actions: list[AllowedAction]
    notices_count: int = 0
    release_checklist: ReleaseChecklist | None = None
    release_ready: bool | None = None
    lineage: list[LineageItem] = Field(default_factory=list)
    observations_open: int = 0


def _clean_optional(value: str | None) -> str | None:
    if value is None:
        return None
    value = value.strip()
    return value or None


class _FdrFields(BaseModel):
    """Field rules shared by create, renew and patch."""

    @field_validator("fdr_number", "bank_name", mode="before", check_fields=False)
    @classmethod
    def _strip(cls, value: Any) -> Any:
        return value.strip() if isinstance(value, str) else value

    @field_validator("branch", "remarks", mode="before", check_fields=False)
    @classmethod
    def _optional_text(cls, value: Any) -> Any:
        return _clean_optional(value) if isinstance(value, str) else value

    @field_validator("ifsc", mode="before", check_fields=False)
    @classmethod
    def _ifsc(cls, value: Any) -> Any:
        if not isinstance(value, str):
            return value
        cleaned = value.strip().upper()
        if not cleaned:
            return None
        if not IFSC_RE.match(cleaned):
            raise ValueError("IFSC must be 4 letters, a zero, then 6 letters or digits (e.g. SBIN0001234)")
        return cleaned


class FdrInput(_FdrFields):
    fdr_number: str = Field(min_length=1, max_length=40)
    institution_id: int
    bank_name: str = Field(min_length=1, max_length=80)
    branch: str | None = Field(default=None, max_length=120)
    ifsc: str | None = Field(default=None, max_length=11)
    amount: Decimal = Field(gt=0, max_digits=14, decimal_places=2)
    issue_date: date
    maturity_date: date
    interest_rate: Decimal = Field(gt=0, le=20, max_digits=5, decimal_places=2)
    maturity_amount: Decimal | None = Field(default=None, gt=0, max_digits=14, decimal_places=2)
    purpose: Purpose = Purpose.security_deposit
    lien_to_aicte: bool = False
    remarks: str | None = Field(default=None, max_length=2000)

    @model_validator(mode="after")
    def _dates(self) -> "FdrInput":
        if self.maturity_date <= self.issue_date:
            raise ValueError("Maturity date must be after the issue date")
        return self


class RenewInput(FdrInput):
    """Same as FdrInput; institution_id is ignored and taken from the old FDR."""

    institution_id: int | None = None  # type: ignore[assignment]


class FdrPatch(_FdrFields):
    fdr_number: str | None = Field(default=None, min_length=1, max_length=40)
    institution_id: int | None = None
    bank_name: str | None = Field(default=None, min_length=1, max_length=80)
    branch: str | None = Field(default=None, max_length=120)
    ifsc: str | None = Field(default=None, max_length=11)
    amount: Decimal | None = Field(default=None, gt=0, max_digits=14, decimal_places=2)
    issue_date: date | None = None
    maturity_date: date | None = None
    interest_rate: Decimal | None = Field(default=None, gt=0, le=20, max_digits=5, decimal_places=2)
    maturity_amount: Decimal | None = Field(default=None, gt=0, max_digits=14, decimal_places=2)
    purpose: Purpose | None = None
    lien_to_aicte: bool | None = None
    remarks: str | None = Field(default=None, max_length=2000)


class DecisionIn(BaseModel):
    action: Literal["approve", "reject"]
    remark: str | None = Field(default=None, max_length=1000)

    @model_validator(mode="after")
    def _remark_on_reject(self) -> "DecisionIn":
        self.remark = _clean_optional(self.remark)
        if self.action == "reject" and not self.remark:
            raise ValueError("A remark is required to reject")
        return self


class ReleaseIn(BaseModel):
    reason: str = Field(min_length=3, max_length=1000)
    checklist: ReleaseChecklist | None = None

    @field_validator("reason")
    @classmethod
    def _reason(cls, value: str) -> str:
        value = value.strip()
        if len(value) < 3:
            raise ValueError("Give a reason for the release request")
        return value


class VerifyIn(BaseModel):
    remark: str | None = Field(default=None, max_length=1000)


# ---------- institutions ----------


class InstitutionItem(BaseModel):
    id: int
    name: str
    aicte_id: str
    city: str
    state: str
    type: InstitutionType
    required_deposit: float
    fdr_count: int
    active_amount: float
    health_score: int | None
    shortfall: float


class InstitutionDetail(InstitutionItem):
    fdrs: list[FdrListItem]
    users_count: int = 0


class InstitutionInput(BaseModel):
    name: str = Field(min_length=3, max_length=200)
    aicte_id: str = Field(min_length=3, max_length=40)
    city: str = Field(min_length=2, max_length=80)
    state: str = Field(min_length=2, max_length=80)
    type: InstitutionType
    required_deposit: Decimal = Field(ge=0, max_digits=14, decimal_places=2)

    @field_validator("name", "aicte_id", "city", "state", mode="before")
    @classmethod
    def _strip(cls, value: Any) -> Any:
        return value.strip() if isinstance(value, str) else value


# ---------- dashboard ----------


class Kpis(BaseModel):
    total_count: int
    total_amount: float
    active_count: int
    active_amount: float
    pending_approvals: int
    release_requests: int
    maturing_30: int
    maturing_90: int
    overdue: int
    open_alerts: int
    avg_health: int | None
    escalated_alerts: int = 0
    observations_open: int = 0


class StatusBucket(BaseModel):
    status: FdrStatus
    label: str
    count: int
    amount: float


class BankBucket(BaseModel):
    bank: str
    count: int
    amount: float


class TimelineMonth(BaseModel):
    month: str
    count: int
    amount: float


class DashboardOut(BaseModel):
    kpis: Kpis
    by_status: list[StatusBucket]
    by_bank: list[BankBucket]
    timeline: list[TimelineMonth]
    upcoming: list[FdrListItem]
    activity: list[AuditItem]


# ---------- approvals ----------


class ApprovalItem(BaseModel):
    fdr: FdrListItem
    kind: Literal["approval", "release"]
    requested_at: datetime
    requested_by: str
    waiting_days: int
    reason: str | None
    release_checklist: ReleaseChecklist | None = None
    release_ready: bool | None = None


class ApprovalsOut(BaseModel):
    items: list[ApprovalItem]


# ---------- alerts ----------


class AlertItem(BaseModel):
    id: int
    fdr_id: int
    fdr_number: str
    institution_name: str
    type: AlertType
    severity: Severity
    message: str
    due_date: date | None
    days: int | None
    created_at: datetime
    acknowledged_at: datetime | None
    acknowledged_by: str | None
    escalated: bool = False
    escalated_at: datetime | None = None
    age_days: int = 0


class AlertRunOut(BaseModel):
    created: int
    resolved: int
    open: int


# ---------- settings ----------


class SettingsIO(BaseModel):
    reminder_days: list[int] = Field(min_length=1, max_length=8)
    overdue_grace_days: int = Field(ge=0, le=365)
    pending_sla_days: int = Field(ge=1, le=365)
    interest_min: float = Field(ge=0, le=20)
    interest_max: float = Field(gt=0, le=20)
    escalate_after_days: int | None = Field(default=None, ge=1, le=60)

    @field_validator("reminder_days")
    @classmethod
    def _days(cls, value: list[int]) -> list[int]:
        if any(d < 1 or d > 730 for d in value):
            raise ValueError("Reminder days must be between 1 and 730")
        return sorted(set(value), reverse=True)

    @model_validator(mode="after")
    def _band(self) -> "SettingsIO":
        if self.interest_min >= self.interest_max:
            raise ValueError("Minimum interest rate must be below the maximum")
        return self


# ---------- audit ----------


class AuditVerifyOut(BaseModel):
    intact: bool
    checked: int
    broken_at: int | None


# ---------- innovation ----------


class RadarItem(BaseModel):
    id: int
    fdr_number: str
    institution_name: str
    amount: float
    projected_value: float
    maturity_date: date
    days_to_maturity: int
    status: FdrStatus


class RadarMonth(BaseModel):
    month: str
    count: int
    principal: float
    projected: float
    items: list[RadarItem]


class RadarOut(BaseModel):
    months: list[RadarMonth]


class FindingsRow(BaseModel):
    fdr_id: int
    fdr_number: str
    institution_name: str
    status: FdrStatus
    health_score: int
    findings: list[Finding]


# ---------- metrics ----------


class MonthlyMetric(BaseModel):
    month: str
    decided: int
    avg_turnaround_days: float | None


class BureauMetrics(BaseModel):
    approval_turnaround_days: float | None
    release_turnaround_days: float | None
    pending_over_sla: int
    verification_rate: float
    document_coverage: float
    renewal_on_time_rate: float | None
    data_quality_rate: float
    alert_ack_median_hours: float | None
    bank_confirmed_share: float | None = None
    monthly: list[MonthlyMetric]


# ---------- notices ----------


class NoticeLetter(BaseModel):
    subject: str
    salutation: str
    body: list[str]
    closing: str


class NoticeItem(BaseModel):
    id: int
    reference_no: str
    kind: NoticeKind
    kind_label: str
    issued_at: datetime
    issued_by: str
    fdr_id: int | None
    fdr_number: str | None
    institution_id: int | None
    institution_name: str
    letter: NoticeLetter
    verify_code: str | None = None


class NoticeVerifyOut(BaseModel):
    valid: bool
    reference_no: str | None = None
    kind_label: str | None = None
    issued_at: datetime | None = None
    institution_name: str | None = None
    fdr_number: str | None = None


class NoticeCandidates(BaseModel):
    maturity: list[FdrListItem]
    overdue: list[FdrListItem]
    shortfall: list[InstitutionItem]


class NoticeCreateIn(BaseModel):
    kind: NoticeKind
    fdr_id: int | None = None
    institution_id: int | None = None


# ---------- imports ----------


class ImportRow(BaseModel):
    row: int
    status: Literal["valid", "warning", "error"]
    data: FdrInput | None
    institution_name: str | None
    errors: list[str]
    findings: list[Finding]


class ImportPreview(BaseModel):
    rows: list[ImportRow]
    valid_count: int
    error_count: int
    warning_count: int


class ImportCommitIn(BaseModel):
    rows: list[FdrInput] = Field(min_length=1, max_length=500)
    source_name: str = Field(min_length=1, max_length=200)


class ImportCommitOut(BaseModel):
    created: int
    batch: str
    ids: list[int]


