"""SQLAlchemy models: users, institutions, FDRs, documents, alerts, settings, audit log."""

from datetime import date, datetime, timezone
from decimal import Decimal
from enum import StrEnum
from typing import Any

from sqlalchemy import (
    JSON,
    Boolean,
    Date,
    DateTime,
    Enum,
    ForeignKey,
    Index,
    Integer,
    Numeric,
    String,
    Text,
)
from sqlalchemy.engine import Dialect
from sqlalchemy.orm import Mapped, mapped_column, relationship
from sqlalchemy.types import TypeDecorator

from app.config import utcnow
from app.db import Base


class Role(StrEnum):
    admin = "admin"
    reviewer = "reviewer"
    approver = "approver"
    auditor = "auditor"
    institution = "institution"


class InstitutionType(StrEnum):
    engineering = "Engineering"
    management = "Management"
    pharmacy = "Pharmacy"
    architecture = "Architecture"
    polytechnic = "Polytechnic"


class Purpose(StrEnum):
    security_deposit = "security_deposit"
    additional_intake = "additional_intake"
    performance_security = "performance_security"
    other = "other"


class FdrStatus(StrEnum):
    draft = "draft"
    pending_approval = "pending_approval"
    approved = "approved"
    rejected = "rejected"
    release_requested = "release_requested"
    released = "released"
    renewed = "renewed"


class Verification(StrEnum):
    submitted = "submitted"
    officer_verified = "officer_verified"
    bank_confirmed = "bank_confirmed"


class AlertType(StrEnum):
    maturity_upcoming = "maturity_upcoming"
    matured_overdue = "matured_overdue"
    pending_too_long = "pending_too_long"
    discrepancy = "discrepancy"
    observation_unanswered = "observation_unanswered"


class Severity(StrEnum):
    info = "info"
    warning = "warning"
    critical = "critical"


class NoticeKind(StrEnum):
    maturity_reminder = "maturity_reminder"
    overdue_notice = "overdue_notice"
    shortfall_notice = "shortfall_notice"
    release_letter = "release_letter"


class DocumentType(StrEnum):
    fdr_receipt = "fdr_receipt"
    lien_letter = "lien_letter"
    affidavit = "affidavit"
    closure_certificate = "closure_certificate"
    renewal_letter = "renewal_letter"
    bank_confirmation = "bank_confirmation"
    other = "other"


class ObservationStatus(StrEnum):
    open = "open"
    answered = "answered"
    closed = "closed"


class AuditEntity(StrEnum):
    fdr = "fdr"
    document = "document"
    alert = "alert"
    settings = "settings"
    auth = "auth"
    export = "export"
    institution = "institution"
    import_entity = "import"
    notice = "notice"
    observation = "observation"


class UtcDateTime(TypeDecorator[datetime]):
    """Stores naive UTC in SQLite and always returns timezone-aware UTC datetimes."""

    impl = DateTime
    cache_ok = True

    def process_bind_param(self, value: datetime | None, dialect: Dialect) -> datetime | None:
        if value is None:
            return None
        if value.tzinfo is None:
            value = value.replace(tzinfo=timezone.utc)
        return value.astimezone(timezone.utc).replace(tzinfo=None)

    def process_result_value(self, value: datetime | None, dialect: Dialect) -> datetime | None:
        if value is None:
            return None
        return value.replace(tzinfo=timezone.utc)


def _enum(enum_cls: type[StrEnum], length: int = 32) -> Enum:
    """Store enums as their string values (not names), without a DB-level CHECK."""
    return Enum(
        enum_cls,
        values_callable=lambda members: [m.value for m in members],
        native_enum=False,
        create_constraint=False,
        length=length,
        validate_strings=True,
    )


class User(Base):
    __tablename__ = "users"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(120))
    email: Mapped[str] = mapped_column(String(200), unique=True, index=True)
    password_hash: Mapped[str] = mapped_column(String(200))
    role: Mapped[Role] = mapped_column(_enum(Role, 16))
    institution_id: Mapped[int | None] = mapped_column(
        ForeignKey("institutions.id"), nullable=True, index=True
    )
    is_active: Mapped[bool] = mapped_column(Boolean, default=True)
    created_at: Mapped[datetime] = mapped_column(UtcDateTime(), default=utcnow)

    institution: Mapped["Institution | None"] = relationship()


class Institution(Base):
    __tablename__ = "institutions"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    name: Mapped[str] = mapped_column(String(200), index=True)
    aicte_id: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    city: Mapped[str] = mapped_column(String(80))
    state: Mapped[str] = mapped_column(String(80))
    type: Mapped[InstitutionType] = mapped_column(_enum(InstitutionType, 20))
    required_deposit: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    created_at: Mapped[datetime] = mapped_column(UtcDateTime(), default=utcnow)

    fdrs: Mapped[list["Fdr"]] = relationship(back_populates="institution")


class Fdr(Base):
    __tablename__ = "fdrs"
    __table_args__ = (Index("ix_fdrs_number_bank", "fdr_number", "bank_name"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fdr_number: Mapped[str] = mapped_column(String(40), index=True)
    institution_id: Mapped[int] = mapped_column(ForeignKey("institutions.id"), index=True)
    bank_name: Mapped[str] = mapped_column(String(80), index=True)
    branch: Mapped[str | None] = mapped_column(String(120), nullable=True)
    ifsc: Mapped[str | None] = mapped_column(String(11), nullable=True)
    amount: Mapped[Decimal] = mapped_column(Numeric(14, 2))
    issue_date: Mapped[date] = mapped_column(Date)
    maturity_date: Mapped[date] = mapped_column(Date, index=True)
    interest_rate: Mapped[Decimal] = mapped_column(Numeric(5, 2))
    maturity_amount: Mapped[Decimal | None] = mapped_column(Numeric(14, 2), nullable=True)
    purpose: Mapped[Purpose] = mapped_column(_enum(Purpose, 32), default=Purpose.security_deposit)
    lien_to_aicte: Mapped[bool] = mapped_column(Boolean, default=False)
    status: Mapped[FdrStatus] = mapped_column(_enum(FdrStatus, 24), default=FdrStatus.draft, index=True)
    verification: Mapped[Verification] = mapped_column(
        _enum(Verification, 24), default=Verification.submitted
    )
    remarks: Mapped[str | None] = mapped_column(Text, nullable=True)
    renewed_from_id: Mapped[int | None] = mapped_column(ForeignKey("fdrs.id"), nullable=True)
    created_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    created_at: Mapped[datetime] = mapped_column(UtcDateTime(), default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(
        UtcDateTime(), default=utcnow, onupdate=utcnow
    )
    release_checklist: Mapped[dict[str, Any] | None] = mapped_column(JSON, nullable=True)
    release_ready: Mapped[bool | None] = mapped_column(Boolean, nullable=True)

    institution: Mapped[Institution] = relationship(back_populates="fdrs")
    created_by: Mapped[User | None] = relationship(foreign_keys=[created_by_id])
    renewed_from: Mapped["Fdr | None"] = relationship(
        remote_side="Fdr.id", foreign_keys=[renewed_from_id], back_populates="renewed_to"
    )
    renewed_to: Mapped["Fdr | None"] = relationship(
        foreign_keys=[renewed_from_id], back_populates="renewed_from", uselist=False
    )
    documents: Mapped[list["Document"]] = relationship(
        back_populates="fdr", order_by="Document.uploaded_at"
    )
    observations: Mapped[list["Observation"]] = relationship(
        back_populates="fdr", order_by="Observation.created_at"
    )


class Document(Base):
    __tablename__ = "documents"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fdr_id: Mapped[int] = mapped_column(ForeignKey("fdrs.id"), index=True)
    filename: Mapped[str] = mapped_column(String(255))
    stored_name: Mapped[str] = mapped_column(String(80), unique=True)
    content_type: Mapped[str] = mapped_column(String(80))
    size_bytes: Mapped[int] = mapped_column(Integer)
    doc_type: Mapped[DocumentType] = mapped_column(
        _enum(DocumentType, 32), default=DocumentType.fdr_receipt
    )
    sha256: Mapped[str | None] = mapped_column(String(64), nullable=True)
    uploaded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    uploaded_at: Mapped[datetime] = mapped_column(UtcDateTime(), default=utcnow)

    fdr: Mapped[Fdr] = relationship(back_populates="documents")
    uploaded_by: Mapped[User | None] = relationship()


class Alert(Base):
    __tablename__ = "alerts"
    __table_args__ = (Index("ix_alerts_key", "fdr_id", "type", "bucket"),)

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fdr_id: Mapped[int] = mapped_column(ForeignKey("fdrs.id"), index=True)
    type: Mapped[AlertType] = mapped_column(_enum(AlertType, 24))
    severity: Mapped[Severity] = mapped_column(_enum(Severity, 16))
    bucket: Mapped[int] = mapped_column(Integer, default=0)
    message: Mapped[str] = mapped_column(String(300))
    due_date: Mapped[date | None] = mapped_column(Date, nullable=True)
    days: Mapped[int | None] = mapped_column(Integer, nullable=True)
    created_at: Mapped[datetime] = mapped_column(UtcDateTime(), default=utcnow)
    acknowledged_at: Mapped[datetime | None] = mapped_column(UtcDateTime(), nullable=True)
    acknowledged_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    auto_resolved: Mapped[bool] = mapped_column(Boolean, default=False)
    escalated: Mapped[bool] = mapped_column(Boolean, default=False)
    escalated_at: Mapped[datetime | None] = mapped_column(UtcDateTime(), nullable=True)

    fdr: Mapped[Fdr] = relationship()
    acknowledged_by: Mapped[User | None] = relationship()


class Setting(Base):
    __tablename__ = "settings"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    reminder_days: Mapped[list[int]] = mapped_column(JSON, default=lambda: [90, 60, 30, 7])
    overdue_grace_days: Mapped[int] = mapped_column(Integer, default=0)
    pending_sla_days: Mapped[int] = mapped_column(Integer, default=7)
    interest_min: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=Decimal("3.00"))
    interest_max: Mapped[Decimal] = mapped_column(Numeric(5, 2), default=Decimal("9.50"))
    escalate_after_days: Mapped[int] = mapped_column(Integer, default=3)


class AuditLog(Base):
    __tablename__ = "audit_logs"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    at: Mapped[datetime] = mapped_column(UtcDateTime(), default=utcnow, index=True)
    actor_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    action: Mapped[str] = mapped_column(String(48), index=True)
    entity: Mapped[AuditEntity] = mapped_column(_enum(AuditEntity, 16))
    entity_id: Mapped[int | None] = mapped_column(Integer, nullable=True)
    fdr_id: Mapped[int | None] = mapped_column(ForeignKey("fdrs.id"), nullable=True, index=True)
    from_status: Mapped[str | None] = mapped_column(String(24), nullable=True)
    to_status: Mapped[str | None] = mapped_column(String(24), nullable=True)
    detail: Mapped[dict[str, Any]] = mapped_column(JSON, default=dict)
    prev_hash: Mapped[str] = mapped_column(String(64))
    hash: Mapped[str] = mapped_column(String(64), unique=True)

    actor: Mapped[User | None] = relationship()
    fdr: Mapped[Fdr | None] = relationship()


class Notice(Base):
    __tablename__ = "notices"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    reference_no: Mapped[str] = mapped_column(String(40), unique=True, index=True)
    kind: Mapped[NoticeKind] = mapped_column(_enum(NoticeKind, 24))
    kind_label: Mapped[str] = mapped_column(String(60))
    issued_at: Mapped[datetime] = mapped_column(UtcDateTime(), default=utcnow, index=True)
    issued_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    fdr_id: Mapped[int | None] = mapped_column(ForeignKey("fdrs.id"), nullable=True, index=True)
    institution_id: Mapped[int | None] = mapped_column(ForeignKey("institutions.id"), nullable=True, index=True)
    subject: Mapped[str] = mapped_column(String(255))
    salutation: Mapped[str] = mapped_column(String(255))
    body: Mapped[list[str]] = mapped_column(JSON)
    closing: Mapped[str] = mapped_column(Text)

    fdr: Mapped[Fdr | None] = relationship()
    institution: Mapped[Institution | None] = relationship()
    issued_by: Mapped[User | None] = relationship()


class Observation(Base):
    __tablename__ = "observations"

    id: Mapped[int] = mapped_column(Integer, primary_key=True)
    fdr_id: Mapped[int] = mapped_column(ForeignKey("fdrs.id"), index=True)
    author_id: Mapped[int] = mapped_column(ForeignKey("users.id"))
    text: Mapped[str] = mapped_column(Text)
    created_at: Mapped[datetime] = mapped_column(UtcDateTime(), default=utcnow)
    response: Mapped[str | None] = mapped_column(Text, nullable=True)
    responded_by_id: Mapped[int | None] = mapped_column(ForeignKey("users.id"), nullable=True)
    responded_at: Mapped[datetime | None] = mapped_column(UtcDateTime(), nullable=True)
    status: Mapped[ObservationStatus] = mapped_column(
        _enum(ObservationStatus, 16), default=ObservationStatus.open
    )

    fdr: Mapped[Fdr] = relationship(back_populates="observations")
    author: Mapped[User] = relationship(foreign_keys=[author_id])
    responded_by: Mapped[User | None] = relationship(foreign_keys=[responded_by_id])


