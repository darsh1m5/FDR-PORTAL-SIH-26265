"""Computed fields: maturity state, projected value, discrepancy findings, health score."""

from collections import Counter, defaultdict
from dataclasses import dataclass, field
from datetime import date
from decimal import ROUND_HALF_UP, Decimal

from sqlalchemy import select
from sqlalchemy.orm import Session

from app.config import today
from app.constants import CLOSED_STATUSES, HELD_STATUSES, IFSC_RE
from app.models import Document, DocumentType, Fdr, FdrStatus, Institution, Setting, Severity, Verification
from app.schemas import Finding, MaturityState

SEVERITY_PENALTY: dict[Severity, int] = {
    Severity.critical: 30,
    Severity.warning: 12,
    Severity.info: 4,
}
SEVERITY_ORDER: dict[Severity, int] = {Severity.critical: 0, Severity.warning: 1, Severity.info: 2}

# Rules that still matter once an instrument is closed (data integrity only).
_CLOSED_RULES = {"DATE_ORDER", "DUPLICATE_NUMBER"}


def get_settings(db: Session) -> Setting:
    row = db.get(Setting, 1)
    if row is None:
        row = Setting(id=1, reminder_days=[90, 60, 30, 7], escalate_after_days=3)
        db.add(row)
        db.flush()
    return row


def days_to_maturity(fdr: Fdr, on: date | None = None) -> int:
    return (fdr.maturity_date - (on or today())).days


def maturity_state(fdr: Fdr, on: date | None = None) -> MaturityState:
    if fdr.status in CLOSED_STATUSES:
        return "closed"
    days = days_to_maturity(fdr, on)
    if days < 0:
        return "matured"
    if days <= 7:
        return "due_7"
    if days <= 30:
        return "due_30"
    if days <= 60:
        return "due_60"
    if days <= 90:
        return "due_90"
    return "active"


def projected_value(amount: Decimal | float, rate: Decimal | float, issue: date, maturity: date) -> float:
    """Quarterly compounding, the Indian bank default: A = P(1 + r/400)^(4t)."""
    principal = float(amount)
    years = max((maturity - issue).days, 0) / 365.25
    value = principal * (1 + float(rate) / 400) ** (4 * years)
    return float(Decimal(str(value)).quantize(Decimal("0.01"), rounding=ROUND_HALF_UP))


def fdr_projected_value(fdr: Fdr) -> float:
    return projected_value(fdr.amount, fdr.interest_rate, fdr.issue_date, fdr.maturity_date)


def _number_key(fdr_number: str, bank_name: str) -> tuple[str, str]:
    return (fdr_number.strip().upper(), bank_name.strip().lower())


@dataclass
class RuleContext:
    """Everything the rules need about other rows, loaded once per request."""

    on: date
    interest_min: float
    interest_max: float
    duplicates: Counter[tuple[str, str]] = field(default_factory=Counter)
    held_by_institution: dict[int, float] = field(default_factory=dict)
    required_by_institution: dict[int, float] = field(default_factory=dict)
    documents_by_fdr: dict[int, int] = field(default_factory=dict)
    doc_types_by_fdr: dict[int, set[str]] = field(default_factory=dict)
    sha256_to_fdrs: dict[str, set[tuple[int, str]]] = field(default_factory=dict)
    shas_by_fdr: dict[int, set[str]] = field(default_factory=dict)
    fdr_parent_info: dict[int, tuple[date, float]] = field(default_factory=dict)

    @classmethod
    def load(cls, db: Session) -> "RuleContext":
        cfg = get_settings(db)
        ctx = cls(
            on=today(),
            interest_min=float(cfg.interest_min),
            interest_max=float(cfg.interest_max),
        )
        held: dict[int, float] = defaultdict(float)
        parent_info: dict[int, tuple[date, float]] = {}
        for fdr_id, number, bank, status, institution_id, amount, mat_date in db.execute(
            select(Fdr.id, Fdr.fdr_number, Fdr.bank_name, Fdr.status, Fdr.institution_id, Fdr.amount, Fdr.maturity_date)
        ):
            ctx.duplicates[_number_key(number, bank)] += 1
            if status in HELD_STATUSES:
                held[institution_id] += float(amount)
            parent_info[fdr_id] = (mat_date, float(amount))
        ctx.held_by_institution = dict(held)
        ctx.fdr_parent_info = parent_info
        ctx.required_by_institution = {
            inst_id: float(required)
            for inst_id, required in db.execute(select(Institution.id, Institution.required_deposit))
        }
        counts: dict[int, int] = defaultdict(int)
        doc_types: dict[int, set[str]] = defaultdict(set)
        sha_to_fdrs: dict[str, set[tuple[int, str]]] = defaultdict(set)
        fdr_shas: dict[int, set[str]] = defaultdict(set)
        for fdr_id, fdr_number, doc_type, sha in db.execute(
            select(Document.fdr_id, Fdr.fdr_number, Document.doc_type, Document.sha256).join(Fdr, Document.fdr_id == Fdr.id)
        ):
            counts[fdr_id] += 1
            val = doc_type.value if hasattr(doc_type, "value") else (str(doc_type) if doc_type else "fdr_receipt")
            doc_types[fdr_id].add(val)
            if sha:
                sha_to_fdrs[sha].add((fdr_id, fdr_number))
                fdr_shas[fdr_id].add(sha)
        ctx.documents_by_fdr = dict(counts)
        ctx.doc_types_by_fdr = dict(doc_types)
        ctx.sha256_to_fdrs = dict(sha_to_fdrs)
        ctx.shas_by_fdr = dict(fdr_shas)
        return ctx

    def document_count(self, fdr_id: int) -> int:
        return self.documents_by_fdr.get(fdr_id, 0)

    def has_doc_type(self, fdr_id: int, doc_type: str | DocumentType) -> bool:
        dt = doc_type.value if hasattr(doc_type, "value") else str(doc_type)
        return dt in self.doc_types_by_fdr.get(fdr_id, set())

    def shortfall(self, institution_id: int) -> float:
        required = self.required_by_institution.get(institution_id, 0.0)
        return max(0.0, round(required - self.held_by_institution.get(institution_id, 0.0), 2))


def _inr(value: float) -> str:
    """Indian digit grouping without decimals, e.g. ₹12,50,000."""
    rounded = int(round(value))
    sign = "-" if rounded < 0 else ""
    digits = str(abs(rounded))
    if len(digits) > 3:
        head, tail = digits[:-3], digits[-3:]
        groups = []
        while len(head) > 2:
            groups.insert(0, head[-2:])
            head = head[:-2]
        if head:
            groups.insert(0, head)
        digits = ",".join(groups) + "," + tail
    return f"{sign}₹{digits}"


def findings_for(fdr: Fdr, ctx: RuleContext) -> list[Finding]:
    found: list[Finding] = []

    def add(code: str, severity: Severity, message: str, fix: str) -> None:
        found.append(Finding(code=code, severity=severity, message=message, fix=fix))

    if fdr.maturity_date <= fdr.issue_date:
        add(
            "DATE_ORDER",
            Severity.critical,
            "Maturity date is on or before the issue date.",
            "Check both dates against the receipt and correct the record.",
        )
    if ctx.duplicates[_number_key(fdr.fdr_number, fdr.bank_name)] > 1:
        add(
            "DUPLICATE_NUMBER",
            Severity.critical,
            f"Another FDR with number {fdr.fdr_number} is recorded at {fdr.bank_name}.",
            "Compare both records with the receipts; reject or correct the duplicate.",
        )
    days = (fdr.maturity_date - ctx.on).days
    if fdr.status == FdrStatus.approved and days < 0:
        add(
            "MATURED_UNRESOLVED",
            Severity.critical,
            f"Matured {abs(days)} day{'s' if abs(days) != 1 else ''} ago and is neither renewed nor released.",
            "Ask the institution for a renewed FDR, or process the release.",
        )
    shortfall = ctx.shortfall(fdr.institution_id)
    if shortfall > 0:
        add(
            "BELOW_REQUIRED",
            Severity.warning,
            f"Institution's deposits held are {_inr(shortfall)} short of the required amount.",
            "Ask the institution to submit an additional FDR for the shortfall.",
        )
    if not fdr.lien_to_aicte:
        add(
            "NO_LIEN",
            Severity.warning,
            "Lien or joint name in favour of AICTE is not marked.",
            "Get the bank to mark a lien to AICTE, then update the record.",
        )
    if not ctx.has_doc_type(fdr.id, DocumentType.fdr_receipt):
        add(
            "NO_DOCUMENT",
            Severity.warning,
            "No scan of the FDR receipt is attached.",
            "Upload a PDF or image of the receipt.",
        )
    if fdr.lien_to_aicte and fdr.status in (FdrStatus.approved, FdrStatus.pending_approval):
        if not ctx.has_doc_type(fdr.id, DocumentType.lien_letter):
            add(
                "NO_LIEN_LETTER",
                Severity.info,
                "Lien is marked to AICTE, but no lien confirmation letter from the bank is attached.",
                "Upload the lien confirmation letter issued by the bank.",
            )
    if fdr.ifsc and not IFSC_RE.match(fdr.ifsc):
        add(
            "BAD_IFSC",
            Severity.warning,
            f"IFSC {fdr.ifsc} is not in the valid format.",
            "Correct the IFSC from the receipt (4 letters, 0, then 6 characters).",
        )
    if fdr.maturity_amount is not None and fdr.issue_date < fdr.maturity_date:
        computed = fdr_projected_value(fdr)
        printed = float(fdr.maturity_amount)
        if computed > 0 and abs(printed - computed) / computed > 0.01:
            add(
                "VALUE_MISMATCH",
                Severity.warning,
                f"Printed maturity amount {_inr(printed)} differs from the computed {_inr(computed)}.",
                "Check the rate, dates and amount against the receipt; confirm with the bank if needed.",
            )
    rate = float(fdr.interest_rate)
    if rate < ctx.interest_min or rate > ctx.interest_max:
        add(
            "RATE_OUT_OF_BAND",
            Severity.info,
            f"Interest rate {rate:.2f}% is outside the expected {ctx.interest_min:.2f}-{ctx.interest_max:.2f}% band.",
            "Confirm the rate on the receipt.",
        )
    if fdr.verification == Verification.submitted and fdr.status == FdrStatus.approved:
        add(
            "NOT_VERIFIED",
            Severity.info,
            "Approved, but details are not yet officer-verified against the document.",
            "A reviewer should verify the details against the receipt.",
        )
    fdr_shas = {d.sha256 for d in fdr.documents if d.sha256} if (hasattr(fdr, "documents") and fdr.documents) else ctx.shas_by_fdr.get(fdr.id, set())
    reused_fdr_numbers: set[str] = set()
    for sha in fdr_shas:
        for other_id, other_num in ctx.sha256_to_fdrs.get(sha, set()):
            if other_id != fdr.id:
                reused_fdr_numbers.add(other_num)
    if reused_fdr_numbers:
        add(
            "DOCUMENT_REUSED",
            Severity.critical,
            "The same file is attached to another deposit in the register.",
            "Remove the duplicate and upload the receipt that belongs to this deposit.",
        )
    if fdr.renewed_from_id:
        parent = ctx.fdr_parent_info.get(fdr.renewed_from_id)
        if not parent and hasattr(fdr, "renewed_from") and fdr.renewed_from:
            parent = (fdr.renewed_from.maturity_date, float(fdr.renewed_from.amount))
        if parent:
            old_mat, old_amt = parent
            gap = (fdr.issue_date - old_mat).days
            if gap > 0:
                add(
                    "RENEWAL_GAP",
                    Severity.warning,
                    f"Cover lapsed for {gap} day{'s' if gap != 1 else ''} between FDRs.",
                    "Ask the institution to cover the days between the two deposits.",
                )
            if float(fdr.amount) < old_amt:
                add(
                    "RENEWAL_AMOUNT_DROP",
                    Severity.warning,
                    f"Replacement deposit of {_inr(float(fdr.amount))} is below the earlier {_inr(old_amt)}.",
                    "Ask the institution to restore the earlier amount, or record why it is lower.",
                )
    if fdr.status in CLOSED_STATUSES and fdr.status != FdrStatus.rejected:
        found = [f for f in found if f.code in _CLOSED_RULES]
    found.sort(key=lambda f: SEVERITY_ORDER[f.severity])
    return found


def health_score(findings: list[Finding]) -> int:
    penalty = sum(SEVERITY_PENALTY[f.severity] for f in findings)
    return max(0, 100 - penalty)
