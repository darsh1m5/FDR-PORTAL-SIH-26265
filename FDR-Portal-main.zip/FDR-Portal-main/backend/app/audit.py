"""Append-only, hash-chained audit log.

Each row stores `hash = sha256(prev_hash + canonical_json(...))`, so editing or
deleting any row breaks every hash after it. Writes are serialised per process
so two concurrent requests can never chain onto the same previous hash.
"""

import hashlib
import json
import threading
from dataclasses import dataclass
from datetime import date, datetime, timezone
from decimal import Decimal
from enum import Enum
from typing import Any

from sqlalchemy import event, select
from sqlalchemy.orm import Session, SessionTransaction

from app.config import utcnow
from app.models import AuditEntity, AuditLog, User

GENESIS = "GENESIS"

ACTION_LABELS: dict[str, str] = {
    "fdr.created": "FDR registered",
    "fdr.updated": "Details edited",
    "fdr.submitted": "Submitted for approval",
    "fdr.approved": "Approved",
    "fdr.rejected": "Rejected",
    "fdr.release_requested": "Release requested",
    "fdr.released": "Released",
    "fdr.release_rejected": "Release request rejected",
    "fdr.renewed": "Renewed",
    "fdr.verified": "Officer-verified",
    "document.uploaded": "Document uploaded",
    "document.deleted": "Document deleted",
    "alert.acknowledged": "Alert acknowledged",
    "alert.run": "Alert rules run",
    "settings.updated": "Alert rules changed",
    "institution.created": "Institution added",
    "auth.login": "Signed in",
    "export.csv": "Register exported",
    "alert.escalated": "Alert escalated",
    "notice.issued": "Notice issued",
    "import.committed": "Spreadsheet imported",
    "observation.raised": "Observation raised",
    "observation.answered": "Institution replied",
    "observation.closed": "Observation closed",
    "fdr.bank_confirmed": "Bank-confirmed (letter)",
}

_chain_lock = threading.Lock()
_LOCK_KEY = "audit_chain_lock"


def action_label(action: str) -> str:
    return ACTION_LABELS.get(action, action.replace(".", " ").replace("_", " ").capitalize())


def _json_default(value: Any) -> Any:
    if isinstance(value, Decimal):
        return float(value)
    if isinstance(value, (date, datetime)):
        return value.isoformat()
    if isinstance(value, Enum):
        return value.value
    raise TypeError(f"Not JSON serialisable: {type(value).__name__}")


def normalise_detail(detail: dict[str, Any] | None) -> dict[str, Any]:
    """Round-trip through JSON so the stored detail is exactly what was hashed."""
    return json.loads(json.dumps(detail or {}, default=_json_default))


def _format_at(at: datetime) -> str:
    if at.tzinfo is None:
        at = at.replace(tzinfo=timezone.utc)
    return at.astimezone(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def compute_hash(
    prev_hash: str,
    *,
    at: datetime,
    actor_id: int | None,
    action: str,
    entity: str,
    entity_id: int | None,
    from_status: str | None,
    to_status: str | None,
    detail: dict[str, Any],
) -> str:
    canonical = json.dumps(
        {
            "at": _format_at(at),
            "actor_id": actor_id,
            "action": action,
            "entity": entity,
            "entity_id": entity_id,
            "from_status": from_status,
            "to_status": to_status,
            "detail": detail,
        },
        sort_keys=True,
        separators=(",", ":"),
        ensure_ascii=False,
    )
    return hashlib.sha256((prev_hash + canonical).encode("utf-8")).hexdigest()


@event.listens_for(Session, "after_transaction_end")
def _release_chain_lock(session: Session, transaction: SessionTransaction) -> None:
    if transaction.parent is None and session.info.pop(_LOCK_KEY, False):
        _chain_lock.release()


def _hold_chain_lock(db: Session) -> None:
    if db.info.get(_LOCK_KEY):
        return
    if not _chain_lock.acquire(timeout=15):
        raise RuntimeError("Audit log is busy, please retry")
    db.info[_LOCK_KEY] = True


def write_audit(
    db: Session,
    *,
    actor: User | None,
    action: str,
    entity: AuditEntity | str,
    entity_id: int | None = None,
    fdr_id: int | None = None,
    from_status: str | None = None,
    to_status: str | None = None,
    detail: dict[str, Any] | None = None,
    at: datetime | None = None,
) -> AuditLog:
    """Add one audit row to the current transaction (the caller commits).

    `at` may be passed to backdate history (seed data); the chain stays valid
    because order is defined by row id, not by timestamp.
    """
    _hold_chain_lock(db)
    entity_value = AuditEntity(entity)
    from_value = from_status.value if isinstance(from_status, Enum) else from_status
    to_value = to_status.value if isinstance(to_status, Enum) else to_status
    clean_detail = normalise_detail(detail)
    when = at or utcnow()
    if when.tzinfo is None:
        when = when.replace(tzinfo=timezone.utc)
    when = when.astimezone(timezone.utc)
    db.flush()
    prev_hash = db.scalar(select(AuditLog.hash).order_by(AuditLog.id.desc()).limit(1)) or GENESIS
    actor_id = actor.id if actor is not None else None
    row = AuditLog(
        at=when,
        actor_id=actor_id,
        action=action,
        entity=entity_value,
        entity_id=entity_id,
        fdr_id=fdr_id,
        from_status=from_value,
        to_status=to_value,
        detail=clean_detail,
        prev_hash=prev_hash,
        hash=compute_hash(
            prev_hash,
            at=when,
            actor_id=actor_id,
            action=action,
            entity=entity_value.value,
            entity_id=entity_id,
            from_status=from_value,
            to_status=to_value,
            detail=clean_detail,
        ),
    )
    db.add(row)
    db.flush()
    return row


@dataclass(frozen=True)
class ChainReport:
    intact: bool
    checked: int
    broken_at: int | None


def verify_chain(db: Session) -> ChainReport:
    """Recompute every hash in id order and report the first row that does not match."""
    expected_prev = GENESIS
    checked = 0
    for row in db.scalars(select(AuditLog).order_by(AuditLog.id)).yield_per(500):
        checked += 1
        recomputed = compute_hash(
            row.prev_hash,
            at=row.at,
            actor_id=row.actor_id,
            action=row.action,
            entity=row.entity.value,
            entity_id=row.entity_id,
            from_status=row.from_status,
            to_status=row.to_status,
            detail=row.detail or {},
        )
        if row.prev_hash != expected_prev or recomputed != row.hash:
            return ChainReport(intact=False, checked=checked, broken_at=row.id)
        expected_prev = row.hash
    return ChainReport(intact=True, checked=checked, broken_at=None)
