"""Reference lists and labels shared by the API, the rules and the seed."""

import re

from app.models import DocumentType, FdrStatus, InstitutionType, Purpose, Role, Verification

BANKS: list[str] = [
    "State Bank of India",
    "Bank of Baroda",
    "Punjab National Bank",
    "Canara Bank",
    "Union Bank of India",
    "Bank of India",
    "Indian Bank",
    "Central Bank of India",
    "Indian Overseas Bank",
    "UCO Bank",
    "Bank of Maharashtra",
    "Punjab & Sind Bank",
    "HDFC Bank",
    "ICICI Bank",
    "Axis Bank",
    "Kotak Mahindra Bank",
    "IDBI Bank",
    "IndusInd Bank",
    "Yes Bank",
    "Federal Bank",
]

PURPOSE_LABELS: dict[Purpose, str] = {
    Purpose.security_deposit: "Security deposit",
    Purpose.additional_intake: "Additional intake",
    Purpose.performance_security: "Performance security",
    Purpose.other: "Other",
}

STATUS_LABELS: dict[FdrStatus, str] = {
    FdrStatus.draft: "Draft",
    FdrStatus.pending_approval: "Pending approval",
    FdrStatus.approved: "Approved",
    FdrStatus.rejected: "Rejected",
    FdrStatus.release_requested: "Release requested",
    FdrStatus.released: "Released",
    FdrStatus.renewed: "Renewed",
}

DOCUMENT_TYPE_LABELS: dict[DocumentType, str] = {
    DocumentType.fdr_receipt: "FDR receipt",
    DocumentType.lien_letter: "Lien letter",
    DocumentType.affidavit: "Affidavit",
    DocumentType.closure_certificate: "Closure certificate",
    DocumentType.renewal_letter: "Renewal letter",
    DocumentType.bank_confirmation: "Bank confirmation letter",
    DocumentType.other: "Other",
}

ROLE_LABELS: dict[Role, str] = {
    Role.admin: "Administrator",
    Role.reviewer: "Reviewer",
    Role.approver: "Competent Authority",
    Role.auditor: "Auditor",
    Role.institution: "Institution",
}

VERIFICATION_LABELS: dict[Verification, str] = {
    Verification.submitted: "Submitted",
    Verification.officer_verified: "Officer-verified",
    Verification.bank_confirmed: "Bank-confirmed",
}

INSTITUTION_TYPES: list[str] = [t.value for t in InstitutionType]

IFSC_RE = re.compile(r"^[A-Z]{4}0[A-Z0-9]{6}$")

# Instruments still on the books: counted in totals, timeline, radar and alerts.
OPEN_STATUSES: frozenset[FdrStatus] = frozenset(
    {FdrStatus.draft, FdrStatus.pending_approval, FdrStatus.approved, FdrStatus.release_requested}
)
# "Active": accepted and held by the bureau.
ACTIVE_STATUSES: frozenset[FdrStatus] = frozenset({FdrStatus.approved, FdrStatus.release_requested})
# Counted towards an institution's required deposit.
HELD_STATUSES: frozenset[FdrStatus] = frozenset(
    {FdrStatus.pending_approval, FdrStatus.approved, FdrStatus.release_requested}
)
CLOSED_STATUSES: frozenset[FdrStatus] = frozenset(
    {FdrStatus.rejected, FdrStatus.released, FdrStatus.renewed}
)
EDITABLE_STATUSES: frozenset[FdrStatus] = frozenset(
    {FdrStatus.draft, FdrStatus.rejected, FdrStatus.pending_approval}
)
