"""Password hashing, JWT tokens and role checks."""

from collections.abc import Callable
from datetime import timedelta
from typing import Annotated

import bcrypt
import jwt
from fastapi import Depends, HTTPException, status
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.config import settings, utcnow
from app.db import get_db
from app.constants import ROLE_LABELS
from app.models import Role, User

_bearer = HTTPBearer(auto_error=False)


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8"), bcrypt.gensalt()).decode("utf-8")


def verify_password(password: str, password_hash: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8"), password_hash.encode("utf-8"))
    except ValueError:
        return False


def create_access_token(user: User) -> str:
    now = utcnow()
    payload = {
        "sub": str(user.id),
        "role": user.role.value,
        "iat": now,
        "exp": now + timedelta(hours=settings.jwt_expire_hours),
    }
    return jwt.encode(payload, settings.secret_key, algorithm=settings.jwt_algorithm)


def _unauthorized(message: str) -> HTTPException:
    return HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail=message,
        headers={"WWW-Authenticate": "Bearer"},
    )


def get_current_user(
    credentials: Annotated[HTTPAuthorizationCredentials | None, Depends(_bearer)],
    db: Annotated[Session, Depends(get_db)],
) -> User:
    if credentials is None or credentials.scheme.lower() != "bearer":
        raise _unauthorized("Not signed in")
    try:
        payload = jwt.decode(
            credentials.credentials, settings.secret_key, algorithms=[settings.jwt_algorithm]
        )
        user_id = int(payload["sub"])
    except jwt.ExpiredSignatureError as exc:
        raise _unauthorized("Session expired, please sign in again") from exc
    except (jwt.InvalidTokenError, KeyError, ValueError) as exc:
        raise _unauthorized("Invalid session token") from exc
    user = db.get(User, user_id)
    if user is None or not user.is_active:
        raise _unauthorized("Account not found or disabled")
    if user.role == Role.institution and user.institution_id is None:
        raise _unauthorized("This institution account is not linked to an institution")
    return user


CurrentUser = Annotated[User, Depends(get_current_user)]


def require_role(*roles: Role | str) -> Callable[[User], User]:
    allowed = {Role(r) for r in roles}

    def checker(user: CurrentUser) -> User:
        if user.role not in allowed:
            names = " or ".join(ROLE_LABELS[r] for r in sorted(allowed))
            article = "an" if names[0] in "AEIOU" else "a"
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail=f"Only {article} {names} can do this",
            )
        return user

    return checker


AdminUser = Annotated[User, Depends(require_role(Role.admin))]
ReviewerUser = Annotated[User, Depends(require_role(Role.reviewer))]
ApproverUser = Annotated[User, Depends(require_role(Role.approver))]
AuditorUser = Annotated[User, Depends(require_role(Role.auditor))]
InstitutionUser = Annotated[User, Depends(require_role(Role.institution))]
AdminOrInstitutionUser = Annotated[User, Depends(require_role(Role.admin, Role.institution))]
BureauUser = Annotated[User, Depends(require_role(Role.admin, Role.reviewer, Role.approver, Role.auditor))]


