"""Runtime settings read from the environment, with an optional `.env` file."""

import os
from dataclasses import dataclass, field
from datetime import date, datetime, timezone
from pathlib import Path
from zoneinfo import ZoneInfo

BACKEND_DIR = Path(__file__).resolve().parent.parent
PROJECT_DIR = BACKEND_DIR.parent
IST = ZoneInfo("Asia/Kolkata")


def _load_dotenv() -> None:
    """Load KEY=VALUE pairs from backend/.env or the project .env without overriding real env vars."""
    for path in (BACKEND_DIR / ".env", PROJECT_DIR / ".env"):
        if not path.is_file():
            continue
        for raw in path.read_text(encoding="utf-8").splitlines():
            line = raw.strip()
            if not line or line.startswith("#") or "=" not in line:
                continue
            key, value = line.split("=", 1)
            os.environ.setdefault(key.strip(), value.strip().strip('"').strip("'"))


def _resolve_sqlite_url(url: str) -> str:
    """Make relative SQLite paths relative to the backend folder, not the working directory."""
    prefix = "sqlite:///"
    if not url.startswith(prefix) or url.startswith(prefix + "/"):
        return url
    target = Path(url[len(prefix):])
    if target.is_absolute() or str(target) == ":memory:":
        return url
    return prefix + (BACKEND_DIR / target).resolve().as_posix()


def _resolve_dir(value: str) -> Path:
    path = Path(value)
    return path if path.is_absolute() else (BACKEND_DIR / path).resolve()


_load_dotenv()


@dataclass(frozen=True)
class Settings:
    secret_key: str = os.environ.get("SECRET_KEY", "fdr-portal-local-development-key-change-me")
    database_url: str = _resolve_sqlite_url(os.environ.get("DATABASE_URL", "sqlite:///./data/fdr.db"))
    upload_dir: Path = _resolve_dir(os.environ.get("UPLOAD_DIR", "./uploads"))
    frontend_dist: Path = _resolve_dir(os.environ.get("FRONTEND_DIST", "../frontend/dist"))
    cors_origins: list[str] = field(
        default_factory=lambda: [
            origin.strip()
            for origin in os.environ.get(
                "CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173"
            ).split(",")
            if origin.strip()
        ]
    )
    jwt_algorithm: str = "HS256"
    jwt_expire_hours: int = 12
    max_upload_bytes: int = 10 * 1024 * 1024
    alert_interval_seconds: int = int(os.environ.get("ALERT_INTERVAL_SECONDS", "600"))
    run_scheduler: bool = os.environ.get("RUN_SCHEDULER", "1") != "0"
    auto_seed: bool = os.environ.get("AUTO_SEED", "1") != "0"


settings = Settings()


def today() -> date:
    """Today's date in India, used for every maturity calculation."""
    return datetime.now(IST).date()


def utcnow() -> datetime:
    """Timezone-aware UTC timestamp."""
    return datetime.now(timezone.utc)
