"""Register queries shared by the list, export, dashboard and institution views."""

from dataclasses import dataclass
from typing import Literal

from fastapi import HTTPException
from sqlalchemy import or_, select
from sqlalchemy.orm import Session, selectinload

from app.models import Fdr, FdrStatus, Institution, Purpose, Verification
from app.rules import RuleContext
from app.schemas import FdrListItem
from app.serializers import fdr_list_item

Window = Literal["due_7", "due_30", "due_60", "due_90", "matured"]
SortField = Literal["maturity_date", "amount", "issue_date", "updated_at", "health_score", "fdr_number"]

_WINDOW_STATES: dict[str, set[str]] = {
    "due_7": {"due_7"},
    "due_30": {"due_7", "due_30"},
    "due_60": {"due_7", "due_30", "due_60"},
    "due_90": {"due_7", "due_30", "due_60", "due_90"},
    "matured": {"matured"},
}


@dataclass
class FdrFilters:
    q: str | None = None
    status: str | None = None  # one status or a comma-separated list
    bank: str | None = None
    institution_id: int | None = None
    window: Window | None = None
    verification: Verification | None = None
    purpose: Purpose | None = None
    sort: SortField = "maturity_date"
    order: Literal["asc", "desc"] = "asc"

    def statuses(self) -> list[FdrStatus]:
        if not self.status:
            return []
        try:
            return [FdrStatus(s.strip()) for s in self.status.split(",") if s.strip()]
        except ValueError as exc:
            raise HTTPException(status_code=422, detail="Unknown status in filter") from exc


def _sort_key(item: FdrListItem, field: SortField, fdr: Fdr) -> tuple:
    if field == "updated_at":
        return (fdr.updated_at, item.id)
    return (getattr(item, field), item.id)


def list_fdr_items(
    db: Session, filters: FdrFilters, ctx: RuleContext | None = None
) -> list[tuple[Fdr, FdrListItem]]:
    ctx = ctx or RuleContext.load(db)
    stmt = select(Fdr).join(Fdr.institution).options(selectinload(Fdr.institution))
    statuses = filters.statuses()
    if statuses:
        stmt = stmt.where(Fdr.status.in_(statuses))
    if filters.bank:
        stmt = stmt.where(Fdr.bank_name == filters.bank)
    if filters.institution_id is not None:
        stmt = stmt.where(Fdr.institution_id == filters.institution_id)
    if filters.verification is not None:
        stmt = stmt.where(Fdr.verification == filters.verification)
    if filters.purpose is not None:
        stmt = stmt.where(Fdr.purpose == filters.purpose)
    if filters.q and filters.q.strip():
        needle = f"%{filters.q.strip()}%"
        stmt = stmt.where(
            or_(
                Fdr.fdr_number.ilike(needle),
                Fdr.bank_name.ilike(needle),
                Fdr.ifsc.ilike(needle),
                Institution.name.ilike(needle),
                Institution.aicte_id.ilike(needle),
            )
        )
    rows = [(fdr, fdr_list_item(fdr, ctx)) for fdr in db.scalars(stmt).all()]
    if filters.window:
        allowed = _WINDOW_STATES[filters.window]
        rows = [(f, i) for f, i in rows if i.maturity_state in allowed]
    rows.sort(key=lambda pair: _sort_key(pair[1], filters.sort, pair[0]), reverse=filters.order == "desc")
    return rows
