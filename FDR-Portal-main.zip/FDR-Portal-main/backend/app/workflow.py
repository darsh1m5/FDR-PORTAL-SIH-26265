"""FDR status machine. Every transition writes audit in the caller's transaction."""

from decimal import Decimal
from typing import Any

from fastapi import HTTPException, status
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.audit import write_audit
from app.constants import BANKS, EDITABLE_STATUSES, STATUS_LABELS
from app.models import (
    AuditEntity,
    Fdr,
    FdrStatus,
    Institution,
    Observation,
    ObservationStatus,
    Role,
    User,
    Verification,
)
from app.schemas import AllowedAction, DecisionIn, FdrInput, FdrPatch, ReleaseIn

_TRACKED_FIELDS = (
    "fdr_number",
    "institution_id",
    "bank_name",
    "branch",
    "ifsc",
    "amount",
    "issue_date",
    "maturity_date",
    "interest_rate",
    "maturity_amount",
    "purpose",
    "lien_to_aicte",
    "remarks",
)


def _conflict(message: str) -> HTTPException:
    return HTTPException(status_code=status.HTTP_409_CONFLICT, detail=message)


def _invalid(message: str) -> HTTPException:
    return HTTPException(status_code=422, detail=message)


def _label(value: FdrStatus) -> str:
    return STATUS_LABELS[value]


def allowed_actions(fdr: Fdr, user: User, db: Session | None = None) -> list[AllowedAction]:
    actions: list[AllowedAction] = []
    has_open_obs = False
    if hasattr(fdr, "observations") and fdr.observations:
        has_open_obs = any(o.status == ObservationStatus.open for o in fdr.observations)
    elif db is not None:
        has_open_obs = bool(
            db.scalar(
                select(func.count(Observation.id)).where(
                    Observation.fdr_id == fdr.id, Observation.status == ObservationStatus.open
                )
            )
        )

    if user.role == Role.admin:
        if fdr.status in EDITABLE_STATUSES:
            actions.append("edit")
        if fdr.status in (FdrStatus.draft, FdrStatus.rejected):
            actions.append("submit")
        if fdr.status == FdrStatus.approved:
            actions.extend(["request_release", "renew"])
        if fdr.status not in (FdrStatus.released, FdrStatus.renewed):
            actions.append("upload")
        if has_open_obs:
            actions.append("respond")
    elif user.role == Role.reviewer:
        if fdr.status == FdrStatus.pending_approval:
            actions.extend(["approve", "reject"])
        if fdr.status != FdrStatus.released and fdr.verification == Verification.submitted:
            actions.append("verify")
        if fdr.status not in (FdrStatus.released, FdrStatus.renewed):
            actions.append("observe")
            if fdr.verification != Verification.bank_confirmed:
                actions.append("bank_confirm")
    elif user.role == Role.approver:
        if fdr.status == FdrStatus.release_requested:
            actions.extend(["sanction_release", "return_release"])
    elif user.role == Role.institution:
        if fdr.institution_id == user.institution_id:
            if fdr.status in (FdrStatus.draft, FdrStatus.rejected):
                actions.extend(["edit", "submit", "upload"])
            elif fdr.status == FdrStatus.approved:
                actions.append("request_release")
            if has_open_obs:
                actions.append("respond")
    return actions


def _check_refs(db: Session, institution_id: int | None, bank_name: str | None) -> None:
    if institution_id is not None and db.get(Institution, institution_id) is None:
        raise _invalid("Institution not found")
    if bank_name is not None and bank_name not in BANKS:
        raise _invalid("Choose a bank from the list")


def _snapshot(fdr: Fdr) -> dict[str, Any]:
    return {name: getattr(fdr, name) for name in _TRACKED_FIELDS}


def create_fdr(
    db: Session,
    data: FdrInput,
    user: User,
    *,
    initial: FdrStatus = FdrStatus.draft,
    renewed_from: Fdr | None = None,
) -> Fdr:
    institution_id = renewed_from.institution_id if renewed_from else data.institution_id
    _check_refs(db, institution_id, data.bank_name)
    fdr = Fdr(
        **data.model_dump(exclude={"institution_id"}),
        institution_id=institution_id,
        status=initial,
        verification=Verification.submitted,
        renewed_from_id=renewed_from.id if renewed_from else None,
        created_by_id=user.id,
    )
    db.add(fdr)
    db.flush()
    detail: dict[str, Any] = {"fdr_number": fdr.fdr_number, "amount": fdr.amount}
    if renewed_from:
        detail["renewed_from"] = {"id": renewed_from.id, "fdr_number": renewed_from.fdr_number}
    write_audit(
        db,
        actor=user,
        action="fdr.created",
        entity=AuditEntity.fdr,
        entity_id=fdr.id,
        fdr_id=fdr.id,
        to_status=initial,
        detail=detail,
    )
    return fdr


def update_fdr(db: Session, fdr: Fdr, patch: FdrPatch, user: User) -> Fdr:
    if fdr.status not in EDITABLE_STATUSES:
        raise _conflict(f"A deposit in '{_label(fdr.status)}' cannot be edited")
    changes = patch.model_dump(exclude_unset=True)
    for required in ("fdr_number", "institution_id", "bank_name", "amount", "issue_date",
                     "maturity_date", "interest_rate", "purpose", "lien_to_aicte"):
        if required in changes and changes[required] is None:
            raise _invalid(f"{required.replace('_', ' ').capitalize()} cannot be empty")
    _check_refs(db, changes.get("institution_id"), changes.get("bank_name"))
    issue = changes.get("issue_date", fdr.issue_date)
    maturity = changes.get("maturity_date", fdr.maturity_date)
    if maturity <= issue:
        raise _invalid("Maturity date must be after the issue date")
    before = _snapshot(fdr)
    for name, value in changes.items():
        setattr(fdr, name, value)
    after = _snapshot(fdr)
    changed = {
        name: {"from": before[name], "to": after[name]}
        for name in _TRACKED_FIELDS
        if _normal(before[name]) != _normal(after[name])
    }
    if not changed:
        return fdr
    detail: dict[str, Any] = {"changes": changed}
    if fdr.verification in (Verification.officer_verified, Verification.bank_confirmed):
        fdr.verification = Verification.submitted
        detail["verification_reset"] = True
    db.flush()
    write_audit(
        db,
        actor=user,
        action="fdr.updated",
        entity=AuditEntity.fdr,
        entity_id=fdr.id,
        fdr_id=fdr.id,
        from_status=fdr.status,
        to_status=fdr.status,
        detail=detail,
    )
    return fdr


def _normal(value: Any) -> Any:
    return float(value) if isinstance(value, Decimal) else value


def _move(
    db: Session,
    fdr: Fdr,
    user: User,
    to: FdrStatus,
    action: str,
    detail: dict[str, Any] | None = None,
) -> Fdr:
    previous = fdr.status
    fdr.status = to
    db.flush()
    write_audit(
        db,
        actor=user,
        action=action,
        entity=AuditEntity.fdr,
        entity_id=fdr.id,
        fdr_id=fdr.id,
        from_status=previous,
        to_status=to,
        detail=detail,
    )
    return fdr


def submit(db: Session, fdr: Fdr, user: User) -> Fdr:
    if fdr.status not in (FdrStatus.draft, FdrStatus.rejected):
        raise _conflict(f"Only a draft or rejected deposit can be submitted (now '{_label(fdr.status)}')")
    return _move(db, fdr, user, FdrStatus.pending_approval, "fdr.submitted")


def decide(db: Session, fdr: Fdr, data: DecisionIn, user: User) -> Fdr:
    remark = {"remark": data.remark} if data.remark else {}
    if fdr.status == FdrStatus.pending_approval:
        if data.action == "approve":
            return _move(db, fdr, user, FdrStatus.approved, "fdr.approved", remark)
        return _move(db, fdr, user, FdrStatus.rejected, "fdr.rejected", remark)
    if fdr.status == FdrStatus.release_requested:
        if data.action == "approve":
            if fdr.release_checklist is not None:
                missing: list[str] = []
                cl = fdr.release_checklist
                if not cl.get("affidavit_received"):
                    missing.append("affidavit received")
                if not cl.get("no_pending_complaints"):
                    missing.append("no pending complaints")
                if cl.get("institution_closure_certificate") is False:
                    missing.append("institution closure certificate")
                if not cl.get("matured_or_lock_in_complete"):
                    missing.append("matured or lock-in complete")
                if not cl.get("bank_discharge_noted"):
                    missing.append("bank discharge noted")
                if missing:
                    raise _conflict(f"Release checklist incomplete: {', '.join(missing)}")
            return _move(db, fdr, user, FdrStatus.released, "fdr.released", remark)
        fdr.release_checklist = None
        fdr.release_ready = None
        return _move(db, fdr, user, FdrStatus.approved, "fdr.release_rejected", remark)
    raise _conflict(f"Nothing to decide: the deposit is '{_label(fdr.status)}'")


def request_release(db: Session, fdr: Fdr, data: ReleaseIn | str, user: User) -> Fdr:
    if fdr.status != FdrStatus.approved:
        raise _conflict(f"Only an approved deposit can be released (now '{_label(fdr.status)}')")
    if isinstance(data, str):
        reason = data
        checklist = None
    else:
        reason = data.reason
        checklist = data.checklist

    if checklist is not None:
        is_ready = bool(
            checklist.affidavit_received
            and checklist.no_pending_complaints
            and (checklist.institution_closure_certificate is None or checklist.institution_closure_certificate is True)
            and checklist.matured_or_lock_in_complete
            and checklist.bank_discharge_noted
        )
        fdr.release_checklist = checklist.model_dump()
        fdr.release_ready = is_ready
    else:
        fdr.release_checklist = None
        fdr.release_ready = None

    detail: dict[str, Any] = {"reason": reason}
    if fdr.release_checklist is not None:
        detail["release_checklist"] = fdr.release_checklist
        detail["release_ready"] = fdr.release_ready

    return _move(db, fdr, user, FdrStatus.release_requested, "fdr.release_requested", detail)


def renew(db: Session, fdr: Fdr, data: FdrInput, user: User) -> Fdr:
    if fdr.status != FdrStatus.approved:
        raise _conflict(f"Only an approved deposit can be renewed (now '{_label(fdr.status)}')")
    replacement = create_fdr(
        db, data, user, initial=FdrStatus.pending_approval, renewed_from=fdr
    )
    _move(
        db,
        fdr,
        user,
        FdrStatus.renewed,
        "fdr.renewed",
        {"renewed_to": {"id": replacement.id, "fdr_number": replacement.fdr_number}},
    )
    return replacement


def verify(db: Session, fdr: Fdr, remark: str | None, user: User) -> Fdr:
    if fdr.status == FdrStatus.released:
        raise _conflict("A released deposit cannot be verified")
    if fdr.verification == Verification.officer_verified:
        raise _conflict("This deposit is already officer-verified")
    if fdr.verification == Verification.bank_confirmed:
        raise _conflict("This deposit is already bank-confirmed")
    fdr.verification = Verification.officer_verified
    db.flush()
    write_audit(
        db,
        actor=user,
        action="fdr.verified",
        entity=AuditEntity.fdr,
        entity_id=fdr.id,
        fdr_id=fdr.id,
        from_status=fdr.status,
        to_status=fdr.status,
        detail={"remark": remark.strip()} if remark and remark.strip() else {},
    )
    return fdr
