"""Turn ORM rows into the response shapes in schemas.py."""

from collections.abc import Iterable

from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.audit import action_label
from app.config import utcnow
from app.constants import DOCUMENT_TYPE_LABELS
from app.models import (
    Alert,
    AuditLog,
    Document,
    DocumentType,
    Fdr,
    Notice,
    Observation,
    ObservationStatus,
    Role,
    User,
)
from app.rules import (
    RuleContext,
    days_to_maturity,
    fdr_projected_value,
    findings_for,
    health_score,
    maturity_state,
)
from app.schemas import (
    AlertItem,
    AllowedAction,
    AuditItem,
    DocumentItem,
    FdrDetail,
    FdrListItem,
    FdrRef,
    LineageItem,
    ObservationItem,
    ReleaseChecklist,
)
from app.workflow import allowed_actions


def fdr_list_item(fdr: Fdr, ctx: RuleContext) -> FdrListItem:
    findings = findings_for(fdr, ctx)
    return FdrListItem(
        id=fdr.id,
        fdr_number=fdr.fdr_number,
        institution_id=fdr.institution_id,
        institution_name=fdr.institution.name,
        bank_name=fdr.bank_name,
        amount=float(fdr.amount),
        issue_date=fdr.issue_date,
        maturity_date=fdr.maturity_date,
        interest_rate=float(fdr.interest_rate),
        purpose=fdr.purpose,
        status=fdr.status,
        verification=fdr.verification,
        days_to_maturity=days_to_maturity(fdr, ctx.on),
        maturity_state=maturity_state(fdr, ctx.on),
        health_score=health_score(findings),
        findings_count=len(findings),
        document_count=ctx.document_count(fdr.id),
    )


def document_item(doc: Document) -> DocumentItem:
    dt = doc.doc_type if hasattr(doc, "doc_type") and doc.doc_type else DocumentType.fdr_receipt
    if isinstance(dt, str):
        try:
            dt = DocumentType(dt)
        except ValueError:
            dt = DocumentType.fdr_receipt
    label = DOCUMENT_TYPE_LABELS.get(dt, "FDR receipt")
    return DocumentItem(
        id=doc.id,
        filename=doc.filename,
        content_type=doc.content_type,
        size_bytes=doc.size_bytes,
        uploaded_by=doc.uploaded_by.name if doc.uploaded_by else None,
        uploaded_at=doc.uploaded_at,
        doc_type=dt,
        doc_type_label=label,
        sha256=doc.sha256,
    )


def audit_item(row: AuditLog) -> AuditItem:
    actor: User | None = row.actor
    return AuditItem(
        id=row.id,
        at=row.at,
        actor_name=actor.name if actor else "System",
        actor_role=actor.role if actor else None,
        action=row.action,
        action_label=action_label(row.action),
        entity=row.entity.value,
        entity_id=row.entity_id,
        fdr_id=row.fdr_id,
        fdr_number=row.fdr.fdr_number if row.fdr else None,
        from_status=row.from_status,
        to_status=row.to_status,
        detail=row.detail or {},
    )


def audit_items(rows: Iterable[AuditLog]) -> list[AuditItem]:
    return [audit_item(r) for r in rows]


def audit_query():  # type: ignore[no-untyped-def]
    """Base select for audit rows with actor and FDR preloaded."""
    return select(AuditLog).options(selectinload(AuditLog.actor), selectinload(AuditLog.fdr))


def _compute_lineage(db: Session, fdr: Fdr) -> list[LineageItem]:
    backwards: list[Fdr] = []
    curr = fdr
    visited = {fdr.id}
    while curr.renewed_from_id:
        prev = db.get(Fdr, curr.renewed_from_id)
        if not prev or prev.id in visited:
            break
        visited.add(prev.id)
        backwards.append(prev)
        curr = prev
    backwards.reverse()

    chain: list[Fdr] = backwards + [fdr]

    curr = fdr
    while True:
        nxt = db.scalar(select(Fdr).where(Fdr.renewed_from_id == curr.id).limit(1))
        if not nxt or nxt.id in visited:
            break
        visited.add(nxt.id)
        chain.append(nxt)
        curr = nxt

    return [
        LineageItem(
            id=item.id,
            fdr_number=item.fdr_number,
            status=item.status,
            issue_date=item.issue_date,
            maturity_date=item.maturity_date,
            amount=float(item.amount),
        )
        for item in chain
    ]


def fdr_detail(db: Session, fdr: Fdr, user: User, ctx: RuleContext | None = None) -> FdrDetail:
    ctx = ctx or RuleContext.load(db)
    base = fdr_list_item(fdr, ctx)
    findings = findings_for(fdr, ctx)
    history = db.scalars(
        audit_query().where(AuditLog.fdr_id == fdr.id).order_by(AuditLog.id.desc())
    ).all()
    renewed_to = db.scalar(select(Fdr).where(Fdr.renewed_from_id == fdr.id).limit(1))
    actions: list[AllowedAction] = allowed_actions(fdr, user, db)
    notices_count = db.scalar(select(func.count(Notice.id)).where(Notice.fdr_id == fdr.id)) or 0
    open_obs = db.scalar(
        select(func.count(Observation.id)).where(
            Observation.fdr_id == fdr.id, Observation.status == ObservationStatus.open
        )
    ) or 0
    return FdrDetail(
        **base.model_dump(),
        branch=fdr.branch,
        ifsc=fdr.ifsc,
        maturity_amount=float(fdr.maturity_amount) if fdr.maturity_amount is not None else None,
        lien_to_aicte=fdr.lien_to_aicte,
        remarks=fdr.remarks,
        projected_value=fdr_projected_value(fdr),
        findings=findings,
        documents=[document_item(d) for d in fdr.documents],
        history=audit_items(history),
        renewed_from=(
            FdrRef(id=fdr.renewed_from.id, fdr_number=fdr.renewed_from.fdr_number)
            if fdr.renewed_from
            else None
        ),
        renewed_to=FdrRef(id=renewed_to.id, fdr_number=renewed_to.fdr_number) if renewed_to else None,
        created_by=fdr.created_by.name if fdr.created_by else "System",
        created_at=fdr.created_at,
        updated_at=fdr.updated_at,
        allowed_actions=actions,
        notices_count=notices_count,
        release_checklist=(
            ReleaseChecklist(**fdr.release_checklist)
            if fdr.release_checklist
            else None
        ),
        release_ready=fdr.release_ready,
        lineage=_compute_lineage(db, fdr),
        observations_open=open_obs,
    )


def alert_item(alert: Alert) -> AlertItem:
    if alert.acknowledged_at is None:
        acknowledged_by = None
    elif alert.auto_resolved:
        acknowledged_by = "System"
    else:
        acknowledged_by = alert.acknowledged_by.name if alert.acknowledged_by else "System"
    return AlertItem(
        id=alert.id,
        fdr_id=alert.fdr_id,
        fdr_number=alert.fdr.fdr_number,
        institution_name=alert.fdr.institution.name,
        type=alert.type,
        severity=alert.severity,
        message=alert.message,
        due_date=alert.due_date,
        days=alert.days,
        created_at=alert.created_at,
        acknowledged_at=alert.acknowledged_at,
        acknowledged_by=acknowledged_by,
        escalated=bool(alert.escalated),
        escalated_at=alert.escalated_at,
        age_days=max(0, (utcnow() - alert.created_at).days) if alert.created_at else 0,
    )


def observation_item(obs: Observation) -> ObservationItem:
    return ObservationItem(
        id=obs.id,
        fdr_id=obs.fdr_id,
        text=obs.text,
        author_name=obs.author.name if obs.author else "Scrutiny Officer",
        author_role=obs.author.role if obs.author else Role.reviewer,
        created_at=obs.created_at,
        response=obs.response,
        responded_by=obs.responded_by.name if obs.responded_by else None,
        responded_at=obs.responded_at,
        status=obs.status,
    )

