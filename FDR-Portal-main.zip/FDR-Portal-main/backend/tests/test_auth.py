"""Auth endpoints: login success/failure and session identity."""

from fastapi.testclient import TestClient

from tests.conftest import ADMIN, REVIEWER


def test_login_returns_token_and_user(client: TestClient):
    response = client.post("/api/auth/login", json=ADMIN)
    assert response.status_code == 200
    body = response.json()
    assert body["token_type"] == "bearer"
    assert body["access_token"]
    assert body["user"]["email"] == ADMIN["email"]
    assert body["user"]["role"] == "admin"
    assert body["user"]["name"] == "Section Officer"


def test_login_reviewer_role(client: TestClient):
    response = client.post("/api/auth/login", json=REVIEWER)
    assert response.status_code == 200
    assert response.json()["user"]["role"] == "reviewer"
    assert response.json()["user"]["name"] == "Scrutiny Officer"


def test_login_wrong_password(client: TestClient):
    response = client.post("/api/auth/login", json={"email": ADMIN["email"], "password": "nope"})
    assert response.status_code == 401


def test_login_unknown_email(client: TestClient):
    response = client.post(
        "/api/auth/login", json={"email": "nobody@fdrportal.demo", "password": "whatever"}
    )
    assert response.status_code == 401


def test_me_returns_current_user(client: TestClient, admin: dict[str, str]):
    response = client.get("/api/auth/me", headers=admin)
    assert response.status_code == 200
    assert response.json()["role"] == "admin"


def test_me_without_token_is_unauthorized(client: TestClient):
    assert client.get("/api/auth/me").status_code == 401


def test_me_with_garbage_token_is_unauthorized(client: TestClient):
    response = client.get("/api/auth/me", headers={"Authorization": "Bearer not-a-jwt"})
    assert response.status_code == 401
