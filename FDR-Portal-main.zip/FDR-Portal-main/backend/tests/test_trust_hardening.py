"""Trust rules found in the role review: who may supply evidence, and what can never be undone silently."""

import io

from fastapi.testclient import TestClient

PDF = b"%PDF-1.4 bank confirmation letter for the hardening tests"


def _own_draft(client: TestClient, institution: dict[str, str], number: str) -> dict:
    me = client.get("/api/auth/me", headers=institution).json()
    body = {
        "fdr_number": number,
        "institution_id": me["institution_id"],
        "bank_name": "Canara Bank",
        "ifsc": "CNRB0001234",
        "amount": 1500000,
        "issue_date": "2026-10-01",
        "maturity_date": "2029-10-01",
        "interest_rate": 7.0,
        "purpose": "security_deposit",
        "lien_to_aicte": True,
    }
    res = client.post("/api/fdrs", headers=institution, json=body)
    assert res.status_code == 201, res.text
    return res.json()


def _upload(client: TestClient, headers: dict[str, str], fdr_id: int, doc_type: str, content: bytes = PDF):
    files = {"file": ("letter.pdf", io.BytesIO(content), "application/pdf")}
    return client.post(f"/api/fdrs/{fdr_id}/documents", headers=headers, files=files, data={"doc_type": doc_type})


def test_institution_cannot_supply_the_bank_confirmation_letter(
    client: TestClient, institution_deccan: dict[str, str]
):
    fdr = _own_draft(client, institution_deccan, "HARD/2026/0001")
    res = _upload(client, institution_deccan, fdr["id"], "bank_confirmation")
    assert res.status_code == 403
    assert _upload(client, institution_deccan, fdr["id"], "fdr_receipt").status_code == 201


def test_bank_confirmation_is_once_and_never_downgraded(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str], institution_deccan: dict[str, str]
):
    fdr = _own_draft(client, institution_deccan, "HARD/2026/0002")
    assert client.post(f"/api/fdrs/{fdr['id']}/submit", headers=institution_deccan).status_code == 200
    letter = _upload(client, admin, fdr["id"], "bank_confirmation", PDF + b" 0002")
    assert letter.status_code == 201, letter.text

    first = client.post(f"/api/fdrs/{fdr['id']}/bank-confirm", headers=reviewer, json={})
    assert first.status_code == 200 and first.json()["verification"] == "bank_confirmed"
    assert client.post(f"/api/fdrs/{fdr['id']}/bank-confirm", headers=reviewer, json={}).status_code == 409
    assert client.post(f"/api/fdrs/{fdr['id']}/verify", headers=reviewer).status_code == 409
    assert client.get(f"/api/fdrs/{fdr['id']}", headers=reviewer).json()["verification"] == "bank_confirmed"

    history = client.get(f"/api/fdrs/{fdr['id']}", headers=reviewer).json()["history"]
    confirmations = [h for h in history if h["action"] == "fdr.bank_confirmed"]
    assert len(confirmations) == 1 and confirmations[0]["to_status"] == "pending_approval"


def test_institution_applies_for_release_only_with_the_checklist(
    client: TestClient, reviewer: dict[str, str], institution_deccan: dict[str, str]
):
    fdr = _own_draft(client, institution_deccan, "HARD/2026/0003")
    client.post(f"/api/fdrs/{fdr['id']}/submit", headers=institution_deccan)
    client.post(f"/api/fdrs/{fdr['id']}/decision", headers=reviewer, json={"action": "approve"})
    bare = client.post(
        f"/api/fdrs/{fdr['id']}/request-release", headers=institution_deccan, json={"reason": "Programme closed"}
    )
    assert bare.status_code == 422


def test_reused_file_finding_does_not_name_another_deposit(
    client: TestClient, admin: dict[str, str], institution_deccan: dict[str, str]
):
    shared = PDF + b" shared scan"
    other = client.get("/api/fdrs?status=approved&page_size=1", headers=admin).json()["items"][0]
    assert _upload(client, admin, other["id"], "fdr_receipt", shared).status_code == 201
    own = _own_draft(client, institution_deccan, "HARD/2026/0004")
    assert _upload(client, institution_deccan, own["id"], "fdr_receipt", shared).status_code == 201

    findings = client.get(f"/api/fdrs/{own['id']}", headers=institution_deccan).json()["findings"]
    reused = next(f for f in findings if f["code"] == "DOCUMENT_REUSED")
    assert other["fdr_number"] not in reused["message"]


def test_every_bureau_role_can_read_settings_and_only_admin_writes(
    client: TestClient,
    admin: dict[str, str],
    reviewer: dict[str, str],
    approver: dict[str, str],
    auditor: dict[str, str],
    institution_deccan: dict[str, str],
):
    current = client.get("/api/settings", headers=admin).json()
    for headers in (reviewer, approver, auditor):
        assert client.get("/api/settings", headers=headers).status_code == 200
        assert client.put("/api/settings", headers=headers, json=current).status_code == 403
    assert client.get("/api/settings", headers=institution_deccan).status_code == 403
