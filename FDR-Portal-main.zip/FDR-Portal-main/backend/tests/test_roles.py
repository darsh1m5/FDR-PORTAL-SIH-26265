"""Tests for 10.1 Roles, permissions, scoping and trust.

Checks:
- All 5 demo users can authenticate and /me returns correct role and institution metadata
- Scoping: institution user can only see own FDRs in list and export
- Detail access: accessing another institution's FDR returns 404 (not 403)
- Create: institution user creating an FDR forces institution_id to their own
- Mutations: institution user cannot edit another institution's FDR (404) or approved FDR (403)
- Forbidden surfaces: institution cannot access /approvals, /audit, /findings, /institutions list (403)
- Auditor: read-only access to register, audit, dashboard, reports; 403 on create, edit, alert ack, etc.
- Allowed actions per role
- Admin and Reviewer workflows unchanged
"""

from fastapi.testclient import TestClient


def test_demo_user_auth_and_me(
    client: TestClient,
    admin: dict[str, str],
    reviewer: dict[str, str],
    approver: dict[str, str],
    auditor: dict[str, str],
    institution_deccan: dict[str, str],
):
    # Admin
    me_admin = client.get("/api/auth/me", headers=admin).json()
    assert me_admin["role"] == "admin"
    assert me_admin["institution_id"] is None
    assert me_admin["institution_name"] is None

    # Reviewer
    me_rev = client.get("/api/auth/me", headers=reviewer).json()
    assert me_rev["role"] == "reviewer"
    assert me_rev["institution_id"] is None

    # Approver
    me_app = client.get("/api/auth/me", headers=approver).json()
    assert me_app["role"] == "approver"
    assert me_app["institution_id"] is None

    # Auditor
    me_aud = client.get("/api/auth/me", headers=auditor).json()
    assert me_aud["role"] == "auditor"
    assert me_aud["institution_id"] is None

    # Institution
    me_inst = client.get("/api/auth/me", headers=institution_deccan).json()
    assert me_inst["role"] == "institution"
    assert me_inst["institution_id"] is not None
    assert "Deccan Crest" in me_inst["institution_name"]


def test_institution_scoping_on_list_and_export(
    client: TestClient,
    admin: dict[str, str],
    institution_deccan: dict[str, str],
):
    me = client.get("/api/auth/me", headers=institution_deccan).json()
    inst_id = me["institution_id"]

    # Bureau admin sees all 44 baseline FDRs
    all_fdrs = client.get("/api/fdrs", headers=admin).json()
    assert all_fdrs["total"] >= 44

    # Institution user only sees their own FDRs
    scoped_fdrs = client.get("/api/fdrs", headers=institution_deccan).json()
    assert scoped_fdrs["total"] < all_fdrs["total"]
    assert all(item["institution_id"] == inst_id for item in scoped_fdrs["items"])

    # Attempting to filter by another institution still returns only own institution
    forced_scope = client.get("/api/fdrs?institution_id=9999", headers=institution_deccan).json()
    assert all(item["institution_id"] == inst_id for item in forced_scope["items"])

    # Export CSV is also scoped
    csv_resp = client.get("/api/fdrs/export.csv", headers=institution_deccan)
    assert csv_resp.status_code == 200
    assert "Deccan Crest" in csv_resp.text
    # Should not contain another institution's AICTE ID
    assert "1-4411720455" not in csv_resp.text  # Kaveri Delta AICTE ID


def test_cross_institution_detail_returns_404(
    client: TestClient,
    admin: dict[str, str],
    institution_deccan: dict[str, str],
    institution_kaveri: dict[str, str],
):
    deccan_me = client.get("/api/auth/me", headers=institution_deccan).json()
    assert client.get("/api/auth/me", headers=institution_kaveri).status_code == 200

    # Find an FDR belonging to Deccan
    deccan_list = client.get("/api/fdrs", headers=institution_deccan).json()
    deccan_fdr_id = deccan_list["items"][0]["id"]

    # Deccan user can view own FDR detail
    own = client.get(f"/api/fdrs/{deccan_fdr_id}", headers=institution_deccan)
    assert own.status_code == 200
    assert own.json()["institution_id"] == deccan_me["institution_id"]

    # Kaveri user gets 404 (not 403) per §10.1 scoping contract
    cross = client.get(f"/api/fdrs/{deccan_fdr_id}", headers=institution_kaveri)
    assert cross.status_code == 404
    assert cross.json()["detail"] == "Deposit not found"


def test_institution_create_fdr_forces_own_institution_id(
    client: TestClient,
    institution_deccan: dict[str, str],
):
    me = client.get("/api/auth/me", headers=institution_deccan).json()
    inst_id = me["institution_id"]

    # Submitting with a spoofed institution_id (e.g. 9999) must force to user's institution_id
    payload = {
        "fdr_number": "DEC-TEST-001",
        "institution_id": 9999,
        "bank_name": "State Bank of India",
        "amount": 500000.0,
        "issue_date": "2026-01-15",
        "maturity_date": "2027-01-15",
        "interest_rate": 7.0,
        "purpose": "security_deposit",
    }
    resp = client.post("/api/fdrs", headers=institution_deccan, json=payload)
    assert resp.status_code == 201
    fdr = resp.json()
    assert fdr["institution_id"] == inst_id
    assert fdr["fdr_number"] == "DEC-TEST-001"
    assert fdr["status"] == "draft"


def test_forbidden_surfaces_for_institution(
    client: TestClient,
    institution_deccan: dict[str, str],
):
    # Approvals queue is 403
    assert client.get("/api/approvals", headers=institution_deccan).status_code == 403
    # Audit log is 403
    assert client.get("/api/audit", headers=institution_deccan).status_code == 403
    assert client.get("/api/audit/verify", headers=institution_deccan).status_code == 403
    # Health check across institutions is 403
    assert client.get("/api/findings", headers=institution_deccan).status_code == 403
    # Institutions register list is 403
    assert client.get("/api/institutions", headers=institution_deccan).status_code == 403
    # Notice candidates queue is 403
    assert client.get("/api/notices/candidates", headers=institution_deccan).status_code == 403
    # Settings is 403 (admin only)
    assert client.get("/api/settings", headers=institution_deccan).status_code == 403
    # Alerts engine run is 403
    assert client.post("/api/alerts/run", headers=institution_deccan).status_code == 403


def test_auditor_is_read_only(
    client: TestClient,
    auditor: dict[str, str],
    admin: dict[str, str],
):
    # Auditor can read
    assert client.get("/api/fdrs", headers=auditor).status_code == 200
    assert client.get("/api/dashboard", headers=auditor).status_code == 200
    assert client.get("/api/audit", headers=auditor).status_code == 200
    assert client.get("/api/audit/verify", headers=auditor).status_code == 200
    assert client.get("/api/approvals", headers=auditor).status_code == 200
    assert client.get("/api/radar", headers=auditor).status_code == 200
    assert client.get("/api/metrics", headers=auditor).status_code == 200
    assert client.get("/api/institutions", headers=auditor).status_code == 200

    # Auditor cannot create FDR
    payload = {
        "fdr_number": "AUD-TEST-001",
        "institution_id": 1,
        "bank_name": "State Bank of India",
        "amount": 500000.0,
        "issue_date": "2026-01-15",
        "maturity_date": "2027-01-15",
        "interest_rate": 7.0,
    }
    assert client.post("/api/fdrs", headers=auditor, json=payload).status_code == 403

    # Auditor cannot acknowledge alerts
    alerts = client.get("/api/alerts", headers=admin).json()
    if alerts:
        alert_id = alerts[0]["id"]
        assert client.post(f"/api/alerts/{alert_id}/acknowledge", headers=auditor).status_code == 403


def test_allowed_actions_by_role(
    client: TestClient,
    admin: dict[str, str],
    reviewer: dict[str, str],
    approver: dict[str, str],
    auditor: dict[str, str],
    institution_deccan: dict[str, str],
):
    # Create a draft FDR as deccan institution
    payload = {
        "fdr_number": "ROLE-ACT-001",
        "institution_id": 1,
        "bank_name": "State Bank of India",
        "amount": 1000000.0,
        "issue_date": "2026-02-01",
        "maturity_date": "2027-02-01",
        "interest_rate": 7.2,
    }
    draft = client.post("/api/fdrs", headers=institution_deccan, json=payload).json()
    fdr_id = draft["id"]

    # Institution on own draft has edit, submit, upload
    as_inst = client.get(f"/api/fdrs/{fdr_id}", headers=institution_deccan).json()
    assert {"edit", "submit", "upload"} <= set(as_inst["allowed_actions"])

    # Admin on draft has edit, submit, upload
    as_admin = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
    assert {"edit", "submit", "upload"} <= set(as_admin["allowed_actions"])

    # Reviewer on draft has observe, verify, bank_confirm
    as_rev = client.get(f"/api/fdrs/{fdr_id}", headers=reviewer).json()
    assert "observe" in as_rev["allowed_actions"]
    assert "edit" not in as_rev["allowed_actions"]

    # Auditor has no allowed actions (read-only)
    as_aud = client.get(f"/api/fdrs/{fdr_id}", headers=auditor).json()
    assert as_aud["allowed_actions"] == []
