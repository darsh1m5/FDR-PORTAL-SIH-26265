"""Role checks: administrators manage, reviewers decide, both can view."""

from fastapi.testclient import TestClient


def test_reviewer_cannot_create(client: TestClient, reviewer: dict[str, str]):
    response = client.post("/api/fdrs", headers=reviewer, json={})
    assert response.status_code == 403


def test_reviewer_cannot_edit_or_submit(client: TestClient, reviewer: dict[str, str], admin: dict[str, str]):
    fdr = client.get("/api/fdrs?status=draft", headers=admin).json()["items"][0]
    fdr_id = fdr["id"]
    assert client.patch(f"/api/fdrs/{fdr_id}", headers=reviewer, json={"amount": 1}).status_code == 403
    assert client.post(f"/api/fdrs/{fdr_id}/submit", headers=reviewer).status_code == 403


def test_reviewer_cannot_upload_or_run_alerts_or_change_settings(
    client: TestClient, reviewer: dict[str, str]
):
    assert client.post("/api/alerts/run", headers=reviewer).status_code == 403
    assert client.put("/api/settings", headers=reviewer, json={}).status_code == 403
    assert client.post("/api/institutions", headers=reviewer, json={}).status_code == 403


def test_admin_cannot_decide_or_verify(client: TestClient, admin: dict[str, str]):
    pending = client.get("/api/fdrs?status=pending_approval", headers=admin).json()["items"][0]
    fdr_id = pending["id"]
    decision = client.post(f"/api/fdrs/{fdr_id}/decision", headers=admin, json={"action": "approve"})
    assert decision.status_code == 403
    assert client.post(f"/api/fdrs/{fdr_id}/verify", headers=admin).status_code == 403


def test_anonymous_cannot_read(client: TestClient):
    assert client.get("/api/fdrs").status_code == 401
    assert client.get("/api/dashboard").status_code == 401


def test_both_roles_can_read(client: TestClient, admin: dict[str, str], reviewer: dict[str, str]):
    assert client.get("/api/fdrs", headers=admin).status_code == 200
    assert client.get("/api/fdrs", headers=reviewer).status_code == 200
    assert client.get("/api/audit", headers=reviewer).status_code == 200
