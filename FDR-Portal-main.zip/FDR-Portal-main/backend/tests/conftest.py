"""Shared fixtures: one temp SQLite database per pytest session, seeded once.

The environment is set at import time, before any `app` module is imported,
because `app.config` reads the environment when it is first imported.
"""

import os
import tempfile
from pathlib import Path

import pytest

_TMP = Path(tempfile.mkdtemp(prefix="fdr-tests-"))
os.environ["DATABASE_URL"] = f"sqlite:///{(_TMP / 'test.db').as_posix()}"
os.environ["UPLOAD_DIR"] = str(_TMP / "uploads")
os.environ["RUN_SCHEDULER"] = "0"

from fastapi.testclient import TestClient  # noqa: E402

from app.main import app  # noqa: E402

ADMIN = {"email": "admin@fdrportal.demo", "password": "Admin@2026"}
REVIEWER = {"email": "reviewer@fdrportal.demo", "password": "Review@2026"}
APPROVER = {"email": "approver@fdrportal.demo", "password": "Approve@2026"}
AUDITOR = {"email": "auditor@fdrportal.demo", "password": "Audit@2026"}
INST_DECCAN = {"email": "deccan.crest@fdrportal.demo", "password": "Inst@2026"}
INST_KAVERI = {"email": "kaveri.delta@fdrportal.demo", "password": "Inst@2026"}
INST_BUNDELKHAND = {"email": "bundelkhand.skills@fdrportal.demo", "password": "Inst@2026"}


@pytest.fixture(scope="session")
def client() -> TestClient:
    with TestClient(app) as test_client:
        yield test_client


def login(client: TestClient, credentials: dict[str, str]) -> dict[str, str]:
    response = client.post("/api/auth/login", json=credentials)
    assert response.status_code == 200, response.text
    return {"Authorization": f"Bearer {response.json()['access_token']}"}


@pytest.fixture(scope="session")
def admin(client: TestClient) -> dict[str, str]:
    return login(client, ADMIN)


@pytest.fixture(scope="session")
def reviewer(client: TestClient) -> dict[str, str]:
    return login(client, REVIEWER)


@pytest.fixture(scope="session")
def approver(client: TestClient) -> dict[str, str]:
    return login(client, APPROVER)


@pytest.fixture(scope="session")
def auditor(client: TestClient) -> dict[str, str]:
    return login(client, AUDITOR)


@pytest.fixture(scope="session")
def institution_deccan(client: TestClient) -> dict[str, str]:
    return login(client, INST_DECCAN)


@pytest.fixture(scope="session")
def institution_kaveri(client: TestClient) -> dict[str, str]:
    return login(client, INST_KAVERI)


@pytest.fixture(scope="session")
def institution_bundelkhand(client: TestClient) -> dict[str, str]:
    return login(client, INST_BUNDELKHAND)
