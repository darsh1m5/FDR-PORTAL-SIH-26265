"""Tests for §9.4 Renewal lineage."""

from fastapi.testclient import TestClient
from sqlalchemy import delete, select, update

from app.db import SessionLocal
from app.models import Alert, AuditLog, Document, Fdr, Notice


def _cleanup_lin_fdrs() -> None:
    with SessionLocal() as db:
        fdr_ids = db.scalars(select(Fdr.id).where(Fdr.fdr_number.startswith("LIN/"))).all()
        if not fdr_ids:
            return
        db.execute(update(Fdr).where(Fdr.id.in_(fdr_ids)).values(renewed_from_id=None))
        db.execute(delete(Alert).where(Alert.fdr_id.in_(fdr_ids)))
        db.execute(delete(Notice).where(Notice.fdr_id.in_(fdr_ids)))
        db.execute(delete(Document).where(Document.fdr_id.in_(fdr_ids)))
        db.execute(delete(AuditLog).where(AuditLog.fdr_id.in_(fdr_ids)))
        db.execute(delete(Fdr).where(Fdr.id.in_(fdr_ids)))
        db.commit()


def test_standalone_fdr_has_length_1_lineage(client: TestClient, admin: dict[str, str]):
    inst = client.get("/api/institutions", headers=admin).json()[0]
    fdr_data = {
        "fdr_number": "LIN/TEST/001",
        "institution_id": inst["id"],
        "bank_name": "State Bank of India",
        "amount": 500000,
        "issue_date": "2026-01-01",
        "maturity_date": "2027-01-01",
        "interest_rate": 7.0,
        "purpose": "security_deposit",
        "lien_to_aicte": True,
    }
    try:
        fdr = client.post("/api/fdrs", json=fdr_data, headers=admin).json()
        fdr_id = fdr["id"]
        detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
        assert "lineage" in detail
        assert len(detail["lineage"]) == 1
        item = detail["lineage"][0]
        assert item["id"] == fdr_id
        assert item["fdr_number"] == "LIN/TEST/001"
        assert item["status"] == "draft"
        assert item["amount"] == 500000.0
    finally:
        _cleanup_lin_fdrs()


def test_twice_renewed_fdr_has_3_item_chain(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str]
):
    inst = client.get("/api/institutions", headers=admin).json()[0]

    try:
        # 1. Create first FDR
        fdr1_data = {
            "fdr_number": "LIN/CHAIN/001",
            "institution_id": inst["id"],
            "bank_name": "State Bank of India",
            "amount": 1000000,
            "issue_date": "2024-01-01",
            "maturity_date": "2025-01-01",
            "interest_rate": 7.0,
            "purpose": "security_deposit",
            "lien_to_aicte": True,
        }
        f1 = client.post("/api/fdrs", json=fdr1_data, headers=admin).json()
        id1 = f1["id"]

        # Submit and approve first FDR
        s1 = client.post(f"/api/fdrs/{id1}/submit", headers=admin)
        assert s1.status_code == 200
        a1 = client.post(f"/api/fdrs/{id1}/decision", json={"action": "approve"}, headers=reviewer)
        assert a1.status_code == 200

        # 2. Renew first FDR -> second FDR
        fdr2_data = {
            "fdr_number": "LIN/CHAIN/002",
            "institution_id": inst["id"],
            "bank_name": "State Bank of India",
            "amount": 1070000,
            "issue_date": "2025-01-01",
            "maturity_date": "2026-01-01",
            "interest_rate": 7.25,
            "purpose": "security_deposit",
            "lien_to_aicte": True,
        }
        r1 = client.post(f"/api/fdrs/{id1}/renew", json=fdr2_data, headers=admin)
        assert r1.status_code == 201, r1.text
        f2 = r1.json()
        id2 = f2["id"]

        # Approve second FDR so it can be renewed
        a2 = client.post(f"/api/fdrs/{id2}/decision", json={"action": "approve"}, headers=reviewer)
        assert a2.status_code == 200

        # 3. Renew second FDR -> third FDR
        fdr3_data = {
            "fdr_number": "LIN/CHAIN/003",
            "institution_id": inst["id"],
            "bank_name": "State Bank of India",
            "amount": 1150000,
            "issue_date": "2026-01-01",
            "maturity_date": "2027-01-01",
            "interest_rate": 7.5,
            "purpose": "security_deposit",
            "lien_to_aicte": True,
        }
        r2 = client.post(f"/api/fdrs/{id2}/renew", json=fdr3_data, headers=admin)
        assert r2.status_code == 201, r2.text
        f3 = r2.json()
        id3 = f3["id"]

        # Now verify lineage from all 3 perspectives (oldest first)
        for check_id in (id1, id2, id3):
            detail = client.get(f"/api/fdrs/{check_id}", headers=admin).json()
            lineage = detail["lineage"]
            assert len(lineage) == 3, f"Expected 3 items in lineage for FDR {check_id}, got {len(lineage)}"
            assert [item["id"] for item in lineage] == [id1, id2, id3]
            assert [item["fdr_number"] for item in lineage] == [
                "LIN/CHAIN/001",
                "LIN/CHAIN/002",
                "LIN/CHAIN/003",
            ]
            assert [item["status"] for item in lineage] == [
                "renewed",
                "renewed",
                "pending_approval",
            ]
            assert lineage[0]["amount"] == 1000000.0
            assert lineage[1]["amount"] == 1070000.0
            assert lineage[2]["amount"] == 1150000.0

    finally:
        _cleanup_lin_fdrs()
