"""Document upload/download/delete, including the file-signature check."""

from fastapi.testclient import TestClient

from tests.test_status_machine import _body

MINIMAL_PDF = (
    b"%PDF-1.4\n"
    b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n"
    b"2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n"
    b"trailer << /Size 3 /Root 1 0 R >>\n%%EOF\n"
)


def test_upload_download_delete_roundtrip(client: TestClient, admin: dict[str, str]):
    fdr = client.post("/api/fdrs", headers=admin, json=_body()).json()
    fdr_id = fdr["id"]

    uploaded = client.post(
        f"/api/fdrs/{fdr_id}/documents",
        headers=admin,
        files={"file": ("receipt.pdf", MINIMAL_PDF, "application/pdf")},
    )
    assert uploaded.status_code == 201, uploaded.text
    document = uploaded.json()
    assert document["filename"] == "receipt.pdf"
    assert document["size_bytes"] == len(MINIMAL_PDF)
    assert document["uploaded_by"] == "Section Officer"

    detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
    assert [d["id"] for d in detail["documents"]] == [document["id"]]

    downloaded = client.get(f"/api/documents/{document['id']}/download", headers=admin)
    assert downloaded.status_code == 200
    assert downloaded.content == MINIMAL_PDF

    deleted = client.delete(f"/api/documents/{document['id']}", headers=admin)
    assert deleted.status_code == 204
    detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
    assert detail["documents"] == []


def test_upload_rejects_non_pdf_bytes(client: TestClient, admin: dict[str, str]):
    fdr = client.post("/api/fdrs", headers=admin, json=_body()).json()
    response = client.post(
        f"/api/fdrs/{fdr['id']}/documents",
        headers=admin,
        files={"file": ("fake.pdf", b"this is not a pdf", "application/pdf")},
    )
    assert response.status_code == 415


def test_upload_rejects_oversized_files(client: TestClient, admin: dict[str, str]):
    fdr = client.post("/api/fdrs", headers=admin, json=_body()).json()
    big = b"%PDF-1.4\n" + b"0" * (10 * 1024 * 1024)
    response = client.post(
        f"/api/fdrs/{fdr['id']}/documents",
        headers=admin,
        files={"file": ("big.pdf", big, "application/pdf")},
    )
    assert response.status_code == 413
