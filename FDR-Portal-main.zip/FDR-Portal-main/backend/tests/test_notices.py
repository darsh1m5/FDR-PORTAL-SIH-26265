"""Tests for notices and letters: candidates, issue notices, authorization, validation, and listing."""

from datetime import date, timedelta
from decimal import Decimal

from fastapi.testclient import TestClient
from sqlalchemy import select

from app.db import SessionLocal
from app.models import AuditEntity, AuditLog, Fdr, FdrStatus, Institution, Purpose


def test_candidates_endpoint(client: TestClient, admin: dict[str, str]) -> None:
    resp = client.get("/api/notices/candidates", headers=admin)
    assert resp.status_code == 200
    data = resp.json()
    assert "maturity" in data
    assert "overdue" in data
    assert "shortfall" in data
    assert isinstance(data["maturity"], list)
    assert isinstance(data["overdue"], list)
    assert isinstance(data["shortfall"], list)


def test_reviewer_forbidden_on_post_notice(client: TestClient, reviewer: dict[str, str]) -> None:
    resp = client.post(
        "/api/notices",
        json={"kind": "maturity_reminder", "fdr_id": 1},
        headers=reviewer,
    )
    assert resp.status_code == 403


def test_validation_errors(client: TestClient, admin: dict[str, str]) -> None:
    # Neither fdr_id nor institution_id
    resp = client.post(
        "/api/notices",
        json={"kind": "maturity_reminder"},
        headers=admin,
    )
    assert resp.status_code == 422

    # Both fdr_id and institution_id
    resp = client.post(
        "/api/notices",
        json={"kind": "maturity_reminder", "fdr_id": 1, "institution_id": 1},
        headers=admin,
    )
    assert resp.status_code == 422

    # Shortfall notice with fdr_id instead of institution_id
    resp = client.post(
        "/api/notices",
        json={"kind": "shortfall_notice", "fdr_id": 1},
        headers=admin,
    )
    assert resp.status_code == 422

    # Release letter on active/non-released FDR
    with SessionLocal() as db:
        active_fdr = db.query(Fdr).filter(Fdr.status != FdrStatus.released).first()
        assert active_fdr is not None
        active_fdr_id = active_fdr.id

    resp = client.post(
        "/api/notices",
        json={"kind": "release_letter", "fdr_id": active_fdr_id},
        headers=admin,
    )
    assert resp.status_code == 409  # a state conflict, like the other workflow refusals
    assert "released" in resp.json()["detail"].lower()


def test_issue_all_kinds_and_sequential_reference(client: TestClient, admin: dict[str, str]) -> None:
    # 1. Maturity reminder
    with SessionLocal() as db:
        fdr = db.query(Fdr).filter(Fdr.status == FdrStatus.approved).first()
        assert fdr is not None
        fdr_id = fdr.id
        fdr_num = fdr.fdr_number

    resp = client.post(
        "/api/notices",
        json={"kind": "maturity_reminder", "fdr_id": fdr_id},
        headers=admin,
    )
    assert resp.status_code == 201
    n1 = resp.json()
    assert n1["kind"] == "maturity_reminder"
    assert n1["reference_no"].startswith("FDRP/NOT/")
    assert n1["fdr_id"] == fdr_id
    assert n1["letter"]["salutation"].startswith("To the Principal / Director")
    assert fdr_num in n1["letter"]["subject"]
    assert len(n1["letter"]["body"]) >= 2
    assert "₹" in n1["letter"]["body"][0]

    # Check detail notices_count
    resp_detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin)
    assert resp_detail.status_code == 200
    assert resp_detail.json()["notices_count"] >= 1

    # Check audit log written
    with SessionLocal() as db:
        audit = db.scalar(
            select(AuditLog).where(
                AuditLog.action == "notice.issued", AuditLog.entity_id == n1["id"]
            )
        )
        assert audit is not None
        assert audit.entity == AuditEntity.notice

    # 2. Overdue notice
    resp2 = client.post(
        "/api/notices",
        json={"kind": "overdue_notice", "fdr_id": fdr_id},
        headers=admin,
    )
    assert resp2.status_code == 201
    n2 = resp2.json()
    assert n2["reference_no"] != n1["reference_no"]
    seq1 = int(n1["reference_no"].split("/")[-1])
    seq2 = int(n2["reference_no"].split("/")[-1])
    assert seq2 == seq1 + 1

    # 3. Shortfall notice (with institution_id)
    with SessionLocal() as db:
        inst = db.query(Institution).first()
        assert inst is not None
        inst_id = inst.id

    resp3 = client.post(
        "/api/notices",
        json={"kind": "shortfall_notice", "institution_id": inst_id},
        headers=admin,
    )
    assert resp3.status_code == 201
    n3 = resp3.json()
    assert n3["kind"] == "shortfall_notice"
    assert n3["institution_id"] == inst_id
    assert n3["fdr_id"] is None
    assert "shortfall" in n3["letter"]["subject"].lower()

    # 4. Release letter on released FDR
    with SessionLocal() as db:
        released_fdr = Fdr(
            institution_id=inst_id,
            fdr_number="TEST-REL-001",
            bank_name="State Bank of India",
            branch="Main Branch",
            ifsc="SBIN0001234",
            amount=Decimal("1500000.00"),
            issue_date=date.today() - timedelta(days=400),
            maturity_date=date.today() - timedelta(days=35),
            interest_rate=Decimal("7.20"),
            maturity_amount=None,
            purpose=Purpose.security_deposit,
            lien_to_aicte=True,
            status=FdrStatus.released,
        )
        db.add(released_fdr)
        db.commit()
        db.refresh(released_fdr)
        rel_id = released_fdr.id

    resp4 = client.post(
        "/api/notices",
        json={"kind": "release_letter", "fdr_id": rel_id},
        headers=admin,
    )
    assert resp4.status_code == 201
    n4 = resp4.json()
    assert n4["kind"] == "release_letter"
    assert "release" in n4["letter"]["subject"].lower()

    # 5. List notices
    resp_list = client.get("/api/notices", headers=admin)
    assert resp_list.status_code == 200
    all_notices = resp_list.json()
    assert len(all_notices) >= 4
    assert all_notices[0]["id"] == n4["id"]

    # Filter by fdr_id
    resp_fdr_filter = client.get(f"/api/notices?fdr_id={fdr_id}", headers=admin)
    assert resp_fdr_filter.status_code == 200
    filtered = resp_fdr_filter.json()
    assert len(filtered) >= 2
    assert all(item["fdr_id"] == fdr_id for item in filtered)
