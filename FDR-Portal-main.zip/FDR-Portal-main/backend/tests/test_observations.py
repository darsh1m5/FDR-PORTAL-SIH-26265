"""Tests for scrutiny observations: query thread, permissions, scoping, and unanswered alert."""

from datetime import datetime, timedelta, timezone

from fastapi.testclient import TestClient

from app.alerts import run_alerts
from app.db import SessionLocal
from app.models import Alert, AlertType, Fdr, FdrStatus, Observation, User


def test_observation_lifecycle(
    client: TestClient,
    admin: dict[str, str],
    reviewer: dict[str, str],
    institution_deccan: dict[str, str],
    institution_kaveri: dict[str, str],
    auditor: dict[str, str],
):
    with SessionLocal() as db:
        deccan_user = db.query(User).filter(User.email == "deccan.crest@fdrportal.demo").first()
        assert deccan_user is not None
        fdr = db.query(Fdr).filter(Fdr.institution_id == deccan_user.institution_id, Fdr.status == FdrStatus.approved).first()
        assert fdr is not None
        fdr_id = fdr.id

    # 1. Non-reviewer cannot raise observation
    assert client.post(
        f"/api/fdrs/{fdr_id}/observations",
        json={"text": "Query from institution"},
        headers=institution_deccan,
    ).status_code == 403

    assert client.post(
        f"/api/fdrs/{fdr_id}/observations",
        json={"text": "Query from admin"},
        headers=admin,
    ).status_code == 403

    assert client.post(
        f"/api/fdrs/{fdr_id}/observations",
        json={"text": "Query from auditor"},
        headers=auditor,
    ).status_code == 403

    # 2. Reviewer raises observation
    res = client.post(
        f"/api/fdrs/{fdr_id}/observations",
        json={"text": "Please provide confirmation of the lien marking from the bank."},
        headers=reviewer,
    )
    assert res.status_code == 201
    obs = res.json()
    obs_id = obs["id"]
    assert obs["text"] == "Please provide confirmation of the lien marking from the bank."
    assert obs["status"] == "open"
    assert obs["author_name"] == "Scrutiny Officer"
    assert obs["author_role"] == "reviewer"

    # Detail now reports 1 open observation
    fdr_detail = client.get(f"/api/fdrs/{fdr_id}", headers=reviewer).json()
    assert fdr_detail["observations_open"] >= 1

    # 3. List observations
    list_res = client.get(f"/api/fdrs/{fdr_id}/observations", headers=reviewer)
    assert list_res.status_code == 200
    items = list_res.json()
    assert any(item["id"] == obs_id for item in items)

    # 4. Another institution gets 404
    assert client.get(f"/api/fdrs/{fdr_id}/observations", headers=institution_kaveri).status_code == 404
    assert client.post(
        f"/api/observations/{obs_id}/respond",
        json={"response": "We cannot see this"},
        headers=institution_kaveri,
    ).status_code == 404

    # 5. Owning institution responds
    resp_res = client.post(
        f"/api/observations/{obs_id}/respond",
        json={"response": "Lien confirmation letter attached under documents."},
        headers=institution_deccan,
    )
    assert resp_res.status_code == 200
    answered_obs = resp_res.json()
    assert answered_obs["status"] == "answered"
    assert answered_obs["response"] == "Lien confirmation letter attached under documents."
    assert answered_obs["responded_by"] is not None

    # Responding again returns 409
    assert client.post(
        f"/api/observations/{obs_id}/respond",
        json={"response": "Second reply attempt"},
        headers=institution_deccan,
    ).status_code == 409

    # 6. Reviewer closes observation
    # Non-reviewer cannot close
    assert client.post(f"/api/observations/{obs_id}/close", headers=admin).status_code == 403
    assert client.post(f"/api/observations/{obs_id}/close", headers=institution_deccan).status_code == 403

    close_res = client.post(f"/api/observations/{obs_id}/close", headers=reviewer)
    assert close_res.status_code == 200
    closed_obs = close_res.json()
    assert closed_obs["status"] == "closed"

    # Closing again returns 409
    assert client.post(f"/api/observations/{obs_id}/close", headers=reviewer).status_code == 409


def test_observation_unanswered_alert(client: TestClient, reviewer: dict[str, str], admin: dict[str, str]):
    with SessionLocal() as db:
        fdr = db.query(Fdr).filter(Fdr.status == FdrStatus.approved).first()
        assert fdr is not None
        fdr_id = fdr.id

    # Raise an observation
    res = client.post(
        f"/api/fdrs/{fdr_id}/observations",
        json={"text": "Clarification required on interest certificate."},
        headers=reviewer,
    )
    assert res.status_code == 201
    obs_id = res.json()["id"]

    # Backdate the observation past pending_sla_days (e.g., 10 days ago)
    with SessionLocal() as db:
        obs = db.get(Observation, obs_id)
        obs.created_at = datetime.now(timezone.utc) - timedelta(days=12)
        db.commit()

        # Run alerts
        run_alerts(db)
        db.commit()

        alert = (
            db.query(Alert)
            .filter(Alert.fdr_id == fdr_id, Alert.type == AlertType.observation_unanswered)
            .first()
        )
        assert alert is not None
        assert alert.acknowledged_at is None
        assert alert.auto_resolved is False

    # Now answer the observation
    client.post(
        f"/api/observations/{obs_id}/respond",
        json={"response": "Interest certificate verified with the branch manager."},
        headers=admin,
    )

    # Run alerts again -> alert should auto-resolve
    with SessionLocal() as db:
        run_alerts(db)
        db.commit()

        alert = (
            db.query(Alert)
            .filter(Alert.fdr_id == fdr_id, Alert.type == AlertType.observation_unanswered)
            .first()
        )
        assert alert is not None
        assert alert.auto_resolved is True
