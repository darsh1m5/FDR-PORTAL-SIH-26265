"""Tests for renewal checks (RENEWAL_GAP, RENEWAL_AMOUNT_DROP) and risk sort (§10.7, §10.8)."""

from datetime import date, timedelta
from decimal import Decimal
from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.models import Fdr, FdrStatus, Institution, Purpose


def _create_base_fdr(db: Session, number: str, amount: Decimal, issue: date, maturity: date) -> Fdr:
    inst = db.query(Institution).first()
    fdr = Fdr(
        institution_id=inst.id,
        fdr_number=number,
        bank_name="State Bank of India",
        branch="Main Branch",
        ifsc="SBIN0001234",
        amount=amount,
        issue_date=issue,
        maturity_date=maturity,
        interest_rate=Decimal("7.00"),
        purpose=Purpose.security_deposit,
        lien_to_aicte=True,
        status=FdrStatus.approved,
    )
    db.add(fdr)
    db.commit()
    db.refresh(fdr)
    return fdr


def test_renewal_gap_and_amount_drop_findings(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str]
):
    with SessionLocal() as db:
        old_mat = date.today() - timedelta(days=20)
        old_issue = old_mat - timedelta(days=365)
        old_fdr = _create_base_fdr(db, "FDR-OLD-001", Decimal("1000000.00"), old_issue, old_mat)
        old_id = old_fdr.id

    # Renew with an issue date 10 days after old maturity date (gap=10)
    # And a dropped amount (800000 < 1000000)
    renewal_body = {
        "fdr_number": "FDR-NEW-001",
        "bank_name": "State Bank of India",
        "branch": "Main Branch",
        "ifsc": "SBIN0001234",
        "amount": 800000.00,
        "issue_date": (old_mat + timedelta(days=10)).isoformat(),
        "maturity_date": (old_mat + timedelta(days=375)).isoformat(),
        "interest_rate": 7.50,
        "purpose": "security_deposit",
        "lien_to_aicte": True,
    }

    resp = client.post(f"/api/fdrs/{old_id}/renew", json=renewal_body, headers=admin)
    assert resp.status_code == 201
    new_fdr = resp.json()
    new_id = new_fdr["id"]

    # Check findings on the replacement FDR
    detail = client.get(f"/api/fdrs/{new_id}", headers=reviewer).json()
    codes = {f["code"]: f for f in detail["findings"]}

    # 1. RENEWAL_GAP
    assert "RENEWAL_GAP" in codes
    assert codes["RENEWAL_GAP"]["severity"] == "warning"
    assert "10 days" in codes["RENEWAL_GAP"]["message"]

    # 2. RENEWAL_AMOUNT_DROP
    assert "RENEWAL_AMOUNT_DROP" in codes
    assert codes["RENEWAL_AMOUNT_DROP"]["severity"] == "warning"


def test_approvals_sort_by_risk(client: TestClient, reviewer: dict[str, str]):
    # Default order (sort=date)
    res_date = client.get("/api/approvals?sort=date", headers=reviewer)
    assert res_date.status_code == 200
    date_items = res_date.json()["items"]
    assert len(date_items) > 0

    # Sort by risk (sort=risk) -> lowest health score first
    res_risk = client.get("/api/approvals?sort=risk", headers=reviewer)
    assert res_risk.status_code == 200
    risk_items = res_risk.json()["items"]
    assert len(risk_items) == len(date_items)

    scores = [item["fdr"]["health_score"] for item in risk_items]
    # Verify scores are sorted ascending
    assert scores == sorted(scores)
