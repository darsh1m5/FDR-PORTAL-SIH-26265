"""Seed behaviour: fixed demo shape and an idempotent run()."""

from fastapi.testclient import TestClient


def test_seed_run_is_idempotent(client: TestClient, admin: dict[str, str]):
    from app.db import SessionLocal
    from app.models import Fdr, User
    from app.seed import run as seed_run

    before_fdrs = client.get("/api/fdrs?page_size=1", headers=admin).json()["total"]
    db = SessionLocal()
    seed_run(db)  # must do nothing while users exist
    users = db.query(User).count()
    after_fdrs = db.query(Fdr).count()
    db.close()

    assert users == 7
    assert after_fdrs == before_fdrs
