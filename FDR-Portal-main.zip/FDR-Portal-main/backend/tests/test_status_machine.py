"""The full status machine: draft -> pending -> approved/rejected, release,
renew lineage, verification, and the 409/422 guards around each transition."""

from datetime import date, timedelta

from fastapi.testclient import TestClient

_serial = 0


def _body(**overrides) -> dict:
    global _serial
    _serial += 1
    today = date.today()
    body = {
        "fdr_number": f"TEST/2026/{_serial:04d}",
        "institution_id": 1,
        "bank_name": "State Bank of India",
        "branch": "Test Branch",
        "ifsc": "SBIN0001234",
        "amount": 1_500_000,
        "issue_date": (today - timedelta(days=10)).isoformat(),
        "maturity_date": (today + timedelta(days=350)).isoformat(),
        "interest_rate": "6.90",
        "purpose": "security_deposit",
        "lien_to_aicte": True,
    }
    body.update(overrides)
    return body


def _create(client: TestClient, admin: dict[str, str], **overrides) -> dict:
    response = client.post("/api/fdrs", headers=admin, json=_body(**overrides))
    assert response.status_code == 201, response.text
    return response.json()


def _to_approved(client: TestClient, admin: dict[str, str], reviewer: dict[str, str]) -> dict:
    fdr = _create(client, admin)
    assert client.post(f"/api/fdrs/{fdr['id']}/submit", headers=admin).status_code == 200
    decision = client.post(
        f"/api/fdrs/{fdr['id']}/decision", headers=reviewer, json={"action": "approve"}
    )
    assert decision.status_code == 200
    return decision.json()


def test_create_produces_draft_with_actions(client: TestClient, admin: dict[str, str]):
    fdr = _create(client, admin)
    assert fdr["status"] == "draft"
    assert fdr["verification"] == "submitted"
    assert "edit" in fdr["allowed_actions"]
    assert "submit" in fdr["allowed_actions"]
    assert "upload" in fdr["allowed_actions"]
    assert fdr["days_to_maturity"] > 300
    assert fdr["maturity_state"] == "active"


def test_maturity_before_issue_is_rejected(client: TestClient, admin: dict[str, str]):
    response = client.post(
        "/api/fdrs", headers=admin, json=_body(issue_date="2026-06-01", maturity_date="2026-01-01")
    )
    assert response.status_code == 422


def test_edit_then_submit_moves_to_pending(client: TestClient, admin: dict[str, str]):
    fdr = _create(client, admin)
    patched = client.patch(f"/api/fdrs/{fdr['id']}", headers=admin, json={"amount": 2_000_000})
    assert patched.status_code == 200
    assert patched.json()["amount"] == 2_000_000

    submitted = client.post(f"/api/fdrs/{fdr['id']}/submit", headers=admin)
    assert submitted.status_code == 200
    assert submitted.json()["status"] == "pending_approval"
    # administrators may still edit a pending FDR
    assert "edit" in submitted.json()["allowed_actions"]


def test_approve_and_reject_paths(client: TestClient, admin: dict[str, str], reviewer: dict[str, str]):
    fdr = _create(client, admin)
    client.post(f"/api/fdrs/{fdr['id']}/submit", headers=admin)

    rejected = client.post(f"/api/fdrs/{fdr['id']}/decision", headers=reviewer, json={"action": "reject"})
    assert rejected.status_code == 422  # a remark is required

    rejected = client.post(
        f"/api/fdrs/{fdr['id']}/decision",
        headers=reviewer,
        json={"action": "reject", "remark": "Receipt copy illegible."},
    )
    assert rejected.status_code == 200
    assert rejected.json()["status"] == "rejected"

    resubmitted = client.post(f"/api/fdrs/{fdr['id']}/submit", headers=admin)
    assert resubmitted.status_code == 200
    approved = client.post(
        f"/api/fdrs/{fdr['id']}/decision", headers=reviewer, json={"action": "approve"}
    )
    assert approved.status_code == 200
    assert approved.json()["status"] == "approved"


def test_409_on_transitions_out_of_place(client: TestClient, admin: dict[str, str], reviewer: dict[str, str]):
    fdr = _to_approved(client, admin, reviewer)
    fdr_id = fdr["id"]
    assert client.post(f"/api/fdrs/{fdr_id}/submit", headers=admin).status_code == 409
    decision = client.post(
        f"/api/fdrs/{fdr_id}/decision", headers=reviewer, json={"action": "approve"}
    )
    assert decision.status_code == 409
    assert client.patch(f"/api/fdrs/{fdr_id}", headers=admin, json={"amount": 5}).status_code == 409


def test_verify_sets_provenance_without_status_change(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str]
):
    fdr = _create(client, admin)
    client.post(f"/api/fdrs/{fdr['id']}/submit", headers=admin)
    verified = client.post(f"/api/fdrs/{fdr['id']}/verify", headers=reviewer)
    assert verified.status_code == 200
    body = verified.json()
    assert body["verification"] == "officer_verified"
    assert body["status"] == "pending_approval"


def test_release_cycle(client: TestClient, admin: dict[str, str], reviewer: dict[str, str], approver: dict[str, str]):
    fdr = _to_approved(client, admin, reviewer)
    fdr_id = fdr["id"]

    missing = client.post(f"/api/fdrs/{fdr_id}/request-release", headers=admin, json={"reason": ""})
    assert missing.status_code == 422

    requested = client.post(
        f"/api/fdrs/{fdr_id}/request-release",
        headers=admin,
        json={"reason": "Programme discontinued; funds to be refunded."},
    )
    assert requested.status_code == 200
    assert requested.json()["status"] == "release_requested"
    assert "reject" not in requested.json()["allowed_actions"]  # computed for the admin caller
    as_reviewer = client.get(f"/api/fdrs/{fdr_id}", headers=reviewer).json()
    assert "approve" not in as_reviewer["allowed_actions"]
    assert "reject" not in as_reviewer["allowed_actions"]
    as_approver = client.get(f"/api/fdrs/{fdr_id}", headers=approver).json()
    assert {"sanction_release", "return_release"} <= set(as_approver["allowed_actions"])

    # Reviewer is refused
    refused = client.post(
        f"/api/fdrs/{fdr_id}/decision", headers=reviewer, json={"action": "approve"}
    )
    assert refused.status_code == 403

    # Approver sanctions
    released = client.post(
        f"/api/fdrs/{fdr_id}/decision", headers=approver, json={"action": "approve"}
    )
    assert released.status_code == 200
    assert released.json()["status"] == "released"
    assert client.patch(f"/api/fdrs/{fdr_id}", headers=admin, json={"amount": 5}).status_code == 409


def test_release_rejection_returns_to_approved(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str], approver: dict[str, str]
):
    fdr = _to_approved(client, admin, reviewer)
    client.post(
        f"/api/fdrs/{fdr['id']}/request-release",
        headers=admin,
        json={"reason": "Requested in error, testing the reject path."},
    )
    assert client.post(
        f"/api/fdrs/{fdr['id']}/decision",
        headers=reviewer,
        json={"action": "reject", "remark": "Hold until the semester ends."},
    ).status_code == 403

    rejected = client.post(
        f"/api/fdrs/{fdr['id']}/decision",
        headers=approver,
        json={"action": "reject", "remark": "Hold until the semester ends."},
    )
    assert rejected.status_code == 200
    assert rejected.json()["status"] == "approved"


def test_renew_creates_linked_replacement(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str]
):
    old = _to_approved(client, admin, reviewer)
    today = date.today()
    replacement_body = _body(
        fdr_number=f"TEST-RENEW/{_serial:04d}",
        amount=1_600_000,
        issue_date=(today - timedelta(days=1)).isoformat(),
        maturity_date=(today + timedelta(days=1800)).isoformat(),
    )
    assert client.post(
        f"/api/fdrs/{old['id']}/renew", headers=reviewer, json=replacement_body
    ).status_code == 403  # reviewers cannot renew

    renewed = client.post(f"/api/fdrs/{old['id']}/renew", headers=admin, json=replacement_body)
    assert renewed.status_code == 201, renewed.text
    replacement = renewed.json()
    assert replacement["status"] == "pending_approval"
    assert replacement["renewed_from"]["id"] == old["id"]
    assert replacement["institution_id"] == old["institution_id"]

    old_after = client.get(f"/api/fdrs/{old['id']}", headers=admin).json()
    assert old_after["status"] == "renewed"
    assert old_after["renewed_to"]["id"] == replacement["id"]
    history_actions = [row["action"] for row in old_after["history"]]
    assert history_actions[0] == "fdr.renewed"  # newest first
    assert "fdr.renewed" in history_actions

    # a renewal replacement follows the normal machine
    approved = client.post(
        f"/api/fdrs/{replacement['id']}/decision", headers=reviewer, json={"action": "approve"}
    )
    assert approved.status_code == 200
    assert approved.json()["status"] == "approved"


def test_editing_verified_fdr_resets_provenance(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str]
):
    fdr = _create(client, admin)
    client.post(f"/api/fdrs/{fdr['id']}/submit", headers=admin)
    verified = client.post(f"/api/fdrs/{fdr['id']}/verify", headers=reviewer)
    assert verified.json()["verification"] == "officer_verified"

    edited = client.patch(f"/api/fdrs/{fdr['id']}", headers=admin, json={"branch": "Annexe"})
    assert edited.status_code == 200
    assert edited.json()["verification"] == "submitted"
