"""Rules engine: projected value maths, planted findings, health scores."""

from datetime import date
from decimal import Decimal

from fastapi.testclient import TestClient


def test_projected_value_maths():
    from app.rules import projected_value

    principal = Decimal("100000")
    rate = Decimal("7.00")
    issue = date(2026, 1, 1)
    maturity = date(2027, 1, 1)

    value = projected_value(principal, rate, issue, maturity)
    years = (maturity - issue).days / 365.25
    expected = round(100000 * (1 + 7 / 400) ** (4 * years), 2)  # r is percent p.a.
    assert value == expected
    assert 100000 * 1.07 < value < 100000 * 1.072  # quarterly compounding beats 7% simple, ~7.19% effective

    # longer tenure compounds more
    five_years = projected_value(principal, rate, issue, date(2031, 1, 1))
    assert five_years > value


def test_findings_endpoint_sorts_worst_first(client: TestClient, admin: dict[str, str]):
    rows = client.get("/api/findings", headers=admin).json()
    scores = [row["health_score"] for row in rows]
    assert scores == sorted(scores)
    assert all(0 <= score <= 100 for score in scores)
    assert rows, "the seed should produce rows with findings"


def test_health_score_matches_the_rule(client: TestClient, admin: dict[str, str]):
    row = client.get("/api/findings", headers=admin).json()[0]
    detail = client.get(f"/api/fdrs/{row['fdr_id']}", headers=admin).json()
    assert detail["health_score"] == row["health_score"]
    weights = {"critical": 30, "warning": 12, "info": 4}
    penalty = sum(weights[f["severity"]] for f in row["findings"])
    assert row["health_score"] == max(0, 100 - penalty)


def test_planted_findings_exist(client: TestClient, admin: dict[str, str]):
    # the duplicate pair both carry the finding
    dup_one = client.get("/api/fdrs?q=PNB/2026/00431", headers=admin).json()["items"]
    assert len(dup_one) == 2
    for item in dup_one:
        detail = client.get(f"/api/fdrs/{item['id']}", headers=admin).json()
        assert "DUPLICATE_NUMBER" in {f["code"] for f in detail["findings"]}

    all_items = client.get("/api/fdrs?page_size=500", headers=admin).json()["items"]
    flagged = [i for i in all_items if i["findings_count"] > 0]
    assert len(flagged) >= 15, "planted discrepancies should flag many rows"


def test_no_lien_value_mismatch_and_rate_findings(client: TestClient, admin: dict[str, str]):
    items = client.get("/api/fdrs?page_size=500", headers=admin).json()["items"]
    codes_by_id: dict[int, set[str]] = {}
    for item in items:
        detail = client.get(f"/api/fdrs/{item['id']}", headers=admin).json()
        codes_by_id[item["id"]] = {f["code"] for f in detail["findings"]}

    no_lien = [
        item["id"] for item in items
        if item["status"] in ("approved", "pending_approval") and codes_by_id[item["id"]].issuperset({"NO_LIEN"})
    ]
    assert len(no_lien) == 2
    assert sum(1 for codes in codes_by_id.values() if "VALUE_MISMATCH" in codes) == 2
    assert sum(1 for codes in codes_by_id.values() if "RATE_OUT_OF_BAND" in codes) == 1
    assert sum(1 for codes in codes_by_id.values() if "BAD_IFSC" in codes) == 1
    assert sum(1 for codes in codes_by_id.values() if "MATURED_UNRESOLVED" in codes) == 3


def test_closed_fdrs_only_carry_date_and_duplicate_findings(
    client: TestClient, admin: dict[str, str]
):
    items = client.get("/api/fdrs?status=renewed", headers=admin).json()["items"]
    assert items
    for item in items:
        detail = client.get(f"/api/fdrs/{item['id']}", headers=admin).json()
        assert {f["code"] for f in detail["findings"]} <= {"DATE_ORDER", "DUPLICATE_NUMBER"}


def test_not_verified_finding_on_approved_submitted(client: TestClient, admin: dict[str, str]):
    items = client.get(
        "/api/fdrs?status=approved&verification=submitted&page_size=500", headers=admin
    ).json()["items"]
    assert items
    detail = client.get(f"/api/fdrs/{items[0]['id']}", headers=admin).json()
    assert "NOT_VERIFIED" in {f["code"] for f in detail["findings"]}


def test_below_required_only_for_the_short_institution(
    client: TestClient, admin: dict[str, str]
):
    items = client.get("/api/fdrs?page_size=500", headers=admin).json()["items"]
    below = []
    for item in items:
        detail = client.get(f"/api/fdrs/{item['id']}", headers=admin).json()
        if "BELOW_REQUIRED" in {f["code"] for f in detail["findings"]}:
            below.append(item["institution_name"])
    assert below and set(below) == {"Bundelkhand Skills Polytechnic"}


def test_maturity_states_on_detail(client: TestClient, admin: dict[str, str]):
    overdue = client.get("/api/fdrs?window=matured", headers=admin).json()["items"]
    assert overdue and all(i["maturity_state"] == "matured" and i["days_to_maturity"] < 0 for i in overdue)
    closed = client.get("/api/fdrs?status=released", headers=admin).json()["items"]
    assert closed and all(i["maturity_state"] == "closed" for i in closed)


def test_date_order_finding_from_data(client: TestClient, admin: dict[str, str]):
    """The API blocks maturity <= issue at input, so plant one directly in the
    database the way an import would, and confirm the rule still catches it."""
    from app.db import SessionLocal
    from app.models import Fdr, FdrStatus, Institution, Purpose, Verification

    db = SessionLocal()
    institution = db.query(Institution).first()
    fdr = Fdr(
        fdr_number="TEST/DATE/0001", institution_id=institution.id, bank_name="Canara Bank",
        amount=Decimal("100000"), issue_date=date(2031, 5, 1), maturity_date=date(2031, 4, 1),
        interest_rate=Decimal("6.50"), purpose=Purpose.security_deposit,
        lien_to_aicte=True, status=FdrStatus.draft, verification=Verification.submitted,
    )
    db.add(fdr)
    db.commit()
    fdr_id = fdr.id
    db.close()

    detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
    finding = next(f for f in detail["findings"] if f["code"] == "DATE_ORDER")
    assert finding["severity"] == "critical"
    weights = {"critical": 30, "warning": 12, "info": 4}
    penalty = sum(weights[f["severity"]] for f in detail["findings"])
    assert detail["health_score"] == max(0, 100 - penalty) <= 70
