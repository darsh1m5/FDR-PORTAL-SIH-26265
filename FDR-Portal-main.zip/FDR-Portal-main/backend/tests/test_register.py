"""Register list: filters, search, sort, pagination and the CSV export."""

import csv
import io

from fastapi.testclient import TestClient


def test_sorting_by_amount(client: TestClient, admin: dict[str, str]):
    desc = client.get("/api/fdrs?sort=amount&order=desc&page_size=50", headers=admin).json()["items"]
    amounts = [item["amount"] for item in desc]
    assert amounts == sorted(amounts, reverse=True)
    asc = client.get("/api/fdrs?sort=amount&order=asc&page_size=50", headers=admin).json()["items"]
    assert [item["amount"] for item in asc] == sorted(amounts)


def test_csv_dates_use_indian_format(client: TestClient, admin: dict[str, str]):
    response = client.get("/api/fdrs/export.csv?status=draft", headers=admin)
    rows = list(csv.reader(io.StringIO(response.content.decode("utf-8-sig"))))
    header = rows[0]
    issue_index = header.index("Issue date")
    sample = rows[1][issue_index]
    assert len(sample) == 11 and sample[2] == " " and sample[-5] == " "
    day, month, year = sample.split(" ")
    assert len(day) == 2 and len(year) == 4 and month.isalpha()


def test_institution_create_and_detail(client: TestClient, admin: dict[str, str]):
    created = client.post(
        "/api/institutions",
        headers=admin,
        json={
            "name": "Test Valley Institute of Technology",
            "aicte_id": "1-9999999999",
            "city": "Dehradun",
            "state": "Uttarakhand",
            "type": "Engineering",
            "required_deposit": 2_500_000,
        },
    )
    assert created.status_code in (200, 201)
    detail = client.get(f"/api/institutions/{created.json()['id']}", headers=admin)
    assert detail.status_code == 200
    assert detail.json()["fdr_count"] == 0
    assert detail.json()["health_score"] is None

    duplicate = client.post(
        "/api/institutions",
        headers=admin,
        json={
            "name": "Another Test Institute",
            "aicte_id": "1-9999999999",
            "city": "Dehradun",
            "state": "Uttarakhand",
            "type": "Engineering",
            "required_deposit": 1,
        },
    )
    assert duplicate.status_code in (400, 409)
