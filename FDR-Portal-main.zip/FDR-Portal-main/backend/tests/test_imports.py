"""Tests for §9.1 Bulk import from spreadsheet."""

import io
from pathlib import Path

from fastapi.testclient import TestClient
from sqlalchemy import delete, select, update

from app.db import SessionLocal
from app.models import Alert, AuditLog, Document, Fdr, Notice

FIXTURE_PATH = Path(__file__).parent / "fixtures" / "sample_import.csv"


def _cleanup_imported_fdrs() -> None:
    with SessionLocal() as db:
        fdr_ids = db.scalars(
            select(Fdr.id).where(
                (Fdr.fdr_number.startswith("FDR-IMP-")) | (Fdr.fdr_number.startswith("MIX-"))
            )
        ).all()
        if not fdr_ids:
            return
        db.execute(update(Fdr).where(Fdr.id.in_(fdr_ids)).values(renewed_from_id=None))
        db.execute(delete(Alert).where(Alert.fdr_id.in_(fdr_ids)))
        db.execute(delete(Notice).where(Notice.fdr_id.in_(fdr_ids)))
        db.execute(delete(Document).where(Document.fdr_id.in_(fdr_ids)))
        db.execute(delete(AuditLog).where(AuditLog.fdr_id.in_(fdr_ids)))
        db.execute(delete(Fdr).where(Fdr.id.in_(fdr_ids)))
        db.commit()


def test_template_download(client: TestClient, admin: dict[str, str], reviewer: dict[str, str]):
    # Reviewer forbidden
    rev_res = client.get("/api/imports/template.csv", headers=reviewer)
    assert rev_res.status_code == 403

    # Admin allowed
    res = client.get("/api/imports/template.csv", headers=admin)
    assert res.status_code == 200
    assert "text/csv" in res.headers["content-type"]
    text = res.content.decode("utf-8-sig")
    header = text.strip().split(",")
    assert header[0] == "FDR number"
    assert "AICTE ID" in header
    assert "Bank" in header
    assert "Amount (INR)" in header
    assert "Issue date" in header
    assert "Maturity date" in header


def test_preview_sample_fixture(client: TestClient, admin: dict[str, str]):
    assert FIXTURE_PATH.is_file(), f"Fixture missing at {FIXTURE_PATH}"
    content = FIXTURE_PATH.read_bytes()
    files = {"file": ("sample.csv", io.BytesIO(content), "text/csv")}
    res = client.post("/api/imports/preview", files=files, headers=admin)
    assert res.status_code == 200, res.text
    data = res.json()
    assert len(data["rows"]) == 10
    assert data["error_count"] == 0
    assert data["valid_count"] + data["warning_count"] == 10
    first = data["rows"][0]
    assert first["status"] in ("valid", "warning")
    assert first["data"]["bank_name"] == "State Bank of India"
    assert float(first["data"]["amount"]) == 1000000.0


def test_preview_mixed_file_counts(client: TestClient, admin: dict[str, str]):
    # Row 1: valid
    # Row 2: warning (no lien)
    # Row 3: error (unknown AICTE ID)
    # Row 4: error (bad dates maturity <= issue)
    csv_text = (
        "FDR number,AICTE ID,Bank,Branch,IFSC,Amount (INR),Issue date,Maturity date,Interest rate (% p.a.),Printed maturity amount (INR),Purpose,Lien to AICTE,Remarks\n"
        "MIX-001,1-4413298712,SBI,Shivajinagar,SBIN0001234,500000,2026-01-01,2027-01-01,7.00,,Security deposit,Yes,Clean valid row\n"
        "MIX-002,1-4413298712,SBI,Shivajinagar,SBIN0001234,500000,2026-01-01,2027-01-01,7.00,,Security deposit,No,Warning row with no lien\n"
        "MIX-003,1-9999999999,SBI,Shivajinagar,SBIN0001234,500000,2026-01-01,2027-01-01,7.00,,Security deposit,Yes,Unknown institution\n"
        "MIX-004,1-4413298712,SBI,Shivajinagar,SBIN0001234,500000,2027-01-01,2026-01-01,7.00,,Security deposit,Yes,Bad date order\n"
    )
    files = {"file": ("mixed.csv", io.BytesIO(csv_text.encode("utf-8")), "text/csv")}
    res = client.post("/api/imports/preview", files=files, headers=admin)
    assert res.status_code == 200, res.text
    data = res.json()
    assert len(data["rows"]) == 4
    assert data["valid_count"] == 1
    assert data["warning_count"] == 1
    assert data["error_count"] == 2
    assert data["rows"][0]["status"] == "valid"
    assert data["rows"][1]["status"] == "warning"
    assert any(f["code"] == "NO_LIEN" for f in data["rows"][1]["findings"])
    assert data["rows"][2]["status"] == "error"
    assert any("Unknown AICTE ID" in e for e in data["rows"][2]["errors"])
    assert data["rows"][3]["status"] == "error"
    assert any("Maturity date must be after issue date" in e for e in data["rows"][3]["errors"])


def test_preview_rejects_empty_and_oversized_file(client: TestClient, admin: dict[str, str]):
    # Empty file -> 422
    files = {"file": ("empty.csv", io.BytesIO(b""), "text/csv")}
    res = client.post("/api/imports/preview", files=files, headers=admin)
    assert res.status_code == 422

    # Oversized file > 2 MB -> 413
    big = b"a" * (2 * 1024 * 1024 + 10)
    files_big = {"file": ("big.csv", io.BytesIO(big), "text/csv")}
    res_big = client.post("/api/imports/preview", files=files_big, headers=admin)
    assert res_big.status_code == 413


def test_commit_validates_and_creates_drafts(client: TestClient, admin: dict[str, str]):
    inst = client.get("/api/institutions", headers=admin).json()[0]
    valid_rows = [
        {
            "fdr_number": "FDR-IMP-TEST-001",
            "institution_id": inst["id"],
            "bank_name": "State Bank of India",
            "branch": "Main Branch",
            "ifsc": "SBIN0001234",
            "amount": 750000,
            "issue_date": "2026-02-01",
            "maturity_date": "2027-02-01",
            "interest_rate": 7.1,
            "purpose": "security_deposit",
            "lien_to_aicte": True,
            "remarks": "Imported draft 1",
        },
        {
            "fdr_number": "FDR-IMP-TEST-002",
            "institution_id": inst["id"],
            "bank_name": "State Bank of India",
            "branch": "Main Branch",
            "ifsc": "SBIN0001234",
            "amount": 850000,
            "issue_date": "2026-03-01",
            "maturity_date": "2028-03-01",
            "interest_rate": 7.25,
            "purpose": "security_deposit",
            "lien_to_aicte": True,
            "remarks": "Imported draft 2",
        },
    ]

    try:
        # Invalid commit: invalid row (amount <= 0)
        invalid_body = {
            "source_name": "invalid_test.csv",
            "rows": valid_rows + [{**valid_rows[0], "amount": -100}],
        }
        bad_res = client.post("/api/imports/commit", json=invalid_body, headers=admin)
        assert bad_res.status_code == 422
        # Nothing created
        check = client.get("/api/fdrs?q=FDR-IMP-TEST-", headers=admin).json()
        assert check["total"] == 0

        # Valid commit
        commit_body = {"source_name": "valid_test.csv", "rows": valid_rows}
        res = client.post("/api/imports/commit", json=commit_body, headers=admin)
        assert res.status_code == 200, res.text
        data = res.json()
        assert data["created"] == 2
        assert len(data["ids"]) == 2
        assert data["batch"].startswith("IMP-")

        # Verify created as drafts
        for fid in data["ids"]:
            detail = client.get(f"/api/fdrs/{fid}", headers=admin).json()
            assert detail["status"] == "draft"

        # Verify audit logs
        audit_res = client.get(f"/api/audit?fdr_id={data['ids'][0]}", headers=admin).json()
        fdr_audits = [item for item in audit_res["items"] if item["action"] == "fdr.created"]
        assert fdr_audits
        assert fdr_audits[0]["detail"].get("imported") is True
        assert fdr_audits[0]["detail"].get("batch") == data["batch"]

        # Verify import.committed audit
        all_audits = client.get("/api/audit?action=import.committed", headers=admin).json()
        imp_audits = [a for a in all_audits["items"] if a["detail"].get("batch") == data["batch"]]
        assert imp_audits
        assert imp_audits[0]["action_label"] == "Spreadsheet imported"

    finally:
        _cleanup_imported_fdrs()


def _preview(client: TestClient, admin: dict[str, str], text: str) -> dict:
    files = {"file": ("check.csv", io.BytesIO(text.encode("utf-8")), "text/csv")}
    res = client.post("/api/imports/preview", files=files, headers=admin)
    assert res.status_code == 200, res.text
    return res.json()


def test_out_of_range_cells_become_error_rows_not_a_crash(client: TestClient, admin: dict[str, str]):
    header = FIXTURE_PATH.read_text(encoding="utf-8").splitlines()[0]
    good = FIXTURE_PATH.read_text(encoding="utf-8").splitlines()[1].split(",")
    rate_too_high = good.copy()
    rate_too_high[8] = "25"
    long_number = good.copy()
    long_number[0] = "X" * 45
    three_decimals = good.copy()
    three_decimals[5] = "100000.555"
    body = "\n".join([header, ",".join(rate_too_high), ",".join(long_number), ",".join(three_decimals)])
    preview = _preview(client, admin, body)
    assert preview["error_count"] == 3
    assert all(row["status"] == "error" and row["errors"] for row in preview["rows"])


def test_columns_are_matched_by_exact_header_in_any_order(client: TestClient, admin: dict[str, str]):
    lines = FIXTURE_PATH.read_text(encoding="utf-8").splitlines()
    header = lines[0].split(",")
    first = lines[1].split(",")
    # Put "Lien to AICTE" before "AICTE ID" and the printed amount before "Amount (INR)".
    order = [11, 9, 0, 1, 2, 3, 4, 5, 6, 7, 8, 10, 12]
    body = "\n".join([",".join(header[i] for i in order), ",".join(first[i] for i in order)])
    preview = _preview(client, admin, body)
    assert preview["error_count"] == 0, preview["rows"][0]["errors"]
    assert preview["rows"][0]["data"]["fdr_number"] == first[0]
