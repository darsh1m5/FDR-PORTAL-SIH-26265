"""Tests for bank confirmation by letter (§10.4)."""

from io import BytesIO
from fastapi.testclient import TestClient

from app.db import SessionLocal
from app.models import Fdr, FdrStatus


def test_bank_confirmation_workflow(
    client: TestClient,
    admin: dict[str, str],
    reviewer: dict[str, str],
    auditor: dict[str, str],
    institution_deccan: dict[str, str],
):
    with SessionLocal() as db:
        fdr = db.query(Fdr).filter(Fdr.status == FdrStatus.approved).first()
        assert fdr is not None
        fdr_id = fdr.id

    # 1. Non-reviewer gets 403
    assert client.post(f"/api/fdrs/{fdr_id}/bank-confirm", headers=admin).status_code == 403
    assert client.post(f"/api/fdrs/{fdr_id}/bank-confirm", headers=auditor).status_code == 403
    assert client.post(f"/api/fdrs/{fdr_id}/bank-confirm", headers=institution_deccan).status_code == 403

    # 2. Reviewer cannot confirm without bank_confirmation document (409)
    # Ensure no bank_confirmation doc exists initially
    res_no_doc = client.post(f"/api/fdrs/{fdr_id}/bank-confirm", headers=reviewer)
    assert res_no_doc.status_code == 409
    assert "bank confirmation letter attached by the bureau is required" in res_no_doc.json()["detail"].lower()

    # 3. Upload a bank_confirmation letter
    pdf_content = b"%PDF-1.4 sample bank confirmation letter content"
    files = {"file": ("confirmation_letter.pdf", BytesIO(pdf_content), "application/pdf")}
    upload_res = client.post(
        f"/api/fdrs/{fdr_id}/documents",
        data={"doc_type": "bank_confirmation"},
        files=files,
        headers=admin,
    )
    assert upload_res.status_code == 201
    assert upload_res.json()["doc_type"] == "bank_confirmation"

    # 4. Reviewer confirms successfully
    confirm_res = client.post(
        f"/api/fdrs/{fdr_id}/bank-confirm",
        json={"remark": "Branch confirmation received via letter dated 2026-10-25."},
        headers=reviewer,
    )
    assert confirm_res.status_code == 200
    data = confirm_res.json()
    assert data["verification"] == "bank_confirmed"

    # Health findings do NOT flag NOT_VERIFIED
    findings = [f["code"] for f in data["findings"]]
    assert "NOT_VERIFIED" not in findings

    # 5. Editing an editable FDR resets verification to submitted
    with SessionLocal() as db:
        f = db.get(Fdr, fdr_id)
        f.status = FdrStatus.pending_approval
        db.commit()

    patch_res = client.patch(
        f"/api/fdrs/{fdr_id}",
        json={"branch": "Updated Branch Office"},
        headers=admin,
    )
    assert patch_res.status_code == 200
    assert patch_res.json()["verification"] == "submitted"


def test_closed_fdr_cannot_be_bank_confirmed(client: TestClient, reviewer: dict[str, str]):
    with SessionLocal() as db:
        fdr = db.query(Fdr).filter(Fdr.status == FdrStatus.released).first()
        if not fdr:
            fdr = db.query(Fdr).filter(Fdr.status == FdrStatus.renewed).first()
        assert fdr is not None
        fdr_id = fdr.id

    res = client.post(f"/api/fdrs/{fdr_id}/bank-confirm", headers=reviewer)
    assert res.status_code == 409
