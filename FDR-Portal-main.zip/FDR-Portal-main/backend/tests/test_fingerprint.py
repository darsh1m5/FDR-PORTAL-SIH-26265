"""Tests for document fingerprinting (sha256, X-Integrity header, DOCUMENT_REUSED finding)."""

import hashlib
from io import BytesIO
from fastapi.testclient import TestClient

from app.db import SessionLocal
from app.models import Fdr, FdrStatus


def test_fingerprint_sha256_and_integrity_header(
    client: TestClient, admin: dict[str, str]
):
    with SessionLocal() as db:
        fdr = db.query(Fdr).filter(Fdr.status == FdrStatus.draft).first()
        if not fdr:
            fdr = db.query(Fdr).filter(Fdr.status == FdrStatus.approved).first()
        assert fdr is not None
        fdr_id = fdr.id

    content = b"%PDF-1.4 unique test receipt for fingerprint check 12345"
    expected_sha = hashlib.sha256(content).hexdigest()

    # 1. Upload document -> sha256 in response
    files = {"file": ("receipt.pdf", BytesIO(content), "application/pdf")}
    res = client.post(
        f"/api/fdrs/{fdr_id}/documents",
        data={"doc_type": "fdr_receipt"},
        files=files,
        headers=admin,
    )
    assert res.status_code == 201
    doc = res.json()
    assert doc["sha256"] == expected_sha

    # 2. Download document -> X-Integrity header
    dl_res = client.get(f"/api/documents/{doc['id']}/download", headers=admin)
    assert dl_res.status_code == 200
    assert dl_res.headers.get("x-integrity") == "verified"


def test_document_reused_finding(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str]
):
    with SessionLocal() as db:
        fdrs = db.query(Fdr).filter(Fdr.status.in_([FdrStatus.draft, FdrStatus.pending_approval, FdrStatus.approved])).limit(2).all()
        assert len(fdrs) >= 2
        fdr1_id, fdr1_number = fdrs[0].id, fdrs[0].fdr_number
        fdr2_id = fdrs[1].id

    shared_content = b"%PDF-1.4 duplicate certificate attached to multiple deposits"

    # Upload to FDR 1
    upload1 = client.post(
        f"/api/fdrs/{fdr1_id}/documents",
        data={"doc_type": "fdr_receipt"},
        files={"file": ("cert.pdf", BytesIO(shared_content), "application/pdf")},
        headers=admin,
    )
    assert upload1.status_code == 201

    # Upload same content to FDR 2
    upload2 = client.post(
        f"/api/fdrs/{fdr2_id}/documents",
        data={"doc_type": "fdr_receipt"},
        files={"file": ("cert.pdf", BytesIO(shared_content), "application/pdf")},
        headers=admin,
    )
    assert upload2.status_code == 201
    doc2_id = upload2.json()["id"]

    # Check detail of FDR 2 -> DOCUMENT_REUSED finding
    detail2 = client.get(f"/api/fdrs/{fdr2_id}", headers=reviewer).json()
    reused2 = [f for f in detail2["findings"] if f["code"] == "DOCUMENT_REUSED"]
    assert len(reused2) == 1
    assert fdr1_number not in reused2[0]["message"]  # never name another deposit
    assert reused2[0]["severity"] == "critical"

    # Delete duplicate document from FDR 2 -> finding clears
    del_res = client.delete(f"/api/documents/{doc2_id}", headers=admin)
    assert del_res.status_code in (200, 204)

    cleared = client.get(f"/api/fdrs/{fdr2_id}", headers=reviewer).json()
    assert not any(f["code"] == "DOCUMENT_REUSED" for f in cleared["findings"])
