"""Tests for public QR notice verification endpoint (§10.6)."""

from fastapi.testclient import TestClient

from app.db import SessionLocal
from app.models import Fdr, FdrStatus


def test_public_notice_verification(client: TestClient, admin: dict[str, str]):
    with SessionLocal() as db:
        fdr = db.query(Fdr).filter(Fdr.status == FdrStatus.approved).first()
        assert fdr is not None
        fdr_id = fdr.id

    # 1. Issue a notice as admin
    create_res = client.post(
        "/api/notices",
        json={"kind": "maturity_reminder", "fdr_id": fdr_id},
        headers=admin,
    )
    assert create_res.status_code == 201
    notice = create_res.json()
    ref_no = notice["reference_no"]
    code = notice.get("verify_code")
    assert code is not None
    assert len(code) == 16

    # 2. Public verification without auth headers succeeds
    res_valid = client.get(f"/api/public/verify-notice?ref={ref_no}&code={code}")
    assert res_valid.status_code == 200
    data = res_valid.json()
    assert data["valid"] is True
    assert data["reference_no"] == ref_no
    assert data["kind_label"] is not None
    assert data["institution_name"] is not None
    assert data["fdr_number"] is not None
    assert data["issued_at"] is not None

    # 3. Wrong code returns valid=False
    res_bad_code = client.get(f"/api/public/verify-notice?ref={ref_no}&code=0123456789abcdef")
    assert res_bad_code.status_code == 200
    assert res_bad_code.json()["valid"] is False
    assert res_bad_code.json()["reference_no"] is None

    # 4. Unknown ref returns valid=False
    res_bad_ref = client.get(f"/api/public/verify-notice?ref=AICTE/FDR/UNKNOWN&code={code}")
    assert res_bad_ref.status_code == 200
    assert res_bad_ref.json()["valid"] is False

    # 5. Empty ref or code returns valid=False
    res_empty = client.get("/api/public/verify-notice?ref=&code=")
    assert res_empty.status_code == 200
    assert res_empty.json()["valid"] is False
