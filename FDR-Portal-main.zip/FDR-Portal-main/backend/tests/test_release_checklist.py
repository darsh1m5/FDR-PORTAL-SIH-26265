"""Tests for release readiness checklist: complete, incomplete (409), legacy requests, and approvals queue."""

from datetime import date, timedelta
from decimal import Decimal

from fastapi.testclient import TestClient
from sqlalchemy.orm import Session

from app.db import SessionLocal
from app.models import Fdr, FdrStatus, Institution, Purpose, Role, User


def _create_approved_fdr(db: Session, number: str) -> int:
    inst = db.query(Institution).first()
    assert inst is not None
    fdr = Fdr(
        institution_id=inst.id,
        fdr_number=number,
        bank_name="State Bank of India",
        branch="Main Branch",
        ifsc="SBIN0001234",
        amount=Decimal("1000000.00"),
        issue_date=date.today() - timedelta(days=400),
        maturity_date=date.today() + timedelta(days=100),
        interest_rate=Decimal("7.00"),
        maturity_amount=None,
        purpose=Purpose.security_deposit,
        lien_to_aicte=True,
        status=FdrStatus.approved,
    )
    db.add(fdr)
    db.commit()
    db.refresh(fdr)
    return fdr.id


def test_complete_checklist_and_approval(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str], approver: dict[str, str]
) -> None:
    with SessionLocal() as db:
        fdr_id = _create_approved_fdr(db, "FDR-REL-COMPLETE-01")

    # 1. Request release with complete checklist
    complete_checklist = {
        "affidavit_received": True,
        "no_pending_complaints": True,
        "institution_closure_certificate": None,  # Not applicable
        "matured_or_lock_in_complete": True,
        "bank_discharge_noted": True,
    }
    resp = client.post(
        f"/api/fdrs/{fdr_id}/request-release",
        json={"reason": "Completion of statutory tenure", "checklist": complete_checklist},
        headers=admin,
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "release_requested"
    assert data["release_ready"] is True
    assert data["release_checklist"] == complete_checklist

    # 2. Check approvals queue exposes release_checklist and release_ready
    resp_appr = client.get("/api/approvals", headers=approver)
    assert resp_appr.status_code == 200
    appr_items = resp_appr.json()["items"]
    target = next((item for item in appr_items if item["fdr"]["id"] == fdr_id), None)
    assert target is not None
    assert target["kind"] == "release"
    assert target["release_ready"] is True
    assert target["release_checklist"] == complete_checklist

    # 3. Reviewer is refused (403)
    resp_rev = client.post(
        f"/api/fdrs/{fdr_id}/decision",
        json={"action": "approve", "remark": "Sanction conveyed"},
        headers=reviewer,
    )
    assert resp_rev.status_code == 403

    # 4. Approver approves release successfully
    resp_dec = client.post(
        f"/api/fdrs/{fdr_id}/decision",
        json={"action": "approve", "remark": "Sanction conveyed"},
        headers=approver,
    )
    assert resp_dec.status_code == 200
    assert resp_dec.json()["status"] == "released"


def test_incomplete_checklist_returns_409(
    client: TestClient, admin: dict[str, str], approver: dict[str, str]
) -> None:
    with SessionLocal() as db:
        fdr_id = _create_approved_fdr(db, "FDR-REL-INCOMPLETE-01")

    # 1. Request release with incomplete checklist (affidavit missing, closure cert missing)
    incomplete_checklist = {
        "affidavit_received": False,
        "no_pending_complaints": True,
        "institution_closure_certificate": False,
        "matured_or_lock_in_complete": True,
        "bank_discharge_noted": False,
    }
    resp = client.post(
        f"/api/fdrs/{fdr_id}/request-release",
        json={"reason": "Premature closure request", "checklist": incomplete_checklist},
        headers=admin,
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "release_requested"
    assert data["release_ready"] is False
    assert data["release_checklist"] == incomplete_checklist

    # 2. Approver approve must return 409 Conflict
    resp_dec = client.post(
        f"/api/fdrs/{fdr_id}/decision",
        json={"action": "approve", "remark": "Attempting approval"},
        headers=approver,
    )
    assert resp_dec.status_code == 409
    detail = resp_dec.json()["detail"]
    assert "Release checklist incomplete:" in detail
    assert "affidavit received" in detail
    assert "institution closure certificate" in detail
    assert "bank discharge noted" in detail

    # Deposit remains release_requested
    with SessionLocal() as db:
        fdr = db.get(Fdr, fdr_id)
        assert fdr.status == FdrStatus.release_requested


def test_legacy_request_without_checklist(
    client: TestClient, admin: dict[str, str], approver: dict[str, str]
) -> None:
    with SessionLocal() as db:
        fdr_id = _create_approved_fdr(db, "FDR-REL-LEGACY-01")

    # 1. Request release with only reason (no checklist field)
    resp = client.post(
        f"/api/fdrs/{fdr_id}/request-release",
        json={"reason": "Legacy release request without pre-recorded checklist"},
        headers=admin,
    )
    assert resp.status_code == 200
    data = resp.json()
    assert data["status"] == "release_requested"
    assert data["release_checklist"] is None
    assert data["release_ready"] is None

    # 2. Approvals queue shows null release_checklist
    resp_appr = client.get("/api/approvals", headers=approver)
    assert resp_appr.status_code == 200
    appr_items = resp_appr.json()["items"]
    target = next((item for item in appr_items if item["fdr"]["id"] == fdr_id), None)
    assert target is not None
    assert target["kind"] == "release"
    assert target["release_checklist"] is None
    assert target["release_ready"] is None

    # 3. Approver approve succeeds for legacy request
    resp_dec = client.post(
        f"/api/fdrs/{fdr_id}/decision",
        json={"action": "approve", "remark": "Approved under legacy procedure"},
        headers=approver,
    )
    assert resp_dec.status_code == 200
    assert resp_dec.json()["status"] == "released"


def test_maker_checker_requester_cannot_sanction(
    client: TestClient, approver: dict[str, str]
) -> None:
    with SessionLocal() as db:
        fdr_id = _create_approved_fdr(db, "FDR-REL-MC-01")
        fdr = db.get(Fdr, fdr_id)
        fdr.status = FdrStatus.release_requested
        approver_user = db.query(User).filter(User.role == Role.approver).first()
        from app.audit import write_audit
        from app.models import AuditEntity
        write_audit(
            db,
            actor=approver_user,
            action="fdr.release_requested",
            entity=AuditEntity.fdr,
            entity_id=fdr.id,
            fdr_id=fdr.id,
        )
        db.commit()

    # The same officer cannot sanction it (409)
    resp_dec = client.post(
        f"/api/fdrs/{fdr_id}/decision",
        json={"action": "approve", "remark": "Sanctioning own request"},
        headers=approver,
    )
    assert resp_dec.status_code == 409
    assert resp_dec.json()["detail"] == "The officer who requested the release cannot sanction it"
