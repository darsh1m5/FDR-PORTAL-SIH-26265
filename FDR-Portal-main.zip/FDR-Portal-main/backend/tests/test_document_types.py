"""Tests for §9.3 Document types: metadata, upload with doc_type, findings."""

import io
from fastapi.testclient import TestClient
from sqlalchemy import delete

from app.db import SessionLocal
from app.models import Alert, AuditLog, Document, Fdr, Notice

MINIMAL_PDF = (
    b"%PDF-1.4\n"
    b"1 0 obj << /Type /Catalog /Pages 2 0 R >> endobj\n"
    b"2 0 obj << /Type /Pages /Kids [3 0 R] /Count 1 >> endobj\n"
    b"trailer << /Size 3 /Root 1 0 R >>\n%%EOF\n"
)


def _cleanup_fdr(fdr_id: int) -> None:
    with SessionLocal() as db:
        db.execute(delete(Alert).where(Alert.fdr_id == fdr_id))
        db.execute(delete(Notice).where(Notice.fdr_id == fdr_id))
        db.execute(delete(Document).where(Document.fdr_id == fdr_id))
        db.execute(delete(AuditLog).where(AuditLog.fdr_id == fdr_id))
        db.execute(delete(Fdr).where(Fdr.id == fdr_id))
        db.commit()


def test_meta_includes_document_types(client: TestClient, admin: dict[str, str]):
    meta = client.get("/api/meta", headers=admin).json()
    assert "document_types" in meta
    types = {item["value"]: item["label"] for item in meta["document_types"]}
    assert "fdr_receipt" in types
    assert "lien_letter" in types
    assert "closure_certificate" in types
    assert "affidavit" in types
    assert "renewal_letter" in types
    assert "other" in types


def test_upload_default_doc_type_is_fdr_receipt(client: TestClient, admin: dict[str, str]):
    inst = client.get("/api/institutions", headers=admin).json()[0]
    fdr_data = {
        "fdr_number": "DOC/TEST/001",
        "institution_id": inst["id"],
        "bank_name": "State Bank of India",
        "amount": 500000,
        "issue_date": "2026-01-01",
        "maturity_date": "2027-01-01",
        "interest_rate": 7.0,
        "purpose": "security_deposit",
        "lien_to_aicte": False,
    }
    fdr = client.post("/api/fdrs", json=fdr_data, headers=admin).json()
    fdr_id = fdr["id"]
    try:
        files = {"file": ("receipt.pdf", io.BytesIO(MINIMAL_PDF), "application/pdf")}
        res = client.post(f"/api/fdrs/{fdr_id}/documents", files=files, headers=admin)
        assert res.status_code == 201, res.text
        doc = res.json()
        assert doc["doc_type"] == "fdr_receipt"
        assert doc["doc_type_label"] == "FDR receipt"

        detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
        assert len(detail["documents"]) == 1
        assert detail["documents"][0]["doc_type"] == "fdr_receipt"
        assert detail["documents"][0]["doc_type_label"] == "FDR receipt"
    finally:
        _cleanup_fdr(fdr_id)


def test_upload_with_explicit_doc_type(client: TestClient, admin: dict[str, str]):
    inst = client.get("/api/institutions", headers=admin).json()[0]
    fdr_data = {
        "fdr_number": "DOC/TEST/002",
        "institution_id": inst["id"],
        "bank_name": "State Bank of India",
        "amount": 500000,
        "issue_date": "2026-01-01",
        "maturity_date": "2027-01-01",
        "interest_rate": 7.0,
        "purpose": "security_deposit",
        "lien_to_aicte": True,
    }
    fdr = client.post("/api/fdrs", json=fdr_data, headers=admin).json()
    fdr_id = fdr["id"]
    try:
        files = {"file": ("lien.pdf", io.BytesIO(MINIMAL_PDF), "application/pdf")}
        data = {"doc_type": "lien_letter"}
        res = client.post(f"/api/fdrs/{fdr_id}/documents", files=files, data=data, headers=admin)
        assert res.status_code == 201, res.text
        doc = res.json()
        assert doc["doc_type"] == "lien_letter"
        assert doc["doc_type_label"] == "Lien letter"
    finally:
        _cleanup_fdr(fdr_id)


def test_no_document_rule_requires_fdr_receipt(client: TestClient, admin: dict[str, str]):
    inst = client.get("/api/institutions", headers=admin).json()[0]
    fdr_data = {
        "fdr_number": "DOC/TEST/003",
        "institution_id": inst["id"],
        "bank_name": "State Bank of India",
        "amount": 500000,
        "issue_date": "2026-01-01",
        "maturity_date": "2027-01-01",
        "interest_rate": 7.0,
        "purpose": "security_deposit",
        "lien_to_aicte": False,
    }
    fdr = client.post("/api/fdrs", json=fdr_data, headers=admin).json()
    fdr_id = fdr["id"]
    try:
        detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
        findings = {f["code"] for f in detail["findings"]}
        assert "NO_DOCUMENT" in findings

        # Uploading non-receipt document (other) leaves NO_DOCUMENT present
        files = {"file": ("notes.pdf", io.BytesIO(MINIMAL_PDF), "application/pdf")}
        res1 = client.post(f"/api/fdrs/{fdr_id}/documents", files=files, data={"doc_type": "other"}, headers=admin)
        assert res1.status_code == 201
        detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
        findings = {f["code"] for f in detail["findings"]}
        assert "NO_DOCUMENT" in findings

        # Uploading fdr_receipt clears NO_DOCUMENT
        files = {"file": ("fdr.pdf", io.BytesIO(MINIMAL_PDF), "application/pdf")}
        res2 = client.post(f"/api/fdrs/{fdr_id}/documents", files=files, data={"doc_type": "fdr_receipt"}, headers=admin)
        assert res2.status_code == 201
        detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
        findings = {f["code"] for f in detail["findings"]}
        assert "NO_DOCUMENT" not in findings
    finally:
        _cleanup_fdr(fdr_id)


def test_no_lien_letter_finding_appears_and_clears(client: TestClient, admin: dict[str, str]):
    inst = client.get("/api/institutions", headers=admin).json()[0]
    fdr_data = {
        "fdr_number": "DOC/TEST/004",
        "institution_id": inst["id"],
        "bank_name": "State Bank of India",
        "amount": 500000,
        "issue_date": "2026-01-01",
        "maturity_date": "2027-01-01",
        "interest_rate": 7.0,
        "purpose": "security_deposit",
        "lien_to_aicte": True,
    }
    fdr = client.post("/api/fdrs", json=fdr_data, headers=admin).json()
    fdr_id = fdr["id"]
    try:
        detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
        findings = {f["code"] for f in detail["findings"]}
        assert "NO_LIEN_LETTER" not in findings

        # Submit FDR -> pending_approval
        sub = client.post(f"/api/fdrs/{fdr_id}/submit", headers=admin)
        assert sub.status_code == 200

        detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
        findings = {f["code"] for f in detail["findings"]}
        assert "NO_LIEN_LETTER" in findings

        # Upload lien_letter -> clears NO_LIEN_LETTER
        files = {"file": ("lien_confirm.pdf", io.BytesIO(MINIMAL_PDF), "application/pdf")}
        res = client.post(f"/api/fdrs/{fdr_id}/documents", files=files, data={"doc_type": "lien_letter"}, headers=admin)
        assert res.status_code == 201

        detail = client.get(f"/api/fdrs/{fdr_id}", headers=admin).json()
        findings = {f["code"] for f in detail["findings"]}
        assert "NO_LIEN_LETTER" not in findings
    finally:
        _cleanup_fdr(fdr_id)
