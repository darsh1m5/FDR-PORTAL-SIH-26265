"""Alert centre: seeded alerts, acknowledge, and the engine following the rules."""

from fastapi.testclient import TestClient

DEFAULT_SETTINGS = {
    "reminder_days": [90, 60, 30, 7],
    "overdue_grace_days": 0,
    "pending_sla_days": 7,
    "interest_min": 3.0,
    "interest_max": 9.5,
}


def _open(client: TestClient, headers: dict[str, str], query: str = "") -> list[dict]:
    return client.get(f"/api/alerts{query}", headers=headers).json()


def test_seed_produces_open_alerts(client: TestClient, reviewer: dict[str, str]):
    alerts = _open(client, reviewer)
    assert alerts
    overdue_ids = {a["fdr_id"] for a in alerts if a["type"] == "matured_overdue"}
    duplicate = [a for a in alerts if a["type"] == "discrepancy" and a["fdr_id"] in overdue_ids]
    assert not duplicate, "a matured FDR is reported once, as overdue"
    assert {a["type"] for a in alerts} <= {
        "maturity_upcoming", "matured_overdue", "pending_too_long", "discrepancy",
    }
    assert all(a["acknowledged_at"] is None for a in alerts)
    assert all(a["fdr_number"] and a["message"] for a in alerts)


def test_open_alerts_are_sorted_critical_first(client: TestClient, reviewer: dict[str, str]):
    alerts = _open(client, reviewer)
    order = {"critical": 0, "warning": 1, "info": 2}
    severities = [order[a["severity"]] for a in alerts]
    assert severities == sorted(severities)


def test_alert_filters(client: TestClient, reviewer: dict[str, str]):
    critical = _open(client, reviewer, "?severity=critical")
    assert critical and all(a["severity"] == "critical" for a in critical)
    overdue = _open(client, reviewer, "?type=matured_overdue")
    assert len(overdue) == 3
    assert all(a["days"] is not None and a["days"] < 0 for a in overdue)


def test_acknowledge_moves_alert_state(client: TestClient, reviewer: dict[str, str]):
    alert = _open(client, reviewer)[0]
    acked = client.post(f"/api/alerts/{alert['id']}/acknowledge", headers=reviewer)
    assert acked.status_code == 200
    body = acked.json()
    assert body["acknowledged_at"] is not None
    assert body["acknowledged_by"] == "Scrutiny Officer"

    open_ids = {a["id"] for a in _open(client, reviewer)}
    assert alert["id"] not in open_ids
    acked_list = client.get("/api/alerts?state=acknowledged", headers=reviewer).json()
    assert alert["id"] in {a["id"] for a in acked_list}


def test_reminder_days_drive_the_alerts(client: TestClient, admin: dict[str, str]):
    before = _open(client, admin, "?type=maturity_upcoming")
    assert before
    assert any(a["days"] > 30 for a in before), "the seed has FDRs due in 31-90 days"

    narrowed = dict(DEFAULT_SETTINGS, reminder_days=[30])
    put = client.put("/api/settings", headers=admin, json=narrowed)
    assert put.status_code == 200
    assert put.json()["reminder_days"] == [30]

    # saving the rules re-runs the engine, so the change shows at once
    after = _open(client, admin, "?type=maturity_upcoming")
    assert 0 < len(after) < len(before)
    assert all(a["days"] <= 30 for a in after)
    resolved = client.get("/api/alerts?state=acknowledged&type=maturity_upcoming", headers=admin).json()
    assert any(a["acknowledged_by"] == "System" for a in resolved)

    restored = client.put("/api/settings", headers=admin, json=DEFAULT_SETTINGS)
    assert restored.status_code == 200
    again = _open(client, admin, "?type=maturity_upcoming")
    assert {a["fdr_id"] for a in again} == {a["fdr_id"] for a in before}

    rerun = client.post("/api/alerts/run", headers=admin).json()
    assert rerun["created"] == 0 and rerun["resolved"] == 0  # engine is idempotent


def test_settings_escalate_after_days_round_trip(client: TestClient, admin: dict[str, str]):
    current = client.get("/api/settings", headers=admin).json()
    assert "escalate_after_days" in current
    assert current["escalate_after_days"] == 3

    payload = dict(current, escalate_after_days=5)
    put = client.put("/api/settings", headers=admin, json=payload)
    assert put.status_code == 200
    assert put.json()["escalate_after_days"] == 5

    fetched = client.get("/api/settings", headers=admin).json()
    assert fetched["escalate_after_days"] == 5

    assert client.put("/api/settings", headers=admin, json=dict(current, escalate_after_days=0)).status_code == 422
    assert client.put("/api/settings", headers=admin, json=dict(current, escalate_after_days=61)).status_code == 422

    client.put("/api/settings", headers=admin, json=dict(current, escalate_after_days=3))


def test_alert_escalation_lifecycle_and_audit(client: TestClient, admin: dict[str, str], reviewer: dict[str, str]):
    from datetime import timedelta
    from app.config import utcnow
    from app.db import SessionLocal
    from app.models import Alert

    client.put("/api/settings", headers=admin, json=dict(DEFAULT_SETTINGS, escalate_after_days=3))

    open_alerts = _open(client, reviewer)
    assert open_alerts
    target_alert_id = open_alerts[0]["id"]

    with SessionLocal() as db:
        a = db.get(Alert, target_alert_id)
        assert a is not None
        a.created_at = utcnow() - timedelta(days=1)
        a.escalated = False
        a.escalated_at = None
        db.commit()

    client.post("/api/alerts/run", headers=admin)
    checked_alert = next(x for x in _open(client, reviewer) if x["id"] == target_alert_id)
    assert checked_alert["escalated"] is False
    assert checked_alert["age_days"] == 1
    assert checked_alert["escalated_at"] is None

    with SessionLocal() as db:
        a = db.get(Alert, target_alert_id)
        assert a is not None
        a.created_at = utcnow() - timedelta(days=4)
        db.commit()

    audit_before = client.get("/api/audit?action=alert.escalated", headers=admin).json()["items"]
    before_count = len(audit_before)

    client.post("/api/alerts/run", headers=admin)
    escalated_item = next(x for x in _open(client, reviewer) if x["id"] == target_alert_id)
    assert escalated_item["escalated"] is True
    assert escalated_item["age_days"] >= 4
    assert escalated_item["escalated_at"] is not None

    audit_after = client.get("/api/audit?action=alert.escalated", headers=admin).json()["items"]
    assert len(audit_after) == before_count + 1
    escalated_audit = next(aud for aud in audit_after if aud["entity_id"] == target_alert_id)
    assert escalated_audit["actor_name"] == "System"
    assert escalated_audit["action_label"] == "Alert escalated"

    # Re-run: audit not duplicated
    client.post("/api/alerts/run", headers=admin)
    audit_again = client.get("/api/audit?action=alert.escalated", headers=admin).json()["items"]
    assert len(audit_again) == len(audit_after)

    dash = client.get("/api/dashboard", headers=admin).json()
    assert dash["kpis"]["escalated_alerts"] >= 1

    alerts_list = _open(client, reviewer)
    by_sev: dict[str, list[dict]] = {}
    for item in alerts_list:
        by_sev.setdefault(item["severity"], []).append(item)
    for items in by_sev.values():
        escalated_flags = [it["escalated"] for it in items]
        assert escalated_flags == sorted(escalated_flags, reverse=True)



def test_escalation_is_recorded_once_even_if_the_rule_changes(
    client: TestClient, admin: dict[str, str], reviewer: dict[str, str]
):
    from datetime import timedelta

    from app.config import utcnow
    from app.db import SessionLocal
    from app.models import Alert

    target_id = _open(client, reviewer)[0]["id"]
    with SessionLocal() as db:
        alert = db.get(Alert, target_id)
        alert.created_at = utcnow() - timedelta(days=5)
        alert.escalated = False
        alert.escalated_at = None
        db.commit()

    def escalations() -> int:
        rows = client.get("/api/audit?action=alert.escalated&page_size=200", headers=admin).json()["items"]
        return sum(1 for r in rows if r["entity_id"] == target_id)

    baseline = escalations()  # an earlier test may already have escalated this alert once
    client.put("/api/settings", headers=admin, json=dict(DEFAULT_SETTINGS, escalate_after_days=3))
    client.post("/api/alerts/run", headers=admin)
    assert escalations() == baseline + 1

    # Raising the threshold must not clear the flag, so lowering it again cannot audit a second time.
    client.put("/api/settings", headers=admin, json=dict(DEFAULT_SETTINGS, escalate_after_days=10))
    still = next(a for a in _open(client, reviewer) if a["id"] == target_id)
    assert still["escalated"] is True
    client.put("/api/settings", headers=admin, json=dict(DEFAULT_SETTINGS, escalate_after_days=3))
    client.post("/api/alerts/run", headers=admin)
    assert escalations() == baseline + 1


def test_settings_without_escalation_field_keep_the_stored_value(client: TestClient, admin: dict[str, str]):
    client.put("/api/settings", headers=admin, json=dict(DEFAULT_SETTINGS, escalate_after_days=6))
    older_client_body = {k: v for k, v in DEFAULT_SETTINGS.items() if k != "escalate_after_days"}
    assert client.put("/api/settings", headers=admin, json=older_client_body).status_code == 200
    assert client.get("/api/settings", headers=admin).json()["escalate_after_days"] == 6
    client.put("/api/settings", headers=admin, json=dict(DEFAULT_SETTINGS, escalate_after_days=3))
