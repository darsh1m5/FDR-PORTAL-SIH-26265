"""Seed-shape assertions that need the untouched demo data.

The suite shares one seeded database per session and other modules create
FDRs and institutions, so every exact-count check lives here and runs first
(pytest collects modules in name order).
"""

import csv
import io

from fastapi.testclient import TestClient


def test_register_totals_and_status_mix(client: TestClient, admin: dict[str, str]):
    body = client.get("/api/fdrs", headers=admin).json()
    assert body["total"] == 44
    counts: dict[str, int] = {}
    for status in ("draft", "pending_approval", "approved", "rejected",
                   "release_requested", "released", "renewed"):
        counts[status] = client.get(f"/api/fdrs?status={status}", headers=admin).json()["total"]
    assert counts == {
        "draft": 4, "pending_approval": 6, "approved": 22, "rejected": 3,
        "release_requested": 3, "released": 3, "renewed": 3,
    }


def test_status_accepts_comma_list(client: TestClient, admin: dict[str, str]):
    body = client.get("/api/fdrs?status=draft,pending_approval", headers=admin).json()
    assert body["total"] == 10


def test_bank_filter(client: TestClient, admin: dict[str, str]):
    body = client.get("/api/fdrs?bank=State Bank of India", headers=admin).json()
    assert body["total"] == 9
    assert all(item["bank_name"] == "State Bank of India" for item in body["items"])


def test_search_matches_number_name_and_aicte_id(client: TestClient, admin: dict[str, str]):
    # the planted duplicate pair shares one receipt number at the same bank
    by_number = client.get("/api/fdrs?q=PNB/2026/00431", headers=admin).json()
    assert by_number["total"] == 2

    by_name = client.get("/api/fdrs?q=Bundelkhand", headers=admin).json()
    assert by_name["total"] == 3
    assert all("Bundelkhand" in item["institution_name"] for item in by_name["items"])

    by_aicte = client.get("/api/fdrs?q=1-4409823115", headers=admin).json()
    assert by_aicte["total"] == 3


def test_institution_filter(client: TestClient, admin: dict[str, str]):
    institutions = client.get("/api/institutions", headers=admin).json()
    short = next(i for i in institutions if i["name"] == "Bundelkhand Skills Polytechnic")
    body = client.get(f"/api/fdrs?institution_id={short['id']}", headers=admin).json()
    assert body["total"] == short["fdr_count"] == 3


def test_maturity_windows_are_cumulative(client: TestClient, admin: dict[str, str]):
    matured = client.get("/api/fdrs?window=matured", headers=admin).json()["total"]
    due_7 = client.get("/api/fdrs?window=due_7", headers=admin).json()["total"]
    due_30 = client.get("/api/fdrs?window=due_30", headers=admin).json()["total"]
    due_90 = client.get("/api/fdrs?window=due_90", headers=admin).json()["total"]
    assert (matured, due_7, due_30, due_90) == (3, 4, 9, 15)
    assert due_7 <= due_30 <= due_90


def test_pagination(client: TestClient, admin: dict[str, str]):
    page = client.get("/api/fdrs?page=2&page_size=10", headers=admin).json()
    assert page["page"] == 2 and page["page_size"] == 10
    assert len(page["items"]) == 10 and page["total"] == 44
    first_page = client.get("/api/fdrs?page=1&page_size=10", headers=admin).json()["items"]
    assert page["items"][0]["id"] != first_page[0]["id"]


def test_csv_export_headers_and_rows(client: TestClient, admin: dict[str, str]):
    response = client.get("/api/fdrs/export.csv", headers=admin)
    assert response.status_code == 200
    assert "text/csv" in response.headers["content-type"]
    raw = response.content
    assert raw[:3] == b"\xef\xbb\xbf"  # UTF-8 BOM for Excel

    text = raw.decode("utf-8-sig")
    rows = list(csv.reader(io.StringIO(text)))
    assert rows[0][:4] == ["FDR number", "Institution", "AICTE ID", "Bank"]
    assert len(rows) == 45  # header + 44 FDRs


def test_csv_export_respects_filters(client: TestClient, admin: dict[str, str]):
    response = client.get("/api/fdrs/export.csv?status=draft", headers=admin)
    rows = list(csv.reader(io.StringIO(response.content.decode("utf-8-sig"))))
    assert len(rows) == 5  # header + 4 drafts


def test_seed_shape_is_stable(client: TestClient, admin: dict[str, str]):
    institutions = client.get("/api/institutions", headers=admin).json()
    assert len(institutions) == 14
    assert all(i["fdr_count"] > 0 for i in institutions)

    states = {i["state"] for i in institutions}
    assert {"Maharashtra", "Karnataka", "Tamil Nadu", "Uttar Pradesh", "Telangana",
            "Gujarat", "Rajasthan", "Madhya Pradesh", "West Bengal", "Kerala"} <= states
