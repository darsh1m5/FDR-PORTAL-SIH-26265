"""Audit trail: listing, filters, and the tamper-evident hash chain."""

from fastapi.testclient import TestClient


def test_verify_reports_intact(client: TestClient, admin: dict[str, str]):
    body = client.get("/api/audit/verify", headers=admin).json()
    assert body["intact"] is True
    assert body["broken_at"] is None
    assert body["checked"] >= 180  # 14 institutions + full FDR histories


def test_institutions_were_registered_in_the_audit(client: TestClient, admin: dict[str, str]):
    rows = client.get("/api/audit?action=institution.created&page_size=50", headers=admin).json()
    assert rows["total"] == 14


def test_fdr_history_is_newest_first(client: TestClient, admin: dict[str, str]):
    renewed = client.get("/api/fdrs?status=renewed", headers=admin).json()["items"][0]
    detail = client.get(f"/api/fdrs/{renewed['id']}", headers=admin).json()
    actions = [row["action"] for row in detail["history"] if row["action"].startswith("fdr.")]
    assert actions == ["fdr.renewed", "fdr.verified", "fdr.approved", "fdr.submitted", "fdr.created"]
    assert all(row["fdr_number"] == renewed["fdr_number"] for row in detail["history"])
    assert detail["history"][0]["detail"]["renewed_to"]["fdr_number"]


def test_audit_list_shows_actor_and_label(client: TestClient, admin: dict[str, str]):
    rows = client.get("/api/audit?action=fdr.approved&page_size=5", headers=admin).json()["items"]
    assert rows
    for row in rows:
        assert row["actor_name"] == "Scrutiny Officer"
        assert row["actor_role"] == "reviewer"
        assert row["action_label"] == "Approved"
        assert row["from_status"] == "pending_approval"
        assert row["to_status"] == "approved"


def test_tampering_breaks_the_chain_at_that_row(client: TestClient, admin: dict[str, str]):
    from sqlalchemy import orm

    from app.db import SessionLocal
    from app.models import AuditLog

    db = SessionLocal()
    row = db.query(AuditLog).order_by(AuditLog.id).offset(4).limit(1).first()
    assert row is not None
    original = row.detail
    with orm.sessionmaker(bind=db.bind)() as writer:
        target = writer.get(AuditLog, row.id)
        target.detail = {"tampered": True}
        writer.commit()
    db.expire_all()

    report = client.get("/api/audit/verify", headers=admin).json()
    assert report["intact"] is False
    assert report["broken_at"] == row.id

    with orm.sessionmaker(bind=db.bind)() as writer:
        target = writer.get(AuditLog, row.id)
        target.detail = original
        writer.commit()
    db.expire_all()

    restored = client.get("/api/audit/verify", headers=admin).json()
    assert restored["intact"] is True
    db.close()
