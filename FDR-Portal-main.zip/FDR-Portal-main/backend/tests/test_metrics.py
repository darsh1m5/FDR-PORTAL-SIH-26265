"""Tests for 9.7 Bureau performance metrics (GET /metrics)."""

import re
from datetime import timedelta
from fastapi.testclient import TestClient

from app.audit import write_audit
from app.config import utcnow
from app.db import SessionLocal
from app.models import AuditEntity, Fdr, FdrStatus, Role, User


def test_metrics_shape_and_ranges(client: TestClient, admin: dict[str, str], reviewer: dict[str, str]):
    res = client.get("/api/metrics", headers=admin)
    assert res.status_code == 200, res.text
    data = res.json()

    # Rate ranges (0 - 100)
    for key in ("verification_rate", "document_coverage", "data_quality_rate"):
        assert 0.0 <= data[key] <= 100.0, f"{key} out of range: {data[key]}"

    if data["renewal_on_time_rate"] is not None:
        assert 0.0 <= data["renewal_on_time_rate"] <= 100.0

    # Non-negative day/hour counts
    if data["approval_turnaround_days"] is not None:
        assert data["approval_turnaround_days"] >= 0.0
    if data["release_turnaround_days"] is not None:
        assert data["release_turnaround_days"] >= 0.0
    if data["alert_ack_median_hours"] is not None:
        assert data["alert_ack_median_hours"] >= 0.0

    assert data["pending_over_sla"] >= 0

    # Monthly array: exactly 6 months
    monthly = data["monthly"]
    assert len(monthly) == 6
    month_regex = re.compile(r"^\d{4}-\d{2}$")
    for m in monthly:
        assert month_regex.match(m["month"])
        assert m["decided"] >= 0
        if m["avg_turnaround_days"] is not None:
            assert m["avg_turnaround_days"] >= 0.0

    # Reviewer can also view metrics
    rev_res = client.get("/api/metrics", headers=reviewer)
    assert rev_res.status_code == 200


def test_metrics_known_turnaround_from_planted_audit_pair(client: TestClient, admin: dict[str, str]):
    now = utcnow()
    t_submit = now - timedelta(days=20)
    t_approve = t_submit + timedelta(days=4)  # Exactly 4.0 days turnaround

    month_key = t_approve.strftime("%Y-%m")

    # Get baseline for this month
    baseline = client.get("/api/metrics", headers=admin).json()
    month_entry_before = next(m for m in baseline["monthly"] if m["month"] == month_key)
    decided_before = month_entry_before["decided"]

    # Plant a pair of audit rows with an existing or new FDR
    with SessionLocal() as db:
        user = db.query(User).filter_by(role=Role.admin).first()
        fdr = db.query(Fdr).first()
        assert fdr is not None and user is not None

        # Plant submission
        write_audit(
            db,
            actor=user,
            action="fdr.submitted",
            entity=AuditEntity.fdr,
            entity_id=fdr.id,
            fdr_id=fdr.id,
            from_status=FdrStatus.draft.value,
            to_status=FdrStatus.pending_approval.value,
            at=t_submit,
        )
        # Plant approval exactly 4.0 days later
        write_audit(
            db,
            actor=user,
            action="fdr.approved",
            entity=AuditEntity.fdr,
            entity_id=fdr.id,
            fdr_id=fdr.id,
            from_status=FdrStatus.pending_approval.value,
            to_status=FdrStatus.approved.value,
            at=t_approve,
        )
        db.commit()

    after = client.get("/api/metrics", headers=admin).json()
    month_entry_after = next(m for m in after["monthly"] if m["month"] == month_key)
    assert month_entry_after["decided"] == decided_before + 1
    assert month_entry_after["avg_turnaround_days"] is not None
    assert after["approval_turnaround_days"] is not None


def test_verification_in_between_does_not_restart_the_turnaround_clock(client: TestClient, admin: dict[str, str]):
    before = client.get("/api/metrics", headers=admin).json()["approval_turnaround_days"]
    now = utcnow()
    t_submit = now - timedelta(days=100)
    with SessionLocal() as db:
        user = db.query(User).filter_by(role=Role.admin).first()
        fdr = db.query(Fdr).first()
        common = dict(actor=user, entity=AuditEntity.fdr, entity_id=fdr.id, fdr_id=fdr.id)
        write_audit(db, action="fdr.submitted", from_status=FdrStatus.draft.value,
                    to_status=FdrStatus.pending_approval.value, at=t_submit, **common)
        # A verification keeps the status: pending_approval -> pending_approval.
        write_audit(db, action="fdr.verified", from_status=FdrStatus.pending_approval.value,
                    to_status=FdrStatus.pending_approval.value, at=t_submit + timedelta(days=59), **common)
        write_audit(db, action="fdr.approved", from_status=FdrStatus.pending_approval.value,
                    to_status=FdrStatus.approved.value, at=t_submit + timedelta(days=60), **common)
        db.commit()
    after = client.get("/api/metrics", headers=admin).json()["approval_turnaround_days"]
    # A 60-day decision raises the average; the old bug counted it as 1 day and lowered it.
    assert before is not None and after > before


def test_institution_scoped_metrics(client: TestClient, admin: dict[str, str]):
    res = client.post("/api/auth/login", json={"email": "deccan.crest@fdrportal.demo", "password": "Inst@2026"})
    assert res.status_code == 200, res.text
    token = res.json()["access_token"]
    inst_headers = {"Authorization": f"Bearer {token}"}

    inst_metrics = client.get("/api/metrics", headers=inst_headers).json()
    bureau_metrics = client.get("/api/metrics", headers=admin).json()

    inst_decided_total = sum(item["decided"] for item in inst_metrics["monthly"])
    bureau_decided_total = sum(item["decided"] for item in bureau_metrics["monthly"])
    assert inst_decided_total <= bureau_decided_total

